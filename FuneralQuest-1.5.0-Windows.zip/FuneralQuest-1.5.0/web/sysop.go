package web

import (
	"crypto/rand"
	"crypto/subtle"
	"encoding/json"
	"errors"
	"log"
	"net/http"
	"net/netip"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"funeralquest/admin"
	"funeralquest/engine"
	"funeralquest/fqnet"
	"funeralquest/guard"
)

// Sysop sessions use a random bearer token kept in the browser tab (sessionStorage), never a
// cookie, so other web sites can't make a sysop's browser do anything (no CSRF). They end
// after 30 idle minutes, after 8 hours, or when the sysop password changes.
type sysopSess struct {
	ip      string
	created time.Time
	seen    time.Time
}

func (s *sysopSess) expired(pwChanged time.Time) bool {
	return time.Since(s.seen) > 30*time.Minute || time.Since(s.created) > 8*time.Hour || pwChanged.After(s.created)
}

// sysopAllowed checks the "sysop pages allowed from" setting.
func (srv *Server) sysopAllowed(r *http.Request) bool {
	allow := strings.TrimSpace(srv.A.Config().SysopAllow)
	if allow == "" {
		return true
	}
	list, _ := guard.ParsePrefixes(strings.ReplaceAll(allow, ",", "\n"))
	a, err := guard.ParseIP(srv.clientIP(r))
	if err != nil {
		return false
	}
	for _, p := range list {
		if p.Contains(a) {
			return true
		}
	}
	return false
}

type sysopHandler func(r *http.Request, body map[string]any) (any, error)

func str(b map[string]any, k string) string {
	switch v := b[k].(type) {
	case string:
		return v
	case float64:
		return strconv.FormatFloat(v, 'f', -1, 64)
	case bool:
		return strconv.FormatBool(v)
	}
	return ""
}

func (srv *Server) sysopRoutes(mux *http.ServeMux) {
	a := srv.A
	handle := func(pattern string, needAuth bool, fn sysopHandler) {
		mux.HandleFunc(pattern, func(w http.ResponseWriter, r *http.Request) {
			ip := srv.clientIP(r)
			if !srv.sysopAllowed(r) {
				http.NotFound(w, r)
				return
			}
			if !a.SysopPasswordSet() && pattern != "POST /api/sysop/setup" && pattern != "GET /api/sysop/setup" {
				w.WriteHeader(http.StatusServiceUnavailable)
				send(w, map[string]any{"error": "No admin password has been set yet.", "setup": true})
				return
			}
			if needAuth && !srv.sysopAuth(r, ip) {
				w.WriteHeader(http.StatusUnauthorized)
				send(w, map[string]any{"error": "Please log on.", "auth": true})
				return
			}
			body := map[string]any{}
			if r.Method == http.MethodPost {
				if !strings.HasPrefix(r.Header.Get("Content-Type"), "application/json") {
					w.WriteHeader(415)
					send(w, errJSON(errors.New("bad request")))
					return
				}
				r.Body = http.MaxBytesReader(w, r.Body, 2<<20)
				if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
					w.WriteHeader(400)
					send(w, errJSON(errors.New("bad request")))
					return
				}
			}
			out, err := fn(r, body)
			if err != nil {
				send(w, errJSON(err))
				return
			}
			if r.Method == http.MethodPost && needAuth {
				srv.secLog("sysop %s: %s", ip, r.URL.Path)
			}
			if out == nil {
				out = map[string]any{"ok": true}
			}
			send(w, out)
		})
	}

	// First-time setup: with no admin password yet, the web server makes a one-time setup code
	// and shows it only on the server (console, server.log and data/sysop-setup-code.txt).
	// Whoever has the code can choose the admin password, once.
	handle("GET /api/sysop/setup", false, func(r *http.Request, b map[string]any) (any, error) {
		return map[string]any{"needed": !a.SysopPasswordSet()}, nil
	})
	handle("POST /api/sysop/setup", false, func(r *http.Request, b map[string]any) (any, error) {
		ip := srv.clientIP(r)
		if a.SysopPasswordSet() {
			return nil, errors.New("The admin password is already set. Log on instead.")
		}
		if !srv.sysopTry.allow(ip) {
			a.Guard.Strike(ip, "too many setup tries", 1)
			return nil, errors.New("Too many tries. Wait a minute.")
		}
		code := srv.setupCode()
		if subtle.ConstantTimeCompare([]byte(strings.ToUpper(strings.TrimSpace(str(b, "code")))), []byte(code)) != 1 {
			srv.secLog("wrong admin setup code from %s", ip)
			a.Guard.Strike(ip, "wrong admin setup code", 1)
			return nil, errors.New("That setup code is wrong. It's in the web server's window, in data\\server.log and in data\\sysop-setup-code.txt on the server.")
		}
		if err := a.SetSysopPassword(str(b, "password")); err != nil {
			return nil, err
		}
		srv.clearSetupCode()
		srv.secLog("admin password set up from the web by %s", ip)
		tok := newToken()
		srv.mu.Lock()
		srv.sysop[tok] = &sysopSess{ip: ip, created: time.Now().Add(time.Second), seen: time.Now()}
		srv.mu.Unlock()
		return map[string]any{"token": tok}, nil
	})
	handle("POST /api/sysop/disable", true, func(r *http.Request, b map[string]any) (any, error) {
		if !a.CheckSysopPassword(str(b, "password")) {
			return nil, errors.New("Your password is wrong.")
		}
		srv.secLog("admin pages turned off from the web by %s", srv.clientIP(r))
		return nil, a.DisableSysopPassword()
	})
	handle("POST /api/sysop/login", false, func(r *http.Request, b map[string]any) (any, error) {
		ip := srv.clientIP(r)
		if !srv.sysopTry.allow(ip) {
			a.Guard.Strike(ip, "too many sysop log-on tries", 1)
			return nil, errors.New("Too many tries. Wait a minute.")
		}
		pw := str(b, "password")
		if len(pw) > 200 || !a.CheckSysopPassword(pw) {
			srv.secLog("FAILED sysop log-on from %s", ip)
			if a.Guard.Strike(ip, "failed sysop log-ons", 1) {
				srv.secLog("banned %s: failed sysop log-ons", ip)
			}
			time.Sleep(time.Second)
			return nil, errors.New("Wrong password.")
		}
		tok := newToken()
		srv.mu.Lock()
		srv.sysop[tok] = &sysopSess{ip: ip, created: time.Now(), seen: time.Now()}
		srv.mu.Unlock()
		srv.secLog("sysop logged on from %s", ip)
		return map[string]any{"token": tok}, nil
	})
	handle("POST /api/sysop/logout", true, func(r *http.Request, b map[string]any) (any, error) {
		srv.mu.Lock()
		delete(srv.sysop, bearer(r))
		srv.mu.Unlock()
		return nil, nil
	})
	handle("POST /api/sysop/password", true, func(r *http.Request, b map[string]any) (any, error) {
		if !a.CheckSysopPassword(str(b, "old")) {
			return nil, errors.New("Your current password is wrong.")
		}
		if err := a.SetSysopPassword(str(b, "new")); err != nil {
			return nil, err
		}
		// every session (this one too) ends; log on again with the new password
		return map[string]any{"ok": true, "relogin": true}, nil
	})
	handle("GET /api/sysop/status", true, func(r *http.Request, b map[string]any) (any, error) {
		return a.Status(), nil
	})

	// settings
	handle("GET /api/sysop/settings", true, func(r *http.Request, b map[string]any) (any, error) {
		c := a.Config()
		type row struct {
			engine.SettingInfo
			Value string `json:"value"`
		}
		var rows []row
		for _, s := range engine.Settings {
			rows = append(rows, row{s, c.Get(s.Key)})
		}
		return map[string]any{"settings": rows}, nil
	})
	handle("POST /api/sysop/settings", true, func(r *http.Request, b map[string]any) (any, error) {
		vals, _ := b["values"].(map[string]any)
		kv := map[string]string{}
		for k := range vals {
			kv[k] = str(vals, k)
		}
		return nil, a.SetSettings(kv)
	})

	// text files
	handle("GET /api/sysop/texts", true, func(r *http.Request, b map[string]any) (any, error) {
		return map[string]any{"texts": admin.Texts}, nil
	})
	handle("GET /api/sysop/text", true, func(r *http.Request, b map[string]any) (any, error) {
		t, err := a.ReadText(r.URL.Query().Get("key"))
		return map[string]any{"content": t}, err
	})
	handle("POST /api/sysop/text", true, func(r *http.Request, b map[string]any) (any, error) {
		return nil, a.WriteText(str(b, "key"), str(b, "content"))
	})

	// players
	handle("GET /api/sysop/players", true, func(r *http.Request, b map[string]any) (any, error) {
		return map[string]any{"players": a.Players(), "fields": admin.PlayerFields}, nil
	})
	handle("GET /api/sysop/player", true, func(r *http.Request, b map[string]any) (any, error) {
		id, _ := strconv.Atoi(r.URL.Query().Get("id"))
		p, err := a.Player(id)
		return map[string]any{"player": p}, err
	})
	handle("POST /api/sysop/player", true, func(r *http.Request, b map[string]any) (any, error) {
		id, _ := strconv.Atoi(str(b, "id"))
		vals, _ := b["values"].(map[string]any)
		kv := map[string]string{}
		for k := range vals {
			kv[k] = str(vals, k)
		}
		return nil, a.UpdatePlayer(id, kv)
	})
	handle("POST /api/sysop/player/password", true, func(r *http.Request, b map[string]any) (any, error) {
		id, _ := strconv.Atoi(str(b, "id"))
		return nil, a.SetPlayerPassword(id, str(b, "password"))
	})
	handle("POST /api/sysop/player/delete", true, func(r *http.Request, b map[string]any) (any, error) {
		id, _ := strconv.Atoi(str(b, "id"))
		return nil, a.DeletePlayer(id)
	})

	// game
	handle("POST /api/sysop/news", true, func(r *http.Request, b map[string]any) (any, error) {
		return nil, a.PostNews(str(b, "text"))
	})
	handle("POST /api/sysop/maint", true, func(r *http.Request, b map[string]any) (any, error) {
		day, err := a.Maint()
		return map[string]any{"day": day}, err
	})
	handle("POST /api/sysop/reset", true, func(r *http.Request, b map[string]any) (any, error) {
		if str(b, "confirm") != "RESET" {
			return nil, errors.New("type RESET to confirm")
		}
		return nil, a.Reset(str(b, "wipe") == "true")
	})

	// security
	handle("GET /api/sysop/bans", true, func(r *http.Request, b map[string]any) (any, error) {
		return map[string]any{"bans": a.Guard.Bans(), "me": srv.clientIP(r)}, nil
	})
	handle("POST /api/sysop/ban", true, func(r *http.Request, b map[string]any) (any, error) {
		ip := strings.TrimSpace(str(b, "ip"))
		if _, err := netip.ParseAddr(ip); err != nil {
			return nil, errors.New("that isn't an IP address")
		}
		if ip == srv.clientIP(r) {
			return nil, errors.New("that's your own address")
		}
		mins, _ := strconv.Atoi(str(b, "minutes"))
		if mins <= 0 {
			mins = 60
		}
		reason := engine.CleanRemote(str(b, "reason"), 80, false)
		if reason == "" {
			reason = "banned by sysop"
		}
		a.Guard.Ban(ip, reason, time.Duration(mins)*time.Minute)
		return nil, nil
	})
	handle("POST /api/sysop/unban", true, func(r *http.Request, b map[string]any) (any, error) {
		if !a.Guard.Unban(str(b, "ip")) {
			return nil, errors.New("that address isn't banned")
		}
		return nil, nil
	})

	// network
	handle("GET /api/sysop/network", true, func(r *http.Request, b map[string]any) (any, error) {
		c := a.Config()
		return map[string]any{"id": a.Net.ID, "fingerprint": fqnet.Fingerprint(a.Net.ID), "public_url": fqnet.AdvertisedURL(c),
			"net_port": c.NetPort, "port_only": c.NetPortOnly, "port_https": c.NetPortHTTPS,
			"auto_accept": c.NetAutoAccept, "version": engine.Version, "peers": peerRows(a.Net, c), "queued": a.Net.QueuedMail(),
			"votes": voteRows(a.Net, c), "vote_apply": !c.NetVoteApplyOff, "intros": a.Net.Intros(), "intro_off": c.NetIntroOff}, nil
	})
	handle("POST /api/sysop/network", true, func(r *http.Request, b map[string]any) (any, error) {
		id := str(b, "id")
		switch str(b, "action") {
		case "add":
			p, err := a.Net.AddPeer(str(b, "url"))
			if err != nil {
				return nil, err
			}
			return map[string]any{"peer": p, "fingerprint": fqnet.Fingerprint(p.ID)}, nil
		case "accept":
			return nil, a.Net.Accept(id)
		case "remove":
			return nil, a.Net.Remove(id)
		case "block":
			return nil, a.Net.Block(id)
		case "sync":
			return nil, a.Net.SyncPeer(id)
		case "use_theirs":
			var keys []string
			if k := str(b, "key"); k != "" {
				keys = []string{k}
			}
			return nil, a.Net.UseTheirs(a, id, keys)
		case "propose":
			p, err := a.Net.Propose()
			if err != nil {
				return nil, err
			}
			return map[string]any{"voters": len(p.Voters)}, nil
		case "vote":
			return nil, a.Net.CastVote(id, str(b, "yes") == "true")
		case "port_only":
			return nil, a.SetSettings(map[string]string{"net_port_only": str(b, "on")})
		case "auto_accept":
			return nil, a.SetSettings(map[string]string{"net_auto_accept": str(b, "on")})
		}
		return nil, errors.New("unknown action")
	})

	// HTTPS certificate
	handle("GET /api/sysop/cert", true, func(r *http.Request, b map[string]any) (any, error) {
		return map[string]any{"cert": a.Cert(), "hosts": strings.Join(a.CertHosts(), ", "), "serving_https": srv.Opt.TLS}, nil
	})
	handle("POST /api/sysop/cert", true, func(r *http.Request, b map[string]any) (any, error) {
		switch str(b, "action") {
		case "make":
			var hosts []string
			for _, h := range strings.Split(str(b, "hosts"), ",") {
				if h = strings.TrimSpace(h); h != "" {
					hosts = append(hosts, h)
				}
			}
			info, err := a.MakeSelfSignedCert(hosts)
			if err != nil {
				return nil, err
			}
			srv.secLog("self-signed certificate made from the web by %s (%s)", srv.clientIP(r), info.Fingerprint)
			return map[string]any{"cert": info}, nil
		case "off":
			return nil, a.TurnOffHTTPS()
		}
		return nil, errors.New("unknown action")
	})

	// logs
	handle("GET /api/sysop/log", true, func(r *http.Request, b map[string]any) (any, error) {
		t, err := a.TailLog(r.URL.Query().Get("name"), 400)
		return map[string]any{"text": t, "logs": admin.Logs}, err
	})
}

type peerRow struct {
	fqnet.Peer
	Fingerprint string       `json:"fingerprint"`
	VersionNote string       `json:"version_note"`
	Reach       string       `json:"reach"` // "" = two-way; otherwise why it can't be fully connected
	Diffs       []fqnet.Diff `json:"diffs"`
}

func peerRows(n *fqnet.Net, c engine.Config) []peerRow {
	var out []peerRow
	for _, p := range n.Peers() {
		r := peerRow{Peer: p, Fingerprint: fqnet.Fingerprint(p.ID)}
		if p.State == fqnet.Linked {
			r.VersionNote, r.Diffs, r.Reach = fqnet.VersionNote(p), fqnet.RuleDiffs(c, p), fqnet.Reach(p)
		}
		out = append(out, r)
	}
	return out
}

func bearer(r *http.Request) string {
	h := r.Header.Get("Authorization")
	if t, ok := strings.CutPrefix(h, "Bearer "); ok {
		return strings.TrimSpace(t)
	}
	return ""
}

func (srv *Server) sysopAuth(r *http.Request, ip string) bool {
	tok := bearer(r)
	if len(tok) != 64 {
		return false
	}
	changed := srv.A.SysopPasswordChanged()
	srv.mu.Lock()
	defer srv.mu.Unlock()
	for t, s := range srv.sysop {
		if subtle.ConstantTimeCompare([]byte(t), []byte(tok)) == 1 {
			if s.expired(changed) || s.ip != ip {
				delete(srv.sysop, t)
				return false
			}
			s.seen = time.Now()
			return true
		}
	}
	return false
}

type voteRow struct {
	fqnet.Proposal
	Mine    bool         `json:"mine"`
	Summary string       `json:"summary"`
	Yes     int          `json:"yes"`
	No      int          `json:"no"`
	Total   int          `json:"total"`
	Diffs   []fqnet.Diff `json:"diffs"`
}

func voteRows(n *fqnet.Net, c engine.Config) []voteRow {
	var out []voteRow
	for _, p := range n.Proposals() {
		y, no, t := fqnet.Tally(p)
		r := voteRow{Proposal: p, Mine: p.From == n.ID, Summary: fqnet.VoteSummary(n.ID, p), Yes: y, No: no, Total: t}
		r.Diffs = fqnet.RuleDiffs(c, fqnet.Peer{Rules: p.Rules})
		out = append(out, r)
	}
	return out
}

// setupCode returns the current one-time admin setup code, making one if needed.
func (srv *Server) setupCode() string {
	srv.mu.Lock()
	defer srv.mu.Unlock()
	if srv.setup == "" {
		const letters = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
		b := make([]byte, 12)
		rand.Read(b)
		for i := range b {
			b[i] = letters[int(b[i])%len(letters)]
		}
		srv.setup = string(b[:4]) + "-" + string(b[4:8]) + "-" + string(b[8:])
		p := filepath.Join(srv.A.Home, "data", "sysop-setup-code.txt")
		os.WriteFile(p, []byte("Funeral Quest admin setup code: "+srv.setup+"\r\nOpen /sysop/ in a browser and enter it to choose the admin password.\r\nThis file is deleted once the password is set.\r\n"), 0o600)
		log.Printf("ADMIN SETUP CODE: %s   (open /sysop/ in a browser and enter it to choose the admin password)", srv.setup)
	}
	return srv.setup
}

func (srv *Server) clearSetupCode() {
	srv.mu.Lock()
	srv.setup = ""
	srv.mu.Unlock()
	os.Remove(filepath.Join(srv.A.Home, "data", "sysop-setup-code.txt"))
}

// PrepareSetup makes the setup code at start-up when no admin password is set.
func (srv *Server) PrepareSetup() {
	if !srv.A.SysopPasswordSet() {
		srv.setupCode()
	} else {
		srv.clearSetupCode()
	}
}

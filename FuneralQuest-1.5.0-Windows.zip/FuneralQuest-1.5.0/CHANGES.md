# Changes

Releases are numbered major.minor.patch. `fq version` (or `fqedit --version`) shows which one you have, and linked towns compare versions automatically.

## 1.5.0 (2026-11-26)

Windows and Linux builds, and a source archive. (macOS and BSD: build from the source with ./build.sh.)

* **Towns that can't be reached can be raided.** An outbound-only town now fetches raid steps from the towns it links to, keeping a waiting request open, the same way it gets chat. When someone breaks in, picks a lock, steals, fights or sets a fire there, the step reaches it within a fraction of a second. It referees the step with its own rules on its own player and sends the result back. Outbound-only towns are now full members of the network while they're online; they're only marked "outbound only and not online right now" when their server is off.
* **A wrong web address no longer breaks a link.** Every town now fetches its raid steps (not only towns with no address), so a town whose address doesn't work from somewhere still gets chat, letters, rankings and raids there. The Network tab says which address isn't working and what to check.
* **A separate network port with the web server.** `fq web` now opens the **Network port** setting too (before, only `fq telnet`/`fq net` did). It's a port just for other Funeral Quest servers, so towns whose web game sits behind Caddy or another proxy can link without routing the network through it.
  * **"Linked servers use the network port only"** (a setting, a checkbox on the Network tab, and a switch in fqedit). The address given to other towns switches to the network port by itself, the web port stops answering other servers, and linked towns are told the new address.
  * **"HTTPS on the network port"**: the certificate is optional there. The default is plain HTTP (messages are signed either way); turn it on to use the town's certificate.
* **The web game and admin pages work in a folder** behind a proxy, e.g. `https://example.com/funeralquest/` with Caddy's `handle_path`. Linking to a town at such an address (with or without the trailing slash) works for syncing, real-time chat and raids. The README has Caddyfile examples.
* **Introductions only pass on addresses that work.** A town only introduces towns it has actually reached in the last 30 minutes, so a mistyped or unreachable address isn't spread around the network.

## 1.4.0 (2026-11-26)

Windows and Linux builds. (macOS and BSD: build from the included source with ./build.sh, or use 1.3.0.)

* **Introductions: the network fills itself in.** Linked towns tell each other which other towns they're linked to. When you link to one town in a network, your town sends link requests to the rest. Towns that follow introductions (the normal setting) accept each other by themselves, so every town ends up linked to every other with nobody clicking anything.
  * Linking checks that each introduced town answers with exactly the ID it was introduced with, so a lying introducer can't send you to an impostor.
  * A town you removed or blocked is never brought back by an introduction.
  * New settings: "Don't follow introductions", "Don't introduce my links", and "Accept introduced towns automatically" (for towns that connect out only).
  * Link requests show which linked town introduced them. Introductions waiting to be followed are listed on the Network tab and in `fq admin links`.

The 1.3.1 fixes below were never released on their own; they're part of 1.4.0.

## 1.3.1 (folded into 1.4.0)

* **Fixed: linking to a town that uses HTTPS** (for example with a self-signed certificate) failed with "bad answer from the other server" unless you typed `https://` in front of its address. Without `http://` or `https://`, the game now tries both.
* **Fixed: a town showed as "not reachable / outbound only"** even though your server was reaching it fine, when that town hadn't set its own web address. A town you can reach is now always shown as reachable, and its players can be raided. (Its sysop should still set **This server's web address** so the towns can reach each other in both directions.)
* The admin Status tab warns when this server is linked but its web address isn't set.
* The "Request came from ..." note no longer stays on towns that were accepted (automatically or by hand).
* **Sturdier network answers.** Every answer between towns now has an exact length (no chunked encoding, which some proxies, firewalls and antivirus web filters break). An answer whose connection drops right after it's complete is accepted when its signature checks out.
* **`fq admin test-link <address>`** checks the way to another town step by step (name lookup, port, Funeral Quest ID, sending a message) and says what's wrong.
* Linking: clearer messages when linking fails. Before linking, the game checks that the address really is a Funeral Quest server. If it isn't, the message shows what answered instead and how to check the address. An answer cut off by a proxy, firewall or antivirus web filter is reported as such, instead of "bad answer from the other server".

## 1.3.0 (2026-11-26)

* **Real-time network chat.** Every linked server keeps a "listen" request open on each of its links, so a line said in one town's Cafe shows up in the others in well under a second (about 0.1 s in testing). It works even when only one side can reach the other. Chat inside a town is real time too: door callers see new lines within a quarter second, and the web page gets them the moment they're said.
* **Version check.** Linked towns exchange their game versions and tell both sysops who's behind and needs to update ("Gravesend runs an older version (1.2.0, you have 1.3.0). Gravesend's sysop needs to update.").
* **Game settings check.** Linked towns exchange their game rules (turns, starting stats, scoring, odds and limits) in every signed handshake. Each sysop sees which settings differ, with "here" and "there" values, and can copy the other town's values one at a time or all at once. You'll find it on the web sysop pages (Status and Network tabs), in fqedit, with `fq admin links`, and in the server log.
* **Settings votes.** A sysop can propose their town's game settings to every linked town. Each other sysop is asked to accept the settings from that town. When more than half of all the towns in the vote agree (the proposing town counts as a yes), every town switches to them. Votes are signed by each town, and every town checks the signatures itself before applying a result. A town can opt out with "Don't apply settings votes". Votes end after 7 days.
* **Auto-accept for links** has its own switch on the web sysop Network tab (it was already a setting, and in fqedit).
* `fq version`, `fq admin propose`, `fq admin votes`, `fq admin vote`, `fq admin use-theirs`.
* **Web admin, complete.**
  * Every setting is on the web admin Settings tab, including the new **Server** group: ports, listen address, HTTPS certificate and key, proxy, and sound. These used to be command-line switches only; the switches still work and override the settings.
  * The game's log-on page has an **Admin** link.
  * First-time admin setup works in the browser with a one-time setup code that only appears on the server.
  * The Status tab shows who's playing.
  * The admin pages can be turned off from the web.
* **Linking without the web server.**
  * `fq telnet` now runs the network link too, and can open a network-only port (`net_port`) for other towns. For BBSes that only run the door, the new `fq net` runs just the network.
  * Towns with no open port at all can link **outbound only**. They get chat, rankings, letters, votes and version and settings checks by connecting out. Other towns list them as "outbound only", and their players can't be raided from other towns.
  * Only one program per town does the network work at a time; the others stand by.
* **RLogin.** Built on the rlogin kit's methods.
  * A BBS can send callers in over RLogin with a gateway secret: Synchronet `rlogin_gate`, Mystic `IR`, or any BBS with outbound RLogin. Players can also connect straight from SyncTERM with their own logon and password.
  * The swapped name/password fields (Synchronet, SyncTERM "RLogin"/"RLogin Reversed", Mystic) are handled by value, so either order works.
  * Only trusted hosts may connect, a name alone is never trusted, and failed log-ons count toward the game's bans.
  * Gateway callers are the same players as door callers from that BBS.
  * It runs in `fq telnet`, or on its own with `fq rlogin`. Setup files are in `extras/rlogin/`.
* **Self-signed HTTPS certificate.** One click on the web admin Security tab, in fqedit, or `fq admin make-cert`. The web address switches to https by itself, and linked towns are told.
* **HTTPS between towns.** Linked servers accept a self-signed certificate the first time and then pin it, refusing a different one later.
* Web game: one request at a time per player session (two fast clicks could step on each other before).

## 1.2.0 (2026-11-25)

* **Raids between linked towns.** Players can break into parlors in other towns, pick their padlocks, steal tags, fight the owner and hire the Twins to burn them out. The defender's own server referees with the normal rules, so linked servers still never change each other's players directly. Both ends cap what the other claims, each player can be raided from out of town at most 3 times a day, and sysops can turn it off (`net_raids_off`).
* **Builds for every system.**
  * Windows: 64-bit, 32-bit and ARM.
  * Linux: x86-64, 32-bit, ARM64 and Raspberry Pi.
  * macOS: Apple Silicon and Intel.
  * FreeBSD (x86-64 and ARM64), OpenBSD and NetBSD.

  fqedit now runs on macOS and the BSDs too. The downloads are split by system.

## 1.1.0 (2026-11-25)

* **fqedit**, a separate full-screen sysop editor (Windows 32/64-bit and Linux). It edits settings, players, game texts, news, maintenance, security, network links, the web sysop password and the logs.
* **Web sysop pages** at `/sysop/`: the same tools in a browser, behind a sysop password.
* **Security**: block lists for IP addresses and host names (`data\blocklist_ip.txt`, `data\blocklist_hosts.txt`) and a never-block list. Automatic temporary bans for telnet attack bots, failed log-ons and connection floods, getting longer each time. The web server is hardened (CSP and security headers, rate limits, timeouts, no directory listings, constant-time log-on, built-in HTTPS, CSRF-proof sysop sessions).
* **Funeral Quest network**: link your town to other servers by address and port. Linked towns share Cafe chat, network rankings and letters. Messages are signed with Ed25519, and linked servers can't change anything on yours.
* Game texts and settings changes take effect in running servers within seconds, without a restart.
* Fixed: "thrown by a house" now says "thrown by a horse".
* Fixed: the picture could stay blank on some screens (seen on a teenage boy customer). The door now checks that the terminal has received each picture before drawing it and re-sends any that didn't arrive. It also redraws the picture after a full-page screen.

## 1.0.0 (2026-11-24)

* First Go release: BBS door (DOOR32.SYS, JPEG XL pictures for SyncTERM with a Sixel fallback, SyncTERM sound), web version with the original Flash look, stand-alone telnet server, Windows 32/64-bit and Linux.

// fqedit is the Funeral Quest sysop editor: settings, players, game texts, news, security
// (bans and block lists), server links, the web sysop password and the logs, full screen
// in a console window. It works on the same data as the running door, telnet and web
// servers, which pick up changes by themselves.
//
//	fqedit [--home DIR]
package main

import (
	"flag"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"

	"funeralquest/admin"
	"funeralquest/engine"
	"funeralquest/fqnet"
)

var (
	A       *admin.Admin
	restore = func() {}
)

func quit() {
	out(cReset + esc + "2J" + esc + "H" + esc + "?25h")
	restore()
	os.Exit(0)
}

func homeDir(flagVal string) string {
	if flagVal != "" {
		return flagVal
	}
	if exe, err := os.Executable(); err == nil {
		dir := filepath.Dir(exe)
		if _, err := os.Stat(filepath.Join(dir, "gamedata")); err == nil {
			return dir
		}
	}
	wd, _ := os.Getwd()
	return wd
}

func main() {
	home := flag.String("home", "", "Funeral Quest folder (the one with gamedata/ and data/)")
	ver := flag.Bool("version", false, "show the version")
	flag.Parse()
	if *ver {
		fmt.Println("Funeral Quest editor", engine.Version)
		return
	}
	h := homeDir(*home)
	a, err := admin.Open(h, nil)
	if err != nil {
		fmt.Fprintln(os.Stderr, "fqedit:", err)
		fmt.Fprintln(os.Stderr, "Run fqedit from the Funeral Quest folder, or use  fqedit --home C:\\doors\\fq")
		if isWindowsConsole() {
			fmt.Fprint(os.Stderr, "\nPress Enter to close.")
			fmt.Scanln()
		}
		os.Exit(1)
	}
	A = a
	r, ok := makeRaw()
	if !ok {
		fmt.Fprintln(os.Stderr, "fqedit needs to run in a console window (Windows 10 or later, or a Linux terminal).")
		os.Exit(1)
	}
	restore = r
	defer quit()
	mainMenu()
}

func isWindowsConsole() bool { return filepath.Separator == '\\' }

// ------------------------------------------------------------------ main menu

func mainMenu() {
	sel := 0
	for {
		s := A.Status()
		items := []item{
			{Label: "Game settings", Help: "Turns, starting stats, odds, scoring, tournament mode, security and network options"},
			{Label: "Players", Value: fmt.Sprintf("%d open", s.Players), Help: "Edit, close, delete players or set their passwords"},
			{Label: "Game texts", Help: "Karma, ratings, news, events, risks, sales pitches, fortune cookies, swear filter"},
			{Label: "News and maintenance", Value: fmt.Sprintf("day %d", s.Day), Help: "Post news, run maintenance, reset the game"},
			{Label: "Security", Value: fmt.Sprintf("%d banned", s.Bans), Help: "Temporary bans, blocked IPs and host names, never-block list"},
			{Label: "Network links", Value: fmt.Sprintf("%d linked, %d waiting", s.Links, s.Pending), Help: "Link this town to other Funeral Quest servers"},
			{Label: "Web sysop password", Value: map[bool]string{true: "set", false: "off"}[A.SysopPasswordSet()], Help: "The password for the /sysop pages of the web server"},
			{Label: "View logs", Help: "Server, door and security logs"},
			{Label: "Quit"},
		}
		title := fmt.Sprintf("%s  (day %d, %d playing now)  v%s", s.Town, s.Day, s.Online, s.Version)
		if len(s.Warn) > 0 {
			items[5].Value += fmt.Sprintf(", %d NEED ATTENTION", len(s.Warn))
			items[5].Help = s.Warn[0]
		}
		var k string
		sel, k = menu(title, "↑↓ choose   Enter select   Esc quit", items, sel, "", "", false)
		if k == "esc" {
			return
		}
		switch sel {
		case 0:
			settingsMenu()
		case 1:
			playersMenu()
		case 2:
			textsMenu()
		case 3:
			gameMenu()
		case 4:
			securityMenu()
		case 5:
			networkMenu()
		case 6:
			sysopPassword()
		case 7:
			logsMenu()
		case 8:
			return
		}
	}
}

// ------------------------------------------------------------------ settings

func settingsMenu() {
	sel, msg, isErr := 0, "", false
	for {
		c := A.Config()
		var items []item
		var keys []string
		group := ""
		for _, s := range engine.Settings {
			if s.Group != group {
				group = s.Group
				items = append(items, item{Label: group, Head: true})
				keys = append(keys, "")
			}
			v := c.Get(s.Key)
			if s.Kind == "bool" {
				v = map[string]string{"true": "Yes", "false": "No"}[v]
			}
			if s.Kind == "text" && v == "" {
				v = "(not set)"
			}
			items = append(items, item{Label: s.Label, Value: v, Help: s.Help})
			keys = append(keys, s.Key)
		}
		var k string
		sel, k = menu("Game settings", "↑↓ choose   Enter change   Esc back", items, sel, "", msg, isErr)
		if k == "esc" {
			return
		}
		key := keys[sel]
		info := engine.SettingByKey(key)
		var nv string
		if info.Kind == "bool" {
			nv = map[bool]string{true: "no", false: "yes"}[c.Get(key) == "true"]
		} else {
			v, ok := input(info.Label+":", c.Get(key), false)
			if !ok {
				msg = ""
				continue
			}
			nv = v
		}
		if err := A.SetSettings(map[string]string{key: nv}); err != nil {
			msg, isErr = err.Error(), true
		} else {
			msg, isErr = "Saved. Running servers pick it up by themselves.", false
		}
	}
}

// ------------------------------------------------------------------ players

func playersMenu() {
	sel, filter, msg, isErr := 0, "", "", false
	showClosed := false
	for {
		var rows []admin.PlayerRow
		for _, p := range A.Players() {
			if !showClosed && !p.Active {
				continue
			}
			if filter != "" && !strings.Contains(strings.ToLower(p.Name+" "+p.Parlor+" "+p.Logon+" "+p.BBSKey), strings.ToLower(filter)) {
				continue
			}
			rows = append(rows, p)
		}
		var items []item
		for _, p := range rows {
			v := fmt.Sprintf("%-22s %10s BP  $%-10s", trunc(p.Parlor, 22), commas(p.Exp), commas(p.Money))
			if p.Online {
				v += " ON NOW"
			}
			if !p.Active {
				v += " (closed)"
			}
			who := p.Logon
			if who == "" {
				who = p.BBSKey
			}
			items = append(items, item{Label: p.Name, Value: v, Dim: !p.Active, Help: fmt.Sprintf("#%d  logon: %s  last played day %d", p.ID, who, p.DayLast)})
		}
		if len(items) == 0 {
			items = []item{{Label: "(nobody)", Dim: true}}
		}
		title := "Players"
		if filter != "" {
			title += "  (matching \"" + filter + "\")"
		}
		help := "Enter edit   F find   C show/hide closed   Esc back"
		var k string
		sel, k = menu(title, help, items, sel, "fc", msg, isErr)
		msg = ""
		switch k {
		case "esc":
			return
		case "f":
			if v, ok := input("Find (part of a name, parlor or logon):", filter, false); ok {
				filter, sel = v, 0
			}
		case "c":
			showClosed = !showClosed
		case "enter":
			if len(rows) > 0 {
				msg, isErr = editPlayer(rows[sel].ID)
			}
		}
	}
}

func editPlayer(id int) (string, bool) {
	sel, msg, isErr := 0, "", false
	for {
		p, err := A.Player(id)
		if err != nil {
			return err.Error(), true
		}
		var items []item
		for _, f := range admin.PlayerFields {
			items = append(items, item{Label: f.Label, Value: p[f.Key]})
		}
		items = append(items, item{Label: "", Head: true},
			item{Label: "Set password...", Help: "Set a new web/telnet password for this player"},
			item{Label: "Delete player...", Help: "Remove the player and their letters for good (to just close the parlor, set Open to no)"})
		title := fmt.Sprintf("%s of %s", p["name"], p["parlor"])
		if p["bbs_key"] != "" {
			title += "  (BBS " + p["bbs_key"] + ")"
		}
		var k string
		sel, k = menu(title, "Enter change   Esc back", items, sel, "", msg, isErr)
		if k == "esc" {
			return "", false
		}
		nf := len(admin.PlayerFields)
		switch {
		case sel < nf:
			f := admin.PlayerFields[sel]
			var nv string
			if f.Kind == "bool" {
				nv = map[bool]string{true: "no", false: "yes"}[p[f.Key] == "yes"]
			} else {
				v, ok := input(f.Label+":", p[f.Key], false)
				if !ok {
					continue
				}
				nv = v
			}
			if err := A.UpdatePlayer(id, map[string]string{f.Key: nv}); err != nil {
				msg, isErr = err.Error(), true
			} else {
				msg, isErr = "Saved.", false
			}
		case sel == nf+1:
			pw, ok := input("New password:", "", true)
			if !ok || pw == "" {
				continue
			}
			if err := A.SetPlayerPassword(id, pw); err != nil {
				msg, isErr = err.Error(), true
			} else {
				msg, isErr = "Password changed.", false
			}
		case sel == nf+2:
			if confirm("Delete " + p["name"] + " for good?") {
				if err := A.DeletePlayer(id); err != nil {
					msg, isErr = err.Error(), true
					continue
				}
				return p["name"] + " deleted.", false
			}
		}
	}
}

// ------------------------------------------------------------------ texts

func textsMenu() {
	sel, msg, isErr := 0, "", false
	for {
		var items []item
		var list []admin.TextFile
		for _, t := range admin.Texts {
			if t.Dir != "gamedata" {
				continue
			}
			list = append(list, t)
			items = append(items, item{Label: t.Title, Value: t.File, Help: t.Help})
		}
		var k string
		sel, k = menu("Game texts", "Enter edit (opens "+defaultEditor()[0]+")   Esc back", items, sel, "", msg, isErr)
		if k == "esc" {
			return
		}
		msg, isErr = editText(list[sel].Key)
	}
}

// editText opens a text file in the system editor (Notepad on Windows), then checks it.
// If the game can't read the result, the old file is put back.
func editText(key string) (string, bool) {
	t := admin.TextByKey(key)
	path := A.TextPath(t)
	before, _ := os.ReadFile(path)
	if len(before) == 0 {
		os.WriteFile(path, []byte{}, 0o644)
	}
	ed := defaultEditor()
	out(cReset + esc + "2J" + esc + "H" + esc + "?25h")
	fmt.Printf("Editing %s in %s.  Save and close the editor to come back.\r\n", path, ed[0])
	restore()
	cmd := exec.Command(ed[0], append(ed[1:], path)...)
	cmd.Stdin, cmd.Stdout, cmd.Stderr = os.Stdin, os.Stdout, os.Stderr
	started := time.Now()
	err := cmd.Run()
	restore, _ = makeRaw()
	if err != nil {
		out(esc + "?25l")
		return "Couldn't start the editor: " + err.Error(), true
	}
	after, _ := os.ReadFile(path)
	if string(after) == string(before) && time.Since(started) < 3*time.Second {
		// some editors (the Windows 11 Notepad) hand off to another process and return at once
		fmt.Print("\r\nWhen you've saved the file and closed the editor, press Enter here (Esc to cancel). ")
		for k := getKey(); k != "enter"; k = getKey() {
			if k == "esc" {
				break
			}
		}
		after, _ = os.ReadFile(path)
	}
	out(esc + "?25l")
	if string(after) == string(before) {
		return "No changes.", false
	}
	// put the old file back and save the new text through the checker (which keeps a .bak)
	os.WriteFile(path, before, 0o644)
	if err := A.WriteText(key, string(after)); err != nil {
		os.WriteFile(path+".rejected", after, 0o644)
		return err.Error() + " (your edit is in " + filepath.Base(path) + ".rejected)", true
	}
	return "Saved " + t.File + " (old version in " + t.File + ".bak). The game uses it within seconds.", false
}

// ------------------------------------------------------------------ news & maintenance

func gameMenu() {
	sel, msg, isErr := 0, "", false
	for {
		items := []item{
			{Label: "Post news", Help: "Put a notice from City Hall on today's front page"},
			{Label: "Run maintenance now", Help: "Start a new game day now (bonuses, closing idle parlors, news)"},
			{Label: "Reset the game...", Help: "Start over at day 1"},
		}
		var k string
		sel, k = menu("News and maintenance", "Enter select   Esc back", items, sel, "", msg, isErr)
		if k == "esc" {
			return
		}
		switch sel {
		case 0:
			if v, ok := input("News:", "", false); ok && v != "" {
				msg, isErr = result(A.PostNews(v), "Posted.")
			}
		case 1:
			if confirm("Run maintenance now? Everyone gets a new day.") {
				day, err := A.Maint()
				msg, isErr = result(err, fmt.Sprintf("Done. It is now day %d.", day))
			}
		case 2:
			v, ok := input("Type RESET to start the game over:", "", false)
			if !ok || v != "RESET" {
				msg, isErr = "Not reset.", false
				continue
			}
			wipe := confirm("Delete every player too?")
			msg, isErr = result(A.Reset(wipe), "The game has been reset.")
		}
	}
}

func result(err error, ok string) (string, bool) {
	if err != nil {
		return err.Error(), true
	}
	return ok, false
}

// ------------------------------------------------------------------ security

func securityMenu() {
	sel, msg, isErr := 0, "", false
	for {
		bans := A.Guard.Bans()
		items := []item{
			{Label: "Blocked IP addresses", Value: "blocklist_ip.txt", Help: "Permanent blocks: one IP or range per line"},
			{Label: "Blocked host names", Value: "blocklist_hosts.txt", Help: "Permanent blocks by name; * wildcards allowed"},
			{Label: "Never-block list", Value: "allowlist_ip.txt", Help: "Addresses that are never blocked or banned (put your own here)"},
			{Label: "Ban an address...", Help: "Ban an IP address for a while"},
			{Label: "HTTPS certificate...", Value: certValue(), Help: "Make a self-signed certificate for the web server, or turn HTTPS off"},
			{Label: fmt.Sprintf("Temporary bans (%d)", len(bans)), Head: true},
		}
		for _, b := range bans {
			items = append(items, item{Label: b.IP, Value: fmt.Sprintf("until %s  %s  (ban #%d)", b.Until.Local().Format("Jan 2 15:04"), b.Reason, b.Count),
				Help: "Enter to lift this ban"})
		}
		if len(bans) == 0 {
			items = append(items, item{Label: "nobody is banned", Dim: true, Help: ""})
		}
		var k string
		sel, k = menu("Security", "Enter select   Esc back", items, sel, "", msg, isErr)
		if k == "esc" {
			return
		}
		switch {
		case sel <= 2:
			msg, isErr = editText([]string{"block_ip", "block_hosts", "allow_ip"}[sel])
		case sel == 3:
			ip, ok := input("IP address to ban:", "", false)
			if !ok || ip == "" {
				continue
			}
			m, ok := input("Minutes:", "60", false)
			mins, _ := strconv.Atoi(m)
			if !ok || mins <= 0 {
				continue
			}
			A.Guard.Ban(ip, "banned by sysop", time.Duration(mins)*time.Minute)
			msg, isErr = "Banned "+ip+".", false
		case sel == 4:
			msg, isErr = certMenu()
		case sel >= 6 && len(bans) > 0:
			b := bans[sel-6]
			if confirm("Lift the ban on " + b.IP + "?") {
				A.Guard.Unban(b.IP)
				msg, isErr = "Unbanned "+b.IP+".", false
			}
		}
	}
}

// ------------------------------------------------------------------ network

func networkMenu() {
	sel, msg, isErr := 0, "", false
	for {
		c := A.Config()
		url := fqnet.AdvertisedURL(c)
		if url == "" {
			url = "(not set: outbound only, other towns can't connect to you or raid you)"
		}
		items := []item{
			{Label: "This server's fingerprint", Value: fqnet.Fingerprint(A.Net.ID), Help: "Tell other sysops this so they know a link request is really from you"},
			{Label: "This server's web address", Value: url, Help: "Enter to change. It's the address other servers use, e.g. http://bbs.example.com:8080"},
			{Label: "Link to another server...", Help: "Type in the other server's address and port"},
			{Label: "Accept requests automatically", Value: map[bool]string{true: "Yes", false: "No"}[c.NetAutoAccept], Help: "Enter to switch. No: link requests wait for you to accept them here"},
			{Label: "Network port only", Value: portOnlyValue(c), Help: "Enter to switch. Yes: other servers connect to the Network port (Settings > Server) instead of the web port, and the address given out switches to it"},
			{Label: "Settings votes...", Value: voteCount(), Help: "Propose your game settings to every linked town, or vote on theirs"},
			{Label: "Linked servers", Head: true},
		}
		peers := A.Net.Peers()
		sort.Slice(peers, func(i, j int) bool { return peers[i].State < peers[j].State })
		q := A.Net.QueuedMail()
		for _, p := range peers {
			st := p.State
			if p.State == fqnet.Linked && !p.TheyOK {
				st = "waiting for them"
			}
			if p.State == fqnet.Pending {
				st = "WANTS TO LINK"
			}
			if p.State == fqnet.KeyChange {
				st = "KEY CHANGED"
			}
			if p.State == fqnet.Linked && p.TheyOK && fqnet.Reach(p) != "" {
				st = "outbound only"
				if p.URL != "" {
					st = "not reachable"
				}
			}
			if p.State == fqnet.Linked && fqnet.Problems(c, p) != "" {
				st = "NEEDS ATTENTION"
			}
			v := fmt.Sprintf("%-17s %s  %s", st, fqnet.Fingerprint(p.ID), ifEmpty(p.URL, "(connects out only)"))
			help := fmt.Sprintf("day %d, %d parlors, %d on now, version %s", p.Day, p.Players, p.Online, p.GameVer)
			if r := fqnet.Reach(p); r != "" {
				help = r
			}
			if pr := fqnet.Problems(c, p); pr != "" {
				help = pr
			}
			if q[p.ID] > 0 {
				help += fmt.Sprintf(", %d letters waiting", q[p.ID])
			}
			if p.LastErr != "" {
				help = "Last error: " + p.LastErr
			}
			if p.Note != "" {
				help += "  " + p.Note
			}
			items = append(items, item{Label: p.Name, Value: v, Help: help})
		}
		if len(peers) == 0 {
			items = append(items, item{Label: "none yet", Dim: true})
		}
		var k string
		sel, k = menu("Network links", "Enter select   Esc back   (the web server does the syncing)", items, sel, "", msg, isErr)
		if k == "esc" {
			return
		}
		switch {
		case sel == 1:
			if v, ok := input("This server's web address:", c.NetPublicURL, false); ok {
				msg, isErr = result(A.SetSettings(map[string]string{"net_public_url": v}), "Saved.")
			}
		case sel == 2:
			v, ok := input("Other server's address:port", "", false)
			if !ok || v == "" {
				continue
			}
			status("Contacting "+v+"...", false)
			p, err := A.Net.AddPeer(v)
			if err != nil {
				msg, isErr = err.Error(), true
				continue
			}
			msg, isErr = fmt.Sprintf("Linked to %s. Check its fingerprint with its sysop: %s", p.Name, fqnet.Fingerprint(p.ID)), false
		case sel == 3:
			msg, isErr = result(A.SetSettings(map[string]string{"net_auto_accept": map[bool]string{true: "no", false: "yes"}[c.NetAutoAccept]}), "Saved.")
		case sel == 4:
			msg, isErr = result(A.SetSettings(map[string]string{"net_port_only": map[bool]string{true: "no", false: "yes"}[c.NetPortOnly]}), "Saved. Other towns are told the new address.")
		case sel == 5:
			msg, isErr = votesMenu()
		case sel >= 7 && len(peers) > 0:
			msg, isErr = peerActions(peers[sel-7])
		}
	}
}

func peerActions(p fqnet.Peer) (string, bool) {
	var items []item
	var acts []string
	if p.State != fqnet.Linked {
		items = append(items, item{Label: "Accept", Help: "Link with this server"})
		acts = append(acts, "accept")
	} else {
		items = append(items, item{Label: "Sync now", Help: "Exchange players, chat and mail right now"})
		acts = append(acts, "sync")
	}
	c := A.Config()
	diffs := fqnet.RuleDiffs(c, p)
	if p.State == fqnet.Linked && (len(diffs) > 0 || fqnet.VersionNote(p) != "") {
		items = append(items, item{Label: "Show version and settings differences", Help: "What's different from this town, and who needs to update"})
		acts = append(acts, "diffs")
	}
	if p.State == fqnet.Linked && len(diffs) > 0 {
		items = append(items, item{Label: fmt.Sprintf("Use %s's settings (%d)", p.Name, len(diffs)), Help: "Change the differing game settings here to match theirs"})
		acts = append(acts, "use")
	}
	if p.State != fqnet.Blocked {
		items = append(items, item{Label: "Block", Help: "Ignore this server from now on"})
		acts = append(acts, "block")
	}
	items = append(items, item{Label: "Remove", Help: "Forget this server, its players and waiting letters"})
	acts = append(acts, "remove")
	sel, k := menu(p.Name+"  "+fqnet.Fingerprint(p.ID), "Enter select   Esc back", items, 0, "", "", false)
	if k == "esc" {
		return "", false
	}
	switch acts[sel] {
	case "diffs":
		var b strings.Builder
		fmt.Fprintf(&b, "Your version: %s    %s's version: %s\n\n", engine.Version, p.Name, ifEmpty(p.GameVer, "unknown (older than 1.3.0)"))
		if v := fqnet.VersionNote(p); v != "" {
			b.WriteString(v + "\n\n")
		}
		if len(diffs) > 0 {
			fmt.Fprintf(&b, "Game settings that differ (both towns should play by the same rules):\n\n%-40s %-14s %s\n", "Setting", "Here", "There")
			for _, d := range diffs {
				fmt.Fprintf(&b, "%-40s %-14s %s\n", d.Label, d.Ours, d.Theirs)
			}
			b.WriteString("\nAgree with " + p.Name + "'s sysop which values to use. To take theirs, choose \"Use " + p.Name + "'s settings\".")
		}
		pager(p.Name+": differences", b.String())
		return "", false
	case "use":
		if confirm(fmt.Sprintf("Change %d setting(s) to %s's values?", len(diffs), p.Name)) {
			return result(A.Net.UseTheirs(A, p.ID, nil), "Settings now match "+p.Name+".")
		}
		return "", false
	case "accept":
		return result(A.Net.Accept(p.ID), "Accepted. "+p.Name+" is linked.")
	case "sync":
		status("Syncing...", false)
		return result(A.Net.SyncPeer(p.ID), "Synced with "+p.Name+".")
	case "block":
		return result(A.Net.Block(p.ID), p.Name+" blocked.")
	case "remove":
		if confirm("Remove " + p.Name + "?") {
			return result(A.Net.Remove(p.ID), p.Name+" removed.")
		}
	}
	return "", false
}

// ------------------------------------------------------------------ sysop password & logs

func sysopPassword() {
	frame("Web sysop password", "Esc to go back")
	state := "The web sysop pages (http://yourserver:port/sysop/) are OFF until you set a password."
	if A.SysopPasswordSet() {
		state = "The web sysop pages are ON. Setting a new password logs out every sysop session."
	}
	out(at(4, 3) + cText + state + cReset)
	out(at(6, 3) + cDim + "Use a long password (10+ characters). Leave it empty and press Enter to turn the pages off." + cReset)
	pw, ok := input("New sysop password:", "", true)
	if !ok {
		return
	}
	if pw == "" {
		if A.SysopPasswordSet() && confirm("Turn the web sysop pages off?") {
			A.DisableSysopPassword()
		}
		return
	}
	pw2, ok := input("Same password again:", "", true)
	if !ok {
		return
	}
	if pw != pw2 {
		status("The passwords don't match. Nothing changed. (press a key)", true)
		getKey()
		return
	}
	if err := A.SetSysopPassword(pw); err != nil {
		status(err.Error()+" (press a key)", true)
	} else {
		status("Sysop password set. (press a key)", false)
	}
	getKey()
}

func logsMenu() {
	sel := 0
	for {
		var items []item
		for _, l := range admin.Logs {
			items = append(items, item{Label: l})
		}
		var k string
		sel, k = menu("Logs", "Enter view   Esc back", items, sel, "", "", false)
		if k == "esc" {
			return
		}
		t, err := A.TailLog(admin.Logs[sel], 2000)
		if err != nil {
			t = err.Error()
		}
		pager(admin.Logs[sel], t)
	}
}

// ------------------------------------------------------------------ helpers

func commas(n int) string {
	s := strconv.Itoa(n)
	neg := strings.HasPrefix(s, "-")
	s = strings.TrimPrefix(s, "-")
	for i := len(s) - 3; i > 0; i -= 3 {
		s = s[:i] + "," + s[i:]
	}
	if neg {
		return "-" + s
	}
	return s
}

func trunc(s string, n int) string {
	r := []rune(s)
	if len(r) > n {
		return string(r[:n])
	}
	return s
}

func ifEmpty(s, def string) string {
	if s == "" {
		return def
	}
	return s
}

func voteCount() string {
	waiting, open := 0, 0
	for _, p := range A.Net.Proposals() {
		if p.Status == "open" {
			open++
			if p.From != A.Net.ID && p.MyVote == "" {
				waiting++
			}
		}
	}
	if waiting > 0 {
		return fmt.Sprintf("%d WAITING FOR YOUR VOTE", waiting)
	}
	if open > 0 {
		return fmt.Sprintf("%d open", open)
	}
	return ""
}

func votesMenu() (string, bool) {
	sel, msg, isErr := 0, "", false
	for {
		props := A.Net.Proposals()
		items := []item{{Label: "Propose my settings to all linked towns", Help: "Each linked town's sysop is asked to accept this town's game settings; if more than half of all towns agree, every town switches"}}
		if len(props) > 0 {
			items = append(items, item{Label: "Votes", Head: true})
		}
		for _, p := range props {
			label := "Your proposal"
			if p.From != A.Net.ID {
				label = p.FromName + "'s settings"
			}
			items = append(items, item{Label: label, Value: fqnet.VoteSummary(A.Net.ID, p), Help: "Enter to see the settings and vote"})
		}
		var k string
		sel, k = menu("Settings votes", "Enter select   Esc back", items, sel, "", msg, isErr)
		if k == "esc" {
			return "", false
		}
		if sel == 0 {
			if confirm("Ask every linked town to switch to this town's game settings?") {
				p, err := A.Net.Propose()
				if err != nil {
					msg, isErr = err.Error(), true
				} else {
					msg, isErr = fmt.Sprintf("Sent to %d town(s). Their sysops will be asked to accept.", len(p.Voters)), false
				}
			}
			continue
		}
		p := props[sel-2]
		msg, isErr = voteOn(p)
	}
}

func voteOn(p fqnet.Proposal) (string, bool) {
	c := A.Config()
	var b strings.Builder
	yes, no, total := fqnet.Tally(p)
	if p.From == A.Net.ID {
		fmt.Fprintf(&b, "Your proposal: %s\n\n%d yes, %d no, %d not voted yet, of %d towns. It needs more than %d yes.\n\n", p.Status, yes, no, total-yes-no, total, total/2)
	} else {
		fmt.Fprintf(&b, "%s asks your town to accept its game settings. (%s)\n\n", p.FromName, p.Status)
		diffs := fqnet.RuleDiffs(c, fqnet.Peer{Rules: p.Rules})
		if len(diffs) == 0 {
			b.WriteString("The proposed settings are the same as yours.\n")
		} else {
			fmt.Fprintf(&b, "%-40s %-14s %s\n", "Setting", "Yours now", "Proposed")
			for _, d := range diffs {
				fmt.Fprintf(&b, "%-40s %-14s %s\n", d.Label, d.Ours, d.Theirs)
			}
		}
		b.WriteString("\nIf more than half of all the towns in the vote accept, every town switches to these settings")
		if c.NetVoteApplyOff {
			b.WriteString(" - except this one, because \"Don't apply settings votes\" is on.")
		} else {
			b.WriteString(", including this one even if you decline.")
		}
		if p.MyVote != "" {
			b.WriteString("\n\nYou voted " + p.MyVote + ". You can change your vote until the vote ends.")
		}
	}
	if p.Note != "" {
		b.WriteString("\n\n" + p.Note)
	}
	pager("Settings vote", b.String())
	if p.From == A.Net.ID || p.Status != "open" {
		return "", false
	}
	sel, k := menu("Your vote on "+p.FromName+"'s settings", "Enter select   Esc back without voting",
		[]item{{Label: "Accept"}, {Label: "Decline"}}, 0, "", "", false)
	if k == "esc" {
		return "", false
	}
	return result(A.Net.CastVote(p.ID, sel == 0), "Vote sent.")
}

func certValue() string {
	c := A.Cert()
	switch {
	case c == nil:
		return "off (plain HTTP)"
	case c.Error != "":
		return "problem: " + c.Error
	case c.SelfSigned:
		return "self-signed, until " + c.Expires.Format("Jan 2 2006")
	}
	return "until " + c.Expires.Format("Jan 2 2006")
}

func certMenu() (string, bool) {
	c := A.Cert()
	var b strings.Builder
	if c == nil {
		b.WriteString("HTTPS is off: the web server uses plain HTTP.\n")
	} else if c.Error != "" {
		fmt.Fprintf(&b, "Certificate file %s: %s\n", c.File, c.Error)
	} else {
		fmt.Fprintf(&b, "Certificate: %s\nFor: %s\nValid until: %s\nSelf-signed: %v\nSHA-256 fingerprint:\n  %s\n", c.File, strings.Join(c.Names, ", "), c.Expires.Format("Jan 2 2006"), c.SelfSigned, c.Fingerprint)
	}
	b.WriteString("\nA self-signed certificate is free and instant, but browsers warn players until they accept it. Linked Funeral Quest servers trust it the first time and then remember it. Restart fq web after making one.")
	pager("HTTPS certificate", b.String())
	sel, k := menu("HTTPS certificate", "Enter select   Esc back", []item{{Label: "Make a self-signed certificate"}, {Label: "Turn HTTPS off"}}, 0, "", "", false)
	if k == "esc" {
		return "", false
	}
	if sel == 1 {
		return result(A.TurnOffHTTPS(), "HTTPS turned off. Restart fq web.")
	}
	hosts, ok := input("Names it's for (comma separated):", strings.Join(A.CertHosts(), ", "), false)
	if !ok {
		return "", false
	}
	var list []string
	for _, h := range strings.Split(hosts, ",") {
		if h = strings.TrimSpace(h); h != "" {
			list = append(list, h)
		}
	}
	info, err := A.MakeSelfSignedCert(list)
	if err != nil {
		return err.Error(), true
	}
	return "Made (fingerprint " + info.Fingerprint[:23] + "...). Restart fq web to use HTTPS.", false
}

func portOnlyValue(c engine.Config) string {
	switch {
	case c.NetPort == 0:
		return "No (set a Network port first)"
	case c.NetPortOnly:
		return fmt.Sprintf("Yes (port %d)", c.NetPort)
	}
	return fmt.Sprintf("No (network port %d is also open)", c.NetPort)
}

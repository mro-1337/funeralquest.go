package engine

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

// Player mirrors player_struct from the original server.
type Player struct {
	ID         int    `json:"id"`
	Name       string `json:"name"`
	Parlor     string `json:"parlor"`
	Male       bool   `json:"male"`
	Logon      string `json:"logon,omitempty"`
	Password   string `json:"password,omitempty"`
	BBSKey     string `json:"bbs_key,omitempty"`
	Active     bool   `json:"active"`
	Created    int64  `json:"created"`
	Turns      int    `json:"turns"`
	Money      int    `json:"money"`
	Exp        int    `json:"exp"`
	Karma      int    `json:"karma"`
	Rating     int    `json:"rating"`
	Coffins    [3]int `json:"coffins"`
	Transport  int    `json:"transport"`
	Plots      int    `json:"plots"`
	DayLast    int    `json:"day_last"`
	SP         int    `json:"sp"`
	Luck       int    `json:"luck"`
	YangsSent  int    `json:"yangs_sent"`
	Psych      int    `json:"psych"`
	Kicked     bool   `json:"kicked_yangs"`
	Strength   int    `json:"strength"`
	HPMax      int    `json:"hp_max"`
	HP         int    `json:"hp"`
	Fights     int    `json:"fights"`
	Police     bool   `json:"police"`
	TagsToday  int    `json:"tags_today"`
	NetRaidDay int    `json:"net_raid_day,omitempty"` // day of the last out-of-town raid on this player
	NetRaids   int    `json:"net_raids,omitempty"`    // out-of-town raids on that day
	Custom     Custom `json:"custom"`
}

// Custom holds the values the original kept in a_custom[] for its scripts.
type Custom struct {
	FireAlarm       int `json:"fire_alarm"`
	Safe            int `json:"safe"`
	Padlock         int `json:"padlock"`
	Lockpick        int `json:"lockpick"`
	PadlockStrength int `json:"padlock_strength"`
}

// Letter is a queued message shown at the player's desk (the original's message queue).
type Letter struct {
	ID      int    `json:"id"`
	To      int    `json:"to"`
	Expire  int    `json:"expire,omitempty"`
	Text    string `json:"text"`
	Pic     string `json:"pic,omitempty"`
	BG      string `json:"bg,omitempty"`
	Luck    int    `json:"luck,omitempty"`
	BP      int    `json:"bp,omitempty"`
	Turns   int    `json:"turns,omitempty"`
	Tags    [3]int `json:"tags,omitempty"`
	ReplyTo int    `json:"reply_to,omitempty"`
	NetFrom string `json:"net_from,omitempty"` // reply address of a letter from a linked server
	Log     string `json:"log,omitempty"`
}

type ChatLine struct {
	ID    int    `json:"id"`
	TS    int64  `json:"ts"`
	To    int    `json:"to,omitempty"`
	Text  string `json:"text"`
	Share bool   `json:"share,omitempty"` // public cafe line that linked servers may see
	Net   string `json:"net,omitempty"`   // came from this linked server
}

type SessionRec struct {
	SID      string `json:"sid"`
	PlayerID int    `json:"player_id"`
	Kind     string `json:"kind"`
	Location string `json:"location"`
	Status   string `json:"status"`
	LastSeen int64  `json:"last_seen"`
}

type TopOld struct {
	Name, Parlor string
	BP           int
}

type Glo struct {
	GameAge   int     `json:"game_age"`
	LastMaint string  `json:"last_maint"`
	TopOld    *TopOld `json:"top_old"`
	TVOff     bool    `json:"tv_off"`
}

// World is everything shared between the door nodes and the web server.
type World struct {
	Config     Config        `json:"config"`
	Glo        Glo           `json:"glo"`
	NextID     int           `json:"next_id"`
	Players    []*Player     `json:"players"`
	NextMailID int           `json:"next_mail_id"`
	Mail       []*Letter     `json:"mail"`
	NextChatID int           `json:"next_chat_id"`
	Chat       []ChatLine    `json:"chat"`
	Sessions   []*SessionRec `json:"sessions"`
	Deeds      []string      `json:"deeds"`

	dir   string
	chat0 int // NextChatID when loaded; a change is announced in chat.seq
	dirty bool
}

// Store keeps the world in <dir>/world.json. Every change happens inside Tx, which holds a lock
// file, so any number of door processes and the web server can share one game safely.
type Store struct {
	Dir string
	mu  sync.Mutex
}

func NewStore(dir string) (*Store, error) {
	if err := os.MkdirAll(filepath.Join(dir, "news"), 0o755); err != nil {
		return nil, err
	}
	return &Store{Dir: dir}, nil
}

func (s *Store) lock() (func(), error) {
	p := filepath.Join(s.Dir, "world.lock")
	deadline := time.Now().Add(30 * time.Second)
	for {
		f, err := os.OpenFile(p, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0o644)
		if err == nil {
			fmt.Fprintf(f, "%d %d", os.Getpid(), time.Now().Unix())
			f.Close()
			return func() { os.Remove(p) }, nil
		}
		// a crashed process can leave the lock behind: break it after 15 seconds
		if st, e := os.Stat(p); e == nil && time.Since(st.ModTime()) > 15*time.Second {
			os.Remove(p)
			continue
		}
		if time.Now().After(deadline) {
			return nil, errors.New("game data is locked (world.lock)")
		}
		time.Sleep(4 * time.Millisecond)
	}
}

func (s *Store) load() (*World, error) {
	w := &World{dir: s.Dir}
	b, err := os.ReadFile(filepath.Join(s.Dir, "world.json"))
	if err == nil {
		if err := json.Unmarshal(b, w); err != nil {
			return nil, fmt.Errorf("world.json is damaged: %w", err)
		}
	} else if !os.IsNotExist(err) {
		return nil, err
	}
	w.dir = s.Dir
	w.chat0 = w.NextChatID
	if w.NextID == 0 {
		w.NextID = 1
	}
	if w.Config.TurnsPerDay == 0 {
		w.Config = DefaultConfig()
	}
	w.Config.fillNew()
	return w, nil
}

func (s *Store) save(w *World) error {
	b, err := json.Marshal(w)
	if err != nil {
		return err
	}
	tmp := filepath.Join(s.Dir, fmt.Sprintf("world.%d.tmp", os.Getpid()))
	if err := os.WriteFile(tmp, b, 0o644); err != nil {
		return err
	}
	final := filepath.Join(s.Dir, "world.json")
	for i := 0; ; i++ {
		err = os.Rename(tmp, final) // atomic replace (MoveFileEx on Windows)
		if err == nil || i > 50 {
			break
		}
		time.Sleep(20 * time.Millisecond) // virus scanners sometimes hold the file briefly
	}
	if err == nil && w.NextChatID != w.chat0 {
		// tiny file that chat screens and the network watch, so they can react to a new
		// line at once without loading the whole game
		os.WriteFile(filepath.Join(s.Dir, "chat.seq"), []byte(strconv.Itoa(w.NextChatID)), 0o644)
		w.chat0 = w.NextChatID
	}
	return err
}

// ChatSeq is the newest chat line number, read cheaply from chat.seq.
func (s *Store) ChatSeq() int {
	b, err := os.ReadFile(filepath.Join(s.Dir, "chat.seq"))
	if err != nil {
		return 0
	}
	n, _ := strconv.Atoi(strings.TrimSpace(string(b)))
	return n
}

// Read loads the world without locking or saving, for read-only looks that must not slow
// anybody down (saves are atomic renames, so a read always sees a complete file).
func (s *Store) Read(fn func(w *World)) error {
	w, err := s.load()
	if err != nil {
		return err
	}
	fn(w)
	return nil
}

// Tx loads the world, runs fn and saves it again, all under the lock.
func (s *Store) Tx(fn func(w *World) error) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	unlock, err := s.lock()
	if err != nil {
		return err
	}
	defer unlock()
	w, err := s.load()
	if err != nil {
		return err
	}
	if err := fn(w); err != nil {
		return err
	}
	return s.save(w)
}

// ---------------------------------------------------------------- world helpers

func (w *World) Player(id int) *Player {
	for _, p := range w.Players {
		if p.ID == id {
			return p
		}
	}
	return nil
}
func (w *World) Active() []*Player {
	var out []*Player
	for _, p := range w.Players {
		if p.Active {
			out = append(out, p)
		}
	}
	return out
}
func (w *World) ByName(name string) *Player {
	for _, p := range w.Players {
		if p.Active && strings.EqualFold(p.Name, name) {
			return p
		}
	}
	return nil
}
func (w *World) ByLogon(logon string) *Player {
	for _, p := range w.Players {
		if p.Logon != "" && strings.EqualFold(p.Logon, logon) {
			return p
		}
	}
	return nil
}
func (w *World) ByBBSKey(k string) *Player {
	for _, p := range w.Players {
		if p.BBSKey != "" && p.BBSKey == k {
			return p
		}
	}
	return nil
}

// Ranked returns active players sorted by total Bury Points.
func (w *World) Ranked() []*Player {
	ps := w.Active()
	sort.SliceStable(ps, func(i, j int) bool { return ps[i].Exp > ps[j].Exp })
	return ps
}

func (w *World) AddMail(l Letter) {
	if p := w.Player(l.To); p == nil || !p.Active {
		return
	}
	w.NextMailID++
	l.ID = w.NextMailID
	w.Mail = append(w.Mail, &l)
}
func (w *World) MailCount(pid int) int {
	n := 0
	for _, m := range w.Mail {
		if m.To == pid {
			n++
		}
	}
	return n
}

// TakeMail removes and returns the oldest letter for pid.
func (w *World) TakeMail(pid int) *Letter {
	for i, m := range w.Mail {
		if m.To == pid {
			w.Mail = append(w.Mail[:i], w.Mail[i+1:]...)
			return m
		}
	}
	return nil
}

// AddSharedChat adds a public cafe line that is also sent to linked servers.
func (w *World) AddSharedChat(text string) {
	w.AddChat(text, 0)
	w.Chat[len(w.Chat)-1].Share = true
}

// AddNetChat adds a cafe line that arrived from a linked server.
func (w *World) AddNetChat(text, peer string) {
	w.AddChat(text, 0)
	w.Chat[len(w.Chat)-1].Net = peer
}

func (w *World) AddChat(text string, to int) {
	w.NextChatID++
	w.Chat = append(w.Chat, ChatLine{ID: w.NextChatID, TS: time.Now().UnixMilli(), To: to, Text: text})
	if len(w.Chat) > 300 {
		w.Chat = w.Chat[len(w.Chat)-300:]
	}
}

func (w *World) TouchSession(sid string, pid int, kind, loc, status string) {
	now := time.Now().UnixMilli()
	for _, s := range w.Sessions {
		if s.SID == sid {
			s.PlayerID, s.Location, s.Status, s.LastSeen = pid, loc, status, now
			return
		}
	}
	w.Sessions = append(w.Sessions, &SessionRec{SID: sid, PlayerID: pid, Kind: kind, Location: loc, Status: status, LastSeen: now})
}
func (w *World) RemoveSession(sid string) {
	for i, s := range w.Sessions {
		if s.SID == sid {
			w.Sessions = append(w.Sessions[:i], w.Sessions[i+1:]...)
			return
		}
	}
}

// Online returns live sessions (and drops stale ones).
func (w *World) Online() []*SessionRec {
	cut := time.Now().Add(-time.Duration(w.Config.OnlineTimeoutMinutes) * time.Minute).UnixMilli()
	var keep []*SessionRec
	for _, s := range w.Sessions {
		if s.LastSeen >= cut {
			keep = append(keep, s)
		}
	}
	w.Sessions = keep
	return keep
}
func (w *World) IsOnline(pid int) bool {
	for _, s := range w.Online() {
		if s.PlayerID == pid {
			return true
		}
	}
	return false
}

// ---------------------------------------------------------------- newspaper files (like the original's news_day_N.txt)

func (w *World) newsFile(day int, section string) string {
	return filepath.Join(w.dir, "news", fmt.Sprintf("day_%d_%s.txt", day, section))
}
func (w *World) AddNews(section, text string) { w.AddNewsDay(w.Glo.GameAge, section, text) }
func (w *World) AddNewsDay(day int, section, text string) {
	f, err := os.OpenFile(w.newsFile(day, section), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644)
	if err != nil {
		return
	}
	f.WriteString(text)
	f.Close()
}
func (w *World) News(day int, section string) string {
	b, _ := os.ReadFile(w.newsFile(day, section))
	return string(b)
}
func (w *World) ClearNews() {
	os.RemoveAll(filepath.Join(w.dir, "news"))
	os.MkdirAll(filepath.Join(w.dir, "news"), 0o755)
}

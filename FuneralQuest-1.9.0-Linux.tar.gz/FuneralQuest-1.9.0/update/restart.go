package update

import (
	"os"
	"path/filepath"
	"strings"
	"time"
)

// ExitCodeRestart is what fq exits with when "Let my service manager restart it" is on.
const ExitCodeRestart = 3

// Restart runs the new version. exitOnly: just exit with ExitCodeRestart and let a service
// manager (NSSM, a Windows service, systemd with Restart=always) start it again.
func Restart(exitOnly bool) error {
	if exitOnly {
		os.Exit(ExitCodeRestart)
	}
	exe, err := os.Executable()
	if err != nil {
		return err
	}
	return restartSelf(exe)
}

// WaitIfRestarted pauses a moment at start-up when this copy was started by Restart on Windows,
// so the old copy has let go of its ports.
func WaitIfRestarted() {
	if os.Getenv("FQ_RESTART_WAIT") != "" {
		os.Unsetenv("FQ_RESTART_WAIT")
		time.Sleep(2 * time.Second)
	}
}

// DiskVersion is the version in the install folder's VERSION file ("" if there's none).
func DiskVersion(home string) string {
	b, err := os.ReadFile(filepath.Join(home, "VERSION"))
	if err != nil {
		return ""
	}
	return strings.TrimSpace(string(b))
}

// Watch restarts a long-running fq (telnet, net, web) once a different version has been put in
// its folder (by the web page, fq update, or by hand) and idle() says nobody would be dropped.
func Watch(home, current string, idle func() bool, exitOnly bool, logf func(string, ...any)) {
	for range time.Tick(time.Minute) {
		v := DiskVersion(home)
		// FQ_RESTARTED_FOR: restart only once for a given version, so a folder whose VERSION file
		// doesn't match its program (files copied by hand) can't cause a restart every minute
		if v == "" || v == current || os.Getenv("FQ_RESTARTED_FOR") == v || (idle != nil && !idle()) {
			continue
		}
		if exe, err := os.Executable(); err != nil || !fileExists(exe) {
			continue // the program is being replaced right now
		}
		os.Setenv("FQ_RESTARTED_FOR", v)
		if logf != nil {
			logf("Funeral Quest %s is installed in this folder; restarting to run it (this is %s)", v, current)
		}
		if err := Restart(exitOnly); err != nil && logf != nil {
			logf("restart failed: %v", err)
			return
		}
	}
}

package fqnet_test

import (
	"strings"
	"testing"
	"time"

	"funeralquest/opmsg"
)

// A sysop's hand edit of a player is reported to the linked towns' sysops, and sysops can
// write to each other; both land in the Mailbox (opmsg) of the other town.
func TestSysopNotes(t *testing.T) {
	A := newTown(t, "Deathville")
	B := newTown(t, "Gravesend")
	B.a.SetSettings(map[string]string{"net_public_url": ""}) // B connects out only
	A.a.SetSettings(map[string]string{"net_auto_accept": "1"})
	alice := A.player(t, "Alice")
	B.player(t, "Bobby")
	if _, err := B.a.Net.AddPeer(A.srv.URL); err != nil {
		t.Fatal(err)
	}
	A.a.Via = "the web admin pages"
	if err := A.a.UpdatePlayer(alice, map[string]string{"exp": "99999", "luck": "100"}); err != nil {
		t.Fatal(err)
	}
	// A's own desk keeps a read copy
	if l := A.a.Notes.List(); len(l) != 1 || !l[0].Read || l[0].Kind != opmsg.KindEdit {
		t.Fatalf("A's record: %+v", l)
	}
	// B fetches (it can't be reached, so the note comes in A's answer)
	if err := B.a.Net.SyncPeer(peerID(B, "Deathville")); err != nil {
		t.Fatal(err)
	}
	notes := B.a.Notes.Unread()
	if len(notes) != 1 {
		t.Fatalf("B's mailbox: %+v", notes)
	}
	n := notes[0]
	for _, want := range []string{"Deathville", "Alice", "99999", "the web admin pages"} {
		if !strings.Contains(n.Text+n.Name+n.Account+n.From, want) {
			t.Errorf("edit note lacks %q: %+v", want, n)
		}
	}
	if n.Peer == "" {
		t.Error("no town ID to reply to")
	}
	// a second sync doesn't deliver it twice, and A stops sending it
	B.a.Net.SyncPeer(peerID(B, "Deathville"))
	B.a.Net.SyncPeer(peerID(B, "Deathville"))
	if len(B.a.Notes.List()) != 1 {
		t.Fatalf("delivered twice: %+v", B.a.Notes.List())
	}
	// B's sysop writes back; it goes in B's next sync
	if sent, err := B.a.WriteSysops(n.Peer, "Re: Alice", "Why did Alice get 99999 points?"); err != nil || sent != 1 {
		t.Fatalf("write: %d %v", sent, err)
	}
	B.a.Net.SyncPeer(peerID(B, "Deathville"))
	deadline := time.Now().Add(5 * time.Second)
	var got []opmsg.Msg
	for time.Now().Before(deadline) {
		if got = A.a.Notes.Unread(); len(got) > 0 {
			break
		}
		time.Sleep(50 * time.Millisecond)
	}
	if len(got) != 1 || got[0].Kind != opmsg.KindSysop || !strings.Contains(got[0].Text, "99999 points") || !strings.Contains(got[0].Text, "Subject: Re: Alice") {
		t.Fatalf("A's mailbox: %+v", got)
	}
}

func peerID(tw *town, name string) string {
	for _, p := range tw.a.Net.Peers() {
		if p.Name == name {
			return p.ID
		}
	}
	return ""
}

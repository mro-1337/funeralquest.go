package engine

import (
	"fmt"
	"sort"
	"strings"
	"time"
)

// Levels, dynasties, weekly challenges and seasons (1.8.0).
//
// Players earn experience from every Bury Point they earn (more when they're behind the
// town's average level) and from weekly challenges, and climb from level 1 to 60. At 60 they
// can retire into the Hall of Legends and carry on as their heir ("Name Jr.") with a family
// heirloom. Nothing is ever taken away by a season or a reset.

const MaxLevel = 60

// levelXP is the experience needed to reach level lv. With pace 100 that's about 17,000 for
// level 60: a few months of playing a few times a week.
func levelXP(lv, pace int) int {
	if lv <= 1 {
		return 0
	}
	return int(4.2 * float64(clamp(pace, 10, 1000)) / 100 * float64((lv-1)*(lv+9)))
}

func levelFor(xp, pace int) int {
	lv := 1
	for lv < MaxLevel && xp >= levelXP(lv+1, pace) {
		lv++
	}
	return lv
}

// LevelFor is the level that goes with xp experience at the town's pace.
func LevelFor(xp, pace int) int { return levelFor(xp, pace) }

func lvl(p *Player) int { return max(1, p.Level) }

var titles = []struct {
	lv   int
	name string
}{{60, "Living Legend"}, {50, "Master Mortician"}, {40, "Funeral Director"}, {30, "Mortician"}, {20, "Embalmer"}, {10, "Undertaker"}, {1, "Gravedigger"}}

// Title is the rank that goes with a level.
func Title(lv int) string {
	for _, t := range titles {
		if lv >= t.lv {
			return t.name
		}
	}
	return "Gravedigger"
}

// gainXP adds experience for Bury Points earned (with the catch-up bonus) and counts them
// for the season.
func gainXP(p *Player, bp int) {
	if bp <= 0 {
		return
	}
	p.XP = clamp(p.XP+bp*(100+clamp(p.XPBoost, 0, 100))/100, 0, 2e9)
	p.SeasonBP = clamp(p.SeasonBP+bp, 0, 2e9)
}

// levelUp applies any levels the player has earned and returns the news for them, or "".
func (g *Game) levelUp(w *World, p *Player) string {
	if p.Level < 1 {
		p.Level = 1
	}
	nl := levelFor(p.XP, w.Config.LevelPace)
	if nl <= p.Level {
		return ""
	}
	gold, title := 0, ""
	for lv := p.Level + 1; lv <= nl; lv++ {
		gold += 1 + lv/10
		if lv%10 == 0 {
			title = Title(lv)
		}
	}
	old := p.Level
	p.Level = nl
	p.Coffins[Gold] += gold
	p.HP = p.HPMax
	if title != "" {
		w.AddNews("front", fmt.Sprintf("`7%s IS NOW A %s\r\n`^%s of %s has reached level %d.\r\n\r\n",
			strings.ToUpper(p.Name), strings.ToUpper(title), p.Name, p.Parlor, nl))
	}
	msg := fmt.Sprintf("`wLEVEL UP!  `$You are now level `w%d`$ (%s).  You get `w%d`$ gold tag(s) and feel fully rested.", nl, Title(nl), gold)
	if nl/10 > old/10 {
		msg += "  From now on you have time for one more customer every day."
	}
	if nl == MaxLevel && p.AI == nil {
		msg += "\n\n`wYou have reached the top.  `$You can retire into the Hall of Legends and hand the parlor to your heir (Retire, at your desk), or carry on as a Living Legend."
	}
	return msg
}

// catchUp gives players below the town's average level more experience: 10% for each level
// behind, up to double.
func catchUp(w *World) {
	sum, n := 0, 0
	for _, p := range w.Active() {
		if p.AI == nil {
			sum += lvl(p)
			n++
		}
	}
	if n == 0 {
		return
	}
	avg := float64(sum) / float64(n)
	for _, p := range w.Active() {
		p.XPBoost = 0
		if p.AI == nil {
			p.XPBoost = clamp(int((avg-float64(lvl(p)))*10), 0, 100)
		}
	}
}

// tooBig says whether a level att player is too far above a level def one to raid them.
func tooBig(c *Config, att, def int) bool {
	return c.LevelGap > 0 && max(1, att)-max(1, def) > c.LevelGap
}

// ======================================================================== heirlooms and retiring

type heirloom struct {
	Key, Name, Desc string
	Max             int
}

var heirloomList = []heirloom{
	{"turns", "The family appointment book", "+2 turns every day", 3},
	{"psych", "Grandpa's psychology notes", "start one psychology level higher", 2},
	{"hearse", "The family hearse", "each heir keeps the hearse", 1},
	{"security", "The old padlock and smoke detector", "each heir starts with a padlock and a smoke detector", 1},
	{"profit", "The family ledger", "+2% profit on every sale", 3},
	{"luck", "Lucky rabbit's foot", "luck never drops below 30", 1},
}

func heirloomByKey(k string) *heirloom {
	for i := range heirloomList {
		if heirloomList[i].Key == k {
			return &heirloomList[i]
		}
	}
	return nil
}

// Legend is a retired parlor in the Hall of Legends.
type Legend struct {
	Name       string `json:"name"`
	Parlor     string `json:"parlor"`
	Generation int    `json:"generation"`
	Exp        int    `json:"exp"`
	Plots      int    `json:"plots"`
	Day        int    `json:"day"`
	Date       string `json:"date"`
}

var romans = []string{"", "", "Jr.", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII", "XIII", "XIV", "XV"}

// heirName is the founder's name with the generation added, e.g. "Earl Hatch Jr.".
func heirName(base string, gen int) string {
	suf := fmt.Sprint(gen)
	if gen < len(romans) {
		suf = romans[gen]
	}
	if max(1, gen) <= 1 {
		return base
	}
	room := 20 - len(suf) - 1
	if len(base) > room {
		base = strings.TrimSpace(base[:room])
	}
	return base + " " + suf
}

func genName(gen int) string {
	switch max(1, gen) {
	case 1:
		return "Founder"
	case 2:
		return "2nd generation"
	case 3:
		return "3rd generation"
	}
	return fmt.Sprintf("%dth generation", gen)
}

func (s *Session) cmdRetire(a Action) Screen {
	me := s.me()
	if me.AI != nil || max(lvl(me), levelFor(me.XP, s.cfg().LevelPace)) < MaxLevel {
		return s.cmdMain()
	}
	base := me.BaseName
	if base == "" {
		base = me.Name
	}
	gen := max(1, me.Generation) + 1
	heir := heirName(base, gen)
	scr := func(t string, bs []Button) Screen {
		return Screen{View: "generic", BG: "background/background_celemony", Pic: "places/funeral-ceremony", Text: t, Buttons: bs,
			Info: "Level 60.  A whole career of funerals behind you.  Maybe it's time to let the next generation take over."}
	}
	switch {
	case a.Sub == "":
		t := fmt.Sprintf("`wRetire into the Hall of Legends?\n\n`$Your parlor goes into the Hall of Legends for good.  `w%s`$ takes over %s, starting again at level 1, with one family heirloom you pick now (and every heirloom the family already has).\n\n`wPick an heirloom:\n", heir, me.Parlor)
		var bs []Button
		for i, h := range heirloomList {
			have := me.Heirlooms[h.Key]
			if have >= h.Max {
				t += fmt.Sprintf("`8%d. %s - %s (the family has all it can use)\n", i+1, h.Name, h.Desc)
				continue
			}
			t += fmt.Sprintf("`w%d. `$%s - %s", i+1, h.Name, h.Desc)
			if have > 0 {
				t += fmt.Sprintf(" `8(have %d of %d)", have, h.Max)
			}
			t += "\n"
			bs = append(bs, B(fmt.Sprint(i+1), "retire", "pick_"+h.Key).K(fmt.Sprint(i+1)))
		}
		if len(bs) == 0 {
			t += "\n`8The family has every heirloom it can use.  Retiring still adds a dynasty star.\n"
			bs = append(bs, B("Retire anyway", "retire", "pick_none").K("r"))
		}
		bs = append(bs, B("Not yet", "main", "").K("n").D())
		return scr(t, bs)

	case strings.HasPrefix(a.Sub, "pick_"):
		k := strings.TrimPrefix(a.Sub, "pick_")
		h := heirloomByKey(k)
		if (h == nil && k != "none") || (h != nil && me.Heirlooms[k] >= h.Max) {
			return s.cmdRetire(Action{})
		}
		what := "no new heirloom"
		if h != nil {
			what = h.Name + " (" + h.Desc + ")"
		}
		return scr(fmt.Sprintf("`$Retire `w%s`$ and hand %s to `w%s`$ with %s?\n\n`$This can't be undone.  Your Bury Points, tags, cash, plots and stats start over for your heir.", me.Name, me.Parlor, heir, what),
			[]Button{B("Yes, retire", "retire", "do_"+k).K("y"), B("No", "retire", "").K("n").D()})

	case strings.HasPrefix(a.Sub, "do_"):
		k := strings.TrimPrefix(a.Sub, "do_")
		h := heirloomByKey(k)
		if (h == nil && k != "none") || (h != nil && me.Heirlooms[k] >= h.Max) {
			return s.cmdRetire(Action{})
		}
		for g2 := gen + 1; g2 < gen+6; g2++ { // someone else already has that name: skip ahead
			if o := s.w.ByName(heir); o == nil || o.ID == me.ID {
				break
			}
			heir = heirName(base, g2)
		}
		return s.retire(h, base, gen, heir)
	}
	return s.cmdRetire(Action{})
}

func (s *Session) retire(h *heirloom, base string, gen int, heir string) Screen {
	me := s.me()
	c := s.cfg()
	s.w.Legends = append(s.w.Legends, Legend{me.Name, me.Parlor, max(1, me.Generation), me.Exp, me.Plots, s.age(), time.Now().Format("2006-01-02")})
	s.news("front", fmt.Sprintf("`7A LEGEND RETIRES\r\n`^After %s Bury Points and %s burials, %s hands the keys of %s to %s.  \"Don't let the customers see you cry,\" were the parting words.\r\n\r\n",
		Cash(me.Exp), Cash(me.Plots), me.Name, me.Parlor, heir))
	s.w.Deeds = append(s.w.Deeds, fmt.Sprintf("%s retired a Living Legend after %s Bury Points, and handed %s to %s.", me.Name, Cash(me.Exp), me.Parlor, heir))
	s.G.Broadcast(s.w, me.Name+" retires and hands "+me.Parlor+" to "+heir+"!")
	keep := *me
	if me.Heirlooms == nil {
		me.Heirlooms = map[string]int{}
	}
	if h != nil {
		me.Heirlooms[h.Key]++
	}
	heirlooms := me.Heirlooms
	s.G.freshStats(s.w, me)
	me.Name, me.BaseName, me.Generation, me.Heirlooms = heir, base, gen, heirlooms
	me.XP, me.Level, me.Week, me.SeasonBP, me.Trophies = 0, 1, keep.Week, keep.SeasonBP, keep.Trophies
	me.Logon, me.Password, me.BBSKey, me.Parlor, me.Male = keep.Logon, keep.Password, keep.BBSKey, keep.Parlor, keep.Male
	me.Psych = min(heirlooms["psych"], 5)
	if heirlooms["hearse"] > 0 {
		me.Transport = keep.Transport
	}
	if heirlooms["security"] > 0 {
		me.Custom.Padlock, me.Custom.PadlockStrength, me.Custom.FireAlarm = 1, 100, 1
	}
	if heirlooms["luck"] > 0 {
		me.Luck = max(me.Luck, 30)
	}
	catchUp(s.w)
	s.greeted = false
	_ = c
	t := fmt.Sprintf("`yYou hang up your apron for the last time.  Your name goes up in the Hall of Legends.\n\n`wA few days later...\n\n`$%s unlocks the front door of %s.  Big shoes to fill.", heir, keep.Parlor)
	if h != nil {
		t += fmt.Sprintf("\n\nIn the back office you find `w%s`$: %s.", h.Name, h.Desc)
	}
	return cont(Screen{View: "desk", Pic: "wait", Text: t}, "main", "Continue")
}

// heirTurns, heirProfit: the always-on heirlooms.
func heirTurns(p *Player) int  { return 2 * p.Heirlooms["turns"] }
func heirProfit(p *Player) int { return 2 * p.Heirlooms["profit"] }

// ======================================================================== weekly challenges

type Weekly struct {
	ID    string      `json:"id"` // ISO week, e.g. 2026-W48
	Ch    []Challenge `json:"ch"`
	Bonus bool        `json:"bonus,omitempty"` // the all-three bonus was paid
}

type Challenge struct {
	Kind string `json:"kind"`
	Need int    `json:"need"`
	Have int    `json:"have"`
	Done bool   `json:"done,omitempty"`
}

type challengeKind struct {
	Kind, Text string
	Lo, Hi     int
	ok         func(c *Config) bool
}

var challengeKinds = []challengeKind{
	{"bury", "Bury %d customers", 10, 20, nil},
	{"near", "Make %d sale(s) within $100 of what the customer can spend", 1, 3, nil},
	{"riddle", "Answer the ghost's riddle in the mausoleum %d time(s)", 1, 2, func(c *Config) bool { return c.GraveQuestsPerDay > 0 }},
	{"ghoul", "Beat the ghoul in the graveyard %d time(s)", 1, 2, func(c *Config) bool { return c.GraveQuestsPerDay > 0 }},
	{"dig", "Dig up %d grave(s)", 2, 4, func(c *Config) bool { return c.GraveQuestsPerDay > 0 }},
	{"tend", "Tend the graves %d time(s)", 2, 3, nil},
	{"fight", "Win %d fight(s) in a rival's parlor", 1, 2, nil},
	{"steal", "Steal tags from rivals %d time(s)", 1, 3, nil},
	{"donate", "Make %d donation(s) at the church", 2, 4, func(c *Config) bool { return c.DonateKarmaPerDay > 0 }},
	{"cafe", "Say something in the Pale Horse Cafe %d times", 3, 6, nil},
	{"bank", "Buy tags at the bank %d time(s)", 1, 2, func(c *Config) bool { return c.TagPrices != [3]int{} }},
}

func weekID(t time.Time) string {
	y, wk := t.ISOWeek()
	return fmt.Sprintf("%d-W%02d", y, wk)
}

func challengeText(ch Challenge) string {
	for _, k := range challengeKinds {
		if k.Kind == ch.Kind {
			return fmt.Sprintf(k.Text, ch.Need)
		}
	}
	return ch.Kind
}

// thisWeek makes sure the player has this week's three challenges.
func thisWeek(p *Player, c *Config) *Weekly {
	id := weekID(time.Now())
	if p.Week != nil && p.Week.ID == id {
		return p.Week
	}
	var pool []challengeKind
	for _, k := range challengeKinds {
		if k.ok == nil || k.ok(c) {
			pool = append(pool, k)
		}
	}
	wk := &Weekly{ID: id}
	for _, i := range randPerm(len(pool)) {
		if len(wk.Ch) == 3 {
			break
		}
		k := pool[i]
		wk.Ch = append(wk.Ch, Challenge{Kind: k.Kind, Need: randomRange(k.Lo, k.Hi)})
	}
	p.Week = wk
	return wk
}

func challengeXP(c *Config, base int) int { return base * clamp(c.LevelPace, 10, 1000) / 100 }

// progress counts n towards this week's challenges of that kind, and pays out the ones that
// are finished (experience now, tags and luck in a letter on the desk).
func (s *Session) progress(kind string, n int) {
	me := s.me()
	c := s.cfg()
	if me == nil || me.AI != nil || c.ChallengesOff || n <= 0 {
		return
	}
	wk := thisWeek(me, c)
	for i := range wk.Ch {
		ch := &wk.Ch[i]
		if ch.Kind != kind || ch.Done {
			continue
		}
		ch.Have = min(ch.Have+n, ch.Need)
		if ch.Have < ch.Need {
			continue
		}
		ch.Done = true
		xp := challengeXP(c, 150)
		me.XP += xp
		s.w.AddMail(Letter{To: me.ID, Pic: "stuff/money_bag_2", Tags: [3]int{0, 0, 1},
			Text: fmt.Sprintf("\n`wWEEKLY CHALLENGE DONE!\n\n`$%s.\n\nYou earn `w%d`$ experience and a `wgold tag`$.\n", challengeText(*ch), xp)})
	}
	all := len(wk.Ch) > 0
	for _, ch := range wk.Ch {
		all = all && ch.Done
	}
	if all && !wk.Bonus {
		wk.Bonus = true
		xp := challengeXP(c, 300)
		me.XP += xp
		s.w.AddMail(Letter{To: me.ID, Pic: "stuff/lottery_win", Tags: [3]int{0, 0, 2}, Luck: 5,
			Text: fmt.Sprintf("\n`wALL THREE CHALLENGES DONE THIS WEEK!\n\n`$Bonus: `w%d`$ experience, `w2`$ gold tags and `w5`$ luck.  New challenges on Monday.\n", xp)})
	}
}

func (s *Session) cmdChallenges() Screen {
	me := s.me()
	c := s.cfg()
	s.setLocation("Challenges")
	lv := lvl(me)
	t := fmt.Sprintf("`wLevel %d `$- %s", lv, Title(lv))
	if g := max(1, me.Generation); g > 1 {
		t += fmt.Sprintf("  `8(%s, %s)", genName(g), strings.Repeat("*", g-1))
	}
	if lv < MaxLevel {
		cur, next := levelXP(lv, c.LevelPace), levelXP(lv+1, c.LevelPace)
		t += fmt.Sprintf("\n`$Experience: `w%s`$  (`w%s`$ more to level %d)", Cash(me.XP), Cash(max(0, next-me.XP)), lv+1)
		t += "\n`2" + strings.Repeat("#", clamp((me.XP-cur)*30/max(1, next-cur), 0, 30)) + "`8" + strings.Repeat(".", 30-clamp((me.XP-cur)*30/max(1, next-cur), 0, 30))
	} else {
		t += "\n`$You're at the top.  Retire at your desk to start a dynasty, or keep going as a Living Legend."
	}
	if me.XPBoost > 0 {
		t += fmt.Sprintf("\n`$Catching up: you earn `w%d%%`$ more experience until you reach the town's average level.", me.XPBoost)
	}
	sheet := func(t string) Screen {
		return Screen{View: "sheet", Title: "Level and weekly challenges", Text: t, Buttons: []Button{B("Back", "main", "").K("b").D()}}
	}
	if c.ChallengesOff {
		return sheet(t + "\n\n`8There are no weekly challenges in this town.")
	}
	wk := thisWeek(me, c)
	left := 8 - int(time.Now().Weekday())
	if time.Now().Weekday() == time.Sunday {
		left = 1
	} else if left > 7 {
		left = 7
	}
	t += fmt.Sprintf("\n\n`wThis week's challenges `8(new ones in %d day(s))\n", left)
	for _, ch := range wk.Ch {
		mark := "`$[ ]"
		if ch.Done {
			mark = "`2[X]"
		}
		t += fmt.Sprintf("%s `$%s  `w%d/%d\n", mark, challengeText(ch), ch.Have, ch.Need)
	}
	t += fmt.Sprintf("\n`8Each one: %d experience and a gold tag.  All three: %d more experience, 2 gold tags and 5 luck.", challengeXP(c, 150), challengeXP(c, 300))
	return sheet(t)
}

// ======================================================================== seasons

// seasonCheck ends the season when it's over (called from the nightly maintenance).
func (g *Game) seasonCheck(w *World) {
	c := w.Config
	if c.SeasonDays <= 0 {
		w.Glo.SeasonStart, w.Glo.Season = 0, 0
		return
	}
	if w.Glo.SeasonStart == 0 || w.Glo.SeasonStart > w.Glo.GameAge {
		w.Glo.SeasonStart, w.Glo.Season = max(1, w.Glo.GameAge), max(1, w.Glo.Season)
		for _, p := range w.Players {
			p.SeasonBP = 0
		}
		return
	}
	if w.Glo.GameAge-w.Glo.SeasonStart < c.SeasonDays {
		return
	}
	top := seasonRanked(w)
	prizes := []int{1000, 500, 250}
	places := []string{"won", "came second in", "came third in"}
	story := fmt.Sprintf("`7SEASON %d IS OVER\r\n`^", w.Glo.Season)
	for i, p := range top {
		if i >= 3 || p.SeasonBP <= 0 {
			break
		}
		xp := prizes[i] * clamp(c.LevelPace, 10, 1000) / 100
		p.XP += xp
		if i == 0 {
			p.Trophies++
		}
		w.Deeds = append(w.Deeds, fmt.Sprintf("%s %s season %d with %s Bury Points.", p.Name, places[i], w.Glo.Season, Cash(p.SeasonBP)))
		story += fmt.Sprintf("%s %s it with %s Bury Points.  ", p.Name, places[i], Cash(p.SeasonBP))
		w.AddMail(Letter{To: p.ID, Pic: "stuff/lottery_win", Text: fmt.Sprintf("\n`wSEASON %d IS OVER!\n\n`$You %s the season with `w%s`$ Bury Points.  You earn `w%d`$ experience%s.\n",
			w.Glo.Season, places[i], Cash(p.SeasonBP), xp, ifs(i == 0, " and the season trophy", ""))})
	}
	w.AddNews("front", story+"A new season starts today.\r\n\r\n")
	for _, p := range w.Players {
		p.SeasonBP = 0
	}
	w.Glo.Season++
	w.Glo.SeasonStart = w.Glo.GameAge
}

func seasonRanked(w *World) []*Player {
	var out []*Player
	for _, p := range w.Active() {
		if p.AI == nil {
			out = append(out, p)
		}
	}
	sort.SliceStable(out, func(i, j int) bool { return out[i].SeasonBP > out[j].SeasonBP })
	return out
}

func (s *Session) cmdSeason() Screen {
	c := s.cfg()
	back := []Button{B("Continue", "cityhall", "").D()}
	if c.SeasonDays <= 0 {
		return s.cmdCityHall()
	}
	var rows []RankRow
	for _, p := range seasonRanked(s.w) {
		st := ""
		if p.Trophies > 0 {
			st = fmt.Sprintf("%d %s", p.Trophies, ifs(p.Trophies == 1, "trophy", "trophies"))
		}
		rows = append(rows, RankRow{p.Name, p.Male, p.Parlor, p.SeasonBP, st, lvl(p)})
	}
	day := s.age() - s.w.Glo.SeasonStart + 1
	return Screen{View: "ranking", Title: fmt.Sprintf("Season %d standings - day %d of %d", max(1, s.w.Glo.Season), clamp(day, 1, c.SeasonDays), c.SeasonDays), RankRows: rows, Buttons: back}
}

// ======================================================================== Hall of Legends

func (s *Session) legendsText() string {
	if len(s.w.Legends) == 0 {
		return "`yThe Hall of Legends is an old marble mausoleum with empty name plates.  Nobody has retired a Living Legend yet.\n\n`$Reach level 60 to be the first."
	}
	t := "`yName plates line the marble walls of the Hall of Legends:\n\n"
	for i := len(s.w.Legends) - 1; i >= 0 && i >= len(s.w.Legends)-15; i-- {
		l := s.w.Legends[i]
		t += fmt.Sprintf("`w%s `$of %s  `8(%s, %s BP, %s burials, retired day %d)\n", l.Name, l.Parlor, genName(l.Generation), Cash(l.Exp), Cash(l.Plots), l.Day)
	}
	if len(s.w.Legends) > 15 {
		t += fmt.Sprintf("\n`8...and %d more.", len(s.w.Legends)-15)
	}
	return t
}

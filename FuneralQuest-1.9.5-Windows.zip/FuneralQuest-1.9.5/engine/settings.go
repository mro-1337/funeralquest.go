package engine

import (
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
)

// SettingInfo describes one sysop setting for the editors (fqedit, the web sysop pages, fq admin).
type SettingInfo struct {
	Key   string  `json:"key"`
	Group string  `json:"group"`
	Label string  `json:"label"`
	Help  string  `json:"help"`
	Kind  string  `json:"kind"` // int, float, bool, text, ints3
	Min   float64 `json:"min"`
	Max   float64 `json:"max"`
}

var Settings = []SettingInfo{
	{"server_name", "Game", "Town name", "Name of the town, shown on the log-on screen and to linked servers.", "text", 1, 30},
	{"turns_per_day", "Game", "Turns per day", "How many customers' worth of turns each player gets every day.", "int", 1, 500},
	{"max_players", "Game", "Maximum players", "New parlors are refused once this many are open.", "int", 1, 100000},
	{"inactive_days", "Game", "Days before closing idle parlors", "Parlors not played for this many days are closed at maintenance.", "int", 1, 3650},
	{"maint_delete", "Game", "Delete closed parlors", "Remove closed parlors from the data file at maintenance, instead of keeping them.", "bool", 0, 0},
	{"online_timeout_minutes", "Game", "Online timeout (minutes)", "A player who does nothing this long no longer shows as online.", "int", 1, 600},
	{"name_change_cost", "Game", "Name change cost (luck)", "Luck it costs to change your name at City Hall.", "int", 0, 1000},

	{"starting_money", "New players", "Starting money", "Cash a new parlor starts with. NETWORKED TOWNS: must match every linked town (the default, unless a settings vote changed it). Changing it by hand stops this town playing with linked towns until it's put back.", "int", 0, 100000000},
	{"starting_luck", "New players", "Starting luck", "NETWORKED TOWNS: must match every linked town (the default, unless a settings vote changed it). Changing it by hand stops this town playing with linked towns until it's put back.", "int", 0, 10000},
	{"starting_hp", "New players", "Starting hit points", "NETWORKED TOWNS: must match every linked town (the default, unless a settings vote changed it). Changing it by hand stops this town playing with linked towns until it's put back.", "int", 1, 10000},
	{"starting_strength", "New players", "Starting strength", "NETWORKED TOWNS: must match every linked town (the default, unless a settings vote changed it). Changing it by hand stops this town playing with linked towns until it's put back.", "int", 0, 10000},
	{"starting_karma", "New players", "Starting karma", "0-100. NETWORKED TOWNS: must match every linked town (the default, unless a settings vote changed it). Changing it by hand stops this town playing with linked towns until it's put back.", "int", 0, 100},
	{"starting_rating", "New players", "Starting rating", "0-100. NETWORKED TOWNS: must match every linked town (the default, unless a settings vote changed it). Changing it by hand stops this town playing with linked towns until it's put back.", "int", 0, 100},

	{"casket_sp", "Scoring", "Casket points (wood,silver,gold)", "From the original's first, simple sale. The current sale (from the original's later versions) scores by price and the trade bonus, so this has no effect; kept so old settings files load.", "ints3", 0, 1000},
	{"plot_sp", "Scoring", "Plot points", "From the original's first, simple sale; has no effect in the current sale. Kept so old settings files load.", "int", 0, 1000},
	{"profit_min", "Scoring", "Lowest profit per sale (%)", "After operating costs and insurance, a player keeps a net profit of somewhere between the lowest and highest percent of each funeral's bill as cash (real funeral homes keep about 6 to 15 percent). Sales that hit close to the customer's limit add 2 percent. 0 and 0 = no cash from sales.", "int", 0, 100},
	{"profit_max", "Scoring", "Highest profit per sale (%)", "See Lowest profit per sale.", "int", 0, 100},
	{"tag_prices", "Scoring", "Tag prices at the bank (wood,silver,gold)", "Cash price of one wood, silver and gold tag at the bank, e.g. 500,1000,2000. 0 = that kind isn't for sale.", "ints3", 0, 100000000},
	{"bonus_exp", "Scoring", "Top seller BP bonus", "Bury points given to the day's top seller.", "int", 0, 100000},
	{"bonus_luck", "Scoring", "Top seller luck bonus", "", "int", 0, 100000},
	{"trade_bonus", "Scoring", "Trade bonus (%)", "", "int", 0, 1000},

	{"risk", "Odds", "Double-or-nothing risk", "Chance (0-100) that a double-or-nothing risk goes badly.", "int", 0, 100},
	{"normal_odds", "Odds", "Random event odds", "Chance of a random parlor event per turn (0-1).", "float", 0, 1},
	{"luck_odds", "Odds", "Luck event odds", "Chance of a luck event per turn (0-1).", "float", 0, 1},
	{"script_odds", "Odds", "Special event odds", "Chance of a special event per turn (0-1).", "float", 0, 1},
	{"yangs_per_day", "Odds", "Fortune cookies per day", "How many fortune cookies (yangs) a player may send per day.", "int", 0, 100},
	{"visits_per_day", "Odds", "Rival visits per day", "How many times a player may break into rival parlors per day.", "int", 0, 100},
	{"tags_receivable_per_day", "Odds", "Tags received per day", "How many toe tags a player may be sent per day.", "int", 0, 100},

	{"karma_sin", "Church & graveyard", "Karma lost per bad deed", "Karma a player loses for stealing tags, hiring the Twins or digging up a grave. 0 = bad deeds don't touch karma.", "int", 0, 100},
	{"donate_karma_per_day", "Church & graveyard", "Karma from donations per day", "Most karma a player can gain from church donations each day (a wood tag is 1 karma, silver 2, gold 4). 0 = no donations.", "int", 0, 100},
	{"confess_cost", "Church & graveyard", "Confession cost (wood tags)", "Wood tags the church asks for a confession (once a day, only for players below 50 karma).", "int", 0, 1000},
	{"confess_karma", "Church & graveyard", "Karma from confession", "Karma a confession gives back (never above 50). 0 = no confessions.", "int", 0, 100},
	{"bless_karma", "Church & graveyard", "Karma needed for a blessing", "Players with at least this much karma can get a blessing once a day.", "int", 0, 100},
	{"bless_luck", "Church & graveyard", "Luck from a blessing", "0 = no blessings.", "int", 0, 100},
	{"grave_quests_per_day", "Church & graveyard", "Graveyard quests per day", "How many graveyard quests (digging, the mausoleum, the ghoul, helping the gravedigger) a player may do each day. They don't cost turns. 0 = graveyard closed.", "int", 0, 100},

	{"level_pace", "Levels", "Leveling pace (%)", "How much experience each level takes: 100 = normal (someone playing a few times a week reaches level 60 in about two to three months), 50 = twice as fast, 200 = twice as slow.", "int", 10, 1000},
	{"level_gap", "Levels", "Raid level gap", "Players can't break into, fight or burn the parlor of anyone more than this many levels below them (raiding up is always allowed). 0 = no limit.", "int", 0, 60},
	{"rest_days", "Levels", "Rested days", "Turns not used carry over for up to this many days, so players who can't play every day still get a full session. 0 = unused turns are lost at midnight (the original game).", "int", 0, 14},
	{"challenges_off", "Levels", "No weekly challenges", "Yes: turn off the three weekly challenges.", "bool", 0, 0},
	{"season_days", "Levels", "Season length (days)", "Optional seasons: every this many days the town's top three in Bury Points earned that season win a trophy, a place in the Book of Deeds and bonus experience, and the season race starts over. Levels, dynasties and Bury Points are never reset. 0 = no seasons.", "int", 0, 3650},

	{"heal_cost", "Hospital", "Patch-up cost (gold tags)", "What the hospital charges to heal a player's hit points all the way. Each patch-up the same day costs this much more again (1, 2, 3...). 0 = the hospital doesn't heal.", "int", 0, 1000},
	{"morgue_cost", "Hospital", "Morgue tip cost (gold tags)", "What the morgue attendant wants for a tip on families about to need a funeral (once a day). 0 = no tips.", "int", 0, 1000},
	{"morgue_turns", "Hospital", "Customers from a morgue tip", "Extra turns (customers) a morgue tip gives.", "int", 0, 100},
	{"volunteer_karma", "Hospital", "Karma for volunteering", "Karma a player gets for spending a turn sitting with patients (once a day). 0 = no volunteering.", "int", 0, 100},
	{"fight_full_hp", "Hospital", "Heal before every fight", "Yes: everyone starts every fight with full hit points, as in the original game, and losing a fight doesn't stop you raiding again. No (normal): you fight with the hit points you have; at 0 you can't raid until a new day or a visit to the hospital.", "bool", 0, 0},

	{"ai_players", "AI players", "AI players", "Computer-run parlors that live in town: they sell funerals, shop, break into parlors, start fires, talk in the cafe and put announcements in the paper. Players can raid them too. 0 = none. Lowering it closes the extra AI parlors.", "int", 0, 8},
	{"ai_skill", "AI players", "AI skill (%)", "How hard AI players work, as a percent of a full day of turns. They never get the daily top-seller bonuses and never train past the town's average human player.", "int", 10, 100},
	{"ai_attacks_off", "AI players", "AI players don't attack", "Yes: AI players never break into, fight or burn anyone's parlor (players can still raid them).", "bool", 0, 0},
	{"ai_chat_off", "AI players", "AI players stay quiet", "Yes: AI players don't talk in the cafe or put announcements in the paper.", "bool", 0, 0},

	{"tourn_active", "Tournament", "Tournament mode", "Run the game as a tournament that ends after a set number of days.", "bool", 0, 0},
	{"tourn_days", "Tournament", "Tournament length (days)", "", "int", 1, 3650},

	{"backup_days", "Security", "Backup every (days)", "Make a zip backup of the data folder (players, settings, news, network keys) this often, in data/backups. 0 = no automatic backups (fq admin backup still works).", "int", 0, 365},
	{"backup_keep", "Security", "Backups to keep", "Older automatic backups are deleted. Backups made before an upgrade are always kept.", "int", 1, 1000},
	{"net_sync_seconds", "Performance", "Sync with linked towns every (seconds)", "How often this town swaps players, letters and news with each linked town. 30 (normal; 0 means 30). On a slow server or a slow connection with many linked towns, 60 to 300 is easier on it. Your own chat and letters still go out right away.", "int", 0, 900},
	{"net_live_off", "Performance", "No live chat connections", "No (normal): one connection per linked town stays open so chat from other towns shows up in the cafe at once. Yes: no open connections; other towns' chat arrives with each sync instead (see the setting above). Saves memory and connections on small servers.", "bool", 0, 0},
	{"memory_limit_mb", "Performance", "Memory limit (MB)", "0 (normal) = no limit. On a small VPS or a Raspberry Pi, a limit such as 64 or 128 makes fq tidy up its memory sooner to stay under it (a little more CPU, less RAM). It's a target, not a hard cap. Takes effect when fq starts.", "int", 0, 4096},

	{"update_check_off", "Updates", "Don't check for updates", "No (normal): every so often (see the next setting) fq asks GitHub whether a newer Funeral Quest has been released, and the Updates tab shows it with an Install button. Yes: never check (Check now on the Updates tab and fq -update still work).", "bool", 0, 0},
	{"update_auto", "Updates", "Install updates automatically", "No (normal): new versions are only shown on the Updates tab and installed when you say so. Yes: when fq finds a new version (see Check for updates every), it downloads it right away (even while people play) and installs it once nobody is playing, then restarts on it. The data folder is backed up first, as always, and the Updates tab can go back.", "bool", 0, 0},
	{"update_check_hours", "Updates", "Check for updates every (hours)", "How often fq asks GitHub whether a new version is out: 1 (normal; 0 also means 1) up to 168 (once a week). With automatic updates on, a new version is downloaded when it's found and installed once nobody is playing.", "int", 0, 168},
	{"update_repo", "Updates", "Get updates from", "The GitHub project whose Releases page has the updates, as owner/name. Empty = the official one (mro-1337/funeralquest.go).", "text", 0, 100},
	{"update_exit_only", "Updates", "My service manager restarts it", "No (normal): after an update fq restarts itself. Yes: fq just exits (with exit code 3) and your service manager (NSSM, a Windows service, systemd with Restart=always) starts the new version.", "bool", 0, 0},

	{"web_hide_admin_link", "Security", "Hide the Admin link", "No (normal, and always until the admin password is set up): the web log-on page shows an Admin link. Yes: the link is hidden; the sysop pages still work at /sysop for whoever knows the address.", "bool", 0, 0},
	{"sysop_captcha_off", "Security", "No puzzle with the admin password", "No (normal): logging on to the sysop pages also asks for the letters on a \"prove you're among the living\" gravestone, which slows down password-guessing programs. Yes: just the password.", "bool", 0, 0},
	{"signup_captcha_off", "Security", "No puzzle for new parlors", "No (normal): opening a new parlor on the web or by telnet asks for the letters on a \"prove you're among the living\" gravestone, so programs can't make accounts. Yes: no puzzle. (BBS door callers never get it: the BBS already signed them up.)", "bool", 0, 0},
	{"ban_strikes", "Security", "Strikes before a ban", "Failed logons or attacks from one address within 10 minutes that cause a temporary ban.", "int", 1, 100},
	{"ban_minutes", "Security", "First ban length (minutes)", "Each repeat ban for the same address is twice as long (up to 7 days).", "int", 1, 10080},
	{"ban_conn_per_minute", "Security", "Connections per minute", "More new telnet connections than this per minute from one address is a flood and gets banned.", "int", 1, 1000},
	{"ban_max_per_ip", "Security", "Connections at once per address", "", "int", 1, 100},
	{"sysop_allow", "Security", "Admin pages allowed from", "IPs/ranges allowed to open the web admin pages (/sysop/), comma separated (e.g. 127.0.0.1, 192.168.0.0/16). Empty = anywhere.", "text", 0, 500},

	{"web_port", "Server (restart to apply)", "Web server port", "Port for the web game, sysop pages and the network link. 0 = 8080. Restart fq web after changing it, and update This server's web address to match.", "int", 0, 65535},
	{"web_host", "Server (restart to apply)", "Web server listens on", "IP address to listen on. Empty = every network card. 127.0.0.1 = only this machine (behind your own proxy).", "text", 0, 60},
	{"web_cert", "Server (restart to apply)", "HTTPS certificate file", "Full path of a PEM certificate (e.g. fullchain.pem). Set this and the key file to serve HTTPS. Empty = plain HTTP.", "text", 0, 300},
	{"web_key", "Server (restart to apply)", "HTTPS key file", "Full path of the PEM private key that goes with the certificate.", "text", 0, 300},
	{"web_trust_proxy", "Server (restart to apply)", "Behind my own proxy", "Yes if Caddy, IIS or nginx on this machine or your LAN passes requests on, so bans hit the real caller's address.", "bool", 0, 0},
	{"telnet_port", "Server (restart to apply)", "Telnet server port", "Port for  fq telnet  (the stand-alone telnet server, not needed when running as a door). 0 = 2323.", "int", 0, 65535},
	{"net_port", "Server (restart to apply)", "Network port", "A port just for other Funeral Quest servers, opened by fq web, fq telnet or fq net. Use it when your web game is behind a proxy such as Caddy, or to keep town-to-town traffic apart: forward it on your router and set This server's web address to http://your.host:thatport (https:// if you made a certificate). 0 = none: fq web uses its own port; telnet/net connect out only.", "int", 0, 65535},
	{"net_port_https", "Server (restart to apply)", "HTTPS on the network port", "No (normal): the network port uses plain HTTP; messages between towns are signed either way, so nobody can fake or change them. Yes: use this server's HTTPS certificate there too (Security tab), which also keeps letters private on the way.", "bool", 0, 0},
	{"sound_off", "Server (restart to apply)", "No sound for callers", "Never send sound to door and telnet callers.", "bool", 0, 0},

	{"rlogin_port", "RLogin", "RLogin port", "Port for RLogin callers (BBS gateways, SyncTERM's RLogin). 0 = RLogin off. The standard port is 513 (needs admin rights on Linux); BBS games often use something like 1513. Runs with  fq telnet  or  fq rlogin. Restart to apply.", "int", 0, 65535},
	{"rlogin_trusted", "RLogin", "Hosts allowed to connect", "IPs or ranges allowed to use RLogin, comma separated. * = anyone (then the gateway secret and players' own passwords protect logins). If your BBS is on this machine, 127.0.0.1 is safest.", "text", 0, 500},
	{"rlogin_secret", "RLogin", "BBS gateway secret", "Shared secret your BBS sends with the caller's name (Synchronet rlogin_gate, Mystic IR /pass=). Whoever has it can enter under any name, so make it long and private. Empty = no gateway logins; callers must send their own game logon and password.", "text", 0, 120},
	{"rlogin_bbs_id", "RLogin", "BBS ID for gateway callers", "Gateway callers are the same players as door callers from the BBS with this ID (the door's --bbs-id, normally bbs), so a caller keeps their parlor whichever way they come in.", "text", 1, 30},

	{"net_public_url", "Network", "This server's web address", "The address other Funeral Quest servers use to reach you, e.g. http://bbs.example.com:8080", "text", 0, 200},
	{"net_port_only", "Network", "Linked servers use the network port only", "Yes: other Funeral Quest servers connect to the Network port (Settings → Server), not the web port. The address given to linked towns switches to the network port by itself (same host name), and the web port stops answering other servers, so linking never goes through Caddy or the web game.", "bool", 0, 0},
	{"net_relay_off", "Network", "Don't pass on messages for other towns", "No (normal): when two linked towns can't reach each other (both connect out only, say), this town passes their messages on, so their players can see, write to and raid each other. Messages stay signed by the town that wrote them, so they can't be faked or changed on the way. Yes: don't pass anything on.", "bool", 0, 0},
	{"net_auto_accept", "Network", "Accept link requests automatically", "Off: link requests from other servers wait for you to accept them.", "bool", 0, 0},
	{"net_chat_off", "Network", "Turn off network chat", "Stop sharing Cafe chat with linked servers.", "bool", 0, 0},
	{"net_mail_off", "Network", "Turn off network mail", "Stop letters to and from players on linked servers.", "bool", 0, 0},
	{"net_news_off", "Network", "Turn off network news", "No (normal): your town's newspaper stories (announcements, crimes, fires, big sales, new parlors, City Hall notices) are printed in linked towns' papers too, marked with your town's name, and theirs in yours. Yes: keep your paper to yourself and don't print theirs.", "bool", 0, 0},
	{"net_raids_off", "Network", "Turn off out-of-town raids", "Stop break-ins, fights and arson between your players and linked towns (both ways).", "bool", 0, 0},
	{"net_intro_off", "Network", "Don't follow introductions", "No (normal): when a linked town introduces the other towns it's linked to, this town sends them link requests, so every town ends up linked to every other. Yes: link only to towns you add yourself.", "bool", 0, 0},
	{"net_share_links_off", "Network", "Don't introduce my links", "No (normal): tell linked towns which other towns you're linked to, so they can link to them too. Yes: keep your list of links to yourself.", "bool", 0, 0},
	{"net_accept_introduced", "Network", "Accept introduced towns automatically", "Yes: a link request from a town that one of your linked towns is linked to is accepted without asking. (Two towns that both follow introductions link up by themselves anyway; this matters for towns that connect out only.)", "bool", 0, 0},
	{"net_vote_apply_off", "Network", "Don't apply settings votes", "No (normal): when a settings vote among linked towns passes, this town switches to those settings even if you voted no. Yes: votes only change the new-player settings (starting money, luck, hit points, strength, karma and rating), which every linked town has to share.", "bool", 0, 0},
	{"net_raids_per_day", "Network", "Out-of-town raids per player per day", "How many times visitors from linked towns can raid or burn one of your players each day.", "int", 1, 100},
}

// Version is the release number of the game (major.minor.patch). Linked towns compare
// versions and tell the sysop running the older one to update. See CHANGES.md.
const Version = "1.9.5"

// SharedSettings are the game rules linked towns should agree on, so nobody gets an edge
// (turns, starting stats, scoring, odds, limits). Local things like the town name, security
// and housekeeping aren't compared.
var SharedSettings = []string{"turns_per_day", "name_change_cost", "starting_money", "starting_luck", "starting_hp",
	"starting_strength", "starting_karma", "starting_rating", "casket_sp", "plot_sp", "bonus_exp", "bonus_luck",
	"trade_bonus", "risk", "normal_odds", "luck_odds", "script_odds", "yangs_per_day", "visits_per_day",
	"tags_receivable_per_day", "tourn_active", "tourn_days", "net_raids_per_day",
	"karma_sin", "donate_karma_per_day", "confess_cost", "confess_karma", "bless_karma", "bless_luck", "grave_quests_per_day",
	"profit_min", "profit_max", "tag_prices", "level_pace", "level_gap", "rest_days", "challenges_off",
	"heal_cost", "morgue_cost", "morgue_turns", "volunteer_karma", "fight_full_hp"}

// ProtectedSettings are the new-player settings every linked town must keep at the network's
// values (the defaults unless a settings vote passed). A town that changes one by hand can't
// play with linked towns until it's put back.
var ProtectedSettings = []string{"starting_money", "starting_luck", "starting_hp", "starting_strength", "starting_karma", "starting_rating"}

// SettingLabel is a setting's name as the sysop pages show it.
func SettingLabel(key string) string {
	for _, s := range Settings {
		if s.Key == key {
			return s.Label
		}
	}
	return key
}

// Rules returns this town's shared settings.
func (c *Config) Rules() map[string]string {
	m := map[string]string{}
	for _, k := range SharedSettings {
		m[k] = c.Get(k)
	}
	return m
}

// CompareVersions returns -1, 0 or 1 for versions like "1.3.0".
func CompareVersions(a, b string) int {
	pa, pb := strings.Split(a, "."), strings.Split(b, ".")
	for i := 0; i < max(len(pa), len(pb)); i++ {
		var x, y int
		if i < len(pa) {
			x, _ = strconv.Atoi(pa[i])
		}
		if i < len(pb) {
			y, _ = strconv.Atoi(pb[i])
		}
		if x != y {
			if x < y {
				return -1
			}
			return 1
		}
	}
	return 0
}

func SettingByKey(k string) *SettingInfo {
	for i := range Settings {
		if Settings[i].Key == k {
			return &Settings[i]
		}
	}
	return nil
}

func (c *Config) asMap() map[string]any {
	m := map[string]any{}
	b, _ := json.Marshal(c)
	json.Unmarshal(b, &m)
	return m
}

// Get returns a setting as text.
func (c *Config) Get(key string) string {
	v, ok := c.asMap()[key]
	if !ok {
		return ""
	}
	switch x := v.(type) {
	case []any:
		var parts []string
		for _, e := range x {
			parts = append(parts, fmt.Sprint(e))
		}
		return strings.Join(parts, ",")
	case float64:
		return strconv.FormatFloat(x, 'f', -1, 64)
	}
	return fmt.Sprint(v)
}

// Set checks and changes one setting given as text.
func (c *Config) Set(key, val string) error {
	info := SettingByKey(key)
	if info == nil {
		return fmt.Errorf("unknown setting %q", key)
	}
	val = strings.TrimSpace(val)
	m := c.asMap()
	num := func(s string) (float64, error) {
		f, err := strconv.ParseFloat(strings.TrimSpace(s), 64)
		if err != nil {
			return 0, fmt.Errorf("%s: %q is not a number", info.Label, s)
		}
		if f < info.Min || f > info.Max {
			return 0, fmt.Errorf("%s must be between %v and %v", info.Label, info.Min, info.Max)
		}
		if info.Kind != "float" && f != float64(int64(f)) {
			return 0, fmt.Errorf("%s must be a whole number", info.Label)
		}
		return f, nil
	}
	switch info.Kind {
	case "bool":
		switch strings.ToLower(val) {
		case "true", "yes", "on", "1", "y":
			m[key] = true
		case "false", "no", "off", "0", "n":
			m[key] = false
		default:
			return fmt.Errorf("%s: use yes or no", info.Label)
		}
	case "int", "float":
		f, err := num(val)
		if err != nil {
			return err
		}
		m[key] = f
	case "ints3":
		parts := strings.Split(val, ",")
		if len(parts) != 3 {
			return fmt.Errorf("%s: give three numbers separated by commas", info.Label)
		}
		var arr []float64
		for _, p := range parts {
			f, err := num(p)
			if err != nil {
				return err
			}
			arr = append(arr, f)
		}
		m[key] = arr
	case "text":
		if strings.ContainsAny(val, "\r\n\x00\x1b") {
			return fmt.Errorf("%s: one line of plain text, please", info.Label)
		}
		if float64(len(val)) < info.Min || float64(len(val)) > info.Max {
			return fmt.Errorf("%s must be %v to %v characters", info.Label, info.Min, info.Max)
		}
		m[key] = val
	}
	b, _ := json.Marshal(m)
	var nc Config
	if err := json.Unmarshal(b, &nc); err != nil {
		return err
	}
	*c = nc
	return nil
}

package door

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"funeralquest/engine"
	"funeralquest/guard"
)

// Screen layout (80x25): stats panel cols 1-40 rows 1-14, picture cols 41-80 rows 1-14
// (320x224 pixels with SyncTERM's 8x16 font), text rows 15-22, buttons rows 23-24.
const (
	picCol, picRow, picCols, picRows  = 41, 1, 40, 14
	textRow, textRows, textCol, textW = 15, 8, 2, 78
	btnRow                            = 23
	artW, artH                        = 308, 224
)

var codeColor = map[byte]int{'1': 1, '2': 2, '3': 3, '4': 12, '5': 13, '6': 6, '7': 7, '8': 8, '9': 9, '0': 10, '!': 11, '@': 12, '#': 13, '$': 14, 'y': 14, 'w': 15, '^': 7}
var ansiOrder = [8]int{0, 4, 2, 6, 1, 5, 3, 7}

func sgr(fg int) string {
	b := "22;"
	if fg >= 8 {
		b = "1;"
	}
	return fmt.Sprintf("%s0;%s%dm", csi, b, 30+ansiOrder[fg%8])
}
func at(row, col int) string { return fmt.Sprintf("%s%d;%dH", csi, row, col) }

// toAnsi converts `x colour codes to ANSI.
func toAnsi(s string) string {
	var b strings.Builder
	for i := 0; i < len(s); i++ {
		if s[i] == '`' && i+1 < len(s) {
			c := s[i+1]
			i++
			if c == 'f' {
				i++
				continue
			}
			if col, ok := codeColor[c]; ok {
				b.WriteString(sgr(col))
			}
			continue
		}
		b.WriteByte(s[i])
	}
	return b.String()
}

func plainLen(s string) int { return len([]rune(engine.StripCodes(s))) }

// dots cuts s to n characters, ending in "..." when it had to cut.
func dots(s string, n int) string {
	r := []rune(s)
	if len(r) <= n {
		return s
	}
	if n <= 3 {
		return string(r[:n])
	}
	return strings.TrimRight(string(r[:n-3]), " ") + "..."
}

func pad(s string, n int) string {
	r := []rune(s)
	if len(r) >= n {
		return string(r[:n])
	}
	return s + strings.Repeat(" ", n-len(r))
}

// wrap word-wraps coloured text; every line starts with the colour in effect.
func wrap(text string, width int, start byte) []string {
	var out []string
	color := start
	for _, para := range strings.Split(strings.ReplaceAll(text, "\r", ""), "\n") {
		line := "`" + string(color)
		n := 0
		for _, word := range strings.SplitAfter(para, " ") {
			if word == "" {
				continue
			}
			wl := plainLen(word)
			trimmed := strings.TrimRight(engine.StripCodes(word), " ")
			if n+len([]rune(trimmed)) > width && n > 0 {
				out = append(out, strings.TrimRight(line, " "))
				line, n = "`"+string(color), 0
			}
			for i := 0; i+1 < len(word); i++ {
				if word[i] == '`' {
					if _, ok := codeColor[word[i+1]]; ok {
						color = word[i+1]
					}
					i++
				}
			}
			for wl > width { // hard-split a monster word
				line += word[:width-n]
				word = word[width-n:]
				out = append(out, line)
				line, n = "`"+string(color), 0
				wl = plainLen(word)
			}
			line += word
			n += wl
		}
		out = append(out, strings.TrimRight(line, " "))
	}
	return out
}

// Door drives one caller.
type Door struct {
	T        *Term
	G        *engine.Game
	Assets   string // .../assets/door
	Deadline time.Time
	Idle     time.Duration
	BBSKey   string

	NoSound bool

	// LoginFail is called by TelnetLogin after a bad logon. bot is true for names only
	// attack scripts use. Returning true ends the connection (the caller got banned).
	LoginFail func(logon string, bot bool) bool

	// Notes takes "Forgot your password?" and "Contact the sysop" notes (telnet log-on).
	// From describes the caller for the note ("telnet 1.2.3.4"); Addr is their address.
	Notes      NoteTaker
	From, Addr string

	sess       *engine.Session
	snd        *audio
	sndBG      string
	sndPic     string
	lastPic    string
	curBG      string
	curPic     string
	framed     bool
	fullScreen bool
}

func New(t *Term, g *engine.Game, assets string, timeLeft time.Duration) *Door {
	return &Door{T: t, G: g, Assets: assets, Deadline: time.Now().Add(timeLeft), Idle: 10 * time.Minute}
}

func (d *Door) w(s string) { d.T.Write(s) }
func (d *Door) cls() {
	d.w(csi + "0m" + csi + "2J" + csi + "H")
	d.lastPic = ""
}

// key waits for a key; ok=false means the caller left, timed out, or ran out of time.
// With a tick > 0, tick=true is returned when nothing was pressed within tick.
func (d *Door) key(tick time.Duration) (k string, ok bool, timedOut bool) {
	left := min(d.Idle, time.Until(d.Deadline))
	if left <= 0 {
		return "", false, false
	}
	wait := left
	if tick > 0 && tick < left {
		wait = tick
	}
	k, got := d.T.Key(wait)
	if !got {
		if tick > 0 && wait == tick {
			return "", true, true
		}
		return "", false, false
	}
	if k == "" {
		return "", false, false
	}
	return k, true, false
}

// ------------------------------------------------------------------ pictures

func (d *Door) drawPicture(bg, pic string) {
	d.curBG, d.curPic = bg, pic
	sig := bg + "|" + pic
	if sig == d.lastPic {
		return
	}
	d.lastPic = sig
	switch {
	case d.T.JXL:
		d.drawJXL(bg, pic)
	case d.T.Sixel:
		d.drawSixel(bg, pic)
	default:
		d.drawCaption(bg, pic)
	}
}

func (d *Door) clearPicCells() {
	d.w(csi + "0m")
	for r := 0; r < picRows; r++ {
		d.w(at(picRow+r, picCol) + strings.Repeat(" ", picCols))
	}
}

// assetFiles reads a picture (and its mask, if it has one) and works out their cache names.
func (d *Door) assetFiles(key string) (name string, data []byte, mask string, mdata []byte) {
	if key == "" {
		return
	}
	b, err := os.ReadFile(filepath.Join(d.Assets, key+".jxl"))
	if err != nil {
		return
	}
	flat := strings.ReplaceAll(key, "/", "_")
	name, data = "fq_"+flat+".jxl", b
	if m, err := os.ReadFile(filepath.Join(d.Assets, key+".pbm")); err == nil {
		mask, mdata = "fq_"+flat+".pbm", m
	}
	return
}

func (d *Door) sendAsset(key string) (name, mask string) {
	name, data, mask, mdata := d.assetFiles(key)
	if name != "" {
		d.T.EnsureCached(name, data)
	}
	if mask != "" {
		d.T.EnsureCached(mask, mdata)
	}
	return
}

func (d *Door) drawJXL(bg, pic string) {
	areaW, areaH := picCols*d.T.CellW, picRows*d.T.CellH
	x := (picCol-1)*d.T.CellW + max(0, (areaW-artW)/2)
	y := (picRow-1)*d.T.CellH + max(0, (areaH-artH)/2)
	d.clearPicCells()

	base, bdata, _, _ := d.assetFiles(bg)
	if base == "" {
		base, bdata, _, _ = d.assetFiles("blank")
		bg = ""
	}
	fg, fdata, mask, mdata := d.assetFiles(pic)
	if bg == "" {
		mask = ""
	}
	files := map[string][]byte{}
	for n, b := range map[string][]byte{base: bdata, fg: fdata, mask: mdata} {
		if n != "" {
			files[n] = b
		}
	}
	// Upload everything first, then make sure the terminal really has it before drawing.
	// Some terminals store uploads in the background, and drawing a file that isn't
	// finished yet leaves the picture blank.
	if !d.T.CacheFiles(files) {
		d.lastPic = "" // try again on the next screen
	}
	if base != "" {
		d.T.DrawJXL(base, x, y, "")
	}
	if fg != "" {
		d.T.DrawJXL(fg, x, y, mask)
	}
}

func (d *Door) drawSixel(bg, pic string) {
	areaW, areaH := picCols*d.T.CellW, picRows*d.T.CellH
	scale := min(float64(areaW)/artW, float64(areaH)/artH)
	w := int(artW * scale)
	h := int(artH*scale) / 6 * 6
	d.clearPicCells()
	p := composite(d.Assets, bg, pic, w, h)
	if p == nil {
		return
	}
	d.w(at(picRow, picCol))
	d.T.RawS(encodeSixel(p))
}

func (d *Door) drawCaption(bg, pic string) {
	name := pic
	if name == "" {
		name = bg
	}
	if i := strings.LastIndex(name, "/"); i >= 0 {
		name = name[i+1:]
	}
	name = strings.TrimRight(strings.ReplaceAll(name, "_", " "), "0123456789 ")
	d.box(picRow, picCol, picRow+picRows-1, picCol+picCols-1, 8)
	for r := picRow + 1; r < picRow+picRows-1; r++ {
		d.w(at(r, picCol+1) + csi + "0m" + strings.Repeat(" ", picCols-2))
	}
	if name != "" {
		label := "[ " + name + " ]"
		d.w(at(picRow+6, picCol+(picCols-len(label))/2) + sgr(8) + label)
	}
}

// ------------------------------------------------------------------ panels

func (d *Door) box(r1, c1, r2, c2, color int) {
	var s strings.Builder
	s.WriteString(sgr(color))
	s.WriteString(at(r1, c1) + "╔" + strings.Repeat("═", c2-c1-1) + "╗")
	for r := r1 + 1; r < r2; r++ {
		s.WriteString(at(r, c1) + "║" + at(r, c2) + "║")
	}
	s.WriteString(at(r2, c1) + "╚" + strings.Repeat("═", c2-c1-1) + "╝")
	d.w(s.String())
}
func bar(v, mx, width, color int) string {
	n := max(0, min(width, (v*width+mx/2)/max(1, mx)))
	return sgr(color) + strings.Repeat("█", n) + sgr(8) + strings.Repeat("░", width-n)
}

func (d *Door) leftPanel(s *engine.Screen) {
	st := s.Stats
	for r := 2; r <= 13; r++ {
		d.w(at(r, 2) + csi + "0m" + strings.Repeat(" ", 38))
	}
	d.box(1, 1, 14, 40, 6)
	d.w(at(1, 3) + sgr(14) + " Funeral Quest " + at(1, 29) + sgr(7) + pad(fmt.Sprintf(" Day %d ", st.Day), 10))
	d.w(at(2, 3) + sgr(15) + pad(st.Name+" of "+st.Parlor, 36))
	d.w(at(3, 3) + sgr(8) + pad(s.Location, 36))
	row := 5
	line := func(t string) {
		if row <= 13 {
			d.w(at(row, 3) + toAnsi(t))
			row++
		}
	}
	if s.Info != "" {
		for i, l := range wrap(s.Info, 36, '7') {
			if i >= 5 {
				break
			}
			line(l)
		}
		row = 11
		line(fmt.Sprintf("`8Today `w%s`8 BP  Turns `w%d`8  Luck `w%d%%", engine.Cash(st.SP), st.Turns, st.Luck))
		line(fmt.Sprintf("`8Tags  `6Wood `w%d  `7Silver `w%d  `$Gold `w%d", st.Tags[0], st.Tags[1], st.Tags[2]))
		return
	}
	line(fmt.Sprintf("`$Bury Points earned today: `w%s", engine.Cash(st.SP)))
	line(fmt.Sprintf("`$Turns left: `w%-5d `$Cash: `w$%s", st.Turns, engine.Cash(st.Money)))
	line(fmt.Sprintf("`$Total BP: `w%-12s `$Level `w%d", engine.Cash(st.Exp), max(1, st.Level)))
	lc := 10
	if st.Luck < 30 {
		lc = 12
	} else if st.Luck < 60 {
		lc = 14
	}
	d.w(at(row, 3) + sgr(14) + "Luck " + bar(st.Luck, 100, 26, lc) + sgr(15) + fmt.Sprintf(" %d%%", st.Luck))
	row++
	line(fmt.Sprintf("`$Tags `6■Wood `w%d  `7■Silver `w%d  `$■Gold `w%d", st.Tags[0], st.Tags[1], st.Tags[2]))
	row++
	switch {
	case s.Sale:
		line("`$Class: `w" + s.Cls)
		line("`$Mood:  `w" + s.Mood)
	case s.Battle != nil:
		b := s.Battle
		d.w(at(row, 3) + sgr(15) + pad(fmt.Sprintf("%s %d/%d hp", b.Me.Name, b.Me.HP, b.Me.Max), 36))
		d.w(at(row+1, 3) + bar(b.Me.HP, b.Me.Max, 34, 9))
		d.w(at(row+2, 3) + sgr(15) + pad(fmt.Sprintf("%s %d/%d hp", b.Him.Name, b.Him.HP, b.Him.Max), 36))
		d.w(at(row+3, 3) + bar(b.Him.HP, b.Him.Max, 34, 12))
	default:
		line(fmt.Sprintf("`$Hitpoints `w%d`$   Parlor visits left `w%d", st.HPMax, st.VisitsLeft))
		if st.Mail > 0 {
			line(fmt.Sprintf("`@You have `w%d`@ letter%s waiting.", st.Mail, map[bool]string{true: "", false: "s"}[st.Mail == 1]))
		}
	}
}

func (d *Door) clearButtons() {
	d.w(csi + "0m" + at(btnRow, 1) + csi + "K" + at(btnRow+1, 1) + strings.Repeat(" ", 79))
}
func (d *Door) hint(t string) { d.clearButtons(); d.w(at(btnRow+1, 2) + toAnsi(t)) }

// showText draws text in the text window (rows 15-22), paging with "more" if needed.
func (d *Door) showText(text string, start byte) bool {
	lines := wrap(text, textW, start)
	for len(lines) > 0 && strings.TrimSpace(engine.StripCodes(lines[len(lines)-1])) == "" {
		lines = lines[:len(lines)-1]
	}
	for i := 0; ; i += textRows {
		var s strings.Builder
		s.WriteString(csi + "0m")
		for r := 0; r < textRows; r++ {
			s.WriteString(at(textRow+r, 1) + csi + "K")
			if i+r < len(lines) {
				s.WriteString(at(textRow+r, textCol) + toAnsi(lines[i+r]))
			}
		}
		d.w(s.String() + csi + "0m")
		if i+textRows >= len(lines) {
			return true
		}
		d.hint("`8-- `wmore`8 -- press any key")
		if _, ok, _ := d.key(0); !ok {
			return false
		}
	}
}

func buttonLabel(b engine.Button) string {
	key := strings.ToUpper(b.Key)
	if b.Key == "esc" {
		key = "ESC"
	}
	if len(key) == 1 {
		if i := strings.Index(strings.ToUpper(b.Label), key); i >= 0 {
			return "`7" + b.Label[:i] + "`$[`w" + b.Label[i:i+1] + "`$]`7" + b.Label[i+1:]
		}
	}
	return "`$[`w" + key + "`$]`7 " + b.Label
}
func (d *Door) drawButtons(bs []engine.Button) {
	d.clearButtons()
	row, col := btnRow, 2
	for _, b := range bs {
		l := buttonLabel(b)
		if b.Def {
			l += "`8·"
		}
		n := plainLen(l)
		if col+n > 78 {
			row++
			col = 2
		}
		if row > btnRow+1 {
			break
		}
		d.w(at(row, col) + toAnsi(l))
		col += n + 3
	}
	d.w(csi + "0m")
}

func (d *Door) chooseButton(bs []engine.Button) (engine.Action, bool) {
	for {
		k, ok, _ := d.key(0)
		if !ok {
			return engine.Action{}, false
		}
		for _, b := range bs {
			switch {
			case k == "enter" && b.Def,
				k == "esc" && (b.Key == "esc" || strings.EqualFold(b.Label, "leave") || strings.EqualFold(b.Label, "back") || strings.EqualFold(b.Label, "cancel")),
				len(k) == 1 && strings.EqualFold(k, b.Key):
				return b.Action, true
			}
		}
	}
}

func (d *Door) readLine(prompt string, maxLen int, def string, password, allowEmpty bool, row int) (string, bool) {
	v := []rune(def)
	draw := func() {
		d.w(csi + "0m" + at(row, 1) + csi + "K" + at(row+1, 1) + strings.Repeat(" ", 79))
		plen := len([]rune(prompt)) + 1
		fw := max(10, min(maxLen, 77-plen))
		shown := string(v)
		if password {
			shown = strings.Repeat("*", len(v))
		}
		if r := []rune(shown); len(r) > fw {
			shown = string(r[len(r)-fw:])
		}
		d.w(at(row, 2) + sgr(14) + prompt + " " + csi + "0;1;37;44m" + pad(shown, fw) + csi + "0m")
		d.w(at(row+1, 2) + toAnsi("`8Enter to accept, ESC to cancel") + at(row, 2+plen+len([]rune(shown))))
	}
	draw()
	for {
		k, ok, _ := d.key(0)
		if !ok {
			return "", false
		}
		switch {
		case k == "enter":
			if len(v) == 0 && !allowEmpty {
				continue
			}
			return string(v), true
		case k == "esc":
			return "", false
		case k == "backspace":
			if len(v) > 0 {
				v = v[:len(v)-1]
			}
			draw()
		case len(k) == 1 && len(v) < maxLen:
			v = append(v, []rune(k)...)
			draw()
		}
	}
}

func (d *Door) readMultiline(prompt string, maxLen int) (string, bool) {
	var lines []string
	for {
		d.showText("`$"+prompt+"\n`8(Enter a blank line when done, /a to abort)\n`w"+strings.Join(lines, "\n"), 'w')
		l, ok := d.readLine(fmt.Sprintf("%d:", len(lines)+1), 76, "", false, true, btnRow)
		if !ok || strings.EqualFold(strings.TrimSpace(l), "/a") {
			return "", false
		}
		if strings.TrimSpace(l) == "" {
			return strings.Join(lines, "\n"), true
		}
		lines = append(lines, l)
		if len(strings.Join(lines, "\n")) >= maxLen || len(lines) >= 12 {
			return strings.Join(lines, "\n"), true
		}
	}
}

// ------------------------------------------------------------------ screens

// render draws a screen and returns the player's next action. ok=false means the caller is gone.
func (d *Door) render(s *engine.Screen) (engine.Action, bool) {
	if d.T.Audio && !d.NoSound {
		if d.snd == nil {
			d.snd = newAudio(d.T, filepath.Join(filepath.Dir(d.Assets), "sound"))
		}
		switch s.View {
		case "popup", "news", "ranking", "stats", "view", "sheet":
			// pages without a scene keep the ambience that's playing; just the paper rustle
			if s.Sound != "" && d.snd.has(s.Sound) {
				d.snd.once(s.Sound)
			}
		default:
			d.snd.scene(s, d.sndBG, d.sndPic)
			d.sndBG, d.sndPic = s.BG, s.Pic
		}
	}
	switch s.View {
	case "news":
		if s.Input != nil {
			return d.renderPopup(s)
		}
		return d.renderNews(s)
	case "ranking":
		return d.renderRanking(s)
	case "stats":
		return d.renderStats(s)
	case "view":
		return d.fullPage("Funeral Quest", s.Text, s.Buttons, 'w')
	case "sheet":
		return d.fullPage(s.Title, s.Text, s.Buttons, '$')
	case "chat":
		return d.renderChat(s)
	case "popup":
		return d.renderPopup(s)
	}
	return d.renderGeneric(s)
}

func (d *Door) frame() {
	if d.fullScreen || !d.framed {
		d.cls()
		d.fullScreen = false
		d.framed = true
	}
}

func (d *Door) renderGeneric(s *engine.Screen) (engine.Action, bool) {
	d.frame()
	d.leftPanel(s)
	d.drawPicture(s.BG, s.Pic)
	d.clearButtons()
	text := s.Text
	if s.View == "map" {
		text += "\n\n"
		for i, b := range s.Buttons {
			l := buttonLabel(b)
			if i%2 == 0 {
				text += l + strings.Repeat(" ", max(1, 30-plainLen(l)))
			} else {
				text += "   " + l + "\n"
			}
		}
	}
	if !d.showText(text, '$') {
		return engine.Action{}, false
	}
	return d.afterText(s)
}

func (d *Door) renderPopup(s *engine.Screen) (engine.Action, bool) {
	if d.fullScreen || !d.framed {
		d.frame()
		d.leftPanel(s)
		// the screen was cleared: put back the picture that belongs behind this popup
		d.drawPicture(d.curBG, d.curPic)
	}
	d.clearButtons()
	if !d.showText(s.Text, '$') {
		return engine.Action{}, false
	}
	return d.afterText(s)
}

func strp(s string) *string { return &s }

func (d *Door) afterText(s *engine.Screen) (engine.Action, bool) {
	if in := s.Input; in != nil {
		var v string
		var ok bool
		prompt := engine.StripCodes(in.Prompt)
		if in.Multiline {
			v, ok = d.readMultiline(prompt, max(100, in.MaxLen))
		} else {
			if in.Kind == "name" {
				prompt += " (part of a name)"
			}
			if len(prompt) > 50 {
				d.showText(s.Text+"\n\n`w"+prompt, '$')
				prompt = ">"
			}
			v, ok = d.readLine(prompt, max(8, in.MaxLen), in.Def, in.Kind == "password", true, btnRow)
		}
		if d.T.Closed() || time.Now().After(d.Deadline) {
			return engine.Action{}, false
		}
		a := engine.Action{Cmd: "input"}
		if ok {
			a.Value = strp(v)
		}
		return a, true
	}
	if len(s.Buttons) == 0 {
		return engine.Action{}, false
	}
	if s.View == "map" {
		d.clearButtons()
	} else {
		d.drawButtons(s.Buttons)
	}
	return d.chooseButton(s.Buttons)
}

func (d *Door) fullPage(title, text string, bs []engine.Button, start byte) (engine.Action, bool) {
	d.cls()
	d.fullScreen, d.framed = true, false
	d.w(at(1, 1) + sgr(14) + pad(" "+title, 79) + at(2, 1) + sgr(6) + strings.Repeat("═", 79))
	lines := wrap(text, 77, start)
	for len(lines) > 0 && strings.TrimSpace(engine.StripCodes(lines[len(lines)-1])) == "" {
		lines = lines[:len(lines)-1]
	}
	rows := btnRow - 4
	for i := 0; ; i += rows {
		var b strings.Builder
		b.WriteString(csi + "0m")
		for r := 0; r < rows; r++ {
			b.WriteString(at(3+r, 1) + csi + "K")
			if i+r < len(lines) {
				b.WriteString(at(3+r, 2) + toAnsi(lines[i+r]))
			}
		}
		d.w(b.String() + at(btnRow-1, 1) + sgr(6) + strings.Repeat("═", 79) + csi + "0m")
		if i+rows >= len(lines) {
			break
		}
		d.hint("`8-- `wmore`8 -- press any key")
		if _, ok, _ := d.key(0); !ok {
			return engine.Action{}, false
		}
	}
	d.drawButtons(bs)
	return d.chooseButton(bs)
}

func (d *Door) renderNews(s *engine.Screen) (engine.Action, bool) {
	sec := "Front Page"
	if s.Section == "crime" {
		sec = "Crime"
	}
	title := fmt.Sprintf("THE FUNERAL TIMES  ·  Day %d  ·  %s", s.Day, sec)
	text := ""
	if s.Section != "crime" {
		text = fmt.Sprintf("`wTop Seller Of The Day: `$%s\n`wYesterday's Top Seller: `$%s\n`6%s\n", s.TopToday, strings.TrimSpace(s.TopYesterday), strings.Repeat("─", 77))
	}
	body := strings.NewReplacer("`^", "`7").Replace(s.Text)
	// headlines (`7 followed by capitals) in white
	var b strings.Builder
	for i := 0; i < len(body); i++ {
		if body[i] == '`' && i+2 < len(body) && body[i+1] == '7' && body[i+2] >= 'A' && body[i+2] <= 'Z' {
			b.WriteString("`w")
			i++
			continue
		}
		b.WriteByte(body[i])
	}
	return d.fullPage(title, text+b.String(), s.Buttons, '7')
}

func (d *Door) renderRanking(s *engine.Screen) (engine.Action, bool) {
	// 77 columns: # 4, name 20, sex 4, level 3, parlor 21, points 10, status what's left (cut with "...")
	const statusW = 77 - 4 - 20 - 4 - 3 - 21 - 10
	text := "`w" + pad("#", 4) + pad("Name", 20) + pad("Sex", 4) + pad("Lv", 3) + pad("Parlor", 21) + pad("Bury Pts", 10) + "Status\n`6" + strings.Repeat("─", 77) + "\n"
	for i, r := range s.RankRows {
		sex := "`#F   "
		if r.Male {
			sex = "`9M   "
		}
		lv := ""
		if r.Level > 0 {
			lv = fmt.Sprint(r.Level)
		}
		text += fmt.Sprintf("`7%s`w%s%s`7%s`$%s`w%s`0%s\n", pad(fmt.Sprint(i+1), 4), pad(dots(r.Name, 19), 20), sex, pad(lv, 3), pad(dots(r.Parlor, 20), 21),
			pad(fmt.Sprintf("%9s", engine.Cash(r.Exp)), 10), dots(r.Status, statusW))
	}
	if len(s.RankRows) == 0 {
		text += "`7Nobody is in town yet."
	}
	title := s.Title
	if title == "" {
		title = "Parlor Rankings"
	}
	return d.fullPage(title, text, s.Buttons, '$')
}

func (d *Door) renderStats(s *engine.Screen) (engine.Action, bool) {
	text := ""
	for _, r := range s.StatRows {
		text += "`$" + pad(r[0]+":", 24) + "`w" + r[1] + "\n"
	}
	text += "`$Rating: `w" + s.Rating + "\n`$Karma:  `w" + s.Karma + "\n"
	if !strings.HasSuffix(s.Text, "Your stats.") {
		text += s.Text
	}
	return d.fullPage("Stats · "+s.Stats.Name, text, s.Buttons, '$')
}

// renderChat runs the Pale Horse Cafe: lines scroll in a region below the picture so the art
// never scrolls away. New lines show up within a quarter second (a cheap check of chat.seq).
func (d *Door) renderChat(s *engine.Screen) (engine.Action, bool) {
	d.cls()
	d.framed = true
	info := *s
	info.Info = "The Pale Horse Cafe.  Type to talk, /? for help.  /bar talks to Bertram the bartender, /drink buys a drink.  ESC or /q leaves."
	d.leftPanel(&info)
	bg := s.BG
	if bg == "" {
		bg = "bar"
	}
	d.drawPicture(bg, "")
	top, bottom := textRow, textRow+textRows-1
	d.w(fmt.Sprintf("%s%d;%dr", csi, top, bottom) + at(bottom, 1))
	print := func(t string) {
		for _, l := range wrap(t, textW, '$') {
			d.w(at(bottom, 1) + "\r\n" + at(bottom, textCol) + toAnsi(l) + csi + "0m")
		}
	}
	print(s.Text)
	var v []rune
	drawInput := func() {
		shown := string(v)
		if len(v) > 68 {
			shown = string(v[len(v)-68:])
		}
		d.w(csi + "0m" + at(btnRow, 1) + csi + "K" + at(btnRow, 2) + toAnsi("`$Say: ") + csi + "0;1;37;44m" + pad(shown, 70) + csi + "0m")
		d.w(at(btnRow+1, 2) + toAnsi("`8Enter sends · /bar Bertram · /drink a drink · ESC leaves the cafe") + at(btnRow, 8+len([]rune(shown))))
	}
	drawInput()
	defer d.w(csi + "r")
	for {
		k, ok, tick := d.key(250 * time.Millisecond)
		if !ok {
			return engine.Action{}, false
		}
		if tick {
			if !d.sess.ChatPending() {
				continue
			}
			if lines := d.sess.ChatUpdate(""); len(lines) > 0 {
				for _, l := range lines {
					print(l)
				}
				drawInput()
			}
			continue
		}
		switch {
		case k == "esc" || (k == "enter" && (strings.EqualFold(strings.TrimSpace(string(v)), "/q") || strings.EqualFold(strings.TrimSpace(string(v)), "/quit"))):
			d.framed = false
			return engine.Action{Cmd: "map"}, true
		case k == "enter" && (strings.EqualFold(strings.TrimSpace(string(v)), "/bar") || strings.EqualFold(strings.TrimSpace(string(v)), "/drink")):
			d.framed = false
			sub := "talk"
			if strings.EqualFold(strings.TrimSpace(string(v)), "/drink") {
				sub = "menu"
			}
			return engine.Action{Cmd: "bar", Sub: sub}, true
		case k == "enter":
			for _, l := range d.sess.ChatUpdate(string(v)) {
				print(l)
			}
			v = v[:0]
			drawInput()
		case k == "backspace":
			if len(v) > 0 {
				v = v[:len(v)-1]
			}
			drawInput()
		case len(k) == 1 && len(v) < 200:
			v = append(v, []rune(k)...)
			drawInput()
		}
	}
}

// ------------------------------------------------------------------ entry points

// Play runs the game for a logged-in player until they quit or drop.
func (d *Door) Play(pid int, kind string) {
	d.sess = d.G.NewSession(pid, kind)
	defer d.sess.Disconnect()
	scr := d.sess.Act(engine.Action{Cmd: "main"})
	for {
		if scr.View == "quit" || scr.View == "gone" {
			if d.snd != nil {
				d.snd.stopAll()
			}
			d.w(csi + "r" + csi + "0m" + csi + "2J" + at(10, 1))
			d.w(toAnsi("`$"+engine.StripCodes(scr.Text)+"\r\n\r\n`7Thanks for playing `wFuneral Quest`7!\r\n\r\n") + csi + "0m")
			return
		}
		a, ok := d.render(&scr)
		if !ok {
			if d.snd != nil {
				d.snd.stopAll()
			}
			if !d.T.Closed() {
				msg := "`$You doze off at your desk...\r\n"
				if time.Now().After(d.Deadline) {
					msg = "`$Your time is up for this call.\r\n"
				}
				d.w(csi + "r" + csi + "0m" + csi + "2J" + at(10, 1) + toAnsi(msg) + csi + "0m")
			}
			return
		}
		scr = d.sess.Act(a)
	}
}

// NewPlayer signs up a BBS caller the first time they enter.
func (d *Door) NewPlayer(alias string) *engine.Player {
	d.cls()
	d.framed = true
	d.drawPicture("places/funeral_home_black_", "")
	d.box(1, 1, 14, 40, 6)
	d.w(at(1, 3) + sgr(14) + " Funeral Quest ")
	intro := "`wWelcome to Deathville.\n\n`$Business is dying to get in.  Run your own funeral parlor, sweet-talk the bereaved into the gold casket, and bury the competition.\n\n`7Original game by Seth A. Robinson, art by Akiko Robinson (c) 2001 Robinson Technologies."
	r := 3
	for _, l := range wrap(intro, 36, 'w') {
		if r < 14 {
			d.w(at(r, 3) + toAnsi(l))
			r++
		}
	}
	if len(alias) > 20 {
		alias = alias[:20]
	}
	for {
		d.showText("`$You've never run a parlor here before.  Let's get you set up.\n\n`7Your name is what other morticians will see; your parlor needs a name too.", '$')
		name, ok := d.readLine("Your name in Deathville:", 20, alias, false, false, btnRow)
		if !ok {
			return nil
		}
		parlor, ok := d.readLine("Name of your funeral parlor:", 20, "", false, false, btnRow)
		if !ok {
			return nil
		}
		d.hint("`$Are you `w(M)`$ale or `w(F)`$emale?")
		male := -1
		for male < 0 {
			k, ok, _ := d.key(0)
			if !ok {
				return nil
			}
			switch strings.ToLower(k) {
			case "m":
				male = 1
			case "f":
				male = 0
			}
		}
		p, err := d.G.CreatePlayer(engine.NewPlayer{Name: name, Parlor: parlor, Male: male == 1, BBSKey: d.BBSKey})
		if err != nil {
			d.showText("`4"+err.Error()+"\n\n`7Press a key to try again.", '$')
			if _, ok, _ := d.key(0); !ok {
				return nil
			}
			continue
		}
		return p
	}
}

// TelnetLogin is the log-on screen for the stand-alone telnet server (web logons work here too).
func (d *Door) TelnetLogin() *engine.Player {
	header := func() {
		d.cls()
		d.w(sgr(14) + "Funeral Quest" + csi + "0m telnet door\r\n\r\n")
		d.w(at(3, 2) + toAnsi("`wNEW`7 = open a parlor"))
		if d.Notes != nil {
			d.w(toAnsi("   `wFORGOT`7 = forgot your password   `wCONTACT`7 = write the sysop"))
		}
	}
	header()
	for tries := 0; tries < 5; tries++ {
		logon, ok := d.readLine("Logon name:", 20, "", false, false, 5)
		if !ok {
			return nil
		}
		if word := strings.ToLower(strings.TrimSpace(logon)); d.Notes != nil && (word == "forgot" || word == "contact") {
			d.noteForm(word == "forgot")
			header()
			tries--
			continue
		}
		if guard.BotNames[strings.ToLower(strings.TrimSpace(logon))] && d.LoginFail != nil {
			d.LoginFail(logon, true)
			return nil
		}
		if strings.EqualFold(logon, "new") {
			off := false
			d.G.View(func(w *engine.World) { off = w.Config.SignupCaptchaOff })
			if !off {
				if !d.Captcha(5) {
					return nil
				}
				header()
				d.w(at(5, 2) + toAnsi("`$Open a new parlor"))
			}
			l, ok := d.readLine("Pick a logon name:", 20, "", false, false, 7)
			if !ok {
				return nil
			}
			pw, ok := d.readLine("Pick a password:", 20, "", true, false, 9)
			if !ok {
				return nil
			}
			email, ok := d.askEmail(11)
			if !ok {
				return nil
			}
			name, ok := d.readLine("Your name in Deathville:", 20, "", false, false, 13)
			if !ok {
				return nil
			}
			parlor, ok := d.readLine("Name of your funeral parlor:", 20, "", false, false, 15)
			if !ok {
				return nil
			}
			d.w(at(17, 2) + sgr(14) + "Are you (M)ale or (F)emale?" + csi + "0m")
			var k string
			for k != "m" && k != "f" {
				kk, ok, _ := d.key(0)
				if !ok {
					return nil
				}
				k = strings.ToLower(kk)
			}
			p, err := d.G.CreatePlayer(engine.NewPlayer{Name: name, Parlor: parlor, Male: k == "m", Logon: l, Password: pw, Email: email})
			if err != nil {
				d.w(at(19, 2) + sgr(12) + err.Error() + csi + "0m")
				continue
			}
			return p
		}
		pw, ok := d.readLine("Password:", 30, "", true, true, 7)
		if !ok {
			return nil
		}
		p, err := d.G.Login(logon, pw)
		if err == nil {
			return p
		}
		d.w(at(9, 2) + sgr(12) + err.Error() + csi + "0m")
		if d.LoginFail != nil && d.LoginFail(logon, false) {
			return nil
		}
		time.Sleep(time.Duration(tries+1) * time.Second) // slow down password guessing
	}
	if d.LoginFail != nil {
		d.LoginFail("", false)
	}
	return nil
}

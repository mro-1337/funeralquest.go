package door

import (
	"bytes"
	"strings"
	"testing"
	"time"

	"funeralquest/engine"
)

// Opening a parlor by telnet asks for the gravestone letters first (on by default).
func TestTelnetSignupPuzzle(t *testing.T) {
	g, err := engine.NewGame(t.TempDir(), "../gamedata", nil)
	if err != nil {
		t.Fatal(err)
	}
	var out bytes.Buffer
	tm := NewTerm(strings.NewReader("new\rwrong\rwrong\rwrong\r"), &out, false)
	d := New(tm, g, t.TempDir(), time.Minute)
	if p := d.TelnetLogin(); p != nil {
		t.Fatal("a parlor opened without the puzzle")
	}
	if !strings.Contains(out.String(), "among the living") {
		t.Fatal("no puzzle shown")
	}
	// turned off: straight to the questions
	g.Store.Tx(func(w *engine.World) error { w.Config.SignupCaptchaOff = true; return nil })
	out.Reset()
	tm = NewTerm(strings.NewReader("new\redna\rsecret1\redna@example.com\rEdna\rEdna's Rest\rf"), &out, false)
	d = New(tm, g, t.TempDir(), time.Minute)
	if p := d.TelnetLogin(); p == nil || p.Name != "Edna" {
		t.Fatalf("sign-up with the puzzle off failed: %v", p)
	}
	if strings.Contains(out.String(), "among the living") {
		t.Fatal("puzzle shown while turned off")
	}
}

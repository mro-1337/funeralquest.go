package door

import (
	"strings"
	"time"

	"funeralquest/captcha"
	"funeralquest/engine"
)

// NoteTaker leaves notes on the sysop's desk (admin.Admin does it).
type NoteTaker interface {
	ForgotPassword(logon, contact, note, from, addr string) error
	ContactSysop(name, email, text, from, addr string) error
}

// askEmail asks for an e-mail address at sign-up (a few tries). ok=false: the caller left.
func (d *Door) askEmail(row int) (string, bool) {
	for try := 0; try < 4; try++ {
		e, ok := d.readLine("E-mail (only to send your password if you forget it):", 100, "", false, false, row)
		if !ok {
			return "", false
		}
		if engine.ValidEmail(e) {
			return strings.TrimSpace(e), true
		}
		d.w(at(row+1, 2) + csi + "K" + toAnsi("`4That doesn't look like an e-mail address (like you@example.com).  Try again."))
		time.Sleep(1200 * time.Millisecond)
	}
	return "", false
}

// noteForm is the telnet version of "Forgot your password?" and "Contact the sysop".
func (d *Door) noteForm(forgot bool) {
	if d.Notes == nil {
		return
	}
	d.cls()
	title := "`$A note for the Undertaker"
	help := "`7Questions, problems or praise for whoever runs this town (the sysop).\r\n`7They'll write back to you by e-mail."
	if forgot {
		title = "`$Lost the key to your parlor?"
		help = "`7Leave a note on the sysop's desk.  They'll look you up in the undertaker's ledger\r\n`7and write back to you by e-mail with a new password."
	}
	d.w(at(1, 2) + toAnsi(title) + at(3, 2) + toAnsi(strings.ReplaceAll(help, "\r\n", "\r\n "+csi+"0m")))
	var who, email, note string
	var ok bool
	if forgot {
		if who, ok = d.readLine("Your logon name:", 20, "", false, false, 6); !ok {
			return
		}
	} else if who, ok = d.readLine("Your name:", 60, "", false, false, 6); !ok {
		return
	}
	if email, ok = d.readLine("Your e-mail address:", 100, "", false, false, 8); !ok {
		return
	}
	prompt := "Your message:"
	if forgot {
		prompt = "A note to the sysop (optional):"
	}
	if note, ok = d.readLine(prompt, 300, "", false, forgot, 10); !ok {
		return
	}
	for try := 0; try < 3; try++ {
		id, ans := captcha.New()
		d.w(at(12, 1) + csi + "0J")
		d.w(at(12, 2) + toAnsi("`$Prove you're among the living: `7type the letters carved on the stone."))
		for i, l := range captcha.Lines(ans, sgr) {
			d.w(at(14+i, 6) + l + csi + "0m")
		}
		guess, ok := d.readLine("Letters:", 12, "", false, false, 22)
		if !ok {
			return
		}
		if !captcha.Check(id, guess) {
			d.w(at(23, 2) + csi + "K" + toAnsi("`4Those aren't the letters on the stone.  Here's another one."))
			time.Sleep(1500 * time.Millisecond)
			continue
		}
		var err error
		if forgot {
			err = d.Notes.ForgotPassword(who, email, note, d.From, d.Addr)
		} else {
			err = d.Notes.ContactSysop(who, email, note, d.From, d.Addr)
		}
		d.w(at(12, 1) + csi + "0J" + at(13, 2))
		switch {
		case err != nil:
			d.w(toAnsi("`4" + err.Error()))
		case forgot:
			d.w(toAnsi("`$Your note is on the sysop's desk.  `7Keep an eye on your e-mail: they'll write\r\n `7back with a new password once they've checked the ledger."))
		default:
			d.w(toAnsi("`$Message delivered.  `7The sysop will find it on their desk and write back by e-mail."))
		}
		d.w(at(16, 2) + toAnsi("`8Press any key."))
		d.key(time.Minute)
		return
	}
}

// Captcha asks for the letters on a gravestone (3 tries) from row down, to keep programs from
// opening parlors. false: they failed or hung up.
func (d *Door) Captcha(row int) bool {
	for try := 0; try < 3; try++ {
		id, ans := captcha.New()
		d.w(at(row, 1) + csi + "0J")
		d.w(at(row, 2) + toAnsi("`$Prove you're among the living: `7type the letters carved on the stone."))
		for i, l := range captcha.Lines(ans, sgr) {
			d.w(at(row+2+i, 6) + l + csi + "0m")
		}
		guess, ok := d.readLine("Letters:", 12, "", false, false, row+10)
		if !ok {
			return false
		}
		if captcha.Check(id, guess) {
			return true
		}
		d.w(at(row+11, 2) + csi + "K" + toAnsi("`4Those aren't the letters on the stone.  Here's another one."))
		time.Sleep(1500 * time.Millisecond)
	}
	return false
}

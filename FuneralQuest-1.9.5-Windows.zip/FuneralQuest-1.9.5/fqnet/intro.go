package fqnet

// Introductions: linked towns tell each other which other towns they're linked to, so the
// network fills in by itself. When Deathville links to Gravesend, and Gravesend is already
// linked to Boneyard, Gravesend introduces Boneyard to Deathville (and Deathville to Boneyard).
// Each of them then sends the other a link request. When both follow introductions (the
// normal setting) they both ask, and the link is made with nobody clicking anything.
//
// Safety:
//   - An introduction is only a name, an address and an ID, received in a signed message
//     from a town you already trust. Linking checks the introduced town answers with exactly
//     that ID, so a lying introducer can't send you to an impostor.
//   - A town you removed or blocked is never brought back by an introduction.
//   - Sysops can stop following introductions, stop sharing their own links, and choose
//     whether towns introduced by a linked town are accepted without asking.

import (
	"encoding/json"
	"strings"
	"time"

	"funeralquest/engine"
)

type knownTown struct {
	ID   string `json:"id"`
	URL  string `json:"url"`
	Name string `json:"name"`
	Via  string `json:"via,omitempty"` // no address: the introducing town (this ID) passes messages to it
}

// Intro is an introduction waiting to be followed.
type Intro struct {
	URL     string    `json:"url"`
	Name    string    `json:"name"`
	By      string    `json:"by"` // the linked town that introduced it
	At      time.Time `json:"at"`
	Tries   int       `json:"tries"`
	NextTry time.Time `json:"next_try"`
	LastErr string    `json:"last_err,omitempty"`
	Via     string    `json:"via,omitempty"` // no address: reach it through this linked town
}

// knownFor lists the towns we can tell peer about.
func (n *Net) knownFor(peer string) []knownTown {
	if n.cfg().NetShareLinksOff {
		return nil
	}
	relay := !n.cfg().NetRelayOff
	var out []knownTown
	for _, p := range n.view().Peers {
		if p.State != Linked || !p.TheyOK || p.ID == peer || len(out) >= 200 {
			continue
		}
		// only towns we've actually reached lately: never pass on an address that doesn't work
		reached := !p.LastOK.IsZero() && time.Since(p.LastOK) < 30*time.Minute
		if p.URL != "" && reached {
			out = append(out, knownTown{ID: p.ID, URL: p.URL, Name: p.Name})
			continue
		}
		// a town with no address that checks in with us lately: we pass messages to it
		fetching := RelayActive(*p) || (!p.LastIn.IsZero() && time.Since(p.LastIn) < 30*time.Minute)
		if p.URL == "" && relay && fetching {
			out = append(out, knownTown{ID: p.ID, Name: p.Name, Via: n.ID})
		}
	}
	return out
}

// noteKnown records the towns a linked town told us about (inside a tx).
func (n *Net) noteKnown(st *state, from string, list []knownTown, acceptIntroduced bool) {
	if st.KnownBy == nil {
		st.KnownBy = map[string][]string{}
	}
	if st.Intros == nil {
		st.Intros = map[string]*Intro{}
	}
	var ids []string
	for i, k := range list {
		if i >= 200 {
			break
		}
		if _, ok := pubFromID(k.ID); !ok || k.ID == n.ID || k.ID == from {
			continue
		}
		ids = append(ids, k.ID)
		if p := st.peer(k.ID); p != nil {
			// a linked town with no address we can't reach: go through the town that introduced it
			if k.URL == "" && k.Via == from && p.URL == "" && !RelayActive(*p) {
				if h := st.peer(p.Via); p.Via == "" || h == nil || h.State != Linked || (h.LastErr != "" && h.ID != from) {
					p.Via = from
				}
			}
			// it already asked us, and a linked town vouches for it: accept if we follow
			// introductions (we'd have asked it ourselves) or accept introduced towns
			_, gone := st.Forgot[k.ID]
			if p.State == Pending && !gone && (acceptIntroduced || !n.cfg().NetIntroOff) {
				p.State, p.Note = Linked, "Accepted: introduced by "+peerName(st, from)+"."
				n.Log("network: accepted %s, introduced by %s", p.Name, peerName(st, from))
			}
			continue
		}
		if _, gone := st.Forgot[k.ID]; gone {
			continue
		}
		if k.URL == "" {
			// no address: only the introducing town itself can pass messages to it
			if k.Via != from {
				continue
			}
			if _, ok := st.Intros[k.ID]; !ok {
				st.Intros[k.ID] = &Intro{Name: cleanName(k.Name), By: from, At: time.Now(), Via: from}
				n.Log("network: %s introduced %s (reached through %s)", peerName(st, from), cleanName(k.Name), peerName(st, from))
			}
			continue
		}
		url, err := normURL(k.URL)
		if err != nil {
			continue
		}
		if _, ok := st.Intros[k.ID]; !ok {
			st.Intros[k.ID] = &Intro{URL: url, Name: cleanName(k.Name), By: from, At: time.Now()}
			n.Log("network: %s introduced %s (%s)", peerName(st, from), cleanName(k.Name), url)
		}
	}
	st.KnownBy[from] = ids
}

func peerName(st *state, id string) string {
	if p := st.peer(id); p != nil {
		return p.Name
	}
	return "a linked town"
}

// vouchedBy returns the name of a linked town that lists id among its links ("" if none).
func vouchedBy(st *state, id string) string {
	for by, ids := range st.KnownBy {
		p := st.peer(by)
		if p == nil || p.State != Linked {
			continue
		}
		for _, x := range ids {
			if x == id {
				return p.Name
			}
		}
	}
	return ""
}

// FollowIntros sends link requests to introduced towns (a few at a time, with backoff).
func (n *Net) FollowIntros() {
	if n.cfg().NetIntroOff {
		return
	}
	type job struct {
		id string
		in Intro
	}
	var jobs []job
	for id, in := range n.load().Intros {
		if time.Now().After(in.NextTry) && len(jobs) < 3 {
			jobs = append(jobs, job{id, *in})
		}
	}
	for _, j := range jobs {
		err := n.linkIntroduced(j.id, j.in)
		n.tx(func(st *state) error {
			in := st.Intros[j.id]
			if in == nil {
				return nil
			}
			if err == nil || st.peer(j.id) != nil {
				delete(st.Intros, j.id)
				return nil
			}
			in.Tries++
			in.LastErr = err.Error()
			if in.Tries >= 6 {
				delete(st.Intros, j.id) // it'll be introduced again on a later sync if it's still around
				return nil
			}
			in.NextTry = time.Now().Add(time.Duration(1<<in.Tries) * 5 * time.Minute)
			return nil
		})
		if err != nil {
			n.Log("network: couldn't link to introduced town %s (%s): %v", j.in.Name, j.in.URL, err)
		}
	}
}

// linkIntroduced links to an introduced town; it must answer with the ID it was introduced with.
func (n *Net) linkIntroduced(id string, in Intro) error {
	c := n.cfg()
	env := newEnvelope(n.ID, id) // we know who it should be: only that town will take it
	msg := helloMsg{envelope: env, URL: n.PublicURL(), Name: c.ServerName, rules: n.ourRules(), Via: in.By}
	target := Peer{ID: id, URL: in.URL, Name: in.Name, Via: in.Via}
	if in.URL != "" {
		target.Via = ""
	}
	rb, err := n.send(target, "/fed/hello", id, msg, env)
	if err != nil {
		return err
	}
	var ans helloAns
	json.Unmarshal(rb, &ans)
	return n.tx(func(st *state) error {
		if st.peer(id) != nil {
			return nil
		}
		for _, p := range st.Peers {
			if in.URL != "" && p.URL == in.URL && p.ID != id {
				return nil // that address belongs to a town we know under another key
			}
		}
		p := &Peer{ID: id, URL: in.URL, Via: target.Via, Name: cleanName(ans.Name), State: Linked, Added: time.Now(),
			TheyOK: ans.State == Linked, Note: "Introduced by " + peerName(st, in.By) + ".", CertPin: n.pendingPin(id)}
		if p.Name == "" {
			p.Name = in.Name
		}
		n.noteRules(p, ans.GameVer, ans.Rules, ans.NetRules)
		st.Peers = append(st.Peers, p)
		n.Log("network: linked to %s, introduced by %s", p.Name, peerName(st, in.By))
		return nil
	})
}

func cleanName(s string) string {
	s = strings.TrimSpace(engine.CleanRemote(s, 30, false))
	if s == "" {
		return "Unnamed town"
	}
	return s
}

// IntroRow is an introduction waiting to be followed, for the sysop pages.
type IntroRow struct {
	Intro
	ID     string `json:"id"`
	ByName string `json:"by_name"`
	Finger string `json:"fingerprint"`
}

// Intros lists introductions waiting to be followed.
func (n *Net) Intros() []IntroRow {
	st := n.load()
	var out []IntroRow
	for id, in := range st.Intros {
		out = append(out, IntroRow{Intro: *in, ID: id, ByName: peerName(st, in.By), Finger: Fingerprint(id)})
	}
	return out
}

package fqnet

// The network's new-player settings. Every linked town has to keep the new-player settings
// (starting money, luck, hit points, strength, karma and rating) at the network's values,
// which are the game's defaults until a settings vote passes. A town whose values were
// changed by hand stops playing with linked towns (no syncs, raids or rankings) until its
// sysop puts them back or a vote passes; other towns refuse it too. When a vote passes, every
// town in it switches to the new values by itself.

import (
	"encoding/json"
	"fmt"
	"path/filepath"
	"strings"
	"time"

	"funeralquest/opmsg"

	"funeralquest/engine"
)

// NetRules are the network's values for the protected settings: the defaults, changed only by
// settings votes that passed.
func (n *Net) NetRules() map[string]string {
	d := engine.DefaultConfig()
	m := map[string]string{}
	for _, k := range engine.ProtectedSettings {
		m[k] = d.Get(k)
	}
	for k, v := range n.view().NetRules {
		if _, ok := m[k]; ok {
			m[k] = v
		}
	}
	return m
}

// RuleProblems lists this town's protected settings that differ from the network's
// ("Starting money is 5000 here; the network's is 2000"). Empty: all is well. A town with
// no linked towns has no problems: it can use any settings it likes.
func (n *Net) RuleProblems() []string {
	if !n.HasLinks() {
		return nil
	}
	c := n.cfg()
	return ruleDiffs(c.Rules(), n.NetRules(), "here")
}

func ruleDiffs(have, want map[string]string, where string) []string {
	var out []string
	for _, k := range engine.ProtectedSettings {
		h, ok := have[k]
		if !ok {
			continue // an older town that doesn't send it
		}
		if strings.TrimSpace(h) != strings.TrimSpace(want[k]) {
			out = append(out, fmt.Sprintf("%s is %s %s; the network's is %s", engine.SettingLabel(k), h, where, want[k]))
		}
	}
	return out
}

// ownRulesError is why this town isn't playing with linked towns right now (nil: it is).
func (n *Net) ownRulesError() error {
	if p := n.RuleProblems(); len(p) > 0 {
		return fmt.Errorf("%s's new-player settings were changed from the network's (%s), so it can't play with linked towns until they're put back or a settings vote passes", n.cfg().ServerName, strings.Join(p, "; "))
	}
	return nil
}

// peerRulesError checks a linked town's protected settings against the network's.
func (n *Net) peerRulesError(name string, theirs map[string]string) error {
	if p := ruleDiffs(theirs, n.NetRules(), "there"); len(p) > 0 {
		return fmt.Errorf("%s's new-player settings were changed from the network's (%s); it can't play with linked towns until its sysop puts them back or a settings vote passes", name, strings.Join(p, "; "))
	}
	return nil
}

// RestoreNetRules puts this town's protected settings back to the network's.
func (n *Net) RestoreNetRules() error {
	want := n.NetRules()
	err := n.G.Store.Tx(func(w *engine.World) error {
		c := w.Config
		for _, k := range engine.ProtectedSettings {
			if err := c.Set(k, want[k]); err != nil {
				return err
			}
		}
		w.Config = c
		return nil
	})
	if err == nil {
		n.Kick()
	}
	return err
}

// adoptNetRules records a passed vote's values for the protected settings as the network's.
func adoptNetRules(st *state, rules map[string]string) {
	if st.NetRules == nil {
		st.NetRules = map[string]string{}
	}
	for _, k := range engine.ProtectedSettings {
		if v, ok := rules[k]; ok {
			st.NetRules[k] = v
		}
	}
}

// peerNow is a fresh copy of a peer.
func (n *Net) peerNow(id string) Peer {
	if p := n.view().peer(id); p != nil {
		return *p
	}
	return Peer{ID: id}
}

// rulesMismatch is why we and a linked town (whose settings are theirs) can't play together.
func (n *Net) rulesMismatch(name string, theirs map[string]string) error {
	if err := n.ownRulesError(); err != nil {
		return err
	}
	return n.peerRulesError(name, theirs)
}

// rulesPauseNote records on a peer why only votes are being passed, and returns it.
func (n *Net) rulesPauseNote(id string) error {
	p := n.peerNow(id)
	err := n.rulesMismatch(p.Name, p.Rules)
	if err == nil {
		return nil
	}
	n.tx(func(st *state) error {
		if pp := st.peer(id); pp != nil {
			pp.LastErr = err.Error()
			pp.LastTry = time.Now()
		}
		delete(st.Remote, id) // their players leave our rankings while paused
		return nil
	})
	return err
}

// votesOnlySync passes votes to and from a town while new-player settings don't match.
func (n *Net) votesOnlySync(p Peer) error {
	env := newEnvelope(n.ID, p.ID)
	msg := syncMsg{envelope: env, rules: n.ourRules(), Vote: n.outgoingVotes(p.ID)}
	msg.Town = n.cfg().ServerName
	rb, err := n.send(p, "/fed/sync", p.ID, msg, env)
	var ans syncAns
	if err == nil {
		err = json.Unmarshal(rb, &ans)
	}
	n.tx(func(st *state) error {
		pp := st.peer(p.ID)
		if pp == nil {
			return nil
		}
		pp.LastTry = time.Now()
		if err != nil {
			pp.LastErr = err.Error()
			pp.Fails++
			return nil
		}
		pp.Fails, pp.TheyOK = 0, true
		n.noteRules(pp, ans.GameVer, ans.Rules, ans.NetRules)
		return nil
	})
	if err != nil {
		return err
	}
	n.incomingVotes(p.ID, p.Name, ans.Vote)
	n.adoptNetwork()
	return nil
}

// votesOnlyAnswer answers a sync from a town while new-player settings don't match: votes only.
func (n *Net) votesOnlyAnswer(from, town string) syncAns {
	ans := syncAns{rules: n.ourRules(), Vote: n.outgoingVotes(from)}
	ans.Town = n.cfg().ServerName
	return ans
}

// PeerRuleProblem says how a linked town's new-player settings differ from the network's
// ("" when they don't, or we haven't heard them yet).
func (n *Net) PeerRuleProblem(p Peer) string {
	if d := ruleDiffs(p.Rules, n.NetRules(), "there"); len(d) > 0 {
		return "its new-player settings were changed from the network's (" + strings.Join(d, "; ") + "), so it can't play with linked towns until its sysop puts them back or a settings vote passes"
	}
	return ""
}

// KindNetwork is the mailbox note about the network's settings.
const KindNetwork = "Network settings"

// adoptNetwork: a town new to the network (it has never played with a linked town and never
// had a settings vote) takes the new-player settings the network voted, from a linked town
// that tells it, and the sysop gets a note listing what changed. Returns true when it did.
func (n *Net) adoptNetwork() bool {
	st := n.view()
	if st.NetJoined || len(st.NetRules) > 0 {
		return false
	}
	var from *Peer
	for _, p := range st.Peers {
		if p.State == Linked && len(p.NetRules) > 0 {
			from = p
			break
		}
	}
	if from == nil {
		return false
	}
	before := n.cfg()
	var adopted map[string]string
	n.tx(func(st *state) error {
		if st.NetJoined || len(st.NetRules) > 0 {
			return nil
		}
		adoptNetRules(st, from.NetRules)
		adopted = st.NetRules
		return nil
	})
	if adopted == nil {
		return false
	}
	if err := n.RestoreNetRules(); err != nil {
		n.Log("network: couldn't switch to the network's new-player settings: %v", err)
	}
	var lines []string
	for _, k := range engine.ProtectedSettings {
		if v, ok := adopted[k]; ok && before.Get(k) != v {
			lines = append(lines, fmt.Sprintf("  %s: was %s here, now %s", engine.SettingLabel(k), before.Get(k), v))
		}
	}
	if len(lines) == 0 {
		return true
	}
	text := fmt.Sprintf("Your town joined a network whose towns voted different new-player settings, so it switched to theirs (they came from %s). Every linked town has to give new players the same start; without the switch your town couldn't play with them.\n\n%s\n\nPlayers who already have a parlor keep what they have. To change these for the whole network, propose your settings in a vote (sysop pages, Network tab).",
		oneLine(from.Name), strings.Join(lines, "\n"))
	n.Log("network: this town is new to the network, so it switched to the network's new-player settings (from %s): %s", from.Name, strings.TrimSpace(strings.Join(lines, ";")))
	box := opmsg.Open(filepath.Dir(n.Dir))
	box.Put(opmsg.Msg{Kind: KindNetwork, From: "this town's network link", Name: oneLine(from.Name), Text: text, Peer: from.ID})
	return true
}

// joined marks this town as having played with a linked town (so it's no longer new).
func (n *Net) joined() {
	if !n.view().NetJoined {
		n.tx(func(st *state) error { st.NetJoined = true; return nil })
	}
}

package engine

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"math"
	"strconv"
	"strings"
	"time"
)

// custStatus is the original's communication_status: what's going on with the current customer/visit.
type custStatus struct {
	CustomerActive bool
	CMale, DMale   bool
	CAge, DAge     int
	Relation       int
	Income         int
	Casket         int
	Upgrade        int
	Money          int
	Loved          bool
	Mood, Cheap    float64
	KillObject     int
	KillType       int
	ShowResistance bool
	URLSave, BG    string
	Special        string
	Risk           int
	Arson          bool
	HisID          int
	Locked         bool
	Visiting       int
	Battle         bool
	ViewHearse     int
	WebLogon       string
}

type namePend struct {
	pend    *Input
	matches []int
	i       int
}

// Session is one logged-in player: a BBS node or a browser.
type Session struct {
	G        *Game
	PID      int
	Kind     string
	SID      string
	Quitting bool

	st       custStatus
	options  []int
	location string
	chatting bool
	greeted  bool
	pending  *Input
	namePend *namePend
	chatLast int
	newsBack string

	w *World
}

func (g *Game) NewSession(pid int, kind string) *Session {
	b := make([]byte, 6)
	rand.Read(b)
	return &Session{G: g, PID: pid, Kind: kind, SID: fmt.Sprintf("%s-%d-%s", kind, pid, hex.EncodeToString(b)), location: "Logon"}
}

func (s *Session) me() *Player        { return s.w.Player(s.PID) }
func (s *Session) cfg() *Config       { return &s.w.Config }
func (s *Session) data() *Data        { return s.G.Data }
func (s *Session) age() int           { return s.w.Glo.GameAge }
func (s *Session) news(sec, t string) { s.w.AddNews(sec, t) }

// Act performs one player action and returns the next screen.
func (s *Session) Act(a Action) (scr Screen) {
	err := s.G.Store.Tx(func(w *World) error {
		s.w = w
		defer func() { s.w = nil }()
		s.G.MaintCheck(w, false)
		me := s.me()
		if me == nil || !me.Active {
			scr = Screen{View: "gone", Text: "`wYour parlor has been closed.  (You were inactive too long, or the game was reset.)"}
			return nil
		}
		func() {
			defer func() {
				if r := recover(); r != nil {
					s.G.Log.Printf("engine panic: %v", r)
					scr = s.desk(fmt.Sprintf("`4Something went wrong in Deathville. (%v)", r))
				}
			}()
			scr = s.dispatch(a)
		}()
		status := "play"
		if s.chatting {
			status = "chat"
		} else if s.st.Visiting != 0 {
			status = "visit:" + strconv.Itoa(s.st.Visiting)
		}
		if scr.View != "quit" {
			w.TouchSession(s.SID, s.PID, s.Kind, s.location, status)
		}
		s.finish(&scr)
		return nil
	})
	if err != nil {
		return Screen{View: "generic", Text: "`4" + err.Error(), Buttons: []Button{B("Continue", "main", "").D()}}
	}
	return scr
}

func (s *Session) dispatch(a Action) Screen {
	if a.Cmd == "input" {
		p := s.pending
		s.pending = nil
		if p == nil {
			return s.cmdMain()
		}
		if p.Kind == "name" {
			v := ""
			if a.Value != nil {
				v = *a.Value
			}
			return s.nameSearch(p, v)
		}
		next := Action{Cmd: p.Cmd, Sub: p.Sub, Value: a.Value}
		if p.Extra != nil {
			next.HisID, next.Kind2, next.From, next.To = p.Extra.HisID, p.Extra.Kind2, p.Extra.From, p.Extra.To
		}
		return s.dispatch(next)
	}
	if a.Cmd == "namepick" {
		return s.namePick(a)
	}
	s.pending = nil
	switch a.Cmd {
	case "main":
		return s.cmdMain()
	case "quit":
		return s.cmdQuit()
	case "wait":
		return s.cmdWait()
	case "done":
		return s.cmdDone()
	case "soft":
		return s.cmdSoft()
	case "hard":
		return s.cmdHard()
	case "guilt":
		return s.cmdGuilt()
	case "sympathy":
		return s.cmdSympathy()
	case "risk_accept":
		return s.cmdRiskAccept()
	case "risk_take":
		return s.cmdRiskTake()
	case "arson":
		return s.cmdArson(a)
	case "stats":
		return s.cmdStats()
	case "weblogin":
		return s.cmdWebLogin(a)
	case "options":
		return s.cmdOptions(a)
	case "map":
		return s.cmdMap()
	case "cityhall":
		return s.cmdCityHall()
	case "news":
		return s.cmdNews(a)
	case "announce":
		return s.cmdAnnounce(a)
	case "ranking":
		return s.cmdRanking()
	case "mail_write":
		return s.cmdMailWrite(a)
	case "yangs":
		return s.cmdYangs(a)
	case "church":
		return s.cmdChurch(a)
	case "hospital":
		return s.cmdHospital(a)
	case "spirit":
		return s.cmdSpirit(a)
	case "bank":
		return s.cmdBank(a)
	case "store":
		return s.cmdStore(a)
	case "comp":
		return s.cmdComp(a)
	case "battle":
		return s.cmdBattle(a)
	case "cafe":
		return s.cmdCafe()
	}
	return s.cmdMain()
}

// ---------------------------------------------------------------- screen helpers

// B makes a button.
func B(label, cmd, sub string) Button {
	return Button{Label: label, Action: Action{Cmd: cmd, Sub: sub}}
}
func (b Button) K(k string) Button { b.Key = k; return b }
func (b Button) D() Button         { b.Def = true; return b }
func (b Button) His(id int) Button { b.HisID = &id; return b }

func (s *Session) finish(scr *Screen) {
	used := map[string]bool{}
	for _, b := range scr.Buttons {
		if b.Key != "" {
			used[strings.ToLower(b.Key)] = true
		}
	}
	for i := range scr.Buttons {
		b := &scr.Buttons[i]
		if b.Key != "" {
			continue
		}
		cand := strings.ToLower(b.Label) + "abcdefghijklmnopqrstuvwxyz0123456789"
		for _, c := range cand {
			k := string(c)
			if (c >= 'a' && c <= 'z' || c >= '0' && c <= '9') && !used[k] {
				b.Key = k
				used[k] = true
				break
			}
		}
	}
	hasDef := false
	for _, b := range scr.Buttons {
		hasDef = hasDef || b.Def
	}
	if !hasDef && len(scr.Buttons) > 0 {
		for i, b := range scr.Buttons {
			l := strings.ToLower(strings.TrimSpace(b.Label))
			if l == "continue" || l == "back" || l == "leave" || l == "done" {
				scr.Buttons[i].Def = true
				hasDef = true
				break
			}
		}
		if !hasDef && len(scr.Buttons) == 1 {
			scr.Buttons[0].Def = true
		}
	}
	if s.w != nil {
		if me := s.me(); me != nil {
			scr.Stats = Stats{Name: me.Name, Parlor: me.Parlor, SP: me.SP, Exp: me.Exp, Turns: me.Turns, Luck: me.Luck, Tags: me.Coffins,
				HP: me.HP, HPMax: me.HPMax, Day: s.age(), Mail: s.w.MailCount(me.ID), VisitsLeft: max(0, s.cfg().VisitsPerDay-me.Fights)}
		}
	}
	scr.Location = s.location
	scr.Pic = PicKey(scr.Pic)
	scr.BG = PicKey(scr.BG)
	if scr.RankRows != nil {
		scr.Rows = scr.RankRows
	} else if scr.StatRows != nil {
		scr.Rows = scr.StatRows
	}
	if scr.Buttons == nil {
		scr.Buttons = []Button{}
	}
	if scr.Input != nil {
		s.pending = scr.Input
	}
}

func (s *Session) deskButtons() []Button {
	return []Button{B("Wait for customers", "wait", "").K("w"), B("Town map", "map", "").K("t"), B("Stats", "stats", "").K("s"),
		B("Newspaper", "news", "").K("n"), B("Write a letter", "mail_write", "").K("l"), B("Quit", "quit", "").K("q")}
}
func (s *Session) desk(text string) Screen {
	return Screen{View: "desk", Pic: "places/desk", Text: text, Buttons: s.deskButtons()}
}
func (s *Session) deskPic(text, pic string) Screen {
	return Screen{View: "desk", Pic: pic, Text: text, Buttons: s.deskButtons()}
}
func cont(scr Screen, cmd, label string) Screen {
	if label == "" {
		label = "Continue"
	}
	if cmd == "" {
		cmd = "main"
	}
	scr.Buttons = []Button{B(label, cmd, "").D()}
	return scr
}
func (s *Session) setLocation(name string) {
	s.st = custStatus{}
	s.location = name
	s.chatting = false
}

func he(p *Player) string  { return ifs(p.Male, "he", "she") }
func He(p *Player) string  { return ifs(p.Male, "He", "She") }
func his(p *Player) string { return ifs(p.Male, "his", "her") }
func him(p *Player) string { return ifs(p.Male, "him", "her") }
func sir(p *Player) string { return ifs(p.Male, "sir", "ma'am") }
func ifs(c bool, a, b string) string {
	if c {
		return a
	}
	return b
}
func (s *Session) transportName(p *Player) string {
	if p.Transport < 0 || p.Transport >= len(s.data().Transport) {
		return "Bicycle"
	}
	return s.data().Transport[p.Transport].Name
}

func expMod(p *Player, v int) {
	if p.SP+v < 0 {
		v = -p.SP
	}
	p.SP = clamp(p.SP+v, 0, 2e9)
	p.Exp = clamp(p.Exp+v, 0, 2e9)
}
func expModForce(p *Player, v int) {
	p.SP = clamp(p.SP+v, 0, 2e9)
	p.Exp = clamp(p.Exp+v, 0, 2e9)
}
func luckMod(p *Player, v int)  { p.Luck = clamp(p.Luck+v, 1, 100) }
func turnsMod(p *Player, v int) { p.Turns = clamp(p.Turns+v, 0, 2e9) }

func (s *Session) randomPlayerExcluding(id int) *Player {
	var list []*Player
	for _, p := range s.w.Active() {
		if p.ID != id {
			list = append(list, p)
		}
	}
	if len(list) == 0 {
		return nil
	}
	return pick(list)
}

// ---------------------------------------------------------------- name lookup (the "i_getname" dialog)

func askName(prompt, cmd, sub string, extra *Action) *Input {
	return &Input{Kind: "name", Prompt: prompt, Cmd: cmd, Sub: sub, Extra: extra, MaxLen: 20}
}
func (s *Session) redispatchWithHis(p *Input, his int) Screen {
	a := Action{Cmd: p.Cmd, Sub: p.Sub, HisID: &his}
	if p.Extra != nil {
		a.Kind2, a.From, a.To = p.Extra.Kind2, p.Extra.From, p.Extra.To
	}
	return s.dispatch(a)
}
func (s *Session) nameSearch(p *Input, value string) Screen {
	q := strings.ToLower(strings.TrimSpace(value))
	if q == "" {
		return s.redispatchWithHis(p, -1)
	}
	var matches []int
	for _, pl := range s.w.Active() {
		if strings.Contains(strings.ToLower(pl.Name), q) {
			matches = append(matches, pl.ID)
		}
	}
	s.namePend = &namePend{pend: p, matches: matches}
	if len(matches) == 0 {
		return Screen{View: "popup", Text: fmt.Sprintf("`$Nobody in town has `w'%s'`$ in their name.", value),
			Buttons: []Button{B("Try again", "namepick", "retry").K("t").D(), B("Cancel", "namepick", "cancel").K("c")}}
	}
	return s.nameConfirm()
}
func (s *Session) nameConfirm() Screen {
	np := s.namePend
	p := s.w.Player(np.matches[np.i])
	return Screen{View: "popup", Text: fmt.Sprintf("`$Did you mean `w%s`$ of %s?", p.Name, p.Parlor),
		Buttons: []Button{B("Yes", "namepick", "yes").K("y"), B("Next", "namepick", "next").K("n"), B("Cancel", "namepick", "cancel").K("c")}}
}
func (s *Session) namePick(a Action) Screen {
	np := s.namePend
	if np == nil {
		return s.cmdMain()
	}
	switch {
	case a.Sub == "retry":
		return Screen{View: "popup", Text: "`$" + np.pend.Prompt, Input: askName(np.pend.Prompt, np.pend.Cmd, np.pend.Sub, np.pend.Extra)}
	case a.Sub == "next" && len(np.matches) > 0:
		np.i = (np.i + 1) % len(np.matches)
		return s.nameConfirm()
	}
	s.namePend = nil
	his := -1
	if a.Sub == "yes" && len(np.matches) > 0 {
		his = np.matches[np.i]
	}
	return s.redispatchWithHis(np.pend, his)
}

func hisID(a Action) int {
	if a.HisID == nil {
		return 0
	}
	return *a.HisID
}
func val(a Action) (string, bool) {
	if a.Value == nil {
		return "", false
	}
	return *a.Value, true
}

// ======================================================================== desk (commands_main.cpp)

func (s *Session) cmdMain() Screen {
	s.setLocation("At Home")
	me := s.me()
	msg := ""
	if !s.greeted {
		s.greeted = true
		if me.DayLast != s.age() {
			first := me.DayLast == 0
			bonus := s.baseNewDay()
			txt := fmt.Sprintf("`wWelcome back, %s!`^\n\n", me.Name)
			if first {
				txt = fmt.Sprintf("`wWelcome to Funeral Quest, %s.  Good luck.`^\n\n", me.Name)
			}
			txt += fmt.Sprintf("`$You unlock the front door and enter your beloved %s Funeral Parlor.  Ah, it's great to be alive.\n\n%s", me.Parlor, bonus)
			return cont(Screen{View: "desk", Pic: "morning_coffee", Text: txt}, "", "")
		}
		msg = fmt.Sprintf("`$Welcome back, `w%s`$.  Unfinished business?\n", me.Name)
	} else if me.DayLast != s.age() {
		bonus := s.baseNewDay()
		txt := "`wYou're eyes grow heavy.  You wake up the next morning, still at your desk.\n\n" +
			fmt.Sprintf("`$You quickly freshen up.. who knows what great things await %s Funeral Parlor today?\n\n%s", me.Parlor, bonus)
		return cont(Screen{View: "desk", Pic: "morning_coffee", Text: txt}, "", "")
	}
	for {
		l := s.w.TakeMail(me.ID)
		if l == nil {
			break
		}
		if l.Expire != 0 && l.Expire <= s.age() {
			continue
		}
		return s.showLetter(l, msg)
	}
	if msg == "" {
		msg = "`$You are sitting at your desk.\n"
		if me.Police {
			msg = "`$You are sitting at your desk.  Police are outside, you feel safe.\n"
		}
	}
	return s.desk(msg)
}

func (s *Session) showLetter(l *Letter, prefix string) Screen {
	me := s.me()
	if l.Luck != 0 {
		luckMod(me, l.Luck)
	}
	if l.BP != 0 {
		expMod(me, l.BP)
	}
	if l.Turns != 0 {
		turnsMod(me, l.Turns)
	}
	for i := 0; i < 3; i++ {
		me.Coffins[i] += l.Tags[i]
	}
	if l.Log != "" {
		s.news("front", l.Log)
	}
	var bs []Button
	if l.ReplyTo != 0 {
		bs = append(bs, B("Reply", "mail_write", "").His(l.ReplyTo).K("r"))
	}
	bs = append(bs, B("Continue", "main", "").D())
	pic := l.Pic
	if pic == "" {
		pic = "note"
	}
	return Screen{View: "desk", Text: prefix + "`w" + l.Text + "\n", Pic: pic, BG: l.BG, Buttons: bs}
}

func (s *Session) baseNewDay() string {
	me := s.me()
	c := s.cfg()
	me.Turns = c.TurnsPerDay
	if me.Transport < 0 || me.Transport >= len(s.data().Transport) {
		me.Transport = 0
	}
	if me.Exp < 0 {
		me.Exp = 0
	}
	me.Turns += s.data().Transport[me.Transport].Bonus
	me.SP, me.Kicked, me.DayLast, me.Fights, me.Police = 0, false, s.age(), 0, false
	if tournEndsToday(s.w) {
		me.Turns, me.Fights = 0, c.VisitsPerDay
	}
	bonus := ""
	if me.Transport > 0 {
		bonus = fmt.Sprintf("Your %s gives you time for `w%d`$ extra customers. ", s.transportName(me), s.data().Transport[me.Transport].Bonus)
	}
	return bonus
}

func (s *Session) cmdQuit() Screen {
	s.G.Broadcast(s.w, s.me().Name+" logged off.")
	s.w.RemoveSession(s.SID)
	s.Quitting = true
	return Screen{View: "quit", Text: "`$You lock up the parlor for the night."}
}

// Disconnect removes the session when a caller drops without quitting.
func (s *Session) Disconnect() {
	s.G.Store.Tx(func(w *World) error {
		if !s.Quitting {
			if p := w.Player(s.PID); p != nil {
				s.G.Broadcast(w, p.Name+" logged off.")
			}
		}
		w.RemoveSession(s.SID)
		return nil
	})
}

// ======================================================================== customers

func (s *Session) cmdWait() Screen {
	me := s.me()
	if me.Turns < 1 {
		return s.deskPic("`$"+pick([]string{"You are out of turns for the day, come back tomorrow!", "It's closing time, you'll have to wait until tomorrow.", "You look at your watch - it's late.  Maybe tomorrow."}), "closed")
	}
	c := s.cfg()
	if frandom(1) < c.NormalOdds {
		return s.randomEventFreeBP()
	}
	s.createRandomCustomer()
	if frandom(1) < c.LuckOdds {
		return s.riskStart()
	}
	if frandom(1) < c.ScriptOdds {
		if random(2) == 0 {
			return s.cmdArson(Action{})
		}
		return s.bonusTag()
	}
	me.Turns--
	return s.complicatedCustomer()
}

func (s *Session) randomEventFreeBP() Screen {
	me := s.me()
	ev := computeEvent(s.data().Events, me.Exp)
	if ev == nil {
		ev = &Event{Message: "Nothing happens."}
	}
	l, b, t := evRoll(ev)
	bpName, tName := "Bury Points", "turns"
	if abs(b) == 1 {
		bpName = "Bury Point"
	}
	if abs(t) == 1 {
		tName = "turn"
	}
	reward := rewardText([][2]any{{bpName, b}, {"luck", l}, {tName, t}})
	expMod(me, b)
	luckMod(me, l)
	turnsMod(me, t)
	pic := ev.Pic
	if pic == "" {
		pic = "places/embalming-room"
	}
	return s.deskPic("`wSPECIAL EVENT\n\n`$"+ev.Message+reward, pic)
}

const (
	ageKid = iota
	ageTeen
	ageAdult
	ageOld
)
const (
	relNone = iota
	relSibling
	relParent
	relChild
	relSpouse
	relCousin
	relGrandParent
	relLover
	relGrandChild
	relFriend
)

var killObject = []string{"car", "tractor", "fridge", "piano", "bull", "elephant", "truck", "fork-lift", "exercise machine", "power boat", "computer", "house"}
var killType = []string{"hit by", "smashed by", "run over by", "thrown by", "crushed by", "done in by", "fatally stuck inside", "smacked a good one by"}

func rangeFromAge(a int) int {
	switch {
	case a >= 60:
		return ageOld
	case a >= 28:
		return ageAdult
	case a >= 15:
		return ageTeen
	}
	return ageKid
}
func randomAge(r int) int {
	switch r {
	case ageKid:
		return randomRange(7, 11)
	case ageTeen:
		return randomRange(15, 19)
	case ageAdult:
		return randomRange(28, 40)
	}
	return randomRange(60, 99)
}

func (s *Session) createRandomCustomer() {
	st := custStatus{CustomerActive: true}
	st.CMale = random(2) == 0
	st.CAge = randomAge(1 + random(3))
	st.DMale = random(2) == 0
	st.DAge = randomAge(random(4))
	st.Relation = relationship(&st)
	st.Upgrade = -1
	st.Income = random(4)
	switch st.Income {
	case 0:
		st.Money = randomRange(casketPrice[0]+1, 2800)
	case 1:
		st.Money = randomRange(1900, 5400)
	case 2:
		st.Money = randomRange(3700, 7530)
	default:
		st.Money = randomRange(4600, 18500)
	}
	st.Loved = random(2) == 1
	st.Mood = frandom(10)
	st.Cheap = frandom(10)
	st.KillObject = random(len(killObject))
	st.KillType = random(len(killType))
	s.st = st
	s.options = nil
	for i := 0; i < 100; i++ {
		s.st.Casket = random(3)
		if s.priceInt() <= s.st.Money {
			break
		}
	}
	if s.priceInt() > s.st.Money {
		s.st.Casket = Wood
	}
}

func relationship(st *custStatus) int {
	cr, dr := rangeFromAge(st.CAge), rangeFromAge(st.DAge)
	diff := st.CMale != st.DMale
	r := relNone
	switch cr {
	case ageKid:
		r = relSibling
		if dr == ageAdult {
			r = relParent
		} else if dr == ageOld {
			r = relGrandParent
		}
	case ageTeen:
		switch dr {
		case ageKid:
			r = relSibling
		case ageTeen:
			x := random(3)
			r = relSibling
			if x == 1 && diff {
				r = relLover
			}
		case ageAdult:
			x := random(3)
			r = relParent
			if x == 1 && diff {
				r = relLover
			}
		case ageOld:
			r = relGrandParent
		}
	case ageAdult:
		switch dr {
		case ageKid:
			r = relChild
		case ageTeen:
			x := random(3)
			r = relChild
			if x == 1 && diff {
				r = relLover
			}
		case ageAdult:
			x := random(6)
			r = relSibling
			if x > 3 && diff {
				r = relSpouse
			}
		case ageOld:
			x := random(6)
			r = relParent
			if x == 1 && diff {
				r = relLover
			}
			if x == 2 && diff {
				r = relSpouse
			}
		}
	default:
		switch dr {
		case ageKid:
			r = relGrandChild
		case ageTeen:
			x := random(10)
			r = relGrandChild
			if x == 1 && diff {
				r = relLover
			}
		case ageAdult:
			x := random(10)
			r = relChild
			if x == 1 && diff {
				r = relLover
			}
			if x == 2 && diff {
				r = relSpouse
			}
		case ageOld:
			x := random(6)
			r = relSibling
			if diff {
				r = relSpouse
			}
			if x == 1 && diff {
				r = relLover
			}
			if x == 2 {
				r = relSibling
			}
		}
	}
	return r
}

// ---- customer words (online_struct.cpp)
func (s *Session) cMan() string {
	young := rangeFromAge(s.st.CAge) <= ageTeen
	if s.st.CMale {
		return ifs(young, "boy", "man")
	}
	return ifs(young, "girl", "woman")
}
func (s *Session) cYoung() string {
	return []string{"little", "teenage", "middle aged", "old"}[rangeFromAge(s.st.CAge)]
}
func (s *Session) cAYoung() string {
	return []string{"A little", "A teenage", "A middle aged", "An old"}[rangeFromAge(s.st.CAge)]
}
func (s *Session) cYoungMan() string {
	x := s.cYoung() + " " + s.cMan()
	return strings.ToUpper(x[:1]) + x[1:]
}
func (s *Session) cIncome() string {
	return []string{"Poor", "Average", "Rich", "Super Rich"}[s.st.Income]
}
func (s *Session) cHe() string      { return ifs(s.st.CMale, "he", "she") }
func (s *Session) cHeU() string     { return ifs(s.st.CMale, "He", "She") }
func (s *Session) cHis() string     { return ifs(s.st.CMale, "his", "her") }
func (s *Session) cHim() string     { return ifs(s.st.CMale, "him", "her") }
func (s *Session) cSirU() string    { return ifs(s.st.CMale, "Sir", "Ma'am") }
func (s *Session) cSir() string     { return ifs(s.st.CMale, "sir", "ma'am") }
func (s *Session) dHeU() string     { return ifs(s.st.DMale, "He", "She") }
func (s *Session) dHe() string      { return ifs(s.st.DMale, "he", "she") }
func (s *Session) dHim() string     { return ifs(s.st.DMale, "him", "her") }
func (s *Session) dFridge() string  { return killObject[s.st.KillObject] }
func (s *Session) dSmashed() string { return killType[s.st.KillType] }
func (s *Session) dRelation() string {
	kidish := rangeFromAge(s.st.CAge) <= ageTeen
	var m [2]string
	switch s.st.Relation {
	case relSibling:
		m = [2]string{"brother", "sister"}
	case relParent:
		if kidish {
			m = [2]string{"dad", "mom"}
		} else {
			m = [2]string{"father", "mother"}
		}
	case relChild:
		m = [2]string{"son", "daughter"}
	case relSpouse:
		m = [2]string{"husband", "wife"}
	case relCousin:
		m = [2]string{"cousin", "cousin"}
	case relGrandParent:
		m = [2]string{"grandfather", "grandmother"}
	case relLover:
		m = [2]string{"boyfriend", "girlfriend"}
	case relGrandChild:
		m = [2]string{"grandson", "granddaughter"}
	case relFriend:
		m = [2]string{"friend", "friend"}
	default:
		return "relative"
	}
	if s.st.DMale {
		return m[0]
	}
	return m[1]
}
func (s *Session) cMood() string {
	loved := []string{"In Shock", "Dazed", "Confused", "Crying", "Numb", "Disturbed", "Frustrated", "Irked", "Angry", "Pissed"}
	not := []string{"Chipper", "In a hurry", "Natural", "Tight Lipped", "Nervous", "Frustrated", "Annoyed", "Irked", "Angry", "Pissed"}
	i := clamp(int(math.Floor(s.st.Mood)), 0, 9)
	if s.st.Loved {
		return loved[i]
	}
	return not[i]
}
func (s *Session) cFlashURL() string {
	r := rangeFromAge(s.st.CAge)
	var u [][]string
	if s.st.CMale {
		u = [][]string{{"m_teen"}, {"m_teen", "m_teen_2"}, {"m_adult", "m_adult_2", "m_adult_3", "m_adult_4"}, {"m_old", "m_old_2", "m_old_5", "m_old_6"}}
	} else {
		u = [][]string{{"f_teen"}, {"f_teen", "f_teen_2"}, {"f_adult", "f_adult_2"}, {"f_old", "f_old_2"}}
	}
	return "people/" + pick(u[r])
}
func (s *Session) priceInt() int {
	p := casketPrice[s.st.Casket]
	for _, o := range s.options {
		p += s.data().Options[o].Price
	}
	for i := 0; i <= s.st.Upgrade && i < len(s.data().Upgrades); i++ {
		p += s.data().Upgrades[i].Price
	}
	return p
}
func (s *Session) total() string {
	t := "\n\nTotal: $" + Cash(s.priceInt())
	if s.st.ShowResistance {
		t += fmt.Sprintf(" `5(Resistance: `#%d%%`5)", int(math.Round(s.st.Cheap*10)))
	}
	return t
}

func (s *Session) complicatedCustomer() Screen {
	me := s.me()
	st := &s.st
	url := s.cFlashURL()
	var parts []string
	if randomYesNo(20+me.Psych*13, 0.98) {
		parts = append(parts, fmt.Sprintf("`wYou successfully analyze %s resistance.`$", s.cHis()))
		st.ShowResistance = true
	}
	if me.Psych > 0 && randomYesNo(me.Psych*14, 0.98) {
		if st.Loved {
			parts = append(parts, fmt.Sprintf("`w%s seems heartbroken.`$", s.cHeU()))
		} else {
			parts = append(parts, fmt.Sprintf("`w%s seems guilty.`$", s.cHeU()))
		}
	}
	if me.Psych > 4 && randomYesNo(me.Psych*15-65, 0.98) {
		parts = append(parts, "`wSpending limit doubled.`$")
		st.Money *= 2
	}
	if me.Psych > 1 && randomYesNo(me.Psych*15-25, 0.98) {
		parts = append(parts, fmt.Sprintf("`wYou estimate %s is worth about $%s.`$", s.cHe(), Cash(st.Money)))
	}
	if me.Psych > 2 && randomYesNo(me.Psych*15-35, 0.98) {
		parts = append(parts, "`wResistance cut in half.`$")
		st.Cheap *= 0.5
	}
	if me.Psych > 3 && randomYesNo(me.Psych*15-50, 0.98) {
		parts = append(parts, "`wMood cut in half.`$")
		st.Mood *= 0.5
	}
	psych := fmt.Sprintf("\n\n`$You are unable to analyze anything extra about %s.", s.cHim())
	if len(parts) > 0 {
		psych = "\n\n" + strings.Join(parts, " ")
	}
	st.URLSave = url
	st.Special = "complicated"
	st.BG = fmt.Sprintf("background/background_%d", random(4)+1)
	text := fmt.Sprintf("`w%s: `$\"Please, I need a funeral service for my %s. I would need a plot and a %s casket for %s.\"", s.cYoungMan(), s.dRelation(), casketName[st.Casket], s.dHim()) + psych + s.total()
	return s.saleScreen(text)
}

func (s *Session) saleScreen(text string) Screen {
	return Screen{View: "desk", Sale: true, Pic: s.st.URLSave, BG: s.st.BG, Text: text, Mood: s.cMood(), Cls: s.cIncome(),
		Buttons: []Button{B("Guilt", "guilt", "").K("g"), B("Sympathy", "sympathy", "").K("y"), B("Hard Sell", "hard", "").K("h"),
			B("Soft Sell", "soft", "").K("s"), B("Done", "done", "").K("d").D()}}
}
func (s *Session) saleGuard() bool { return s.st.CustomerActive && s.st.Special == "complicated" }
func (s *Session) ym() string      { return "`w" + s.cYoungMan() + ": `$" }

func (s *Session) cmdDone() Screen {
	if !s.saleGuard() {
		return s.cmdMain()
	}
	me := s.me()
	st := &s.st
	price := s.priceInt()
	bp := int(float64(price) * 0.0064)
	extra := ""
	tb := s.cfg().TradeBonus
	switch {
	case price == st.Money:
		extra = fmt.Sprintf("`wEXCELLENT! `$For making this funeral cost the max %s could pay you receive a `w200`$ BP bonus!\n\n", s.cHe())
		bp += 200
		s.news("front", fmt.Sprintf("`7%s makes a perfect sale, the industry is in awe.\r\n\r\n", me.Name))
	case abs(price-st.Money) <= 50:
		extra = fmt.Sprintf("`wGREAT! `$For getting within 50 of this customers limit you receive a `w%d`$ BP bonus!\n\n", tb+10)
		bp += tb + 10
	case abs(price-st.Money) <= 100:
		extra = fmt.Sprintf("`wNICE! `$For getting within 100 of this customers limit you receive a `w%d`$ BP bonus!\n\n", tb)
		bp += tb
	}
	text := fmt.Sprintf("`w`$The service is a success!  Total bill is $%s.\n\n%sYou earn `w%d`$ Bury Points and a %s sales tag.", Cash(price), extra, bp, casketName[st.Casket])
	if bp > 69 {
		s.G.Tv(s.w, fmt.Sprintf("\"It appears %s just made a %d BP sale,\" a guy reports.", me.Name, bp))
	}
	st.Special, st.CustomerActive = "", false
	expMod(me, bp)
	me.Coffins[st.Casket]++
	me.Plots++
	return cont(Screen{View: "desk", Pic: "stuff/money_bag_2", Text: text}, "", "")
}

func (s *Session) leavePissed(prefix string, overLimit bool) Screen {
	me := s.me()
	st := &s.st
	ym := s.ym()
	var ans string
	if overLimit {
		ans = pick([]string{ym + "\"That would put me over my limit.. I don't have time for this, bye.\"\n",
			fmt.Sprintf("%s\"Damn, you see, I can only spend $%s.  I'm leaving.\"\n", ym, Cash(st.Money)),
			fmt.Sprintf("%s\"My visa only goes to $%s... I'll try next-door.\"\n", ym, Cash(st.Money))})
	} else {
		ans = pick([]string{ym + "\"You know what? I really don't like the way you work. Bye.\"\n", ym + "\"Enough is enough.  I'm sick of you.\"\n",
			ym + "\"I just realized that you disgust me.  Sayoonara.\"\n", ym + "\"Can we cut the crap for a second here?  I guess not, bye.\"\n"})
	}
	s.G.Tv(s.w, fmt.Sprintf("\"A %s %s %s just left %s looking pissed,\" a reporter says.", s.cIncome(), s.cYoung(), s.cMan(), me.Parlor))
	other := ""
	if np := s.randomPlayerExcluding(me.ID); np != nil {
		other = fmt.Sprintf("\n`$You watch %s through the window after %s leaves.  You see %s go into %s to see %s!", s.cHim(), s.cHe(), s.cHim(), np.Parlor, np.Name)
		pts := 5 + random(5)
		s.w.AddMail(Letter{To: np.ID, Pic: st.URLSave, BG: "background/background_2", BP: pts,
			Text: fmt.Sprintf("\n`$%s %s walks in with a dead body. \"Hello %s, I would like you to know I got treated like crap by %s of %s. I know you'll do a better job!\"\n\nYou earn `w%d`$ Bury Points for stealing this sale!\n",
				s.cAYoung(), s.cMan(), sir(np), me.Name, me.Parlor, pts)})
	}
	st.Special, st.CustomerActive = "", false
	return cont(Screen{View: "desk", Pic: "stuff/money_bag", Text: prefix + ans + other}, "", "")
}

func (s *Session) cmdSoft() Screen {
	if !s.saleGuard() {
		return s.cmdMain()
	}
	me := s.me()
	st := &s.st
	oi := random(len(s.data().Options))
	o := s.data().Options[oi]
	n := me.Name
	cust := pick([]string{
		fmt.Sprintf("`w%s: `$\"You know, your neighbor was in here recently.. he bought %s %s for only $%s. Impeccable taste.\"\n\n", n, o.A, o.Name, Cash(o.Price)),
		fmt.Sprintf("`w%s: `$\"I can tell by the fine clothes you're wearing that you appreciate the finer things. How about %s %s for $%s?\"\n\n", n, o.A, o.Name, Cash(o.Price)),
		fmt.Sprintf("`w%s: `$\"I don't mean to rush you, but this isn't really something you can wait a week thinking about. We do have %s %s for $%s...\"\n\n", n, o.A, o.Name, Cash(o.Price)),
		fmt.Sprintf("`w%s: `$\"You know..  I bet your %s's social security death benefits would probably cover %s %s for $%s?\"\n\n", n, s.dRelation(), o.A, o.Name, Cash(o.Price)),
	})
	ym := s.ym()
	var ans string
	if frandom(10) < st.Cheap {
		st.Mood += 0.4 + frandom(0.7)
		if st.Mood >= 10 {
			return s.leavePissed(cust, false)
		}
		r3 := fmt.Sprintf("%s\"I'm not gonna pay another $%s for an 'effing %s I barely knew!\"", ym, Cash(o.Price), s.dRelation())
		if st.Loved {
			r3 = fmt.Sprintf("%s\"When my %s was alive %s asked me not to buy that.  I'm sorry.\"", ym, s.dRelation(), s.dHe())
		}
		ans = pick([]string{fmt.Sprintf("%s\"I really don't think my %s needs that.\"", ym, s.dRelation()), fmt.Sprintf("%s\"Actually, my %s wanted a very simple funeral.\"", ym, s.dRelation()),
			ym + "\"Um, no.\"", r3, ym + "\"You've got to be kidding.\"", ym + "\"I'm not saying I can't afford that, but I don't think I really need it.\""})
		return s.saleScreen(cust + ans + s.total())
	}
	m := st.Mood
	if s.priceInt()+o.Price <= st.Money {
		s.options = append(s.options, oi)
		switch {
		case m < 2:
			ans = ym + "\"Thank you, I'll take it.\""
		case m < 4:
			ans = fmt.Sprintf("%s\"You don't say? %s is something I want then.\"", ym, o.Name)
		case m < 7:
			ans = ym + "\"Fine, I'll take it.\""
		case m < 9:
			ans = ym + "\"I think I'm getting ripped off here but I'll take it.\""
		default:
			ans = ym + "\"WHATEVER!! Just give it to me I guess.\""
		}
	} else {
		if m > 9 {
			return s.leavePissed("", true)
		}
		st.Mood += 0.4 + frandom(1)
		ans = ym + "\"That would put me over my limit.. how about something cheaper?\""
	}
	return s.saleScreen(cust + ans + s.total())
}

func (s *Session) cmdHard() Screen {
	if !s.saleGuard() {
		return s.cmdMain()
	}
	st := &s.st
	if st.Casket == Gold {
		return s.complicatedUpgrade()
	}
	n := s.me().Name
	var price int
	var cust string
	if st.Casket == Wood {
		price = casketPrice[Silver] - casketPrice[Wood]
		cust = pick([]string{fmt.Sprintf("`w%s: `$\"Well, I suppose you COULD go with a wood casket.. except it really doesn't offer much protection from worms and the like.  How about a Silver Casket for only $%s additional?\"\n\n", n, Cash(price)),
			fmt.Sprintf("`w%s: `$\"Wouldn't your %s prefer our traditional Silver Casket for only $%s more?\"\n\n", n, s.dRelation(), Cash(price))})
	} else {
		price = casketPrice[Gold] - casketPrice[Silver]
		cust = pick([]string{fmt.Sprintf("`w%s: `$\"Just think of the beautiful memory picture you would have of your %s in a Gold Casket - a bargain for only $%s more!\"\n\n", n, s.dRelation(), Cash(price)),
			fmt.Sprintf("`w%s: `$\"A Gold Casket (only $%s additional) reflects character and station in life.. its suberb styling reflects a successful living.\"\n\n", n, Cash(price))})
	}
	metal := ifs(st.Casket == Silver, "gold", "silver")
	ym := s.ym()
	var ans string
	if frandom(10) < st.Cheap || st.Cheap > 8 {
		st.Mood += 0.6 + frandom(1)
		if st.Mood >= 10 {
			return s.leavePissed(cust, false)
		}
		r3 := fmt.Sprintf("%s\"My %s doesn't deserve %s.\"", ym, s.dRelation(), metal)
		if st.Loved {
			r3 = ym + "\"No way, for that much it should have AC and a stereo!\""
		}
		ans = pick([]string{fmt.Sprintf("%s\"I really don't think my %s needs that.\"", ym, s.dRelation()), fmt.Sprintf("%s\"Actually, my %s wanted a very simple funeral.\"", ym, s.dRelation()),
			ym + "\"A casket is a casket, right?\"", r3, ym + "\"I don't want to spend that much.\"", ym + "\"I've got the dough, but I would rather give to charity.\""})
		return s.saleScreen(cust + ans + s.total())
	}
	if s.priceInt()+price <= st.Money {
		st.Casket++
		if st.Mood < 7 {
			ans = pick([]string{ym + "\"Alright, I'll take it.\"", ym + "\"Ok, I'll do the upgrade.\"", ym + "\"Well, since you put it that way, ok.\""})
		} else {
			ans = fmt.Sprintf("%s\"Fine, I'll take the damn %s casket, ok?\"", ym, metal)
		}
	} else {
		if st.Mood > 9 {
			return s.leavePissed(cust, true)
		}
		st.Mood += 0.4 + frandom(1)
		ans = ym + "\"That casket would put me over my limit.. how about something cheaper?\""
	}
	return s.saleScreen(cust + ans + s.total())
}

func (s *Session) complicatedUpgrade() Screen {
	st := &s.st
	ups := s.data().Upgrades
	ui := st.Upgrade + 1
	if ui >= len(ups) {
		return s.saleScreen(fmt.Sprintf("`yThis %s has already bought everything big you can think of.  It's a great feeling.", s.cMan()) + s.total())
	}
	last := "Gold Casket"
	if st.Upgrade >= 0 {
		last = ups[st.Upgrade].Name
	}
	u := ups[ui]
	n := s.me().Name
	cust := pick([]string{fmt.Sprintf("`w%s: `$\"A simple %s may be enough for some.  But tell me, don't the words '%s' (only $%s additional) give you goosebumps?\"\n\n", n, last, u.Name, Cash(u.Price)),
		fmt.Sprintf("`w%s: `$\"I would feel guilty if I didn't mention we do offer a %s for a small fee of $%s.\"\n\n", n, u.Name, Cash(u.Price)),
		fmt.Sprintf("`w%s: `$\"%s's are a great idea for an enternal slumber. A fee of $%s will be charged, alright?\"\n\n", n, u.Name, Cash(u.Price))})
	ym := s.ym()
	var ans string
	if frandom(10) < st.Cheap || st.Cheap > 8 {
		st.Mood += 0.7 + frandom(1)
		if st.Mood >= 10 {
			return s.leavePissed(cust, false)
		}
		r3 := fmt.Sprintf("%s\"In case you haven't noticed, I wasn't overly fond of my %s.  Forget it.\"", ym, s.dRelation())
		if st.Loved {
			r3 = ym + "\"God, can't you see this is hurting me talking about this now?\""
		}
		ans = pick([]string{ym + "\"No.\"", fmt.Sprintf("%s\"Actually I want a simple funeral for my %s.\"", ym, s.dRelation()), ym + "\"I would rather spend money getting drunk after this.\"",
			r3, fmt.Sprintf("%s\"You just said $%d right? I hope you're kidding.\"", ym, u.Price), ym + "\"I've got the dough, but I would rather spend it on something that matters.\""})
		return s.saleScreen(cust + ans + s.total())
	}
	if s.priceInt()+u.Price <= st.Money {
		st.Upgrade++
		if st.Mood < 7 {
			ans = pick([]string{ym + "\"Alright, I'll take it.\"", ym + "\"Ok.\"", ym + "\"Maybe you're right.  Ok.\""})
		} else {
			ans = ym + "\"Fine, whatever, ok?\""
		}
	} else {
		if st.Mood > 9 {
			return s.leavePissed(cust, false)
		}
		st.Mood += 0.4 + frandom(1)
		ans = ym + "\"That would put me over my limit.. how about something cheaper?\""
	}
	return s.saleScreen(cust + ans + s.total())
}

func (s *Session) cmdGuilt() Screen {
	if !s.saleGuard() {
		return s.cmdMain()
	}
	st := &s.st
	if st.Mood >= 10 {
		return s.leavePissed("`$You are interrupted!\n\n", false)
	}
	n := s.me().Name
	cust := pick([]string{fmt.Sprintf("`w%s: `$\"The funeral is not occasion for a display of cheapness, %s.\"\n\n", n, s.cSir()),
		fmt.Sprintf("`w%s: `$\"%s,  let me ask you one simple thing.  Did you hate %s?  Why else wouldn't you make this funeral something to be proud of?\"\n\n", n, s.cSirU(), s.dHim()),
		fmt.Sprintf("`w%s: `$\"Some believe an expensive funeral absolves the purchaser from any sin.  I happen to believe this, my friend.\"\n\n", n),
		fmt.Sprintf("`w%s: `$\"I would stay away from cremation.  Your loved one deserves better than 'bake and shake' - people would talk.\"\n\n", n),
		fmt.Sprintf("`w%s: `$\"Resistance to a 'proper' funeral will send the wrong message, wouldn't you agree?\"\n\n", n)})
	st.Mood += frandom(1)
	ym := s.ym()
	var ans string
	if st.Loved {
		st.Mood += 1 + frandom(2)
		ans = pick([]string{fmt.Sprintf("%s\"I LOVED %s! Don't you get it? None of that stuff matters to me!\"", ym, s.dHim()),
			fmt.Sprintf("%s\"My %s was %s a %s for god-sake! How can you say something like that?\"", ym, s.dRelation(), s.dSmashed(), s.dFridge()),
			ym + "\"If you want to keep my business you're going to stop saying stuff like that.\""})
	} else {
		st.Cheap = fclamp(st.Cheap-(0.7+frandom(2)), 0, 10)
		ans = pick([]string{ym + "\"You're right. I should be a little looser with my money.\"",
			fmt.Sprintf("%s\"Good call.  I guess it would be appropriate to spend more on my %s.\"", ym, s.dRelation()),
			ym + "\"You've got a point there.. It makes me mad but you're right.\"",
			fmt.Sprintf("%s\"I agree in principle.. but I only want to spend $%s on this.\"", ym, Cash(st.Money))})
	}
	return s.saleScreen(cust + ans + s.total())
}

func (s *Session) cmdSympathy() Screen {
	if !s.saleGuard() {
		return s.cmdMain()
	}
	st := &s.st
	if st.Mood >= 10 {
		return s.leavePissed("`$You are interrupted!\n\n", false)
	}
	n := s.me().Name
	cust := pick([]string{fmt.Sprintf("`w%s: `$\"%s, I understand you've been through a lot, please tell me what happened.\"\n\n", n, s.cSirU()),
		fmt.Sprintf("`w%s: `$\"I know how you feel.  I know someone who lost a %s once.\"\n\n", n, s.dRelation()),
		fmt.Sprintf("`w%s: `$\"So you two were close?  %s sounds very special.\"\n\n", n, s.dHeU()),
		fmt.Sprintf("`w%s: `$\"I'm not a licensed therapist.. but keep talking, get the pain out.\"\n\n", n),
		fmt.Sprintf("`w%s: `$\"Any time a %s is involved in an accident it's going to be traumatic.\"\n\n", n, s.dFridge())})
	st.Mood += 0.4 + frandom(1)
	ym := s.ym()
	var ans string
	if !st.Loved {
		st.Mood += 1 + frandom(2)
		ans = pick([]string{ym + "\"Sorry, I don't read ya, pard.\"", ym + "\"I don't go for all this touchy feeling crap, ok?  Don't hug me.\"",
			fmt.Sprintf("%s\"Um yeah.. except I actually have another %s, so it ain't so bad.  No more wasting my time, ok?\"", ym, s.dRelation())})
	} else {
		st.Cheap = fclamp(st.Cheap-(0.7+frandom(2)), 0, 10)
		ans = pick([]string{fmt.Sprintf("%s\"It's just.. I feel like %s is just in another room, you know?\"", ym, s.dHe()),
			fmt.Sprintf("%s\"I still have dreams.. of %s getting %s a %s over and over.\"", ym, s.dHim(), s.dSmashed(), s.dFridge()),
			fmt.Sprintf("%s\"I mean, usually someone's %s is close.. but we were REALLY close if you know what I mean.\"", ym, s.dRelation()),
			fmt.Sprintf("%s\"I appreciate what you're trying to do but I need to get this over with..for $%s or less..\"", ym, Cash(st.Money))})
	}
	return s.saleScreen(cust + ans + s.total())
}

// ---- risks (commands_customer_risk.cpp)
func (s *Session) riskWords(t string) string {
	me := s.me()
	return strings.NewReplacer("*SIR*", sir(me), "*NAME*", me.Name, "*PARLOR*", me.Parlor, "\\n", "\n").Replace(t)
}
func (s *Session) riskStart() Screen {
	st := &s.st
	st.Special = "risk"
	st.Risk = random(len(s.data().Risks))
	r := s.data().Risks[st.Risk]
	return Screen{View: "desk", Pic: r.StartURL, BG: r.StartBG, Text: s.riskWords(r.StartMessage),
		Buttons: []Button{B(ifs(r.Risk != "", r.Risk, "Risk it"), "risk_take", "").K("r"), B(ifs(r.Accept != "", r.Accept, "Play safe"), "risk_accept", "").K("p")}}
}
func (s *Session) cmdRiskAccept() Screen {
	st := &s.st
	if !st.CustomerActive || st.Special != "risk" {
		return s.cmdMain()
	}
	r := s.data().Risks[st.Risk]
	sp := randomRange(4, 10)
	expMod(s.me(), sp)
	st.CustomerActive, st.Special = false, ""
	return cont(Screen{View: "desk", Pic: r.AcceptURL, BG: r.AcceptBG, Text: s.riskWords(r.AcceptMessage) + fmt.Sprintf("\n\n`$You earned `w%d`$ Bury Points.\n", sp)}, "", "")
}
func (s *Session) cmdRiskTake() Screen {
	st := &s.st
	if !st.CustomerActive || st.Special != "risk" {
		return s.cmdMain()
	}
	me := s.me()
	r := s.data().Risks[st.Risk]
	sp := s.cfg().Risk
	var scr Screen
	if !randomYesNo(me.Luck, 0.9) {
		scr = Screen{View: "desk", Pic: r.FailURL, BG: r.FailBG, Text: s.riskWords(r.FailMessage) + fmt.Sprintf("\n\n`$You lose `#%d`$ Bury Points.", sp)}
		expMod(me, -sp)
	} else {
		scr = Screen{View: "desk", Pic: r.SuccessURL, BG: r.SuccessBG, Text: s.riskWords(r.SuccessMessage) + fmt.Sprintf("\n\n`$You earned `w%d`$ Bury Points!", sp)}
		expMod(me, sp)
	}
	if scr.BG == "" {
		scr.BG = r.StartBG
	}
	st.CustomerActive, st.Special = false, ""
	return cont(scr, "", "")
}

// ---- scripted events (script_event.c -> bonus_tag.c / arson.c)
func (s *Session) bonusTag() Screen {
	me := s.me()
	t := random(3)
	place := []string{"davenport", "shed", "desk", "embalming fluids", "stereo", "parlor"}[random(6)]
	me.Coffins[t]++
	return cont(Screen{View: "desk", Pic: "stuff/money_bag_2", Text: fmt.Sprintf("`yWhile cleaning behind the %s you find a `w%s tag`y.", place, []string{"wood", "silver", "gold"}[t])}, "", "")
}

func (s *Session) cmdArson(a Action) Screen {
	me := s.me()
	const cost = 6
	offer := func(prefix string) Screen {
		return Screen{View: "desk", BG: "background/background_5", Pic: "people/m_old_3",
			Text:    prefix + fmt.Sprintf("`wThe Twins: `y\"We like to play with fire.  We'll discreetly pay a 'visit' to any funeral parlor in town for only %d gold tags.\"\n\nA fire will destroy 5 percent of the parlors gravestones and burn all wood tags. If the parlor has a fire alarm, there is only a 20 percent chance of success.", cost),
			Buttons: []Button{B("Hire Twins", "arson", "hire").K("h"), B("No Thanks", "main", "").K("n")}}
	}
	if a.Sub == "" {
		s.st = custStatus{Arson: true}
		return offer("")
	}
	if !s.st.Arson {
		return s.cmdMain()
	}
	switch a.Sub {
	case "hire":
		if me.Coffins[Gold] < cost {
			s.st = custStatus{}
			return cont(Screen{View: "desk", BG: "background/background_5", Pic: "people/m_old_3", Text: "`wThe Twins: `y\"You don't have enough gold tags, fool!  We shall come again...\""}, "", "")
		}
		return Screen{View: "desk", BG: "background/background_5", Pic: "people/m_old_3", Text: "`yWho would you like the Twins to pay a visit to?",
			Input: askName("Who would you like the Twins to pay a visit to?", "arson", "target", nil)}
	case "target":
		tid := hisID(a)
		if tid <= 0 {
			return offer("`yThe twins look confused.  Better try again.\n\n")
		}
		if tid == me.ID {
			return offer("`yEven as a joke you don't think you should suggest the twins burn down your own building.  Try again.\n\n")
		}
		t := s.w.Player(tid)
		if t == nil || !t.Active {
			return offer("`yThe twins look confused.  Better try again.\n\n")
		}
		if s.w.IsOnline(tid) {
			return offer(fmt.Sprintf("`yThe twins shake their heads vigorously.  Apparently they saw %s working in the yard.\n\n", t.Name))
		}
		s.st = custStatus{}
		if t.Custom.FireAlarm == 1 && randomRange(1, 10) > 2 {
			s.news("front", fmt.Sprintf("`7EARLY WARNING SAVES PARLOR\n`^A small fire was quickly put out at local business %s before any damage was done. \"It was a close call,\" said a relieved %s.\n\n", t.Parlor, t.Name))
			s.G.Tv(s.w, fmt.Sprintf("You see some breaking news.  It looks like %s's parlor was saved by a smoke detector.", t.Name))
			s.w.AddMail(Letter{To: t.ID, Pic: "stuff/fire_alarm", Tags: [3]int{0, 0, 3},
				Text: "\n`yA mysterious fire was started on your property.  Thanks to your smoke detector the fire was put out before any serious damage was done.  The police chief awards you `w3`y gold tags!\n"})
			me.Coffins[Gold] -= cost
			return cont(Screen{View: "desk", Text: "`yYou watch from your window.\n\n`4The fire is put out before it can do any serious damage!\n\n`yDamn smoke detectors!"}, "", "")
		}
		burned := int(float64(t.Plots) * 0.05)
		lost := t.Coffins[Wood]
		me.Coffins[Gold] -= cost
		var text string
		if t.Custom.Safe > 0 {
			text = fmt.Sprintf("`yYou watch from your window.\n\n`wA fire engulfs %s!\n\n`y%s loses `w%d`y gravestone(s).  You see a shiny safe through a window.", t.Parlor, t.Name, burned)
			s.w.AddMail(Letter{To: t.ID, Pic: "stuff/fire_alarm", Text: fmt.Sprintf("\n`yA mysterious fire was started on your property.  You lost `4%d`y gravestone(s) but your `wSafe`y protected all your tags.\n", burned)})
		} else {
			text = fmt.Sprintf("`yYou watch from your window.\n\n`wA fire engulfs %s!\n\n`y%s loses `w%d`y gravestone(s) and `w%d`y wood tag(s).", t.Parlor, t.Name, burned, lost)
			s.w.AddMail(Letter{To: t.ID, Pic: "stuff/fire_alarm", Text: fmt.Sprintf("\n`yA mysterious fire was started on your property.  You lost `4%d`y gravestone(s) and `4%d`y wood tag(s).\n", burned, lost)})
			t.Coffins[Wood] = 0
		}
		t.Plots = max(0, t.Plots-burned)
		if random(2) == 0 {
			s.news("front", fmt.Sprintf("`7PARLOR DAMAGED BY FIRE, ARSON SUSPECTED\n`^A small fire was not noticed until too late at %s today.  \"This isn't happening!\" said %s, still in shock.\n\n", t.Parlor, t.Name))
		} else {
			s.news("front", fmt.Sprintf("`7PARLOR GETS BURNED\n`^A small fire was not noticed until too late at %s today.  \"Faulty wiring my ass, someone is gonna pay for this!\" said a distraught %s.\n\n", t.Parlor, t.Name))
		}
		s.G.Tv(s.w, fmt.Sprintf("You see some breaking news.  It looks like %s's parlor caught on fire.", t.Name))
		return cont(Screen{View: "desk", Pic: "places/fire", Text: text}, "", "")
	}
	return s.cmdMain()
}

// ======================================================================== stats, name change, web login

func (s *Session) cmdStats() Screen {
	s.setLocation("Stats")
	me := s.me()
	ranked := s.w.Ranked()
	idx := 0
	for i, p := range ranked {
		if p.ID == me.ID {
			idx = i
		}
	}
	pct := clamp(100-int(float64(idx)/float64(max(1, len(ranked)))*100), 1, 100)
	rating := s.data().Ratings[pct-1]
	if rating == "" {
		rating = "(No text for this rating.)"
	}
	karma := s.data().Karma[clamp(me.Karma, 1, 100)-1]
	extra := ""
	if me.Custom.FireAlarm == 1 {
		extra += "Smoke detector installed.\n"
	}
	if me.Custom.Padlock == 1 {
		extra += fmt.Sprintf("Your parlor entrance is padlocked. (`w%d percent strength`y)\n", me.Custom.PadlockStrength)
	}
	if me.Custom.Safe == 1 {
		extra += "You own a safe.\n"
	}
	if me.Custom.Lockpick > 0 {
		extra += fmt.Sprintf("You carry `w%d`y lockpick(s).\n", me.Custom.Lockpick)
	}
	if extra == "" {
		extra = "Your stats."
	}
	skills := []string{"None", "Mood reading", "Financial Estimation", "Cutting resistance in half", "Cutting mood in half", "Doubling spending limit"}
	rows := [][2]string{{"Name", me.Name}, {"Parlor", me.Parlor}, {"Day", strconv.Itoa(s.age())},
		{"Total Bury Points", Cash(me.Exp)}, {"Today's Bury Points", Cash(me.SP)},
		{"Rank", fmt.Sprintf("#%d of %d", idx+1, len(ranked))}, {"Burials (plots)", Cash(me.Plots)},
		{"Turns left", strconv.Itoa(me.Turns)}, {"Parlor visits left", strconv.Itoa(max(0, s.cfg().VisitsPerDay-me.Fights))},
		{"Luck", fmt.Sprintf("%d%%", me.Luck)}, {"Hitpoints", strconv.Itoa(me.HPMax)}, {"Strength", strconv.Itoa(me.Strength)},
		{"Psychology", fmt.Sprintf("level %d (%s)", me.Psych+1, skills[min(me.Psych, 5)])},
		{"Transportation", s.transportName(me)},
		{"Casket tags", fmt.Sprintf("%d wood, %d silver, %d gold", me.Coffins[0], me.Coffins[1], me.Coffins[2])}}
	bs := []Button{B("Change name", "options", "").K("n")}
	if s.Kind == "bbs" {
		bs = append(bs, B("Web login", "weblogin", "").K("w"))
	}
	bs = append(bs, B("Back", "main", "").K("b").D())
	return Screen{View: "stats", StatRows: rows, Rating: rating, Karma: fmt.Sprintf("%d - %s", me.Karma, karma), Text: "`y" + extra, Buttons: bs, Pic: "places/desk"}
}

func (s *Session) cmdWebLogin(a Action) Screen {
	me := s.me()
	switch a.Sub {
	case "logon":
		v, ok := val(a)
		if !ok {
			return s.cmdStats()
		}
		s.st.WebLogon = stripDangerous(v)
		if len(s.st.WebLogon) > 20 {
			s.st.WebLogon = s.st.WebLogon[:20]
		}
		return Screen{View: "popup", Text: "`$Now pick a web password.", Input: &Input{Kind: "password", Prompt: "Web password:", Cmd: "weblogin", Sub: "pw", MaxLen: 30}}
	case "pw":
		v, ok := val(a)
		if !ok {
			return s.cmdStats()
		}
		l := s.st.WebLogon
		if o := s.w.ByLogon(l); o != nil && o.ID != me.ID {
			return cont(Screen{View: "desk", Pic: "stuff/question", Text: "`4Someone is already using the logon name of " + l + "."}, "stats", "")
		}
		if len(l) < 3 || len(l) > 20 {
			return cont(Screen{View: "desk", Pic: "stuff/question", Text: "`4Logon names must be 3 to 20 characters."}, "stats", "")
		}
		if len(v) < 4 {
			return cont(Screen{View: "desk", Pic: "stuff/question", Text: "`4Use a password of at least 4 characters."}, "stats", "")
		}
		me.Logon, me.Password = l, HashPassword(v)
		return cont(Screen{View: "desk", Pic: "stuff/question", Text: fmt.Sprintf("`$Done.  You can now play this same parlor on the web as `w%s`$.", me.Logon)}, "stats", "")
	}
	cur := ""
	if me.Logon != "" {
		cur = fmt.Sprintf("  (Currently `w%s`$.)", me.Logon)
	}
	return Screen{View: "desk", Pic: "stuff/question", Text: fmt.Sprintf("`$Pick a logon name so you can run %s from a web browser too.%s", me.Parlor, cur),
		Input: &Input{Kind: "text", Prompt: "Web logon name:", Cmd: "weblogin", Sub: "logon", MaxLen: 20, Def: ifs(me.Logon != "", me.Logon, me.Name)}}
}

func (s *Session) cmdOptions(a Action) Screen {
	me := s.me()
	cost := s.cfg().NameChangeCost
	if cost < 1 {
		return cont(Screen{View: "desk", Pic: "stuff/question", Text: "`$This server doesn't allow name changes.  You're stuck with what your parents gave you."}, "stats", "")
	}
	switch a.Sub {
	case "input":
		return Screen{View: "desk", Pic: "stuff/question", Text: "`wEnter your new name.", Input: &Input{Kind: "text", Prompt: "New name:", Cmd: "options", Sub: "name", MaxLen: 20}}
	case "name":
		v, ok := val(a)
		if !ok {
			return s.cmdOptions(Action{})
		}
		name := swearCheck(stripDangerous(v), s.data().Swears)
		again := func(t string) Screen {
			return cont(Screen{View: "desk", Pic: "stuff/question", Text: t}, "options", "")
		}
		if me.Coffins[Gold] < cost {
			return cont(Screen{View: "desk", Pic: "stuff/question", Text: "`$You don't have enough gold tags.  Go exchange your woods or something."}, "stats", "")
		}
		if name == me.Name {
			return again(fmt.Sprintf("`$Yeah, %s.. you like the sound of that... oh wait...", name))
		}
		if len(name) < 3 {
			return again("`$What, are those initials?  Pick a longer name.")
		}
		if len(name) > 20 {
			return again("`$Is that a name or a lecture?  Try something shorter.")
		}
		if u := s.w.ByName(name); u != nil && u.ID != me.ID {
			return again(fmt.Sprintf("`$Um, don't you think the real %s would kind of be pissed?  Try something original.", name))
		}
		me.Coffins[Gold] -= cost
		s.news("front", fmt.Sprintf("`5NAME CHANGE: %s has changed %s name to %s.\r\n\r\n", me.Name, his(me), name))
		me.Name = name
		return cont(Screen{View: "desk", Pic: "stuff/question", Text: fmt.Sprintf("`$You will now be known as `w%s`$.", name)}, "stats", "")
	}
	s.setLocation("Change Name")
	return Screen{View: "desk", Pic: "stuff/question", Text: fmt.Sprintf("`$Announcing your new name in the newspaper will cost `w%d`$ gold tag(s).  Do it?", cost),
		Info:    "You stare at yourself in the mirror.\n\nMaybe it's time for a change.",
		Buttons: []Button{B("Yes", "options", "input").K("y"), B("No", "stats", "").K("n").D()}}
}

// ======================================================================== map, city hall, news, rankings, mail

func (s *Session) cmdMap() Screen {
	if s.chatting {
		s.w.AddChat("`5"+s.me().Name+" steps outside.", 0)
	}
	s.setLocation("Town Map")
	return Screen{View: "map", Pic: "map", Text: "`$Where to?", Buttons: []Button{
		B("Your parlor", "main", "").K("p"), B("Pale Horse Cafe", "cafe", "").K("c"), B("Yang's", "yangs", "").K("y"), B("Church", "church", "").K("h"),
		B("Di-Mart", "store", "").K("d"), B("Spirit University", "spirit", "").K("u"), B("Bank", "bank", "").K("b"), B("Hospital", "hospital", "").K("o"),
		B("Rival parlors", "comp", "").K("r"), B("City Hall", "cityhall", "").K("i")}}
}

func (s *Session) cmdCityHall() Screen {
	s.setLocation("City Hall")
	return Screen{View: "generic", BG: "places/desk_enemy",
		Info:    "The marble halls of City Hall echo with the footsteps of busy clerks.  A rack of newspapers and the official parlor rankings are posted by the door.",
		Text:    "`$A clerk looks up from a pile of death certificates.\n\n`wClerk: `$\"Paper's on the rack, rankings are on the wall.  Try not to drip on anything.\"",
		Buttons: []Button{B("Funeral Times", "news", "").K("f"), B("Rankings", "ranking", "").K("r"), B("Leave", "map", "").K("l")}}
}

func (s *Session) cmdNews(a Action) Screen {
	if !strings.HasPrefix(s.location, "News") {
		s.newsBack = ifs(s.location == "City Hall", "cityhall", "main")
	}
	s.location = "News"
	day := s.age()
	if a.Day != nil {
		day = *a.Day
	}
	section := ifs(a.Section != "", a.Section, "front")
	c := s.cfg()
	text := ""
	if section == "front" && c.TournActive && s.age()+5 > c.TournDays {
		switch {
		case s.age() == c.TournDays:
			text += "`5Today is the final day of the tournament - a winner will be declared at midnight!\n\n"
		case !tournEndsToday(s.w) && s.age() == c.TournDays-1:
			text += "`5Tomorrow is the last day of the tournament.\n\n"
		case !tournEndsToday(s.w):
			text += fmt.Sprintf("`5Only %d days left before a tournament winner shall be declared!\n\n", c.TournDays-s.age())
		}
	}
	body := s.w.News(day, section)
	if body == "" {
		body = ifs(section == "front", "Nothing has happened today.", "There has been no crime reported today.")
	}
	text += body
	topToday := "Sadly, no one has managed to sell anything yet today."
	if t := topOfDay(s.w); t != nil {
		topToday = fmt.Sprintf("%s from %s with %d Bury Points.", t.Name, t.Parlor, t.SP)
	}
	if tournEndsToday(s.w) {
		if r := s.w.Ranked(); len(r) > 0 {
			topToday = "Top seller of the universe is " + r[0].Name + "."
		}
	}
	topY := "No one died yesterday."
	if o := s.w.Glo.TopOld; o != nil {
		topY = fmt.Sprintf("%s from %s with %d Bury Points.", o.Name, o.Parlor, o.BP)
	}
	dayBtn := func(label string, d int, sec, key string) Button {
		b := B(label, "news", "").K(key)
		b.Day = &d
		b.Section = sec
		return b
	}
	var bs []Button
	if section == "front" {
		bs = append(bs, dayBtn("Crime", day, "crime", "c"))
	} else {
		bs = append(bs, dayBtn("Front Page", day, "front", "f"))
	}
	if day == s.age() && day > 1 {
		bs = append(bs, dayBtn("Yesterday", day-1, section, "y"))
	}
	if day != s.age() {
		bs = append(bs, dayBtn("Today", s.age(), section, "t"))
	}
	bs = append(bs, B("Make Announcement", "announce", "").K("m"), B("Continue", ifs(s.newsBack != "", s.newsBack, "main"), "").D())
	return Screen{View: "news", Day: day, Section: section, Text: text, TopToday: topToday, TopYesterday: topY, Buttons: bs}
}

func (s *Session) cmdAnnounce(a Action) Screen {
	if a.Sub != "text" {
		return Screen{View: "popup", Text: "`$What would you like to announce to the town?  (it goes on the front page)",
			Input: &Input{Kind: "text", Prompt: "Announcement:", Cmd: "announce", Sub: "text", MaxLen: 400, Multiline: true}}
	}
	if v, ok := val(a); ok && strings.TrimSpace(v) != "" {
		me := s.me()
		t := strings.NewReplacer("`", "", "\r", "").Replace(swearCheck(v, s.data().Swears))
		s.news("front", fmt.Sprintf("`8%s of %s makes an announcement:`6\r\n", me.Name, me.Parlor))
		s.news("front", t+"\r\n\r\n")
	}
	return s.cmdNews(Action{})
}

func (s *Session) rankingRows(aliveOnly bool) []RankRow {
	status := map[int]string{}
	for _, x := range s.w.Online() {
		status[x.PlayerID] = x.Status
	}
	rows := []RankRow{}
	for _, p := range s.w.Ranked() {
		if aliveOnly && p.Police {
			continue
		}
		st := ""
		if v, ok := status[p.ID]; ok {
			st = ifs(v == "chat", "in cafe", "on now")
		} else if p.Police {
			st = "Protected"
		}
		rows = append(rows, RankRow{p.Name, p.Male, p.Parlor, p.Exp, st})
	}
	return rows
}
func (s *Session) cmdRanking() Screen {
	back := ifs(s.location == "City Hall", "cityhall", "main")
	return Screen{View: "ranking", Title: "Parlor Rankings", RankRows: s.rankingRows(false), Buttons: []Button{B("Continue", back, "").D()}}
}

func (s *Session) cmdMailWrite(a Action) Screen {
	if a.HisID == nil {
		return Screen{View: "popup", Text: "`$Who do you want to write to?", Input: askName("Write a letter to:", "mail_write", "", nil)}
	}
	id := *a.HisID
	if id <= 0 {
		return s.cmdMain()
	}
	to := s.w.Player(id)
	if to == nil || !to.Active {
		return s.desk("`$Can't send mail, that parlor doesn't exist anymore.")
	}
	if a.Sub != "send" {
		return Screen{View: "popup", Text: fmt.Sprintf("`$Writing a letter to `w%s`$.", to.Name),
			Input: &Input{Kind: "text", Prompt: "Letter to " + to.Name + ":", Cmd: "mail_write", Sub: "send", Extra: &Action{HisID: &id}, MaxLen: 1500, Multiline: true}}
	}
	v, ok := val(a)
	if !ok || strings.TrimSpace(v) == "" {
		return s.desk("`$You crumple up the letter.")
	}
	me := s.me()
	content := swearCheck(strings.ReplaceAll(v, "\r\n", "\n"), s.data().Swears)
	s.w.AddMail(Letter{To: to.ID, ReplyTo: me.ID, Pic: "note", Text: fmt.Sprintf("`$You have received a letter from `w%s`$:\n\n%s", me.Name, content)})
	s.w.AddChat("`5You have mail waiting for you at your parlor.", to.ID)
	return s.desk(fmt.Sprintf("`$Your letter to `w%s`$ is on its way.", to.Name))
}

// ======================================================================== Yang's (commands_yangs.cpp)

func yangsMenu() string {
	return "`wThe Menu\n\n" +
		"`w#1`$ - Lucky Dragon (adds `w10 `$luck, for here only) Cost: `w5`$ Bury Points\n" +
		"`w#2`$ - Lucky Sparrow (adds `w5 `$luck, for delivery only) Cost: `w20`$ Bury Points\n" +
		"`w#3`$ - Cursed Tiger (removes `w10`$ luck, for delivery only) Cost: `w20`$ Bury Points\n"
}
func yangsScr(text string, bs []Button) Screen {
	if bs == nil {
		bs = []Button{B("Order #1", "yangs", "dragon").K("1"), B("Order #2", "yangs", "sparrow").K("2"), B("Order #3", "yangs", "tiger").K("3"), B("Leave", "map", "").K("l")}
	}
	return Screen{View: "generic", BG: "places/yangs", Info: "What could be luckier than a box of delectable grilled teriyaki spread over hot rice? Your mouth waters at the very thought of it.", Text: text, Buttons: bs}
}
func (s *Session) cmdYangs(a Action) Screen {
	me := s.me()
	if a.Sub == "" {
		s.setLocation("Yang's")
		if me.Kicked {
			return yangsScr(fmt.Sprintf("`w%s: `$\"Hello? I'd like some service here!\"\n\n`wJune: `$\"Just leave, asshole.\"", me.Name), []Button{B("Leave", "map", "")})
		}
		return yangsScr(yangsMenu(), nil)
	}
	if s.location != "Yang's" {
		return s.cmdYangs(Action{})
	}
	contY := func(t string) Screen { return yangsScr(t, []Button{B("Continue", "yangs", "menu").D()}) }
	limit := s.cfg().YangsPerDay
	switch a.Sub {
	case "menu":
		return yangsScr(yangsMenu(), nil)
	case "dragon":
		if me.Luck >= 40 {
			return contY("`$Maybe later.  You especially like to eat Yang's when you're feeling down on your luck. (like less than 40 percent for instance)")
		}
		if me.SP < 5 {
			return contY("`$You check your wallet.. shoot, not enough Bury Points!")
		}
		expMod(me, -5)
		me.Luck += 10
		return contY("`$You relish every bite of your General Tso's Chicken.\n\nYou gain `w10`$ luck.")
	case "bitchy":
		me.Kicked = true
		return yangsScr(fmt.Sprintf("`w%s: `$\"That's very interesting.  Now get the god damn teriyaki, put it in a box, and deliver it.\"\n\n`wJune: `$\"Please leave now.\"", me.Name), []Button{B("Leave", "map", "")})
	case "sparrow", "tiger":
		if me.YangsSent >= limit {
			what := ifs(a.Sub == "tiger", "a cursed tiger", "a lucky sparrow")
			return yangsScr(fmt.Sprintf("`w%s: `$\"I would like %s delivered, please.\"\n\n`wJune: `$\"I'm sorry, my dad is out delivering food right now.  How about something for here?\"", me.Name, what),
				[]Button{B("Continue", "yangs", "menu").D(), B("Get Bitchy", "yangs", "bitchy").K("g")})
		}
		prompt := "`wJune: `$\"That's very nice of you.  Who's the lucky person?\""
		if a.Sub == "tiger" {
			prompt = "`wJune: `$\"Ah.. someone you are not too fond of, I take it.  Who would this unlucky person be?\""
		}
		scr := yangsScr(prompt, []Button{})
		scr.Input = askName("Deliver to:", "yangs", "fortune", &Action{Kind2: a.Sub})
		return scr
	case "fortune":
		if hisID(a) <= 0 {
			return yangsScr(yangsMenu(), nil)
		}
		id := hisID(a)
		scr := yangsScr("`wJune: `$\"If you would like to write a custom fortune, enter it now.\"", []Button{})
		scr.Input = &Input{Kind: "text", Prompt: "Fortune (Enter for a random one):", Cmd: "yangs", Sub: "deliver", Extra: &Action{HisID: &id, Kind2: a.Kind2}, MaxLen: 120, AllowEmpty: true}
		return scr
	case "deliver":
		v, ok := val(a)
		if !ok {
			return yangsScr(yangsMenu(), nil)
		}
		tiger := a.Kind2 == "tiger"
		if me.YangsSent >= limit {
			return contY(fmt.Sprintf("`$\"We only allow %d delivery per day,\" Mr Yang tells you apologetically. ", limit))
		}
		id := hisID(a)
		if id == me.ID {
			return yangsScr(fmt.Sprintf("`w%s: `$\"If you could just deliver that to my parlor, that would be great, m'kay?\"\n\n`wJune: `$\"Why don't you just get food for here?\"\n\n`w%s: `$\"Ok, fine.\"\n\n", me.Name, me.Name),
				[]Button{B("Continue", "yangs", "menu").D()})
		}
		t := s.w.Player(id)
		if t == nil || !t.Active {
			return contY("`$Error delivering food, he wasn't home.")
		}
		if me.SP < 20 {
			return contY("`$You don't have enough Bury Points.  You realize you would just look stupid trying to order now...")
		}
		me.YangsSent++
		expMod(me, -20)
		fortune := strings.TrimSpace(swearCheck(strings.ReplaceAll(v, "`", ""), s.data().Swears))
		if fortune == "" {
			src := s.data().YangsNice
			if tiger {
				src = s.data().Yangs
			}
			if ev := computeEvent(src, t.Exp); ev != nil {
				fortune = ev.Message
			} else {
				fortune = "Confucius say nothing."
			}
		}
		s.G.Tv(s.w, fmt.Sprintf("A Yang's commercial comes on. It looks like %s in the background.", t.Parlor))
		if tiger {
			if random(4) == 1 {
				s.news("front", pick([]string{
					fmt.Sprintf("`7SPOTLIGHT ON OUR TOWN\r\n`^Local mortician %s is seen buying some Yang's for delivery.\r\n\r\n", me.Name),
					fmt.Sprintf("`7YANG'S NOW DELIVERS\r\n`^\"Yes, delivery is very popular.  You see this package from %s? I'm going deliver it all the way to %s, no extra charge!\" Mr Yang smiles.\r\n\r\n", me.Name, t.Parlor),
					fmt.Sprintf("`7YANG'S DOING WELL\r\n`^\"Ah, yes.  Business is very good today! People like %s buying so much delivery,\" Mr Yang comments.\r\n\r\n", me.Name),
					fmt.Sprintf("`7YANG'S MAKES A GREAT GIFT\r\n`^Looking for that special gift?  How about food? Today %s was seen buying some, seems popular.\r\n\r\n", me.Name)}))
			}
			s.w.AddMail(Letter{To: t.ID, Pic: "chinese_takeout", Luck: -10, Text: fmt.Sprintf("\n`$Some delicious smelling chinese food has been left on your doorstep.\nYour fortune cookie reads:\n`w\"%s\"\n`$You lose `w10`$ luck!\n", fortune)})
		} else {
			s.w.AddMail(Letter{To: t.ID, Pic: "chinese_takeout", Luck: 5, Text: fmt.Sprintf("\n`$%s has sent you some chinese food.\nYour fortune cookie reads:\n`w\"%s\"\n`$You gain `w5`$ luck!\n", me.Name, fortune)})
		}
		return contY("`$Mr. Yang leaves to deliver the food.")
	}
	return yangsScr(yangsMenu(), nil)
}

// ======================================================================== church, hospital

func (s *Session) cmdChurch(a Action) Screen {
	s.setLocation("Church")
	hi := fmt.Sprintf("`wFather Smyth: `y\"Why hello there, %s.  Isn't it a wonderfully fantastic day today?  Praise the Lord.\"", s.me().Name)
	if a.Sub == "hi" {
		hi = "`wFather Smyth: `y\"Hi there.  I already said hi though.\""
	}
	return Screen{View: "generic", BG: "background/background_church", Pic: "people/churchguy_h",
		Info: "Father Smyth greets you warmly, a little too warmly.  You wonder if he has anything on under that robe.", Text: hi,
		Buttons: []Button{B("Say hi", "church", "hi").K("s"), B("Leave", "map", "").K("l").D()}}
}

func (s *Session) cmdHospital(a Action) Screen {
	me := s.me()
	s.setLocation("Hospital")
	info := "You are at the city hospital.  A nurse smiles at you."
	switch a.Sub {
	case "room":
		return Screen{View: "generic", BG: "places/hospital_room", Info: "You are lying on a bed, it doesn't look like your own.", Text: "`$Your whole body aches.",
			Buttons: []Button{B("Leave", "hospital", "leave_room").D()}}
	case "leave_room":
		return Screen{View: "generic", BG: "places/hospital_desk", Info: info,
			Text:    fmt.Sprintf("`wNurse: `$\"I see you finally woke up, %s.  Hope you'll be more careful next time.\"", ifs(me.Male, "prince charming", "sleeping beauty")),
			Buttons: []Button{B("Leave", "map", "").D()}}
	}
	return Screen{View: "generic", BG: "places/hospital_desk", Info: info,
		Text: fmt.Sprintf("`wNurse: `$\"Hi %s.  I don't recall you having a pick-up today.\"", me.Name), Buttons: []Button{B("Leave", "map", "").D()}}
}

// ======================================================================== Spirit U (commands_spirit.cpp)

func psychCost(p *Player) int { return 4 + p.Psych*2 }
func hpCost(p *Player) int    { return int(float64(p.HPMax) * 1.2) }
func strCost(p *Player) int   { return p.Strength * 3 }
func spiritScr(text string, bs []Button) Screen {
	return Screen{View: "generic", BG: "places/psych",
		Info:   "The role of the funeral director is constantly changing, encompassing more and more responsibilities each year. (for a fee, of course)",
		Status: "Taking classes at SU is a great way to expand your options.", Text: text, Buttons: bs}
}
func (s *Session) classes() Screen {
	me := s.me()
	return spiritScr(fmt.Sprintf("`wClass schedules\n\n`$PSY - Social Psychology (cost: `w%d`$ gold tags)\n`$PE - Physical Education (cost: `w%d`$ gold tags)\n`$ST - Strength Training (cost: `w%d`$ gold tags)", psychCost(me), hpCost(me), strCost(me)),
		[]Button{B("Take PSY", "spirit", "psy").K("p"), B("Take PE", "spirit", "pe").K("e"), B("Take ST", "spirit", "st").K("s"), B("Library", "spirit", "library").K("b"), B("Leave", "map", "").K("l")})
}
func (s *Session) cmdSpirit(a Action) Screen {
	me := s.me()
	back := func(t string) Screen { return spiritScr(t, []Button{B("Continue", "spirit", "menu").D()}) }
	const broke = "You fumble through your pockets in vain - you don't have enough gold tags to pay for the class."
	library := func() Screen {
		return spiritScr("You are in the library.\n\n`$Students are quietly studying here.  You see one nerdy looking kid hogging the lone library computer.\n\n`$The book of deeds is sitting on a pedestal close by.",
			[]Button{B("Old Papers", "spirit", "paper_start").K("o"), B("View Deeds", "spirit", "deeds").K("v"), B("Back", "spirit", "menu").K("b").D()})
	}
	switch a.Sub {
	case "":
		s.setLocation("Spirit U")
		return s.classes()
	case "menu":
		return s.classes()
	case "psy":
		if psychCost(me) > me.Coffins[Gold] {
			return back(broke)
		}
		me.Coffins[Gold] -= psychCost(me)
		me.Psych++
		skills := map[int]string{1: "Mood reading", 2: "Financial Estimation", 3: "Cutting resistance in half", 4: "Cutting mood in half", 5: "Doubling spending limit"}
		extra := ""
		if k, ok := skills[me.Psych]; ok {
			extra = "\n\n`$You have learned a new skill: `w" + k
		}
		return back(fmt.Sprintf("You study hard for about an hour.  Your psychology level is raised to `w%d`$!%s", me.Psych+1, extra))
	case "pe":
		if hpCost(me) > me.Coffins[Gold] {
			return back(broke)
		}
		me.Coffins[Gold] -= hpCost(me)
		hp := randomRange(4, 5)
		me.HPMax += hp
		return back(fmt.Sprintf("You run laps around the gym.  You gain `w%d`$ hitpoints!", hp))
	case "st":
		if strCost(me) > me.Coffins[Gold] {
			return back(broke)
		}
		me.Coffins[Gold] -= strCost(me)
		me.Strength++
		return back("You lift weights for a while.  You gain `w1`$ strength!")
	case "library":
		return library()
	case "deeds":
		t := "The Book Of Deeds`$\n\n"
		if len(s.w.Deeds) > 0 {
			t += strings.Join(s.w.Deeds, "\n")
		} else {
			t += "No one in Deathville has ever done anything worthing noting.\n\nIt's sad, really.\n"
			if r := s.w.Ranked(); len(r) > 0 {
				t += fmt.Sprintf("\nThere is a glimmer of hope in `w%s`$, but %s has a way to go.", r[0].Name, he(r[0]))
			}
		}
		return Screen{View: "view", BG: "places/psych", Text: "`w" + t, Buttons: []Button{B("Back", "spirit", "library").D()}}
	case "paper_start":
		if s.age()-1 < 1 {
			return library()
		}
		scr := library()
		scr.Input = &Input{Kind: "number", Prompt: fmt.Sprintf("Which old newspaper would you like to look at?  You can choose between 1 and %d.", s.age()-1), Cmd: "spirit", Sub: "paper", MaxLen: 6}
		return scr
	case "paper":
		v, ok := val(a)
		if !ok {
			return library()
		}
		day := atoi(v)
		var t string
		if day < 1 || day > s.age()-1 {
			t = fmt.Sprintf("You desperately hunt around for anything dealing with a day %d but fail.", day)
		} else {
			body := s.w.News(day, "front")
			if body == "" {
				body = "Nothing happened that day."
			}
			t = fmt.Sprintf("You find a yellowing paper from day %d, it looks like it may have been peed on.`$\n\n", day) +
				strings.NewReplacer("`7", "`w", "`^", "`$").Replace(body)
		}
		return Screen{View: "view", BG: "places/psych", Text: t, Buttons: []Button{B("Back", "spirit", "library").D()}}
	}
	return s.classes()
}

// ======================================================================== bank (commands_bank.cpp)

func bankScr(text string, bs []Button) Screen {
	return Screen{View: "generic", BG: "places/bank", Info: "You are at the city bank.  This facility allows you to exchange casket sales tags and transfer them to other accounts.", Text: text, Buttons: bs}
}
func bankHome(text string) Screen {
	return bankScr(text, []Button{B("Exchange", "bank", "exchange").K("e"), B("All to gold", "bank", "all_gold").K("g"), B("All to wood", "bank", "all_wood").K("w"), B("Leave", "map", "").K("l")})
}
func fromBtn(label string, f int, key string) Button {
	b := B(label, "bank", "from").K(key)
	b.From = &f
	return b
}
func (s *Session) cmdBank(a Action) Screen {
	me := s.me()
	V := [3]int{1, 2, 4}
	pickFrom := func() Screen {
		return bankScr("`wTeller: `$\"Which kind tag would you like to exchange?\"", []Button{fromBtn("Gold", Gold, "g"), fromBtn("Silver", Silver, "s"), fromBtn("Wood", Wood, "w"), B("Back", "bank", "").K("b")})
	}
	switch a.Sub {
	case "":
		s.setLocation("Bank")
		return bankHome(fmt.Sprintf("`wTeller: `$\"How's business, %s?\"", me.Name))
	case "exchange":
		return pickFrom()
	case "from":
		if a.From == nil {
			return pickFrom()
		}
		f := *a.From
		var bs []Button
		for t := 0; t < 3; t++ {
			if t != f {
				b := B(casketName[t], "bank", "ask")
				ff, tt := f, t
				b.From, b.To = &ff, &tt
				bs = append(bs, b)
			}
		}
		bs = append(bs, B("Back", "bank", "exchange").K("b"))
		return bankScr(fmt.Sprintf("`wTeller: `$\"What would you like to convert your %s to?\"", casketName[f]), bs)
	case "ask":
		if a.From == nil || a.To == nil {
			return pickFrom()
		}
		f, t := *a.From, *a.To
		hf, ht := V[t]/V[f], 1
		if f == Silver && t == Gold {
			hf = 2
		}
		if hf < 1 {
			ht, hf = V[f]/V[t], 1
		}
		scr := bankScr(fmt.Sprintf("`wTeller: `$\"%d %s tag(s) = %d %s tag(s).  How many %s tags would you like to exchange?\"", hf, casketName[f], ht, casketName[t], casketName[f]), []Button{})
		ff, tt := f, t
		scr.Input = &Input{Kind: "number", Prompt: "How many " + casketName[f] + " tags?", Cmd: "bank", Sub: "do", Extra: &Action{From: &ff, To: &tt}, Def: strconv.Itoa(me.Coffins[f]), MaxLen: 9}
		return scr
	case "do":
		v, ok := val(a)
		if !ok || a.From == nil || a.To == nil {
			return pickFrom()
		}
		f, t := *a.From, *a.To
		n := atoi(v)
		again := func(txt string) Screen { return bankScr(txt, []Button{B("Continue", "bank", "exchange").D()}) }
		switch {
		case n == 0:
			return pickFrom()
		case n < 0:
			return again(fmt.Sprintf("`wTeller: `$\"You are very amusing %s.\"", sir(me)))
		case n > me.Coffins[f]:
			return again("`wTeller: `$\"You can't exchange what you don't have.  I'm trying to be nice here, but please, think next time.\"")
		case V[f]*n/V[t] < 1:
			return again(fmt.Sprintf("`wTeller: `$\"You don't understand, do you. You can't trade just %d for a %s tag, alright?\"", n, casketName[t]))
		}
		gain := int(float64(n) * float64(V[f]) / float64(V[t]))
		lost := gain * V[t] / V[f]
		me.Coffins[f] -= lost
		me.Coffins[t] += gain
		return bankScr(fmt.Sprintf("`wTeller: `$\"Very good, I have converted %d %s tag(s) to %d %s tag(s). Any other tags you would like to convert?\"", lost, casketName[f], gain, casketName[t]),
			[]Button{fromBtn("Gold", Gold, "g"), fromBtn("Silver", Silver, "s"), fromBtn("Wood", Wood, "w"), B("Back", "bank", "").K("b")})
	case "all_wood", "all_gold":
		me.Coffins[Wood] += me.Coffins[Silver]*V[Silver] + me.Coffins[Gold]*V[Gold]
		me.Coffins[Silver], me.Coffins[Gold] = 0, 0
		if a.Sub == "all_gold" {
			gain := me.Coffins[Wood] / V[Gold]
			me.Coffins[Wood] -= gain * V[Gold]
			me.Coffins[Gold] += gain
		}
		return bankHome(fmt.Sprintf("`wA teller converts all your tags to %s for you.", ifs(a.Sub == "all_gold", "Gold", "Wood")))
	}
	return bankHome(fmt.Sprintf("`wTeller: `$\"How's business, %s?\"", me.Name))
}

// ======================================================================== Di-Mart (command_store.cpp, store_supplies.c, store_security.c)

const storeInfo = "Di-Mart is not only an official DuraRest (tm) reseller but also carries many other useful supplies for the death care industry.\n\nA really creepy looking guy in a suit smiles at you."

func storeScr(pic, text string, bs []Button) Screen {
	return Screen{View: "generic", BG: "places/store", Pic: pic, Info: storeInfo, Text: text, Buttons: bs}
}
func (s *Session) cmdStore(a Action) Screen {
	me := s.me()
	T := s.data().Transport
	C := &me.Custom
	if a.Sub == "" {
		s.setLocation("Store")
		return storeScr("people/store_guy", fmt.Sprintf("`wElijah: `$\"What can I get for you today, %s?\"", me.Name),
			[]Button{B("Hearses", "store", "hearse").K("h"), B("Supplies", "store", "supplies").K("s"), B("Security", "store", "security").K("e"), B("Leave", "map", "").K("l")})
	}
	if s.location != "Store" {
		return s.cmdStore(Action{})
	}
	const LP, SMOKE, SAFE, PAD = 1, 8, 6, 6
	item := func(pic, text, buy, back, buyLabel string) Screen {
		return storeScr(pic, text, []Button{B(buyLabel, "store", buy).K("u"), B("Back", "store", back).K("b")})
	}
	elija := func(t, back string) Screen {
		return storeScr("people/store_guy", t, []Button{B("Continue", "store", back).D()})
	}
	bought := func(t, back string) Screen {
		return storeScr("stuff/money_bag_2", t, []Button{B("Continue", "store", back).D()})
	}
	broke := func(extra string) Screen {
		return elija("`wElija: `y\"I'm sorry, you seem to be lacking in funds.  Perhaps another time?\"\n\n"+extra, "security")
	}
	switch a.Sub {
	case "hearse":
		t := "`wElijah: `$\"We carry nothing but the best in funeral transportation.\"\n\n"
		var bs []Button
		for i := 1; i < len(T); i++ {
			t += fmt.Sprintf("`w%d`$ - %s - Cost: `w%d`$ gold tags.\n", i, T[i].Name, T[i].Price)
			b := B(fmt.Sprintf("View #%d", i), "store", "view").K(strconv.Itoa(i))
			b.N = i
			bs = append(bs, b)
		}
		bs = append(bs, B("Back", "store", "").K("b"))
		return storeScr("people/store_guy", t, bs)
	case "view":
		i := a.N
		if i < 1 || i >= len(T) {
			return s.cmdStore(Action{Sub: "hearse"})
		}
		s.st.ViewHearse = i
		trade := T[me.Transport].Price / 2
		scr := storeScr("", fmt.Sprintf("`wThe %s`$ - %s\n\nEffect: `w%d`$ extra turns per day.\n\nAfter trading in your %s for `w%d`$ gold tags, the cost will be `w%d`$ gold tags.", T[i].Name, T[i].Desc, T[i].Bonus, s.transportName(me), trade, T[i].Price-trade),
			[]Button{B("Buy it", "store", "buy").K("u"), B("Back", "store", "hearse").K("b")})
		scr.BG = T[i].URL
		return scr
	case "buy":
		i := s.st.ViewHearse
		if i < 1 || i >= len(T) {
			return s.cmdStore(Action{Sub: "hearse"})
		}
		price := T[i].Price - T[me.Transport].Price/2
		if price > me.Coffins[Gold] {
			return storeScr("people/store_guy", fmt.Sprintf("`wElijah: `$\"I'm sorry, I really don't have time to waste.  You obviously cannot afford a luxury sedan such as the %s.\"", T[i].Name), []Button{B("Back", "store", "hearse")})
		}
		old := s.transportName(me)
		me.Coffins[Gold] -= price
		me.Transport = i
		me.Turns += T[i].Bonus
		return storeScr("stuff/money_bag_2", fmt.Sprintf("You trade in your %s for a brand new %s!\n\nYou have time for an extra `w%d`$ customers today.", old, T[i].Name, T[i].Bonus), []Button{B("Back", "store", "hearse")})
	case "supplies":
		scr := storeScr("people/store_guy", fmt.Sprintf("`wElijah: `y\"We carry a wide assortment of useful items.\"\n\n`w1`y - Lockpick - Cost: `w%d`y gold tag\n", LP),
			[]Button{B("View #1", "store", "lockpick").K("1"), B("Back", "store", "").K("b")})
		scr.Info = "You are in the supplies section."
		return scr
	case "lockpick":
		return item("stuff/lockpick", fmt.Sprintf("Have you ever accidently locked yourself out of your parlor?  A `wLockpick`y can 'let' you back in!  These are `w%d`y gold tag each.  (You currently have `w%d`y lockpick(s))\n\n`wEffect: `yWill instantly open any parlor front door.  One time use.", LP, C.Lockpick), "buy_lockpick", "supplies", "Buy one")
	case "buy_lockpick":
		if me.Coffins[Gold] < LP {
			return elija("`wElija: `y\"You don't have a single gold tag at the moment?  That's too bad.  These are great little lockpicks.\"", "supplies")
		}
		C.Lockpick++
		me.Coffins[Gold] -= LP
		return bought(fmt.Sprintf("`yYou purchase a `wLockpick`y for `w%d`y gold tag.", LP), "lockpick")
	case "security":
		t := "`wElijah: `y\"This town seems accident prone.  Investing in security is a great idea.\"\n\n"
		t += fmt.Sprintf("`w1`y - Heavy Padlock - Cost: `w%d`y gold tags%s\n", PAD, ifs(C.Padlock == 1, fmt.Sprintf(" (`walready own one at %d percent strength`y)", C.PadlockStrength), ""))
		t += fmt.Sprintf("`w2`y - Smoke Detector - Cost: `w%d`y gold tags%s\n", SMOKE, ifs(C.FireAlarm == 1, " (`walready own one`y)", ""))
		t += fmt.Sprintf("`w3`y - Safe - Cost: `w%d`y gold tags%s\n", SAFE, ifs(C.Safe == 1, " (`walready own one`y)", ""))
		scr := storeScr("people/store_guy", t, []Button{B("View #1", "store", "padlock").K("1"), B("View #2", "store", "smoke").K("2"), B("View #3", "store", "safe").K("3"), B("Back", "store", "").K("b")})
		scr.Info = "You are in the security section."
		return scr
	case "padlock":
		return item("stuff/padlock", fmt.Sprintf("`ySecure your parlor and stop intruders with a new steel laminated `wHeavy Padlock`y.  The shackle is crome plated and hardened to maximize its strength. Only `w%d`y gold tags.\n\n`wEffect: `yCasual thieves will no longer be able to break into your parlor.", PAD), "buy_padlock", "security", "Buy it")
	case "smoke":
		return item("stuff/fire_alarm", fmt.Sprintf("`yA `wSmoke Detector`y will allow you to notice fires and call the fire department much quicker.  It retails here for `w%d`y gold tags.\n\n`wEffect: `yReduce the risk of a fire getting large enough to cause damage to 20 percent.", SMOKE), "buy_smoke", "security", "Buy it")
	case "safe":
		return item("stuff/safe", fmt.Sprintf("`yOur commercial `wSafe`y is the perfect way to product your valuables.  Features steel castors and automatic re-locking system.  Only `w%d`y gold tags.\n\n`wEffect: `ySales tags cannot be stolen or damaged in a fire.", SAFE), "buy_safe", "security", "Buy it")
	case "buy_padlock":
		if C.Padlock == 1 {
			return elija("`wElija: `y\"Wait until the one you have breaks. Sorry, company policy.\"", "security")
		}
		if me.Coffins[Gold] < PAD {
			return broke("You mumble something about leaving the gold tags in your other pants.")
		}
		C.Padlock, C.PadlockStrength = 1, 100
		me.Coffins[Gold] -= PAD
		return bought(fmt.Sprintf("`yYou purchase the `wHeavy Padlock`y for `w%d`y gold tags.", PAD), "security")
	case "buy_smoke":
		if C.FireAlarm == 1 {
			return elija("`wElija: `y\"Your parlor is quite small.  You really don't need two of these things.\"\n\nYou nod in agreement.  Why waste the cash?", "security")
		}
		if me.Coffins[Gold] < SMOKE {
			return broke("You feel like a complete dumbass.  He's right.")
		}
		C.FireAlarm = 1
		me.Coffins[Gold] -= SMOKE
		return bought(fmt.Sprintf("`yYou purchase the `wSmoke Detector`y for `w%d`y gold tags.", SMOKE), "security")
	case "buy_safe":
		if C.Safe == 1 {
			return elija("`wElija: `y\"You already own a Safe.  You shouldn't need two.\"", "security")
		}
		if me.Coffins[Gold] < SAFE {
			return broke("You nod in agreement.")
		}
		C.Safe = 1
		me.Coffins[Gold] -= SAFE
		return bought(fmt.Sprintf("`yYou purchase the `wSafe`y for `w%d`y gold tags.", SAFE), "security")
	}
	return s.cmdStore(Action{})
}

// ======================================================================== rival parlors (commands_comp.cpp, commands_battle.cpp)

const compInfo = "A dense fog covers the row upon row of funeral homes. You see disturbed, emotionally unstable people trying to choose which parlor to patronize.  You fight the urge to hand out business cards, you have more important things to attend to."

func (s *Session) compMenu() Screen {
	left := s.cfg().VisitsPerDay - s.me().Fights
	t := fmt.Sprintf("You look at your watch, you have time to visit `w%d`$ more parlors today.\n", left)
	if left <= 0 {
		t = "You look at your watch, you should really get back to your parlor.\n"
	} else if left == 1 {
		t = "You look at your watch, you have time to visit `w1`$ more parlor today.\n"
	}
	return Screen{View: "generic", BG: "places/palors", Info: compInfo, Text: t,
		Buttons: []Button{B("Visit", "comp", "getname").K("v"), B("Look", "comp", "look").K("o"), B("Leave", "map", "").K("l")}}
}
func enemyScr(info, text string, bs []Button) Screen {
	return Screen{View: "generic", BG: "places/funeral_enemy", Info: info, Text: text, Buttons: bs}
}
func (s *Session) cmdComp(a Action) Screen {
	me := s.me()
	switch a.Sub {
	case "":
		s.setLocation("Parlors")
		return s.compMenu()
	case "menu":
		s.st.Visiting, s.st.Locked = 0, false
		return s.compMenu()
	case "look":
		return Screen{View: "ranking", Title: "Parlors you could visit", RankRows: s.rankingRows(true), Buttons: []Button{B("Continue", "comp", "menu").D()}}
	case "getname":
		if me.Fights >= s.cfg().VisitsPerDay {
			scr := s.compMenu()
			scr.Text = "Is today look at everyone's parlor day?  No, it's not.  Maybe tomorrow."
			scr.Buttons = []Button{B("Continue", "comp", "menu").D()}
			return scr
		}
		scr := s.compMenu()
		scr.Input = askName("Who's funeral home would you like to pay a little visit to?", "comp", "gotname", nil)
		return scr
	case "gotname":
		id := hisID(a)
		if id <= 0 || me.Fights >= s.cfg().VisitsPerDay {
			return s.compMenu()
		}
		if t := s.w.Player(id); t == nil || !t.Active {
			return s.compMenu()
		}
		s.st.Visiting, s.st.Locked, s.st.HisID = 0, false, id
		return s.inFront()
	}
	t := s.w.Player(s.st.HisID)
	if t == nil {
		return s.compMenu()
	}
	switch a.Sub {
	case "try_door":
		return s.tryDoor(t)
	case "picklock":
		return s.pickLock(t)
	case "inside":
		return s.insideMenu(t)
	case "steal":
		return s.steal(t)
	case "attack":
		if !s.st.Locked {
			return s.compMenu()
		}
		me.HP, t.HP = me.HPMax, t.HPMax
		return s.battleStart(t)
	}
	return s.compMenu()
}

func (s *Session) inFront() Screen {
	me := s.me()
	t := s.w.Player(s.st.HisID)
	info := fmt.Sprintf("You are standing in front of a funeral parlor.  The sign above the door proudly announces the name, \"%s\". ", t.Parlor)
	leave := []Button{B("Leave", "comp", "menu").D()}
	if t.ID == me.ID {
		return enemyScr(info, "This parlor looks strangely familiar.\n\nYou decide to go inside...", []Button{B("Continue", "main", "").D()})
	}
	if s.w.IsOnline(t.ID) {
		return enemyScr(info, fmt.Sprintf("You see %s through the window talking earnestly to a young couple, perhaps later would be better...", t.Name), leave)
	}
	if t.Police {
		scr := enemyScr(info, fmt.Sprintf("You park your %s a few blocks away from %s.  As you approach you see %s talking to some cops, maybe you should come back after things cool down.", s.transportName(me), t.Parlor, t.Name), leave)
		scr.BG = "places/funeral_enemy_police"
		return scr
	}
	for _, x := range s.w.Online() {
		if x.Status == "visit:"+strconv.Itoa(t.ID) && x.SID != s.SID {
			if lp := s.w.Player(x.PlayerID); lp != nil {
				return enemyScr(info, fmt.Sprintf("As you take your position behind a bush, you are surprised to see %s already sitting there.\n\n`w%s: `$\"Oh, hey %s.  Tell ya what, %s's mine first, ok?\"\n\nYou agree to come back later.", lp.Name, lp.Name, me.Name, he(t)), leave)
			}
		}
	}
	me.Fights++
	s.st.Locked = true
	s.st.Visiting = t.ID
	return enemyScr(info, fmt.Sprintf("The lights are off, the parlor is silent.  %s must be sleeping inside.\n\nNobody seems to be looking, you could try the door-knob if you like.\n\nYou see a `w%s`$ parked nearby.", t.Name, s.transportName(t)),
		[]Button{B("Try Door", "comp", "try_door").K("t"), B("Leave", "comp", "menu").K("l")})
}
func doorMenu() []Button {
	return []Button{B("Pick Lock", "comp", "picklock").K("p"), B("Leave", "comp", "menu").K("l")}
}
func (s *Session) tryDoor(t *Player) Screen {
	if !s.st.Locked {
		return s.compMenu()
	}
	me := s.me()
	if t.Custom.Padlock > 0 {
		txt := fmt.Sprintf("There is a heavy padlock on the door at `w%d percent strength`y.  What do you want to do?", t.Custom.PadlockStrength)
		if me.Custom.Lockpick > 0 {
			txt = fmt.Sprintf("There is a heavy padlock on the door at `w%d percent strength`y. What do you want to do?\n\nYou are holding `w%s`y lockpick(s).", t.Custom.PadlockStrength, Cash(me.Custom.Lockpick))
		}
		return enemyScr("", txt, doorMenu())
	}
	return s.insideMenu(t)
}
func (s *Session) pickLock(t *Player) Screen {
	if !s.st.Locked {
		return s.compMenu()
	}
	me := s.me()
	if me.Custom.Lockpick < 1 {
		return enemyScr("", "You attempt to pick the lock with your finger.  No go.  Perhaps if you had a real lockpick...", doorMenu())
	}
	dmg := randomRange(5, 10)
	t.Custom.PadlockStrength -= dmg
	var txt string
	if t.Custom.PadlockStrength < 1 {
		t.Custom.Padlock, t.Custom.PadlockStrength = 0, 0
		txt = "As you are picking the lock the whole thing breaks and falls off!  Too bad your lockpick got stuck inside it."
		s.w.AddMail(Letter{To: t.ID, Text: "`yYour padlock is `4damaged beyond repair`y by a prowler and falls off!"})
	} else {
		txt = fmt.Sprintf("`yYou successfully pick the lock.  Your lockpick breaks as you try to get it out which causes the padlock `w%d`y points of damage.", dmg)
		s.w.AddMail(Letter{To: t.ID, Text: fmt.Sprintf("`yYour padlock is weakened by `4%d`y down to `w%d percent strength`y by a prowler.", dmg, t.Custom.PadlockStrength)})
	}
	me.Custom.Lockpick--
	return enemyScr("", txt, []Button{B("Continue", "comp", "inside").D()})
}
func (s *Session) insideMenu(t *Player) Screen {
	if !s.st.Locked {
		return s.compMenu()
	}
	txt := fmt.Sprintf("You quickly slip in and close the door.  You hear %s softly snoring in the back room.", t.Name)
	if t.Custom.Safe > 0 {
		txt += "\n\nYou see a large combination `wSafe`$ in the corner.  You won't be able to steal tags."
	}
	txt += fmt.Sprintf("\n\nJudging from the room, you would guess %s has `w%d`$ hitpoints.", t.Name, t.HPMax)
	var bs []Button
	if t.Custom.Safe == 0 {
		bs = append(bs, B("Steal", "comp", "steal").K("s"))
	}
	bs = append(bs, B("Attack", "comp", "attack").K("a"))
	return Screen{View: "generic", BG: "places/desk_enemy", Info: fmt.Sprintf("You have broken into %s.", t.Parlor), Text: txt, Buttons: bs}
}
func stealTags(max int, me, him *Player) (int, string) {
	typ := random(3)
	name := []string{"wooden", "silver", "gold"}[typ]
	if him.Coffins[typ] <= 0 {
		return -1, name
	}
	n := min(randomRange(0, max), him.Coffins[typ])
	him.Coffins[typ] -= n
	me.Coffins[typ] += n
	return n, name
}
func (s *Session) steal(t *Player) Screen {
	if !s.st.Locked || t.Custom.Safe > 0 {
		return s.compMenu()
	}
	me := s.me()
	n, name := stealTags(3, me, t)
	var txt string
	switch {
	case n == -1:
		txt = "You look around but can't find anything of value."
	case n == 0:
		txt = "You begin wildly opening drawers and things looking for anything of value."
	case n == 1:
		txt = fmt.Sprintf("You look around and find `w1 %s`$ tag hidden on top of the refrigerator!", name)
	default:
		txt = fmt.Sprintf("You look around and find `w%d %s`$ tags in a drawer!", n, name)
	}
	sexy := ifs(me.Male && !t.Male, "lingerie", "pajamas")
	txt += fmt.Sprintf("\n\nYou are startled by a noise behind you.  It's %s in %s %s! You crash through a window and run like hell.", t.Name, his(t), sexy)
	m := fmt.Sprintf("\n`wYou caught %s sneaking around inside your parlor!`$\n", me.Name)
	switch {
	case n == 1:
		m += fmt.Sprintf("You scare %s off.  You notice `w%d %s tag `$is missing.", him(me), n, name)
	case n > 1:
		m += fmt.Sprintf("You scare %s off.  You notice `w%d %s tags `$are missing.", him(me), n, name)
	default:
		m += fmt.Sprintf("You scare %s off before %s could steal anything.", him(me), he(me))
	}
	s.w.AddMail(Letter{To: t.ID, Text: m, Pic: "people/man_prowl"})
	s.st = custStatus{}
	return enemyScr("", txt, []Button{B("Leave", "comp", "menu").D()})
}

func (s *Session) battleInfo(t *Player) *Battle {
	me := s.me()
	return &Battle{Me: Fighter{me.Name, me.HP, me.HPMax}, Him: Fighter{t.Name, t.HP, t.HPMax}}
}
func (s *Session) battleScr(t *Player, text string, bs []Button) Screen {
	if bs == nil {
		bs = []Button{B("Attack", "battle", "attack").K("a").D(), B("Run", "battle", "run").K("r")}
	}
	return Screen{View: "battle", BG: "places/funeral_enemy", Info: "You are in battle.", Battle: s.battleInfo(t), Text: text, Buttons: bs}
}
func (s *Session) battleStart(t *Player) Screen {
	me := s.me()
	s.st.Battle = true
	cry := pick([]string{"Stop stealing my customers!", "I will BURY you!", fmt.Sprintf("Messing with me was a grave mistake, dear %s.", t.Name),
		ifs(t.Male, "Discount this, bastard!", "Discount this, bitch!"), "I was in this town first!", "You're an amateur! You don't belong here!"})
	txt := fmt.Sprintf("`w\"%s\" `$you scream as you break into %s room.\n\n", cry, his(t))
	if me.Plots > t.Plots {
		txt += t.Name + " is completely surprised, you get first swing!\n\n"
	} else {
		txt += fmt.Sprintf("%s's eyes flick open, %s knew you were in the house!\n\n", t.Name, he(t))
		txt += s.getHit(t)
		if d, ok := s.somebodyDied(t, txt); ok {
			return d
		}
	}
	return s.battleScr(t, txt, nil)
}
func hitName(h int, third bool) string {
	base := "slam"
	for _, x := range []struct {
		lo, hi int
		n      string
	}{{1, 2, "slap"}, {3, 4, "sock"}, {5, 6, "punch"}, {7, 8, "kick"}, {9, 10, "throw"}, {11, 12, "squeeze"}, {13, 14, "ninja"}} {
		if h >= x.lo && h <= x.hi {
			base = x.n
		}
	}
	if !third {
		return base
	}
	switch base {
	case "punch":
		return "punches"
	case "ninja":
		return "ninja's"
	}
	return base + "s"
}
func (s *Session) getHit(t *Player) string {
	me := s.me()
	hit := int(frandom(float64(t.Strength+1)/2) + float64(t.Strength+1)/2)
	var txt string
	if random(20) == 0 || hit == 0 {
		txt, hit = t.Name+" swings but you sidestep the blow.", 0
	} else {
		txt = fmt.Sprintf("%s %s you for `4%d`$ damage.", t.Name, hitName(hit, true), hit)
	}
	me.HP -= hit
	return txt + "\n\n"
}
func (s *Session) doHit(t *Player) string {
	me := s.me()
	hit := int(frandom(float64(me.Strength+1)/2) + float64(me.Strength+1)/2)
	var txt string
	switch {
	case hit == 0:
		txt = t.Name + " dodges your swing."
	case random(10) == 0:
		hit *= 2
		txt = fmt.Sprintf("You `wsoul smash`$ %s for `4%d`$ damage!", t.Name, hit)
	default:
		txt = fmt.Sprintf("You %s %s for `4%d`$ damage.", hitName(hit, false), t.Name, hit)
	}
	t.HP -= hit
	return txt + "\n\n"
}
func battleBP(winner, loser *Player, selfDefense bool) (win, lose int) {
	if selfDefense {
		win, lose = int(float64(loser.Exp)*0.01), int(float64(loser.Exp)*0.005)
	} else {
		win, lose = int(float64(loser.Exp)*0.02), int(float64(loser.Exp)*0.01)
	}
	expModForce(loser, -lose)
	expModForce(winner, win)
	return
}
func (s *Session) somebodyDied(t *Player, txt string) (Screen, bool) {
	me := s.me()
	if t.HP < 1 {
		t.HP = 0
		t.Police = true
		n, name := stealTags(4, me, t)
		win, lose := battleBP(me, t, false)
		stolen := " Nothing was stolen."
		if n == 1 {
			stolen = fmt.Sprintf(" `w%d`$ %s tag was stolen from your pocket.", n, name)
		} else if n > 1 {
			stolen = fmt.Sprintf(" `w%d`$ %s tags were stolen from your pockets.", n, name)
		}
		s.G.Tv(s.w, fmt.Sprintf("It looks like %s was taken to the hospital.", t.Name))
		s.w.AddMail(Letter{To: t.ID, Pic: "stuff/battle_lose", Text: fmt.Sprintf("\n`wYou were attacked in your sleep by %s!`$\n\nYou are badly injured.  You vaguely remember riding in an ambulance.\n\n`$You lose `w%s `$Bury Points.%s", me.Name, Cash(lose), stolen)})
		found := fmt.Sprintf("You go through %s pockets but find nothing.", his(t))
		if n >= 1 {
			found = fmt.Sprintf("You go through %s pockets and find `w%d `$%s tag%s.", his(t), n, name, ifs(n == 1, "", "s"))
		}
		txt += fmt.Sprintf("%s crumples to the floor. You have won the battle!\n\nYou earn `w%s `$Bury Points. %s", t.Name, Cash(win), found)
		s.st.Battle = false
		scr := s.battleScr(t, txt, []Button{B("Continue", "battle", "yell_win").D()})
		scr.Pic = "stuff/money_bag_2"
		return scr, true
	}
	if me.HP < 1 {
		me.HP = 0
		win, lose := battleBP(t, me, true)
		s.w.AddMail(Letter{To: t.ID, Pic: "places/hospital_ambulance", Text: fmt.Sprintf("\n`wYou were attacked in your sleep by %s!`$\n\nYou woke up and kicked %s ass!\n\n`$You earn `w%s `$Bury Points. (applied to day %d)", me.Name, his(me), Cash(win), s.age())})
		s.G.Tv(s.w, fmt.Sprintf("It looks like %s was taken to the hospital.", me.Name))
		txt += fmt.Sprintf("You fall down, unable to get up.\n\nYou lose `w%s `$Bury Points.", Cash(lose))
		s.st.Battle = false
		scr := s.battleScr(t, txt, []Button{B("Continue", "battle", "yell_lost").D()})
		scr.BG, scr.Pic = "", "stuff/battle_lose"
		return scr, true
	}
	return Screen{}, false
}
func (s *Session) cmdBattle(a Action) Screen {
	t := s.w.Player(s.st.HisID)
	if t == nil {
		return s.cmdMain()
	}
	me := s.me()
	switch a.Sub {
	case "attack", "run":
		if !s.st.Battle || me.HP <= 0 || t.HP <= 0 {
			return s.cmdMain()
		}
	}
	switch a.Sub {
	case "run":
		s.w.AddMail(Letter{To: t.ID, Pic: "people/man_prowl", Text: fmt.Sprintf("\n`wYou were attacked in your sleep by %s!`$\n\n%s got scared and ran off.\n\n", me.Name, He(me))})
		s.st = custStatus{}
		scr := s.compMenu()
		scr.Text = "You backflip through an open window and take off running."
		scr.Buttons = []Button{B("Continue", "comp", "").D()}
		return scr
	case "attack":
		txt := s.doHit(t)
		if d, ok := s.somebodyDied(t, txt); ok {
			return d
		}
		txt += s.getHit(t)
		if d, ok := s.somebodyDied(t, txt); ok {
			return d
		}
		return s.battleScr(t, txt, nil)
	case "yell_win", "yell_lost":
		win := a.Sub == "yell_win"
		prompt := "`wYou feel yourself being lifted into an ambulance.  Mutter something or just hit ENTER to continue."
		if win {
			prompt = "`wYou hear police sirens in the distance... you can yell something as you leave or just hit ENTER to continue."
		}
		scr := s.battleScr(t, prompt, []Button{})
		if !win {
			scr.BG = ""
		}
		scr.Input = &Input{Kind: "text", Prompt: ifs(win, "Yell:", "Mutter:"), Cmd: "battle", Sub: ifs(win, "got_win", "got_lost"), MaxLen: 120, AllowEmpty: true}
		return scr
	case "got_win", "got_lost":
		v, _ := val(a)
		text := strings.TrimSpace(swearCheck(strings.ReplaceAll(v, "`", ""), s.data().Swears))
		if a.Sub == "got_win" {
			if len(text) < 2 {
				s.news("crime", fmt.Sprintf("`8%s brutally assaulted %s!\r\n\r\n", me.Name, t.Name))
			} else {
				s.news("crime", fmt.Sprintf("`8%s brutally assaulted %s!`6\r\n\"%s\" `8justified %s.\r\n\r\n", me.Name, t.Name, text, me.Name))
				s.w.AddMail(Letter{To: t.ID, Pic: "places/hospital_room", Text: fmt.Sprintf("`$While recovering you can't get what %s yelled while escaping out of your head...\n\n`w\"%s\"`$", me.Name, text)})
			}
			s.st = custStatus{}
			return s.cmdComp(Action{})
		}
		if len(text) < 2 {
			s.news("crime", fmt.Sprintf("`8%s assaulted %s in self defense!\r\n\r\n", t.Name, me.Name))
		} else {
			s.news("crime", fmt.Sprintf("`8%s assaulted %s in self defense!`6\r\n\"%s\" `8moaned %s from the ambulance.\r\n\r\n", t.Name, me.Name, text, me.Name))
			s.w.AddMail(Letter{To: t.ID, Pic: "places/hospital_ambulance", Text: fmt.Sprintf("`$As %s is leaving you hear %s moaning from the ambulance...\n\n`w\"%s\"`$", me.Name, him(me), text)})
		}
		s.st = custStatus{}
		return s.cmdHospital(Action{Sub: "room"})
	}
	return s.cmdMain()
}

// ======================================================================== Pale Horse Cafe (commands_bar.cpp)

func (s *Session) namesInCafe() string {
	seen := map[int]bool{}
	var names []string
	for _, x := range s.w.Online() {
		if x.Status == "chat" && x.PlayerID != s.PID && !seen[x.PlayerID] {
			seen[x.PlayerID] = true
			if p := s.w.Player(x.PlayerID); p != nil {
				names = append(names, p.Name)
			}
		}
	}
	if len(names) == 0 {
		return "`$You are the only one here."
	}
	return "`$Other people here: " + strings.Join(names, ", ")
}
func (s *Session) cmdCafe() Screen {
	me := s.me()
	s.setLocation("in cafe")
	s.chatting = true
	s.w.AddChat("`5"+me.Name+" saunters in.", 0)
	s.chatLast = s.w.NextChatID
	text := "`$The `wPale Horse `$has been here since before you can remember.  A great place to gossip or just sip a mochachino and watch tv.\n\nYou always wondered why they had that big glass bottle on the roof.\n\n" + s.namesInCafe() + "\nEnter /? for help.\n"
	return Screen{View: "chat", BG: "bar", Text: text, Buttons: []Button{B("Leave", "map", "").K("esc")}}
}

// ChatUpdate says something (optional) and returns new cafe lines for this player.
func (s *Session) ChatUpdate(say string) []string {
	var out []string
	s.G.Store.Tx(func(w *World) error {
		s.w = w
		defer func() { s.w = nil }()
		s.G.MaintCheck(w, false)
		if s.me() == nil {
			return nil
		}
		if strings.TrimSpace(say) != "" {
			s.chatInput(say, func(t string) { out = append(out, t) })
		}
		for _, l := range w.Chat {
			if l.ID > s.chatLast && (l.To == 0 || l.To == s.PID) {
				out = append(out, l.Text)
			}
		}
		s.chatLast = w.NextChatID
		w.TouchSession(s.SID, s.PID, s.Kind, s.location, "chat")
		return nil
	})
	return out
}

func (s *Session) chatInput(text string, self func(string)) {
	me := s.me()
	sw := s.data().Swears
	for _, line := range strings.Split(text, "|") {
		line = strings.NewReplacer("\r", " ", "\n", " ").Replace(line)
		if line == "" {
			continue
		}
		if line[0] != '/' {
			s.w.AddChat(fmt.Sprintf("`$%s: `w%s", me.Name, swearCheck(line, sw)), 0)
			continue
		}
		body := line[1:]
		f := strings.Fields(body)
		c := ""
		if len(f) > 0 {
			c = strings.ToLower(f[0])
		}
		arg := func(i int) string {
			if i < len(f) {
				return f[i]
			}
			return ""
		}
		switch c {
		case "?":
			self("\n** `$Cafe chat help **`w\n\n`w/yell `$to send a message to everyone\n`w/me`$ to do a custom action\n`w/all `$to see who is online now\n" +
				"`w/give name tag_type `$to give a tag. Example: `w/give Seth gold\n`w/info `$to show how many BP's, turns and tags you have now.\n`w/who `$to see who is in the cafe\n`w/tv on (or off) `$to control the cafe tv.\n")
		case "who":
			self(s.namesInCafe())
		case "info":
			self(fmt.Sprintf("`5You have `w%d`5 turns left today and `w%d`5 parlor visits.\nToday's BP's: `w%s`5, total BP's: `w%s`5.\nCasket tags: `w%d`5 wood, `w%d`5 silver, `w%d`5 gold.",
				me.Turns, max(0, s.cfg().VisitsPerDay-me.Fights), Cash(me.SP), Cash(me.Exp), me.Coffins[0], me.Coffins[1], me.Coffins[2]))
		case "give":
			s.chatGive(arg(1), arg(2), self)
		case "tv":
			if arg(1) == "" {
				self(ifs(!s.w.Glo.TVOff, "`5The TV is currently on.", "`5The TV is currently off, that stuff will rot your brain."))
			} else {
				s.w.Glo.TVOff = strings.ToLower(arg(1)) != "on"
				self(ifs(!s.w.Glo.TVOff, "`5You turn the tv on.", "`5You turn the tv off."))
			}
		case "me":
			s.w.AddChat(fmt.Sprintf("`$%s %s", me.Name, swearCheck(strings.TrimSpace(body[2:]), sw)), 0)
		case "yell":
			s.G.Broadcast(s.w, fmt.Sprintf("%s yells: %s", me.Name, swearCheck(strings.TrimSpace(body[4:]), sw)))
		case "all":
			self("\n`wName                 Status            Last hit")
			self("`$-----------------------------------------------")
			for _, x := range s.w.Online() {
				p := s.w.Player(x.PlayerID)
				if p == nil {
					continue
				}
				ago := (time.Now().UnixMilli() - x.LastSeen) / 1000
				where := x.Location
				if x.Status == "chat" {
					where = "in cafe"
				}
				self(fmt.Sprintf("%-20s %-12s  %ds ago (%s)", p.Name, where, ago, x.Kind))
			}
		default:
			self("Unknown command.  Do /? for the list.")
		}
	}
}
func (s *Session) chatGive(who, tag string, self func(string)) {
	me := s.me()
	var target *Player
	for _, x := range s.w.Online() {
		if x.Status != "chat" {
			continue
		}
		if p := s.w.Player(x.PlayerID); p != nil && who != "" && strings.Contains(strings.ToLower(p.Name), strings.ToLower(who)) {
			target = p
			break
		}
	}
	if target == nil {
		self(fmt.Sprintf("`5You look around the room but don't see anyone with `w'%s'`5 in their name.", who))
		return
	}
	typ, ok := map[string]int{"wood": Wood, "silver": Silver, "gold": Gold}[strings.ToLower(tag)]
	if !ok {
		self("`5Valid tag types are wood, silver and gold.")
		return
	}
	if me.Coffins[typ] < 1 {
		s.w.AddChat(fmt.Sprintf("`5%s looks in %s pocket for a %s tag but comes up empty.", me.Name, his(me), casketName[typ]), 0)
		return
	}
	if target.ID == me.ID {
		s.w.AddChat(fmt.Sprintf("`5%s absently tosses a %s tag into the air and catches it.", me.Name, casketName[typ]), 0)
		return
	}
	lim := s.cfg().TagsReceivablePerDay
	if target.TagsToday >= lim {
		if lim == 0 {
			s.w.AddChat(fmt.Sprintf("`5%s is unable to give `w%s `5a %s tag. (the admin has disabled tag transfer)", me.Name, target.Name, casketName[typ]), 0)
		} else {
			s.w.AddChat(fmt.Sprintf("`5%s is unable to give `w%s `5a %s tag. (%s's already received %d today)", me.Name, target.Name, casketName[typ], he(target), target.TagsToday), 0)
		}
		return
	}
	me.Coffins[typ]--
	target.Coffins[typ]++
	target.TagsToday++
	s.w.AddChat(fmt.Sprintf("`5%s gives `w%s `5a %s tag.", me.Name, target.Name, casketName[typ]), 0)
}

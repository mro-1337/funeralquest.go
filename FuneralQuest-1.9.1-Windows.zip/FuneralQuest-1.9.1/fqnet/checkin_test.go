package fqnet_test

import (
	"testing"
	"time"
)

// A door-only BBS (no fq net running) checks in when callers come and go.
func TestCheckIn(t *testing.T) {
	A := newTown(t, "Deathville")
	B := newTown(t, "Gravesend")
	B.a.SetSettings(map[string]string{"net_public_url": ""})
	A.a.SetSettings(map[string]string{"net_auto_accept": "1"})
	A.player(t, "Alice")
	B.player(t, "Bobby")
	if _, err := B.a.Net.AddPeer(A.srv.URL); err != nil {
		t.Fatal(err)
	}
	if !B.a.Net.HasLinks() {
		t.Fatal("no links")
	}
	n, ran := B.a.Net.CheckIn(10 * time.Second)
	if !ran || n != 1 {
		t.Fatalf("check-in: reached %d, ran %v", n, ran)
	}
	if !hasRemote(A, "Bobby") || !hasRemote(B, "Alice") {
		t.Fatal("players not exchanged")
	}
	// with the network program running, a check-in leaves it alone
	go B.a.Net.Run()
	time.Sleep(300 * time.Millisecond)
	other := B.a.Net // same program: allowed
	if _, ran := other.CheckIn(time.Second); !ran {
		t.Fatal("the program running the network should be able to check in")
	}
}

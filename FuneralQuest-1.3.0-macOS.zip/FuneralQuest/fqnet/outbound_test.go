package fqnet_test

import (
	"strings"
	"testing"
	"time"

	"funeralquest/engine"
	"funeralquest/fqnet"
)

// Gravesend runs without an open port (telnet only, behind a firewall): it has no public
// address, so Deathville can never connect to it. Everything must still work by Gravesend
// connecting out.
func TestOutboundOnlyTown(t *testing.T) {
	A := newTown(t, "Deathville")
	B := newTown(t, "Gravesend")
	B.a.SetSettings(map[string]string{"net_public_url": ""})
	alice := A.player(t, "Alice")
	A.player(t, "Alma")
	bobby := B.player(t, "Bobby")

	// B links to A; A accepts a request that has no address
	pa, err := B.a.Net.AddPeer(A.srv.URL)
	if err != nil {
		t.Fatal(err)
	}
	reqs := A.a.Net.Peers()
	if len(reqs) != 1 || reqs[0].URL != "" {
		t.Fatalf("A should have an address-less request: %+v", reqs)
	}
	if err := A.a.Net.Accept(reqs[0].ID); err != nil {
		t.Fatalf("accepting an outbound-only town: %v", err)
	}
	bID := reqs[0].ID
	if err := B.a.Net.SyncPeer(pa.ID); err != nil {
		t.Fatal(err)
	}
	waitView()

	// both sides know each other's players
	if rp := A.a.Net.RemotePlayers(); len(rp) != 1 || rp[0].Name != "Bobby" {
		t.Fatalf("A doesn't know Bobby: %+v", rp)
	}
	if rp := B.a.Net.RemotePlayers(); len(rp) != 2 || rp[0].Name != "Alice" {
		t.Fatalf("B didn't pull A's players: %+v", rp)
	}
	// A lists B as outbound only; B sees A as fully connected
	if r := fqnet.Reach(peerOf(A, bID)); !strings.Contains(r, "outbound only") {
		t.Fatalf("A should list Gravesend as outbound only, got %q", r)
	}
	if r := fqnet.Reach(peerOf(B, pa.ID)); r != "" {
		t.Fatalf("B's view of A should be two-way, got %q", r)
	}
	var town engine.Town
	for _, tw := range A.a.Net.Towns() {
		town = tw
	}
	if !town.OutOnly {
		t.Fatal("town list doesn't mark Gravesend outbound only")
	}

	// a letter from Alice to Bobby: A can't push it, B pulls it
	if err := A.a.Net.QueueMail(bID, "Bobby", alice, "Alice", "Rest Easy", "Can you hear me?"); err != nil {
		t.Fatal(err)
	}
	B.a.Net.SyncPeer(pa.ID) // pull: letter delivered
	var got *engine.Letter
	B.a.G.Store.Tx(func(w *engine.World) error { got = w.TakeMail(bobby); return nil })
	if got == nil || !strings.Contains(got.Text, "Can you hear me?") {
		t.Fatalf("Bobby didn't get the letter: %+v", got)
	}
	if A.a.Net.QueuedMail()[bID] != 1 {
		t.Fatal("A dropped the letter before hearing it arrived")
	}
	B.a.Net.SyncPeer(pa.ID) // B's answer goes back: A clears its outbox
	if A.a.Net.QueuedMail()[bID] != 0 {
		t.Fatal("A's outbox not cleared after the acknowledgement")
	}
	B.a.Net.SyncPeer(pa.ID)
	n := 0
	B.a.G.View(func(w *engine.World) {
		for _, l := range w.Mail {
			if l.To == bobby {
				n++
			}
		}
	})
	if n != 0 {
		t.Fatal("letter delivered twice")
	}

	// raids into B are impossible, and B's players don't come up as raid targets
	p := &play{t: t, s: A.a.G.NewSession(alice, "web")}
	p.act(engine.Action{Cmd: "comp"})
	p.press("Visit")
	p.input("bob")
	if strings.Contains(p.scr.Text, "Gravesend") {
		t.Fatalf("an outbound-only town's player was offered as a raid target: %q", p.scr.Text)
	}
	if _, err := A.a.Net.Raid(bID, engine.RaidReq{Op: "look", Target: "Bobby"}); err == nil || !strings.Contains(err.Error(), "connects out only") {
		t.Fatalf("raid into outbound-only town: %v", err)
	}
	// but B's players can raid A
	q := &play{t: t, s: B.a.G.NewSession(bobby, "web")}
	q.act(engine.Action{Cmd: "comp"})
	q.press("Visit")
	q.input("alm")
	q.press("Yes")
	if !strings.Contains(q.scr.Text, "lights are off") {
		t.Fatalf("outbound-only town can't raid out: %q", q.scr.Text)
	}

	// real-time chat into B: B listens to A
	go B.a.Net.Run()
	time.Sleep(4 * time.Second)
	start := time.Now()
	A.a.G.Store.Tx(func(w *engine.World) error { w.AddSharedChat("`$Alice: `wanyone behind that firewall?"); return nil })
	for {
		heard := false
		B.a.G.Store.Read(func(w *engine.World) {
			for _, l := range w.Chat {
				heard = heard || strings.Contains(l.Text, "behind that firewall")
			}
		})
		if heard {
			break
		}
		if time.Since(start) > 3*time.Second {
			t.Fatal("outbound-only town didn't hear chat")
		}
		time.Sleep(20 * time.Millisecond)
	}
	t.Logf("chat reached the outbound-only town in %v", time.Since(start).Round(time.Millisecond))
}

func TestOneNetworkRunner(t *testing.T) {
	A := newTown(t, "Deathville")
	// a second program for the same town (say fq telnet next to fq web)
	other, err := fqnet.Open(A.a.G, A.a.Home+"/data")
	if err != nil {
		t.Fatal(err)
	}
	var log1, log2 []string
	A.a.Net.Log = func(f string, a ...any) { log1 = append(log1, f) }
	other.Log = func(f string, a ...any) { log2 = append(log2, f) }
	go A.a.Net.Run()
	time.Sleep(300 * time.Millisecond)
	go other.Run()
	time.Sleep(300 * time.Millisecond)
	if len(log2) == 0 || !strings.Contains(log2[0], "standing by") {
		t.Fatalf("second runner didn't stand by: %v", log2)
	}
}

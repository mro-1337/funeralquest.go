package fqnet_test

import (
	"crypto/tls"
	"net"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"

	"funeralquest/web"
)

// Gravesend serves HTTPS with a self-signed certificate made by MakeSelfSignedCert.
// Deathville trusts it the first time, pins it, and refuses a different one later.
func TestSelfSignedHTTPSBetweenTowns(t *testing.T) {
	A := newTown(t, "Deathville")
	B := newTown(t, "Gravesend")
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	addr := ln.Addr().String()
	serve := func(l net.Listener) *httptest.Server {
		info, err := B.a.MakeSelfSignedCert([]string{"127.0.0.1", "localhost"})
		if err != nil {
			t.Fatal(err)
		}
		if !info.SelfSigned || info.Fingerprint == "" {
			t.Fatalf("cert info: %+v", info)
		}
		c := B.a.Config()
		crt, err := tls.LoadX509KeyPair(c.WebCert, c.WebKey)
		if err != nil {
			t.Fatal(err)
		}
		s := httptest.NewUnstartedServer(web.New(B.a, filepath.Join(B.a.Home, "web"), filepath.Join(B.a.Home, "art"), web.Options{TLS: true}).Handler())
		s.Listener = l
		s.TLS = &tls.Config{Certificates: []tls.Certificate{crt}}
		s.StartTLS()
		return s
	}
	srv := serve(ln)
	url := "https://" + addr
	B.a.SetSettings(map[string]string{"net_public_url": url})
	if !strings.HasPrefix(B.a.Config().NetPublicURL, "https://") {
		t.Fatalf("making a certificate should switch the address to https: %q", B.a.Config().NetPublicURL)
	}
	p, err := A.a.Net.AddPeer(url)
	if err != nil {
		t.Fatalf("linking over self-signed https: %v", err)
	}
	if peerOf(A, p.ID).CertPin == "" {
		t.Fatal("certificate not pinned")
	}
	for _, x := range B.a.Net.Peers() {
		B.a.Net.Accept(x.ID)
	}
	if err := A.a.Net.SyncPeer(p.ID); err != nil {
		t.Fatalf("sync over https: %v", err)
	}

	// a different certificate at the same address is refused
	srv.Close()
	ln2, err := net.Listen("tcp", addr)
	if err != nil {
		t.Skip("couldn't reuse the port:", err)
	}
	srv2 := serve(ln2)
	defer srv2.Close()
	err = A.a.Net.SyncPeer(p.ID)
	if err == nil || !strings.Contains(err.Error(), "certificate has changed") {
		t.Fatalf("changed certificate accepted: %v", err)
	}
}

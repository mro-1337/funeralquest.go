// Package admin is the sysop toolkit shared by "fq admin", the web sysop pages and fqedit.
package admin

import (
	"encoding/json"
	"errors"
	"fmt"
	"funeralquest/opmsg"
	"io"
	"log"
	"net/netip"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"

	"funeralquest/engine"
	"funeralquest/fqnet"
	"funeralquest/guard"
)

type Admin struct {
	Home  string
	G     *engine.Game
	Guard *guard.Guard
	Net   *fqnet.Net
	Notes *opmsg.Box // notes for the operator: forgotten passwords, the Contact form
}

// Open opens the game in an install folder (the one holding gamedata/ and data/).
func Open(home string, logw io.Writer) (*Admin, error) {
	if logw == nil {
		logw = io.Discard
	}
	data := filepath.Join(home, "data")
	g, err := engine.NewGame(data, filepath.Join(home, "gamedata"), log.New(logw, "", log.LstdFlags))
	if err != nil {
		return nil, err
	}
	a := &Admin{Home: home, G: g, Guard: guard.New(data), Notes: opmsg.Open(data)}
	if n, err := fqnet.Open(g, data); err == nil {
		a.Net = n
		g.Net = n
		a.Guard.TownAt = n.TownAt // linked towns' addresses are never banned
	} else {
		return nil, err
	}
	a.ApplyGuardSettings()
	return a, nil
}

// ApplyGuardSettings copies the ban settings from the game settings into the guard.
func (a *Admin) ApplyGuardSettings() {
	var c engine.Config
	a.G.View(func(w *engine.World) { c = w.Config })
	a.Guard.S.StrikeLimit = c.BanStrikes
	a.Guard.S.BanTime = time.Duration(c.BanMinutes) * time.Minute
	a.Guard.S.ConnPerMinute = c.BanConnPerMinute
	a.Guard.S.MaxPerIP = c.BanMaxPerIP
}

func (a *Admin) Config() engine.Config {
	var c engine.Config
	a.G.View(func(w *engine.World) { c = w.Config })
	return c
}

// SetSettings changes several settings at once; nothing is saved if any value is bad.
func (a *Admin) SetSettings(kv map[string]string) error {
	err := a.G.Store.Tx(func(w *engine.World) error {
		c := w.Config
		keys := make([]string, 0, len(kv))
		for k := range kv {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		for _, k := range keys {
			v := kv[k]
			if c.Get(k) == strings.TrimSpace(v) {
				continue
			}
			if err := c.Set(k, v); err != nil {
				return err
			}
			if err := checkSpecial(k, c.Get(k)); err != nil {
				return err
			}
		}
		if c.NetPortOnly && c.NetPort == 0 {
			return errors.New("set the Network port (Settings → Server) before using the network port only")
		}
		w.Config = c
		return nil
	})
	if err == nil {
		a.ApplyGuardSettings()
	}
	return err
}

func checkSpecial(k, v string) error {
	switch k {
	case "sysop_allow":
		_, bad := guard.ParsePrefixes(strings.ReplaceAll(v, ",", "\n"))
		if len(bad) > 0 {
			return fmt.Errorf("sysop pages allowed from: can't understand %q", bad[0])
		}
	case "rlogin_trusted":
		for _, t := range strings.Split(v, ",") {
			t = strings.TrimSpace(t)
			if t == "" || t == "*" {
				continue
			}
			if _, err := netip.ParsePrefix(t); err == nil {
				continue
			}
			if _, err := netip.ParseAddr(t); err != nil {
				return fmt.Errorf("hosts allowed to connect: can't understand %q", t)
			}
		}
	case "rlogin_secret":
		if v != "" && len(v) < 12 {
			return errors.New("the BBS gateway secret must be at least 12 characters (or empty for none)")
		}
		if strings.ContainsAny(v, " ,") {
			return errors.New("the BBS gateway secret can't have spaces or commas (BBS menus split on them)")
		}
	case "rlogin_bbs_id":
		if strings.ContainsAny(v, ": ") {
			return errors.New("the BBS ID can't have spaces or colons")
		}
	case "web_host":
		if v != "" {
			if _, err := netip.ParseAddr(v); err != nil {
				return errors.New("web server listens on: give an IP address like 0.0.0.0 or 127.0.0.1, or leave it empty")
			}
		}
	case "web_cert", "web_key":
		if v != "" {
			if _, err := os.Stat(v); err != nil {
				return fmt.Errorf("can't find the file %s", v)
			}
		}
	case "net_public_url":
		if v != "" && !strings.HasPrefix(v, "http://") && !strings.HasPrefix(v, "https://") {
			return errors.New("this server's web address must start with http:// or https://")
		}
	}
	return nil
}

// ------------------------------------------------------------------ text files

type TextFile struct {
	Key   string `json:"key"`
	File  string `json:"file"`
	Title string `json:"title"`
	Help  string `json:"help"`
	Dir   string `json:"-"` // "gamedata" or "data"
}

var Texts = []TextFile{
	{"karma", "karma.txt", "Karma text", "What the stats screen says about each karma level.", "gamedata"},
	{"ratings", "ratings.txt", "Rating text", "What the stats screen says about each parlor rating.", "gamedata"},
	{"news_blurbs", "news_blurbs.txt", "Random news events", "Stories maintenance puts in the paper each day.", "gamedata"},
	{"no_customers", "no_customers.txt", "Random no-customer messages", "Shown when nobody walks in.", "gamedata"},
	{"yangs", "yangs.txt", "Fortune cookies (mean)", "Mean fortunes for Yang's.", "gamedata"},
	{"yangs_nice", "yangs_nice.txt", "Fortune cookies (nice)", "Nice fortunes for Yang's.", "gamedata"},
	{"events", "events.txt", "Random parlor events", "Things that happen while you wait for customers.", "gamedata"},
	{"risks", "risks.txt", "Double-or-nothing risks", "The risks customers offer.", "gamedata"},
	{"hard_sell", "hard_sell.txt", "Hard sell texts", "Upgrade pitches.", "gamedata"},
	{"soft_sell", "soft_sell.txt", "Soft sell texts", "Gentle sales pitches.", "gamedata"},
	{"swear_words", "swear_words.txt", "Swear filter", "Words replaced in names, chat and letters.", "gamedata"},
	{"block_ip", "blocklist_ip.txt", "Blocked IP addresses", "One IP or range (CIDR) per line.", "data"},
	{"block_hosts", "blocklist_hosts.txt", "Blocked host names", "One host name per line; * wildcards allowed.", "data"},
	{"allow_ip", "allowlist_ip.txt", "Never-block list", "Addresses that are never blocked or banned.", "data"},
}

func TextByKey(k string) *TextFile {
	for i := range Texts {
		if Texts[i].Key == k {
			return &Texts[i]
		}
	}
	return nil
}

func (a *Admin) TextPath(t *TextFile) string { return filepath.Join(a.Home, t.Dir, t.File) }

func (a *Admin) ReadText(key string) (string, error) {
	t := TextByKey(key)
	if t == nil {
		return "", errors.New("no such text")
	}
	b, err := os.ReadFile(a.TextPath(t))
	if os.IsNotExist(err) {
		return "", nil
	}
	return strings.ReplaceAll(string(b), "\r\n", "\n"), err
}

// WriteText saves a text file (keeping the old one as .bak). Game texts must still load
// afterwards, or the old file is put back.
func (a *Admin) WriteText(key, content string) error {
	t := TextByKey(key)
	if t == nil {
		return errors.New("no such text")
	}
	if len(content) > 1<<20 {
		return errors.New("that's too big")
	}
	if strings.ContainsRune(content, 0) {
		return errors.New("that isn't text")
	}
	if t.Key == "block_ip" || t.Key == "allow_ip" {
		if _, bad := guard.ParsePrefixes(content); len(bad) > 0 {
			return fmt.Errorf("can't understand the address %q", bad[0])
		}
	}
	content = strings.ReplaceAll(strings.ReplaceAll(content, "\r\n", "\n"), "\n", "\r\n")
	p := a.TextPath(t)
	old, oldErr := os.ReadFile(p)
	if oldErr == nil {
		os.WriteFile(p+".bak", old, 0o644)
	}
	tmp := p + ".tmp"
	if err := os.WriteFile(tmp, []byte(content), 0o644); err != nil {
		return err
	}
	if err := os.Rename(tmp, p); err != nil {
		return err
	}
	if t.Dir == "gamedata" {
		d := engine.LoadData(filepath.Join(a.Home, "gamedata"))
		if len(d.Risks) == 0 || len(d.Options) == 0 || len(d.Upgrades) == 0 {
			if oldErr == nil {
				os.WriteFile(p, old, 0o644)
			}
			return errors.New("the game couldn't read that file any more, so the old one was put back. Check the layout matches the original")
		}
	}
	return nil
}

// ------------------------------------------------------------------ players

type PlayerRow struct {
	ID      int    `json:"id"`
	Name    string `json:"name"`
	Parlor  string `json:"parlor"`
	Male    bool   `json:"male"`
	Active  bool   `json:"active"`
	Online  bool   `json:"online"`
	Exp     int    `json:"exp"`
	Money   int    `json:"money"`
	Turns   int    `json:"turns"`
	DayLast int    `json:"day_last"`
	Logon   string `json:"logon"`
	BBSKey  string `json:"bbs_key"`
	Level   int    `json:"level"`
	Email   string `json:"email"`
}

func (a *Admin) Players() []PlayerRow {
	var out []PlayerRow
	a.G.View(func(w *engine.World) {
		on := map[int]bool{}
		for _, s := range w.Online() {
			on[s.PlayerID] = true
		}
		for _, p := range w.Players {
			logon := p.Logon
			if p.AI != nil && logon == "" {
				logon = "(AI player)"
			}
			out = append(out, PlayerRow{p.ID, p.Name, p.Parlor, p.Male, p.Active, on[p.ID], p.Exp, p.Money, p.Turns, p.DayLast, logon, p.BBSKey, max(1, p.Level), p.Email})
		}
	})
	sort.Slice(out, func(i, j int) bool {
		if out[i].Active != out[j].Active {
			return out[i].Active
		}
		return out[i].Exp > out[j].Exp
	})
	return out
}

// PlayerField describes an editable player value.
type PlayerField struct {
	Key   string `json:"key"`
	Label string `json:"label"`
	Kind  string `json:"kind"` // int, text, bool
}

var PlayerFields = []PlayerField{
	{"name", "Name", "text"}, {"parlor", "Parlor", "text"}, {"male", "Male", "bool"}, {"active", "Open (active)", "bool"},
	{"logon", "Web/telnet logon", "text"}, {"email", "E-mail (for forgotten passwords)", "text"}, {"money", "Money", "int"}, {"exp", "Bury points (BP)", "int"}, {"xp", "Experience (sets the level)", "int"}, {"turns", "Turns left today", "int"},
	{"luck", "Luck", "int"}, {"karma", "Karma", "int"}, {"rating", "Rating", "int"}, {"strength", "Strength", "int"},
	{"hp", "Hit points", "int"}, {"hp_max", "Max hit points", "int"}, {"plots", "Plots", "int"}, {"transport", "Hearse (0-based)", "int"},
	{"wood", "Wood tags", "int"}, {"silver", "Silver tags", "int"}, {"gold", "Gold tags", "int"}, {"police", "Police protection", "bool"},
}

func playerMap(p *engine.Player) map[string]string {
	b := func(v bool) string { return map[bool]string{true: "yes", false: "no"}[v] }
	i := strconv.Itoa
	return map[string]string{"name": p.Name, "parlor": p.Parlor, "male": b(p.Male), "active": b(p.Active), "logon": p.Logon, "email": p.Email,
		"money": i(p.Money), "exp": i(p.Exp), "xp": i(p.XP), "turns": i(p.Turns), "luck": i(p.Luck), "karma": i(p.Karma), "rating": i(p.Rating),
		"strength": i(p.Strength), "hp": i(p.HP), "hp_max": i(p.HPMax), "plots": i(p.Plots), "transport": i(p.Transport),
		"wood": i(p.Coffins[0]), "silver": i(p.Coffins[1]), "gold": i(p.Coffins[2]), "police": b(p.Police)}
}

func (a *Admin) Player(id int) (map[string]string, error) {
	var out map[string]string
	a.G.View(func(w *engine.World) {
		if p := w.Player(id); p != nil {
			out = playerMap(p)
			out["id"] = strconv.Itoa(p.ID)
			out["bbs_key"] = p.BBSKey
		}
	})
	if out == nil {
		return nil, errors.New("no such player")
	}
	return out, nil
}

// UpdatePlayer changes player values. Only the fields in PlayerFields can be changed.
func (a *Admin) UpdatePlayer(id int, kv map[string]string) error {
	return a.G.Store.Tx(func(w *engine.World) error {
		p := w.Player(id)
		if p == nil {
			return errors.New("no such player")
		}
		cp := *p
		for k, v := range kv {
			v = strings.TrimSpace(v)
			var f *PlayerField
			for i := range PlayerFields {
				if PlayerFields[i].Key == k {
					f = &PlayerFields[i]
				}
			}
			if f == nil {
				return fmt.Errorf("can't change %q", k)
			}
			var n int
			var bv bool
			switch f.Kind {
			case "int":
				x, err := strconv.Atoi(v)
				if err != nil || x < -2_000_000_000 || x > 2_000_000_000 {
					return fmt.Errorf("%s must be a number", f.Label)
				}
				n = x
			case "bool":
				switch strings.ToLower(v) {
				case "yes", "true", "1", "on", "y":
					bv = true
				case "no", "false", "0", "off", "n":
				default:
					return fmt.Errorf("%s: yes or no", f.Label)
				}
			case "text":
				if strings.ContainsAny(v, "\r\n\x00\x1b`") || len(v) > 30 {
					return fmt.Errorf("%s: plain text, 30 characters at most", f.Label)
				}
			}
			switch k {
			case "name":
				if len(v) < 3 {
					return errors.New("name is too short")
				}
				if o := w.ByName(v); o != nil && o.ID != id {
					return errors.New("another player already has that name")
				}
				cp.Name = v
			case "parlor":
				cp.Parlor = v
			case "logon":
				if v != "" {
					if o := w.ByLogon(v); o != nil && o.ID != id {
						return errors.New("another player already uses that logon")
					}
				}
				cp.Logon = v
			case "email":
				if v != "" && !engine.ValidEmail(v) {
					return errors.New("that e-mail address doesn't look right")
				}
				cp.Email = strings.TrimSpace(v)
			case "male":
				cp.Male = bv
			case "active":
				cp.Active = bv
			case "police":
				cp.Police = bv
			case "money":
				cp.Money = n
			case "exp":
				cp.Exp = n
			case "xp":
				cp.XP = max(0, n)
				cp.Level = engine.LevelFor(cp.XP, w.Config.LevelPace)
			case "turns":
				cp.Turns = max(0, n)
			case "luck":
				cp.Luck = n
			case "karma":
				cp.Karma = n
			case "rating":
				cp.Rating = n
			case "strength":
				cp.Strength = n
			case "hp":
				cp.HP = n
			case "hp_max":
				cp.HPMax = max(1, n)
			case "plots":
				cp.Plots = max(0, n)
			case "transport":
				if n < 0 || n >= len(a.G.D().Transport) {
					return fmt.Errorf("hearse must be 0 to %d", len(a.G.D().Transport)-1)
				}
				cp.Transport = n
			case "wood":
				cp.Coffins[0] = max(0, n)
			case "silver":
				cp.Coffins[1] = max(0, n)
			case "gold":
				cp.Coffins[2] = max(0, n)
			}
		}
		*p = cp
		return nil
	})
}

func (a *Admin) SetPlayerPassword(id int, pw string) error {
	if len(pw) < 4 {
		return errors.New("password must be at least 4 characters")
	}
	h := engine.HashPassword(pw)
	return a.G.Store.Tx(func(w *engine.World) error {
		p := w.Player(id)
		if p == nil {
			return errors.New("no such player")
		}
		p.Password = h
		return nil
	})
}

// DeletePlayer removes a player and their mail for good.
func (a *Admin) DeletePlayer(id int) error {
	return a.G.Store.Tx(func(w *engine.World) error {
		for i, p := range w.Players {
			if p.ID == id {
				w.Players = append(w.Players[:i], w.Players[i+1:]...)
				var keep []*engine.Letter
				for _, l := range w.Mail {
					if l.To != id {
						keep = append(keep, l)
					}
				}
				w.Mail = keep
				return nil
			}
		}
		return errors.New("no such player")
	})
}

// ------------------------------------------------------------------ game

func (a *Admin) PostNews(text string) error {
	text = strings.TrimSpace(text)
	if text == "" || len(text) > 2000 {
		return errors.New("news must be 1 to 2000 characters")
	}
	return a.G.Store.Tx(func(w *engine.World) error {
		w.AddNews("front", "`7NOTICE FROM CITY HALL\r\n`^"+strings.ReplaceAll(text, "\n", "\r\n")+"\r\n\r\n")
		return nil
	})
}

func (a *Admin) Maint() (int, error) {
	day := 0
	err := a.G.Store.Tx(func(w *engine.World) error {
		a.G.MaintCheck(w, true)
		day = w.Glo.GameAge
		return nil
	})
	return day, err
}

// Backup zips the data folder now and returns the file's path.
func (a *Admin) Backup() (string, error) { return a.G.BackupNow() }

// BackupList lists backups, newest first, with their sizes.
func (a *Admin) BackupList() []map[string]any {
	var out []map[string]any
	for _, f := range a.G.Backups() {
		if st, err := os.Stat(f); err == nil {
			out = append(out, map[string]any{"file": filepath.Base(f), "size": st.Size(), "when": st.ModTime().Format("2006-01-02 15:04")})
		}
	}
	return out
}

func (a *Admin) Reset(wipe bool) error {
	return a.G.Store.Tx(func(w *engine.World) error {
		a.G.ResetGame(w, wipe)
		a.G.MaintCheck(w, true)
		return nil
	})
}

type Status struct {
	Town    string   `json:"town"`
	Day     int      `json:"day"`
	Players int      `json:"players"`
	Online  int      `json:"online"`
	Mail    int      `json:"mail"`
	Bans    int      `json:"bans"`
	Links   int      `json:"links"`
	Pending int      `json:"pending"`
	ID      string   `json:"id"`
	Finger  string   `json:"fingerprint"`
	Version string   `json:"version"`
	OnNow   []string `json:"on_now"`   // who's playing right now
	Warn    []string `json:"warnings"` // linked towns with a different version or settings
}

func (a *Admin) Status() Status {
	var s Status
	a.G.View(func(w *engine.World) {
		s.Town, s.Day, s.Players, s.Mail = w.Config.ServerName, w.Glo.GameAge, len(w.Active()), len(w.Mail)
		on := map[int]bool{}
		for _, x := range w.Online() {
			on[x.PlayerID] = true
		}
		s.Online = len(on)
		for id := range on {
			if p := w.Player(id); p != nil {
				s.OnNow = append(s.OnNow, p.Name+" ("+p.Parlor+")")
			}
		}
		sort.Strings(s.OnNow)
	})
	s.Bans = len(a.Guard.Bans())
	c := a.Config()
	for _, p := range a.Net.Peers() {
		switch p.State {
		case fqnet.Linked:
			s.Links++
			if w := fqnet.Problems(c, p); w != "" {
				s.Warn = append(s.Warn, p.Name+": "+w)
			}
		case fqnet.Pending, fqnet.KeyChange:
			s.Pending++
		}
	}
	s.ID, s.Finger, s.Version = a.Net.ID, fqnet.Fingerprint(a.Net.ID), engine.Version
	if c.NetPortOnly && c.NetPublicURL == "" {
		s.Warn = append(s.Warn, "\"Linked servers use the network port only\" is on, but This server's web address is empty, so other towns don't know which host to connect to. Set it to your host name, e.g. https://bbs.example.com (the network port is added by itself).")
	}
	if c.NetPortHTTPS && c.WebCert == "" {
		s.Warn = append(s.Warn, "HTTPS on the network port is on, but there's no certificate, so the network port uses plain HTTP. Make one on the Security tab, or turn the setting off.")
	}
	if c.NetPublicURL == "" && s.Links > 0 {
		s.Warn = append(s.Warn, "This server's web address (Settings → Network) isn't set, so linked towns treat yours as outbound only: it works, but everything has to be fetched by your server. If other servers can reach you, set it to that address, e.g. https://bbs.example.com:8089. Leave it empty only if your server really can't be reached from outside.")
	}
	for _, p := range a.Net.Proposals() {
		if p.From != a.Net.ID && p.Status == "open" && p.MyVote == "" {
			s.Warn = append(s.Warn, p.FromName+" asks your town to accept its game settings. Vote on the Network tab (or in fqedit).")
		}
	}
	return s
}

// ------------------------------------------------------------------ logs

var Logs = []string{"server.log", "door.log", "security.log"}

// TailLog returns the last n lines of a log in the data folder.
func (a *Admin) TailLog(name string, n int) (string, error) {
	ok := false
	for _, l := range Logs {
		ok = ok || l == name
	}
	if !ok {
		return "", errors.New("no such log")
	}
	f, err := os.Open(filepath.Join(a.Home, "data", name))
	if err != nil {
		if os.IsNotExist(err) {
			return "(empty)", nil
		}
		return "", err
	}
	defer f.Close()
	st, _ := f.Stat()
	const chunk = 256 * 1024
	off := max(0, st.Size()-chunk)
	b := make([]byte, st.Size()-off)
	f.ReadAt(b, off)
	lines := strings.Split(strings.TrimRight(string(b), "\r\n"), "\n")
	if off > 0 && len(lines) > 0 {
		lines = lines[1:]
	}
	if len(lines) > n {
		lines = lines[len(lines)-n:]
	}
	return strings.Join(lines, "\n"), nil
}

// ------------------------------------------------------------------ sysop password (web pages)

type sysopFile struct {
	Hash    string    `json:"hash"`
	Changed time.Time `json:"changed"`
}

func (a *Admin) sysopPath() string { return filepath.Join(a.Home, "data", "sysop.json") }

func (a *Admin) SysopPasswordSet() bool {
	_, err := os.Stat(a.sysopPath())
	return err == nil
}

func (a *Admin) SetSysopPassword(pw string) error {
	if len(pw) < 10 {
		return errors.New("the sysop password must be at least 10 characters")
	}
	b, _ := json.Marshal(sysopFile{engine.HashPassword(pw), time.Now()})
	return os.WriteFile(a.sysopPath(), b, 0o600)
}

func (a *Admin) DisableSysopPassword() error {
	err := os.Remove(a.sysopPath())
	if os.IsNotExist(err) {
		return nil
	}
	return err
}

// CheckSysopPassword is slow on purpose (PBKDF2).
func (a *Admin) CheckSysopPassword(pw string) bool {
	b, err := os.ReadFile(a.sysopPath())
	if err != nil {
		engine.CheckPassword(pw, "pbkdf2$00$00") // same delay either way
		return false
	}
	var f sysopFile
	if json.Unmarshal(b, &f) != nil {
		return false
	}
	return engine.CheckPassword(pw, f.Hash)
}

// SysopPasswordChanged lets the web server end sessions made before a password change.
func (a *Admin) SysopPasswordChanged() time.Time {
	b, err := os.ReadFile(a.sysopPath())
	if err != nil {
		return time.Time{}
	}
	var f sysopFile
	json.Unmarshal(b, &f)
	return f.Changed
}

// ForgotPassword leaves the sysop a note from someone who forgot their password. The note
// says which parlor the logon name belongs to and the e-mail address on file, if any; the
// person asking is never told whether the logon name exists.
func (a *Admin) ForgotPassword(logon, contact, note, from, addr string) error {
	logon, contact = strings.TrimSpace(logon), strings.TrimSpace(contact)
	if logon == "" {
		return errors.New("Which logon name did you forget the password for?")
	}
	if len(contact) < 5 {
		return errors.New("Tell the sysop how to reach you (your e-mail address).")
	}
	m := opmsg.Msg{Kind: opmsg.KindPassword, Logon: logon, Email: contact, Text: note, From: from}
	a.G.View(func(w *engine.World) {
		if p := w.ByLogon(logon); p != nil {
			m.Account = fmt.Sprintf("%s (%s), player #%d", engine.StripCodes(p.Name), engine.StripCodes(p.Parlor), p.ID)
			m.OnFile = p.Email
			if m.OnFile == "" {
				m.OnFile = "(none)"
			}
		} else {
			m.Account = "(no such logon name here)"
		}
	})
	_, err := a.Notes.Save(m, addr)
	return err
}

// ContactSysop leaves the sysop a message from the Contact form.
func (a *Admin) ContactSysop(name, email, text, from, addr string) error {
	name, email, text = strings.TrimSpace(name), strings.TrimSpace(email), strings.TrimSpace(text)
	switch {
	case name == "":
		return errors.New("What's your name?")
	case !engine.ValidEmail(email):
		return errors.New("That e-mail address doesn't look right.  The sysop needs it to write back.")
	case len(text) < 3:
		return errors.New("Write the sysop a message first.")
	}
	_, err := a.Notes.Save(opmsg.Msg{Kind: opmsg.KindContact, Name: name, Email: email, Text: text, From: from}, addr)
	return err
}

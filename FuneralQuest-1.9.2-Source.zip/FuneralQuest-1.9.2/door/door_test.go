package door

import "testing"

func TestDots(t *testing.T) {
	for _, c := range []struct {
		in   string
		n    int
		want string
	}{{"Winterzedge", 15, "Winterzedge"}, {"bbses.info Palace of the Dead (Protected)", 15, "bbses.info P..."}, {"[eob] Foggy bottom estates", 15, "[eob] Foggy..."}} {
		if got := dots(c.in, c.n); got != c.want || len([]rune(got)) > c.n {
			t.Errorf("dots(%q, %d) = %q, want %q", c.in, c.n, got, c.want)
		}
	}
}

package door

import (
	"fmt"
	"strings"
	"time"

	"funeralquest/engine"
)

// The welcome screen callers see first (door, telnet and RLogin): the web log-on page's gold
// logo and graveyard as a picture on JPEG XL and Sixel terminals, or as ANSI art, with the
// version, the town and the credits in a box underneath.

const welcomeKey = "ui/welcome"
const welcomeW, welcomeH = 640, 240

// WelcomeInfo is what the box under the title shows.
type WelcomeInfo struct {
	Town            string
	Players, Online int
}

// Welcome shows the welcome screen until a key is pressed (or 30 seconds go by).
// It returns false if the caller hung up.
func (d *Door) Welcome(info WelcomeInfo) bool {
	d.cls()
	top := 0 // last screen row the title uses
	switch {
	case d.T.JXL && d.welcomeJXL():
		top = (welcomeH + d.T.CellH - 1) / max(1, d.T.CellH)
	case d.T.Sixel:
		if h := d.welcomeSixel(); h > 0 {
			top = (h + d.T.CellH - 1) / max(1, d.T.CellH)
		} else {
			top = d.welcomeANSI()
		}
	default:
		top = d.welcomeANSI()
	}
	rows := max(24, d.T.Rows)
	boxTop := min(rows-8, max(top+1, 16))
	d.welcomeBox(boxTop, info)
	d.w(csi + "0m" + at(rows, 1))
	_, ok, timedOut := d.key(30 * time.Second)
	if timedOut {
		return true
	}
	return ok
}

func (d *Door) welcomeJXL() bool {
	name, data, _, _ := d.assetFiles(welcomeKey)
	if name == "" {
		return false
	}
	d.T.CacheFiles(map[string][]byte{name: data})
	x := max(0, (d.T.Cols*d.T.CellW-welcomeW)/2)
	d.T.DrawJXL(name, x, 0, "")
	return true
}

// welcomeSixel draws the picture and returns its height in pixels (0 if it couldn't).
func (d *Door) welcomeSixel() int {
	areaW := min(80, d.T.Cols) * d.T.CellW
	w := min(welcomeW, areaW)
	h := welcomeH * w / welcomeW / 6 * 6
	p := composite(d.Assets, welcomeKey, "", w, h)
	if p == nil {
		return 0
	}
	col := 1 + max(0, (d.T.Cols*d.T.CellW-w)/2/max(1, d.T.CellW))
	d.w(at(1, col))
	d.T.RawS(encodeSixel(p))
	return h
}

// a 5x5 block font for the title
var bigFont = map[rune][5]string{
	'F': {"#####", "#    ", "#### ", "#    ", "#    "},
	'U': {"#   #", "#   #", "#   #", "#   #", " ### "},
	'N': {"#   #", "##  #", "# # #", "#  ##", "#   #"},
	'E': {"#####", "#    ", "#### ", "#    ", "#####"},
	'R': {"#### ", "#   #", "#### ", "#  # ", "#   #"},
	'A': {" ### ", "#   #", "#####", "#   #", "#   #"},
	'L': {"#    ", "#    ", "#    ", "#    ", "#####"},
	'Q': {" ### ", "#   #", "#   #", "#  # ", " ## #"},
	'S': {" ####", "#    ", " ### ", "    #", "#### "},
	'T': {"#####", "  #  ", "  #  ", "  #  ", "  #  "},
	' ': {"     ", "     ", "     ", "     ", "     "},
}

// graveyard in ANSI: each line is drawn centered; letters pick the color
//
//	g grass (green)  s stone (gray)  d dark stone  c cross (white)  b bones (yellow-white)
var graveArt = []struct{ text, color string }{
	{"                         ┼                                ", "                         c                                "},
	{"       ┼               ▄███▄          ☻                   ", "       c               sssss          b                   "},
	{"      ▄█▄      ▄▄▄      ███     ▄▄   /█\\      ▄▄▄▄        ", "      sss      ddd      sss     dd   bbb      ssss        "},
	{"     █████    █████     ███    ████   █      ██████       ", "     sssss    ddddd     sss    dddd   b      ssssss       "},
	{"     █████    █████  ▄▄▄███▄▄▄ ████  / \\     ██████       ", "     sssss    ddddd  sssssssss dddd  b b     ssssss       "},
	{"▄▄▄▄▄█████▄▄▄▄█████▄▄█████████▄████▄▄▄▄▄▄▄▄▄▄██████▄▄▄▄▄▄▄", "gggggsssssggggdddddggsssssssssgddddggggggggggssssssggggggg"},
}

func (d *Door) welcomeANSI() int {
	// title, gold on a dark shadow: two bright rows, three darker ones, like the web logo's shine
	title := "FUNERAL QUEST"
	width := len(title)*6 - 1
	grid := make([][]byte, 6)
	for r := range grid {
		grid[r] = []byte(strings.Repeat(" ", width+1))
	}
	x := 0
	for _, ch := range title {
		g := bigFont[ch]
		for r := 0; r < 5; r++ {
			for c := 0; c < 5; c++ {
				if g[r][c] == '#' {
					grid[r][x+c] = 'L'
				}
			}
		}
		for r := 0; r < 5; r++ {
			for c := 0; c < 5; c++ {
				if g[r][c] == '#' && grid[r+1][x+c+1] == ' ' && (r == 4 || g[r+1][c] != '#' || c == 4 || g[r][c+1] != '#') {
					grid[r+1][x+c+1] = 'S'
				}
			}
		}
		x += 6
	}
	col := 1 + max(0, (min(80, d.T.Cols)-(width+1))/2)
	for r := 0; r < 6; r++ {
		var b strings.Builder
		b.WriteString(at(2+r, col))
		for c := 0; c <= width; c++ {
			switch grid[r][c] {
			case 'L':
				switch {
				case r <= 1:
					b.WriteString(sgr(14) + "█")
				case r == 2:
					b.WriteString(sgr(14) + "▓")
				default:
					b.WriteString(sgr(6) + "█")
				}
			case 'S':
				b.WriteString(sgr(8) + "▀")
			default:
				b.WriteString(csi + "0m ")
			}
		}
		d.w(b.String())
	}
	colors := map[byte]int{'g': 2, 's': 7, 'd': 8, 'c': 15, 'b': 14}
	for i, line := range graveArt {
		text := []rune(line.text)
		gcol := 1 + max(0, (min(80, d.T.Cols)-len(text))/2)
		var b strings.Builder
		b.WriteString(at(9+i, gcol))
		last := -1
		for j, r := range text {
			cc := colors[line.color[j]]
			if r != ' ' && cc != last {
				b.WriteString(sgr(cc))
				last = cc
			}
			b.WriteRune(r)
		}
		d.w(b.String())
	}
	return 9 + len(graveArt) - 1
}

// welcomeBox is the wood-framed box under the title, like the web log-on box.
func (d *Door) welcomeBox(top int, info WelcomeInfo) {
	cols := min(80, d.T.Cols)
	w := 62
	left := 1 + (cols-w)/2
	d.box(top, left, top+6, left+w-1, 6)
	center := func(row int, s string) {
		n := plainLen(s)
		d.w(at(row, left+1) + csi + "0m" + strings.Repeat(" ", w-2))
		d.w(at(row, left+1+max(0, (w-2-n)/2)) + toAnsi(s))
	}
	town := info.Town
	if town == "" {
		town = "Deathville"
	}
	center(top+1, "`$Version `w"+engine.Version)
	center(top+2, "`7Welcome to `w"+engine.StripCodes(town)+"`7.")
	who := fmt.Sprintf("`7%d parlor%s open", info.Players, plural(info.Players))
	if info.Online > 0 {
		who += fmt.Sprintf(", `0%d`7 playing now", info.Online)
	}
	center(top+3, who)
	center(top+4, "`8Original game by Seth A. Robinson, art by Akiko Robinson")
	center(top+5, "`8(c) 2001 Robinson Technologies.  Ported to Go.")
	d.w(at(top+7, 1) + csi + "0m")
	prompt := "`$Press any key to enter " + engine.StripCodes(town) + "..."
	d.w(at(top+7, 1+max(0, (cols-plainLen(prompt))/2)) + toAnsi(prompt) + csi + "0m")
}

func plural(n int) string {
	if n == 1 {
		return ""
	}
	return "s"
}

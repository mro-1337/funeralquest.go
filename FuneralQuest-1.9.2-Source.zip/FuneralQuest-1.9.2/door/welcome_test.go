package door

import (
	"bytes"
	"io"
	"os"
	"strings"
	"testing"
	"unicode/utf8"

	"funeralquest/engine"
)

func TestGraveArtLines(t *testing.T) {
	for i, l := range graveArt {
		if utf8.RuneCountInString(l.text) != len(l.color) {
			t.Errorf("graveyard line %d: %d characters but %d colors", i, utf8.RuneCountInString(l.text), len(l.color))
		}
	}
	for ch := range bigFont {
		for _, row := range bigFont[ch] {
			if len(row) != 5 {
				t.Errorf("font %q row %q", ch, row)
			}
		}
	}
}

func TestWelcomeANSI(t *testing.T) {
	var out bytes.Buffer
	in := strings.NewReader("x")
	tm := NewTerm(in, &out, false)
	d := New(tm, nil, t.TempDir(), 0)
	d.Deadline = d.Deadline.Add(1e9 * 60)
	d.Welcome(WelcomeInfo{Town: "Deathville", Players: 12, Online: 3})
	s := out.String()
	for _, want := range []string{"Version", engine.Version, "Deathville", "12 parlors open", "3", "Press any key"} {
		if !strings.Contains(s, want) {
			t.Errorf("welcome screen lacks %q", want)
		}
	}
	if p := os.Getenv("FQ_WELCOME_DUMP"); p != "" {
		os.WriteFile(p, out.Bytes(), 0o644)
	}
	_ = io.Discard
}

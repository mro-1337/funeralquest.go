package door

import (
	"bytes"
	"os"
	"strings"
	"testing"
	"time"
)

type fakeNotes struct{ n int }

func (f *fakeNotes) ForgotPassword(logon, contact, note, from, addr string) error { f.n++; return nil }
func (f *fakeNotes) ContactSysop(name, email, text, from, addr string) error      { f.n++; return nil }

func TestTelnetForgotScreen(t *testing.T) {
	var out bytes.Buffer
	tm := NewTerm(strings.NewReader("forgot\rbob\rbob@example.com\rit is me\r"), &out, false)
	d := New(tm, nil, t.TempDir(), time.Minute)
	d.Notes = &fakeNotes{}
	d.TelnetLogin()
	s := out.String()
	if !strings.Contains(s, "Lost the key") || !strings.Contains(s, "among the living") {
		t.Fatalf("forgot screen missing: %q", s[:min(400, len(s))])
	}
	if p := os.Getenv("FQ_NOTES_DUMP"); p != "" {
		// keep only the forgot screen: from its clear-screen on
		k := strings.Index(s, "Lost the key")
		i := strings.LastIndex(s[:k], "\x1b[2J")
		j := strings.Index(s[k:], "\x1b[2J")
		if j < 0 {
			j = len(s) - k
		}
		os.WriteFile(p, []byte(s[max(0, i):k+j]), 0o644)
	}
}

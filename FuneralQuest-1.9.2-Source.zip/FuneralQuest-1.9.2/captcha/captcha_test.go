package captcha

import (
	"os"
	"strings"
	"testing"
)

func TestCaptcha(t *testing.T) {
	id, ans := New()
	if len(ans) != Length || Answer(id) != ans {
		t.Fatal("bad puzzle")
	}
	for _, c := range ans {
		if _, ok := glyphs[byte(c)]; !ok {
			t.Fatalf("no glyph for %q", c)
		}
	}
	for _, c := range alphabet {
		if _, ok := glyphs[byte(c)]; !ok {
			t.Fatalf("no glyph for %q", c)
		}
	}
	png := PNG(ans)
	if len(png) < 1000 {
		t.Fatal("tiny image")
	}
	if p := os.Getenv("CAPTCHA_DUMP"); p != "" {
		os.WriteFile(p, png, 0o644)
	}
	if len(Lines(ans, func(int) string { return "" })) != 7 {
		t.Fatal("lines")
	}
	if !Check(id, strings.ToLower(ans[:2])+" "+ans[2:]) {
		t.Fatal("right answer refused")
	}
	if Check(id, ans) {
		t.Fatal("a puzzle worked twice")
	}
	id2, _ := New()
	if Check(id2, "WRONG") || Check(id2, "") {
		t.Fatal("wrong answer accepted")
	}
}

// Package captcha makes the "prove you're among the living" puzzles in front of the forgotten
// password and contact-the-sysop forms: a few letters and numbers in different colors, carved
// on a gravestone (a PNG for the web) or drawn in big colored blocks (ANSI for telnet).
package captcha

import (
	"bytes"
	"crypto/rand"
	"encoding/hex"
	"image"
	"image/color"
	"image/png"
	"math/big"
	"strings"
	"sync"
	"time"
)

// Letters that can't be mistaken for each other (no 0/O, 1/I/L, 2/Z, 5/S, 8/B).
const alphabet = "ACDEFGHJKMNPRTUVWXY34679"

const (
	Length   = 5
	lifetime = 10 * time.Minute
	maxLive  = 20000
)

type entry struct {
	answer string
	until  time.Time
}

var (
	mu   sync.Mutex
	live = map[string]entry{}
)

func rnd(n int) int {
	v, _ := rand.Int(rand.Reader, big.NewInt(int64(n)))
	return int(v.Int64())
}

// New makes a puzzle and returns its id and the answer (the answer is only for drawing it).
func New() (id, answer string) {
	b := make([]byte, 12)
	rand.Read(b)
	id = hex.EncodeToString(b)
	var sb strings.Builder
	for i := 0; i < Length; i++ {
		sb.WriteByte(alphabet[rnd(len(alphabet))])
	}
	answer = sb.String()
	mu.Lock()
	defer mu.Unlock()
	now := time.Now()
	if len(live) > maxLive {
		for k, e := range live {
			if now.After(e.until) || len(live) > maxLive/2 {
				delete(live, k)
			}
		}
	}
	live[id] = entry{answer, now.Add(lifetime)}
	return id, answer
}

// Answer returns a live puzzle's answer, for drawing it ("" if it's gone).
func Answer(id string) string {
	mu.Lock()
	defer mu.Unlock()
	e, ok := live[id]
	if !ok || time.Now().After(e.until) {
		return ""
	}
	return e.answer
}

// Check says whether guess solves the puzzle. Each puzzle can be tried only once.
func Check(id, guess string) bool {
	mu.Lock()
	e, ok := live[id]
	delete(live, id)
	mu.Unlock()
	if !ok || time.Now().After(e.until) {
		return false
	}
	g := strings.ToUpper(strings.Join(strings.Fields(guess), ""))
	return g == e.answer
}

// 5x7 glyphs
var glyphs = map[byte][7]string{
	'A': {" ### ", "#   #", "#   #", "#####", "#   #", "#   #", "#   #"},
	'C': {" ####", "#    ", "#    ", "#    ", "#    ", "#    ", " ####"},
	'D': {"#### ", "#   #", "#   #", "#   #", "#   #", "#   #", "#### "},
	'E': {"#####", "#    ", "#    ", "#### ", "#    ", "#    ", "#####"},
	'F': {"#####", "#    ", "#    ", "#### ", "#    ", "#    ", "#    "},
	'G': {" ####", "#    ", "#    ", "#  ##", "#   #", "#   #", " ### "},
	'H': {"#   #", "#   #", "#   #", "#####", "#   #", "#   #", "#   #"},
	'J': {"  ###", "   # ", "   # ", "   # ", "   # ", "#  # ", " ##  "},
	'K': {"#   #", "#  # ", "# #  ", "##   ", "# #  ", "#  # ", "#   #"},
	'M': {"#   #", "## ##", "# # #", "# # #", "#   #", "#   #", "#   #"},
	'N': {"#   #", "##  #", "# # #", "#  ##", "#   #", "#   #", "#   #"},
	'P': {"#### ", "#   #", "#   #", "#### ", "#    ", "#    ", "#    "},
	'R': {"#### ", "#   #", "#   #", "#### ", "# #  ", "#  # ", "#   #"},
	'T': {"#####", "  #  ", "  #  ", "  #  ", "  #  ", "  #  ", "  #  "},
	'U': {"#   #", "#   #", "#   #", "#   #", "#   #", "#   #", " ### "},
	'V': {"#   #", "#   #", "#   #", "#   #", "#   #", " # # ", "  #  "},
	'W': {"#   #", "#   #", "#   #", "# # #", "# # #", "## ##", "#   #"},
	'X': {"#   #", "#   #", " # # ", "  #  ", " # # ", "#   #", "#   #"},
	'Y': {"#   #", "#   #", " # # ", "  #  ", "  #  ", "  #  ", "  #  "},
	'3': {"#### ", "    #", "    #", " ### ", "    #", "    #", "#### "},
	'4': {"#   #", "#   #", "#   #", "#####", "    #", "    #", "    #"},
	'6': {" ### ", "#    ", "#    ", "#### ", "#   #", "#   #", " ### "},
	'7': {"#####", "    #", "   # ", "  #  ", " #   ", " #   ", " #   "},
	'9': {" ### ", "#   #", "#   #", " ####", "    #", "    #", " ### "},
}

// colors that stand out on dark gray stone, like candle light and grave flowers
var inks = []color.RGBA{
	{236, 64, 64, 255},   // blood red
	{250, 204, 60, 255},  // gold
	{110, 220, 90, 255},  // moss green
	{80, 200, 240, 255},  // ghost blue
	{220, 110, 240, 255}, // lily purple
	{255, 150, 60, 255},  // candle orange
	{245, 245, 235, 255}, // bone white
}

// PNG draws the puzzle carved on a gravestone.
func PNG(answer string) []byte {
	const W, H, cell = 280, 96, 6
	img := image.NewRGBA(image.Rect(0, 0, W, H))
	// stone: speckled gray, rounded top, darker edge
	for y := 0; y < H; y++ {
		for x := 0; x < W; x++ {
			if y < 24 {
				cx := 24
				if x > W/2 {
					cx = W - 25
				}
				if (x < 24 || x > W-25) && (x-cx)*(x-cx)+(y-24)*(y-24) > 24*24 {
					continue // transparent corners of the rounded top
				}
			}
			g := uint8(70 + rnd(22))
			if x < 3 || x > W-4 || y > H-4 {
				g = 45
			}
			img.SetRGBA(x, y, color.RGBA{g, g, g + 4, 255})
		}
	}
	// faint scratches
	for i := 0; i < 7; i++ {
		x0, y0 := rnd(W), rnd(H)
		dx, dy := rnd(9)-4, rnd(5)-2
		c := uint8(95 + rnd(40))
		for t := 0; t < 60; t++ {
			x, y := x0+dx*t/4, y0+dy*t/4
			if image.Pt(x, y).In(img.Rect) && img.RGBAAt(x, y).A != 0 {
				img.SetRGBA(x, y, color.RGBA{c, c, c, 255})
			}
		}
	}
	// letters, each its own color, height and slant
	used := map[int]bool{}
	x := 22
	for i := 0; i < len(answer); i++ {
		g, ok := glyphs[answer[i]]
		if !ok {
			continue
		}
		k := rnd(len(inks))
		for used[k] && len(used) < len(inks) {
			k = rnd(len(inks))
		}
		used[k] = true
		ink := inks[k]
		y0 := 20 + rnd(16)
		slant := rnd(3) - 1
		for r := 0; r < 7; r++ {
			for c := 0; c < 5; c++ {
				if g[r][c] != '#' {
					continue
				}
				px := x + c*cell + slant*(3-r)
				py := y0 + r*cell
				for yy := 0; yy < cell-1; yy++ {
					for xx := 0; xx < cell-1; xx++ {
						// carved: dark shadow down-right, then the paint
						if p := image.Pt(px+xx+2, py+yy+2); p.In(img.Rect) {
							img.SetRGBA(p.X, p.Y, color.RGBA{25, 25, 28, 255})
						}
					}
				}
				for yy := 0; yy < cell-1; yy++ {
					for xx := 0; xx < cell-1; xx++ {
						if p := image.Pt(px+xx, py+yy); p.In(img.Rect) {
							img.SetRGBA(p.X, p.Y, ink)
						}
					}
				}
			}
		}
		x += 5*cell + 12 + rnd(6)
	}
	// moss specks over everything, so it isn't a clean picture to read by machine
	for i := 0; i < 260; i++ {
		px, py := rnd(W), rnd(H)
		if img.RGBAAt(px, py).A != 0 {
			img.SetRGBA(px, py, color.RGBA{uint8(40 + rnd(80)), uint8(90 + rnd(90)), 40, 255})
		}
	}
	var buf bytes.Buffer
	png.Encode(&buf, img)
	return buf.Bytes()
}

// ansiColors: bright red, yellow, green, cyan, magenta, white (PC color numbers)
var ansiColors = []int{12, 14, 10, 11, 13, 15}

// Lines draws the puzzle as 7 lines of colored blocks for a terminal, using the given
// function to turn a PC color number into an escape sequence.
func Lines(answer string, sgr func(int) string) []string {
	out := make([]string, 7)
	used := map[int]bool{}
	cols := make([]int, len(answer))
	for i := range answer {
		k := rnd(len(ansiColors))
		for used[k] && len(used) < len(ansiColors) {
			k = rnd(len(ansiColors))
		}
		used[k] = true
		cols[i] = ansiColors[k]
	}
	for r := 0; r < 7; r++ {
		var b strings.Builder
		for i := 0; i < len(answer); i++ {
			g := glyphs[answer[i]]
			b.WriteString(sgr(cols[i]))
			for c := 0; c < 5; c++ {
				if g[r][c] == '#' {
					b.WriteString("█")
				} else {
					b.WriteString(" ")
				}
			}
			b.WriteString("  ")
		}
		out[r] = b.String()
	}
	return out
}

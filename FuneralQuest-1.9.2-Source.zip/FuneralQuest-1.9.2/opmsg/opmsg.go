// Package opmsg keeps the notes players leave for the operator (the sysop): forgotten
// password requests and messages from the Contact form. Each is a text file in data/operator,
// named after the date and time it arrived: 2026-11-27_21-35-01.operator.msg.txt
package opmsg

import (
	"bufio"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"
)

const (
	KindPassword = "Forgotten password"
	KindContact  = "Message to the operator"
	suffix       = ".operator.msg.txt"
	maxFiles     = 2000 // refuse more than this many waiting (a flood)
	perAddrHour  = 4    // notes per address per hour
)

// Msg is one note.
type Msg struct {
	File    string    `json:"file"`
	Kind    string    `json:"kind"`
	Date    time.Time `json:"date"`
	Logon   string    `json:"logon,omitempty"`   // forgotten password: the logon name they gave
	Account string    `json:"account,omitempty"` // forgotten password: the parlor that logon belongs to
	OnFile  string    `json:"on_file,omitempty"` // forgotten password: the e-mail address on that account
	Name    string    `json:"name,omitempty"`
	Email   string    `json:"email,omitempty"` // how they asked to be reached
	From    string    `json:"from,omitempty"`  // web 1.2.3.4 / telnet 1.2.3.4
	Text    string    `json:"text"`
	Read    bool      `json:"read"`
}

// Box is the folder of notes.
type Box struct {
	Dir string

	mu     sync.Mutex
	recent map[string][]time.Time
}

func Open(dataDir string) *Box {
	return &Box{Dir: filepath.Join(dataDir, "operator"), recent: map[string][]time.Time{}}
}

func clean(s string, max int) string {
	s = strings.Map(func(r rune) rune {
		if r == '\n' || r == '\t' {
			return r
		}
		if r < 32 || r == 127 {
			return -1
		}
		return r
	}, strings.ReplaceAll(s, "\r", ""))
	s = strings.TrimSpace(s)
	if r := []rune(s); len(r) > max {
		s = string(r[:max])
	}
	return s
}

func oneLine(s string, max int) string { return strings.ReplaceAll(clean(s, max), "\n", " ") }

// Save stores a note. addr is the sender's address (for the per-address limit).
func (b *Box) Save(m Msg, addr string) (Msg, error) {
	b.mu.Lock()
	defer b.mu.Unlock()
	now := time.Now()
	var keep []time.Time
	for _, t := range b.recent[addr] {
		if now.Sub(t) < time.Hour {
			keep = append(keep, t)
		}
	}
	if len(keep) >= perAddrHour {
		return m, errors.New("You've left enough notes for one hour.  The sysop will get to them.")
	}
	if err := os.MkdirAll(b.Dir, 0o700); err != nil {
		return m, err
	}
	if ents, _ := os.ReadDir(b.Dir); len(ents) > maxFiles {
		return m, errors.New("The sysop's desk is buried in notes right now.  Try again later.")
	}
	b.recent[addr] = append(keep, now)
	m.Date = now
	m.Logon, m.Account, m.OnFile = oneLine(m.Logon, 40), oneLine(m.Account, 80), oneLine(m.OnFile, 100)
	m.Name, m.Email, m.From = oneLine(m.Name, 60), oneLine(m.Email, 120), oneLine(m.From, 80)
	m.Text = clean(m.Text, 2000)
	var sb strings.Builder
	sb.WriteString("Funeral Quest: a note for the operator\r\n")
	field := func(k, v string) {
		if v != "" {
			sb.WriteString(k + ": " + v + "\r\n")
		}
	}
	field("Kind", m.Kind)
	field("Date", now.Format("2006-01-02 15:04:05"))
	field("Logon name", m.Logon)
	field("Account", m.Account)
	field("E-mail on file", m.OnFile)
	field("Name", m.Name)
	field("Contact", m.Email)
	field("From", m.From)
	sb.WriteString("---\r\n")
	sb.WriteString(strings.ReplaceAll(m.Text, "\n", "\r\n") + "\r\n")
	base := now.Format("2006-01-02_15-04-05")
	name := base + suffix
	for i := 2; fileExists(filepath.Join(b.Dir, name)); i++ {
		name = fmt.Sprintf("%s_%d%s", base, i, suffix)
	}
	m.File = name
	return m, os.WriteFile(filepath.Join(b.Dir, name), []byte(sb.String()), 0o600)
}

func fileExists(p string) bool { _, err := os.Stat(p); return err == nil }

func (b *Box) readSet() map[string]bool {
	out := map[string]bool{}
	f, err := os.Open(filepath.Join(b.Dir, "read.txt"))
	if err != nil {
		return out
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		if t := strings.TrimSpace(sc.Text()); t != "" {
			out[t] = true
		}
	}
	return out
}

func (b *Box) writeSet(set map[string]bool) error {
	var names []string
	for n := range set {
		if fileExists(filepath.Join(b.Dir, n)) {
			names = append(names, n)
		}
	}
	sort.Strings(names)
	return os.WriteFile(filepath.Join(b.Dir, "read.txt"), []byte(strings.Join(names, "\n")+"\n"), 0o600)
}

func parse(name string, data []byte) Msg {
	m := Msg{File: name}
	text := strings.ReplaceAll(string(data), "\r\n", "\n")
	head, body, _ := strings.Cut(text, "\n---\n")
	m.Text = strings.TrimRight(body, "\n")
	for _, line := range strings.Split(head, "\n") {
		k, v, ok := strings.Cut(line, ": ")
		if !ok {
			continue
		}
		switch k {
		case "Kind":
			m.Kind = v
		case "Date":
			m.Date, _ = time.ParseInLocation("2006-01-02 15:04:05", v, time.Local)
		case "Logon name":
			m.Logon = v
		case "Account":
			m.Account = v
		case "E-mail on file":
			m.OnFile = v
		case "Name":
			m.Name = v
		case "Contact":
			m.Email = v
		case "From":
			m.From = v
		}
	}
	return m
}

// List returns every note, newest first.
func (b *Box) List() []Msg {
	ents, _ := os.ReadDir(b.Dir)
	read := b.readSet()
	var out []Msg
	for _, e := range ents {
		if e.IsDir() || !strings.HasSuffix(e.Name(), suffix) {
			continue
		}
		data, err := os.ReadFile(filepath.Join(b.Dir, e.Name()))
		if err != nil {
			continue
		}
		m := parse(e.Name(), data)
		m.Read = read[e.Name()]
		out = append(out, m)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].File > out[j].File })
	return out
}

// Unread lists the notes not read yet, oldest first.
func (b *Box) Unread() []Msg {
	var out []Msg
	all := b.List()
	for i := len(all) - 1; i >= 0; i-- {
		if !all[i].Read {
			out = append(out, all[i])
		}
	}
	return out
}

func validName(n string) bool {
	return strings.HasSuffix(n, suffix) && !strings.ContainsAny(n, `/\`) && !strings.HasPrefix(n, ".")
}

// MarkRead marks notes read.
func (b *Box) MarkRead(names ...string) error {
	b.mu.Lock()
	defer b.mu.Unlock()
	set := b.readSet()
	for _, n := range names {
		if validName(n) {
			set[n] = true
		}
	}
	return b.writeSet(set)
}

// Delete removes a note.
func (b *Box) Delete(name string) error {
	if !validName(name) {
		return errors.New("no such note")
	}
	b.mu.Lock()
	defer b.mu.Unlock()
	if err := os.Remove(filepath.Join(b.Dir, name)); err != nil {
		return errors.New("no such note")
	}
	return b.writeSet(b.readSet())
}

// Format writes a note out as plain text (for the console).
func Format(m Msg) string {
	var sb strings.Builder
	fmt.Fprintf(&sb, "=== %s  (%s)\n", m.Kind, m.Date.Format("Jan 2 15:04"))
	line := func(k, v string) {
		if v != "" {
			fmt.Fprintf(&sb, "  %-15s %s\n", k+":", v)
		}
	}
	line("Logon name", m.Logon)
	line("Account", m.Account)
	line("E-mail on file", m.OnFile)
	line("Name", m.Name)
	line("Contact", m.Email)
	line("From", m.From)
	for _, l := range strings.Split(m.Text, "\n") {
		sb.WriteString("  | " + l + "\n")
	}
	sb.WriteString("  File: data/operator/" + m.File + "\n")
	return sb.String()
}

package opmsg

import (
	"strings"
	"testing"
)

func TestBox(t *testing.T) {
	b := Open(t.TempDir())
	m, err := b.Save(Msg{Kind: KindPassword, Logon: "bob", Email: "bob@example.com", Account: "Bob (Bob's), player #3", Text: "it's me\nreally\r\n\x07"}, "1.2.3.4")
	if err != nil || !strings.HasSuffix(m.File, ".operator.msg.txt") {
		t.Fatalf("save: %v %q", err, m.File)
	}
	b.Save(Msg{Kind: KindContact, Name: "Ann", Email: "ann@example.com", Text: "hi"}, "1.2.3.4")
	l := b.List()
	if len(l) != 2 || len(b.Unread()) != 2 {
		t.Fatalf("list %+v", l)
	}
	got := b.Unread()[0]
	if got.Logon != "bob" || got.Text != "it's me\nreally" || got.Kind != KindPassword {
		t.Fatalf("parsed %+v", got)
	}
	b.MarkRead(got.File)
	if len(b.Unread()) != 1 {
		t.Fatal("mark read")
	}
	if b.Delete("../../etc/passwd") == nil {
		t.Fatal("deleted outside")
	}
	if err := b.Delete(got.File); err != nil || len(b.List()) != 1 {
		t.Fatal("delete")
	}
	b.Save(Msg{Kind: KindContact, Text: "x"}, "1.2.3.4")
	b.Save(Msg{Kind: KindContact, Text: "x"}, "1.2.3.4")
	if _, err := b.Save(Msg{Kind: KindContact, Text: "x"}, "1.2.3.4"); err == nil {
		t.Fatal("no per-address limit")
	}
	if !strings.Contains(Format(l[0]), "===") {
		t.Fatal("format")
	}
}

package fqnet

// Passing messages on for towns that can't reach each other.
//
// Two towns that both connect out only (behind firewalls, or door-only BBSes) can never reach
// each other directly. If both are linked to a town that can be reached (a "hub"), that town
// passes their messages on: the sender posts its message to the hub (/fed/via), the hub hands
// it to the other town the next time that town fetches (the same waiting fetch raids use, see
// relay.go) and carries the answer back. If the other town has a working address of its own,
// the hub simply forwards the message there.
//
// The hub can't read anything it couldn't already see, and it can't fake or change anything:
// the message keeps the sender's own signature and the answer keeps the receiver's, both
// bound to the sender's one-time nonce. The receiver checks the message exactly as if it had
// arrived directly (same handler, same replay check), and the sender checks the answer.
//
// Hubs introduce the outbound-only towns that fetch from them to their other linked towns
// (marked "through <hub>"), so every town gets linked with every other and every parlor shows
// up everywhere. Sysops can turn passing messages on off (net_relay_off).

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"

	"funeralquest/guard"
)

// maxTunnel is the biggest message passed on (it travels inside another message).
const maxTunnel = maxBody / 2

// what may be passed on: linking, syncing and raid steps
var tunnelPaths = map[string]bool{"/fed/hello": true, "/fed/sync": true, "/fed/raid": true}

type tunnelReq struct {
	Path string `json:"path"`
	Body []byte `json:"body"`
	Sig  string `json:"sig"`
}

type viaMsg struct {
	envelope
	Target string `json:"target"`
	tunnelReq
}

type viaAns struct {
	envelope
	Body []byte `json:"body"`
	Sig  string `json:"sig"`
}

// reachable says whether we have a way to send to a linked town: its own address, or a
// linked town that passes messages on to it.
func reachable(p Peer) bool { return p.URL != "" || p.Via != "" }

// send posts a signed message to a linked town: directly, or through the town in p.Via.
func (n *Net) send(p Peer, path, expect string, req any, env envelope) (json.RawMessage, error) {
	if p.URL != "" {
		rb, _, err := n.post(p.URL, path, expect, req, env)
		return rb, err
	}
	if p.Via != "" {
		return n.viaPost(p, path, expect, req, env)
	}
	return nil, errors.New(p.Name + " can't be reached from here")
}

func (n *Net) viaPost(p Peer, path, expect string, req any, env envelope) (json.RawMessage, error) {
	hub := n.view().peer(p.Via)
	if hub == nil || hub.State != Linked || hub.URL == "" {
		return nil, fmt.Errorf("can't reach %s: the town that passed messages to it isn't linked any more", p.Name)
	}
	body, _ := json.Marshal(req)
	if len(body) > maxTunnel {
		return nil, errors.New("message too big to pass on")
	}
	m := viaMsg{envelope: newEnvelope(n.ID, hub.ID), Target: p.ID,
		tunnelReq: tunnelReq{Path: path, Body: body, Sig: n.sign([]byte("FQNET1"), []byte(path), body)}}
	rb, _, err := n.postWith(n.long, hub.URL, "/fed/via", hub.ID, m, m.envelope)
	if err != nil {
		return nil, fmt.Errorf("through %s: %v", hub.Name, err)
	}
	var a viaAns
	if json.Unmarshal(rb, &a) != nil || len(a.Body) == 0 {
		return nil, fmt.Errorf("through %s: bad answer", hub.Name)
	}
	if expect == "" {
		expect = p.ID
	}
	_, ok, err := n.checkAnswer(a.Body, a.Sig, path, env.Nonce, expect)
	if !ok {
		return nil, err
	}
	return a.Body, err
}

// viaIn passes a message from one linked town on to another.
func (n *Net) viaIn(ctx context.Context, env envelope, body []byte, ip string, gd *guard.Guard) (any, error) {
	c := n.cfg()
	if c.NetRelayOff {
		return nil, errors.New(c.ServerName + " doesn't pass on messages for other towns")
	}
	var m viaMsg
	if json.Unmarshal(body, &m) != nil || !tunnelPaths[m.Path] || len(m.Body) == 0 || len(m.Body) > maxTunnel {
		return nil, errors.New("bad message")
	}
	st := n.view()
	from, to := st.peer(env.From), st.peer(m.Target)
	if from == nil || from.State != Linked {
		return nil, fmt.Errorf("not accepted by %s yet", c.ServerName)
	}
	if to == nil || to.State != Linked || !to.TheyOK || to.ID == from.ID {
		return nil, fmt.Errorf("%s isn't linked to that town", c.ServerName)
	}
	// only pass on what the asking town really wrote, addressed to that town
	var inner envelope
	if json.Unmarshal(m.Body, &inner) != nil || inner.From != env.From || inner.To != to.ID ||
		!verify(env.From, m.Sig, []byte("FQNET1"), []byte(m.Path), m.Body) {
		if gd != nil {
			gd.Strike(ip, "bad message to pass on", 2)
		}
		return nil, errors.New("bad message")
	}
	switch {
	case RelayActive(*to):
		done, err := n.relayWait(to, relayJob{Tun: &m.tunnelReq})
		if err != nil {
			return nil, err
		}
		if done.Err != "" {
			return nil, errors.New(done.Err)
		}
		return viaAns{Body: done.TunBody, Sig: done.TunSig}, nil
	case to.URL != "":
		ab, asig, err := n.forward(ctx, to.URL, m.Path, m.Body, m.Sig)
		if err != nil {
			return nil, fmt.Errorf("%s couldn't reach %s: %v", c.ServerName, to.Name, err)
		}
		return viaAns{Body: ab, Sig: asig}, nil
	}
	return nil, fmt.Errorf("%s isn't online right now", to.Name)
}

// forward sends a message, as signed by the town that wrote it, to a town's own address.
func (n *Net) forward(ctx context.Context, base, path string, body []byte, sig string) ([]byte, string, error) {
	client := n.client
	var learned string
	if len(base) > 8 && base[:8] == "https://" {
		client = n.httpsClient(base, client.Timeout, &learned)
	}
	hr, err := http.NewRequestWithContext(ctx, "POST", base+path, bytes.NewReader(body))
	if err != nil {
		return nil, "", err
	}
	hr.Header.Set("Content-Type", "application/json")
	hr.Header.Set("Cache-Control", "no-transform")
	hr.Header.Set("X-FQ-Sig", sig)
	resp, err := client.Do(hr)
	if err != nil {
		return nil, "", err
	}
	defer resp.Body.Close()
	rb, err := io.ReadAll(io.LimitReader(resp.Body, maxTunnel+1))
	if err != nil || len(rb) > maxTunnel || !json.Valid(rb) {
		return nil, "", errors.New("bad answer")
	}
	return rb, resp.Header.Get("X-FQ-Sig"), nil
}

// processTunnel runs a message another town passed on to us (fetched from the hub hubID),
// exactly as if it had arrived directly, and returns the signed answer.
func (n *Net) processTunnel(hubID string, t *tunnelReq) (body []byte, sig, errText string) {
	var fn handlerFn
	switch t.Path {
	case "/fed/hello":
		fn = n.hello
	case "/fed/sync":
		fn = n.syncIn
	case "/fed/raid":
		fn = n.raidIn
	default:
		return nil, "", "not passed on"
	}
	code, text, out, osig := n.process(t.Path, t.Body, t.Sig, "via "+hubID, nil, fn)
	if code != 0 {
		return nil, "", text
	}
	// remember the way back to the town that wrote it (it has no address of its own)
	var env envelope
	if json.Unmarshal(t.Body, &env) == nil && env.From != "" {
		n.tx(func(st *state) error {
			if p := st.peer(env.From); p != nil && p.URL == "" && p.Via != hubID {
				p.Via = hubID
			}
			return nil
		})
	}
	return out, osig, ""
}

func newJobID() string {
	b := make([]byte, 12)
	rand.Read(b)
	return hex.EncodeToString(b)
}

// relayHub says which of our hubs passes messages to p, for the sysop pages.
func (n *Net) relayHub(p Peer) string {
	if p.URL != "" || p.Via == "" {
		return ""
	}
	if h := n.view().peer(p.Via); h != nil {
		return h.Name
	}
	return ""
}

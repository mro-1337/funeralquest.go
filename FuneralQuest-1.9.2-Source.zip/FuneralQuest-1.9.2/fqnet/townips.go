package fqnet

// The addresses linked towns use, so the sysop's ban rules never lock a linked town out. A
// sysop who mistypes their password on a friend's web game gets their address banned there;
// without this, their own game server (often on the same address) couldn't reach that town
// any more either. Addresses come from two places: where signed messages from a linked town
// actually arrive from, and what the host name in its address resolves to.

import (
	"context"
	"net"
	"net/netip"
	"net/url"
	"sync"
	"time"
)

type townIPs struct {
	mu   sync.Mutex
	m    map[string]string // address -> town name
	at   time.Time
	busy bool
}

func canonIP(ip string) string {
	a, err := netip.ParseAddr(ip)
	if err != nil {
		return ""
	}
	return a.Unmap().String()
}

// TownAt says which linked town uses an address ("" = none).
func (n *Net) TownAt(ip string) string {
	key := canonIP(ip)
	if key == "" {
		return ""
	}
	t := &n.tips
	t.mu.Lock()
	defer t.mu.Unlock()
	if time.Since(t.at) > 10*time.Minute && !t.busy {
		t.busy = true
		go n.RefreshTownIPs()
	}
	return t.m[key]
}

// RefreshTownIPs looks up the addresses of every linked town again.
func (n *Net) RefreshTownIPs() {
	m := map[string]string{}
	for _, p := range n.Peers() {
		if p.State != Linked {
			continue
		}
		for _, ip := range p.IPs {
			m[ip] = p.Name
		}
		if p.URL == "" {
			continue
		}
		u, err := url.Parse(p.URL)
		if err != nil {
			continue
		}
		host := u.Hostname()
		if k := canonIP(host); k != "" {
			m[k] = p.Name
			continue
		}
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		addrs, _ := net.DefaultResolver.LookupNetIP(ctx, "ip", host)
		cancel()
		for _, a := range addrs {
			m[a.Unmap().String()] = p.Name
		}
	}
	t := &n.tips
	t.mu.Lock()
	t.m, t.at, t.busy = m, time.Now(), false
	t.mu.Unlock()
}

// noteTownIP remembers the address a verified message from a linked town came from.
func (n *Net) noteTownIP(id, ip string) {
	key := canonIP(ip)
	if key == "" {
		return
	}
	p := n.view().peer(id)
	if p == nil || p.State != Linked {
		return
	}
	for _, have := range p.IPs {
		if have == key {
			return
		}
	}
	n.tx(func(st *state) error {
		if p := st.peer(id); p != nil {
			p.IPs = append(p.IPs, key)
			if len(p.IPs) > 4 {
				p.IPs = p.IPs[len(p.IPs)-4:]
			}
		}
		return nil
	})
	t := &n.tips
	t.mu.Lock()
	if t.m == nil {
		t.m = map[string]string{}
	}
	t.m[key] = p.Name
	t.mu.Unlock()
}

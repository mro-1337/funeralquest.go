package fqnet

// Night raids (see engine/night.go): raids planned against a town that can't be reached right
// now. The raider's town keeps each plan as a file in data/net/night/<town>/ (a door process
// may plan it while the web or net process does the syncing) and hands the plans over when
// that town next checks in. The town carries them out and sends the results back in a later
// sync; the raider's town then gives the raider the spoils and deletes the plan.

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"funeralquest/engine"
)

type nightWire struct {
	Night     []engine.NightRaid   `json:"night,omitempty"`      // plans against your players
	NightDone []engine.NightResult `json:"night_done,omitempty"` // how your plans went
}

const maxNight = 10 // plans or results per sync

func (n *Net) nightDir(peer string) string { return filepath.Join(n.Dir, "night", peer) }

// QueueNightRaid keeps a planned raid until its town checks in. It's called with the world
// lock held, so it must not read the world (the game already checked that raids are on).
func (n *Net) QueueNightRaid(p engine.NightPending) error {
	pp := n.load().peer(p.Peer)
	if pp == nil || pp.State != Linked {
		return errors.New("that town isn't linked any more")
	}
	dir := n.nightDir(p.Peer)
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return err
	}
	b, _ := json.Marshal(p)
	tmp := filepath.Join(dir, p.ID+".tmp")
	if err := os.WriteFile(tmp, b, 0o600); err != nil {
		return err
	}
	n.Kick()
	return os.Rename(tmp, filepath.Join(dir, p.ID+".json"))
}

func (n *Net) nightPending(peer string) []engine.NightPending {
	m, _ := filepath.Glob(filepath.Join(n.nightDir(peer), "*.json"))
	var out []engine.NightPending
	for _, f := range m {
		b, err := os.ReadFile(f)
		var p engine.NightPending
		if err == nil && json.Unmarshal(b, &p) == nil && p.ID != "" {
			out = append(out, p)
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Created < out[j].Created })
	return out
}

// nightFor lists our plans against that town, for its sync.
func (n *Net) nightFor(peer string) []engine.NightRaid {
	var out []engine.NightRaid
	for _, p := range n.nightPending(peer) {
		if len(out) < maxNight && time.Since(time.Unix(p.Created, 0)) < engine.NightRaidDays*24*time.Hour {
			out = append(out, p.NightRaid)
		}
	}
	return out
}

// nightResults gives our raiders the results that town sent back. Only plans we actually
// sent to that town count; anything else is ignored.
func (n *Net) nightResults(peer string, rs []engine.NightResult) {
	for i, r := range rs {
		if i >= maxNight || strings.ContainsAny(r.ID, `/\.`) || r.ID == "" {
			continue
		}
		f := filepath.Join(n.nightDir(peer), r.ID+".json")
		b, err := os.ReadFile(f)
		var p engine.NightPending
		if err != nil || json.Unmarshal(b, &p) != nil || p.Peer != peer {
			continue
		}
		if os.Remove(f) != nil { // someone else is handling it
			continue
		}
		n.G.Store.Tx(func(w *engine.World) error { n.G.NightRaidDone(w, p, r); return nil })
	}
}

// nightSweep calls off plans nobody picked up in time (and pays the raiders back).
func (n *Net) nightSweep() {
	dirs, _ := filepath.Glob(filepath.Join(n.Dir, "night", "*"))
	for _, d := range dirs {
		peer := filepath.Base(d)
		for _, p := range n.nightPending(peer) {
			if time.Since(time.Unix(p.Created, 0)) < engine.NightRaidDays*24*time.Hour {
				continue
			}
			if os.Remove(filepath.Join(d, p.ID+".json")) == nil {
				n.G.Store.Tx(func(w *engine.World) error {
					n.G.NightRaidDone(w, p, engine.NightResult{ID: p.ID, Refused: "expired"})
					return nil
				})
			}
		}
	}
}

// nightIn carries out plans a linked town made against our players (each only once) and
// keeps the results to send back.
func (n *Net) nightIn(peer, town string, plans []engine.NightRaid) {
	if len(plans) == 0 {
		return
	}
	n.nightMu.Lock()
	defer n.nightMu.Unlock()
	seen := map[string]bool{}
	for _, id := range n.load().NightSeen[peer] {
		seen[id] = true
	}
	var res []engine.NightResult
	var ids []string
	for i, q := range plans {
		if i >= maxNight || q.ID == "" || len(q.ID) > 64 || seen[q.ID] {
			continue
		}
		seen[q.ID] = true
		ids = append(ids, q.ID)
		var r engine.NightResult
		n.G.Store.Tx(func(w *engine.World) error {
			r = n.G.DoNightRaid(w, peer, town, q)
			return nil
		})
		res = append(res, r)
	}
	if len(ids) == 0 {
		return
	}
	n.tx(func(st *state) error {
		if st.NightSeen == nil {
			st.NightSeen = map[string][]string{}
		}
		if st.NightOut == nil {
			st.NightOut = map[string][]engine.NightResult{}
		}
		s := append(st.NightSeen[peer], ids...)
		if len(s) > 300 {
			s = s[len(s)-300:]
		}
		st.NightSeen[peer] = s
		st.NightOut[peer] = append(st.NightOut[peer], res...)
		return nil
	})
	n.Kick() // send the results back soon
}

// nightTake takes up to maxNight results waiting for that town.
func (n *Net) nightTake(peer string) []engine.NightResult {
	var out []engine.NightResult
	n.tx(func(st *state) error {
		q := st.NightOut[peer]
		k := min(len(q), maxNight)
		out = append(out, q[:k]...)
		if k > 0 {
			st.NightOut[peer] = q[k:]
		}
		return nil
	})
	return out
}

// nightPut puts results back when a sync failed, so they go next time.
func (n *Net) nightPut(peer string, rs []engine.NightResult) {
	if len(rs) == 0 {
		return
	}
	n.tx(func(st *state) error {
		if st.NightOut == nil {
			st.NightOut = map[string][]engine.NightResult{}
		}
		st.NightOut[peer] = append(rs, st.NightOut[peer]...)
		return nil
	})
}

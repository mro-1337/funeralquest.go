package fqnet

// Raids into towns that can't be reached ("outbound only").
//
// Nobody can connect to an outbound-only town, so it fetches its raid steps instead. It keeps
// a waiting request open on every town it's linked to (/fed/jobs). When a player in one of
// those towns raids it, that town's server queues the step; the waiting request returns it at
// once. The outbound-only town referees the step with its own rules on its own player, exactly
// as if the step had been sent to it, and sends the result back (/fed/jobdone). The attacker's
// server is waiting for that result.
//
// The queue is a folder of small files (data/net/relay/<town>/), because the attacker may be
// playing in a door or telnet process while the web or network process answers the fetches.
// Everything that crosses the network is signed as usual.

import (
	"context"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"funeralquest/engine"
)

const (
	relayWait = 20 * time.Second // how long a raid step waits for an outbound-only town to answer
	jobsHold  = 25 * time.Second // how long a fetch is held open waiting for steps
)

type relayJob struct {
	ID  string         `json:"id"`
	Req engine.RaidReq `json:"req"`
	Tun *tunnelReq     `json:"tun,omitempty"` // a message another town passes on through us (via.go)
}

type jobsMsg struct {
	envelope
}

type jobsAns struct {
	envelope
	Jobs []relayJob `json:"jobs"`
}

type jobDoneMsg struct {
	envelope
	ID      string         `json:"id"`
	Ans     engine.RaidAns `json:"ans"`
	Err     string         `json:"err,omitempty"`
	TunBody []byte         `json:"tun_body,omitempty"` // the signed answer to a passed-on message
	TunSig  string         `json:"tun_sig,omitempty"`
}

func (n *Net) relayDir(peer string) string { return filepath.Join(n.Dir, "relay", peer) }

// RelayActive says whether an outbound-only town has been fetching its raid steps from us
// lately, so raids into it can go through.
func RelayActive(p Peer) bool { return !p.RelayAt.IsZero() && time.Since(p.RelayAt) < 2*time.Minute }

// relayRaid queues a raid step for an outbound-only town and waits for its answer.
func (n *Net) relayRaid(p *Peer, req engine.RaidReq) (engine.RaidAns, error) {
	done, err := n.relayWait(p, relayJob{Req: req})
	if err != nil {
		return engine.RaidAns{}, err
	}
	if done.Err != "" {
		return engine.RaidAns{}, errors.New(done.Err)
	}
	return done.Ans, nil
}

// relayWait queues a job for an outbound-only town and waits for its answer.
func (n *Net) relayWait(p *Peer, job relayJob) (jobDoneMsg, error) {
	dir := n.relayDir(p.ID)
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return jobDoneMsg{}, err
	}
	id := newJobID()
	job.ID = id
	data, _ := json.Marshal(job)
	tmp := filepath.Join(dir, id+".tmp")
	if err := os.WriteFile(tmp, data, 0o600); err != nil {
		return jobDoneMsg{}, err
	}
	os.Rename(tmp, filepath.Join(dir, id+".req"))
	defer func() {
		for _, ext := range []string{".req", ".sent", ".ans"} {
			os.Remove(filepath.Join(dir, id+ext))
		}
	}()
	deadline := time.Now().Add(relayWait)
	for time.Now().Before(deadline) {
		if b, err := os.ReadFile(filepath.Join(dir, id+".ans")); err == nil {
			var done jobDoneMsg
			if json.Unmarshal(b, &done) != nil {
				return jobDoneMsg{}, errors.New("bad answer")
			}
			return done, nil
		}
		time.Sleep(40 * time.Millisecond)
	}
	return jobDoneMsg{}, errors.New(p.Name + " didn't answer (its server connects out only and may be offline)")
}

// jobsIn holds a fetch from an outbound-only town until a raid step is queued for it.
func (n *Net) jobsIn(ctx context.Context, env envelope) (any, error) {
	p := n.view().peer(env.From)
	if p == nil || p.State != Linked {
		return nil, errors.New("not accepted by " + n.cfg().ServerName + " yet")
	}
	if time.Since(p.RelayAt) > 20*time.Second {
		n.tx(func(st *state) error {
			if pp := st.peer(env.From); pp != nil {
				pp.RelayAt = time.Now()
			}
			return nil
		})
	}
	dir := n.relayDir(env.From)
	os.MkdirAll(dir, 0o700)
	deadline := time.Now().Add(jobsHold)
	for {
		if jobs := takeJobs(dir); len(jobs) > 0 {
			return jobsAns{Jobs: jobs}, nil
		}
		if time.Now().After(deadline) {
			return jobsAns{}, nil
		}
		select {
		case <-ctx.Done():
			return nil, errors.New("gone")
		case <-time.After(60 * time.Millisecond):
		}
	}
}

// takeJobs hands out queued steps (each once) and clears out old leftovers.
func takeJobs(dir string) []relayJob {
	ents, _ := os.ReadDir(dir)
	sort.Slice(ents, func(i, j int) bool { return ents[i].Name() < ents[j].Name() })
	var jobs []relayJob
	for _, e := range ents {
		name := e.Name()
		info, err := e.Info()
		if err == nil && time.Since(info.ModTime()) > 2*relayWait {
			os.Remove(filepath.Join(dir, name))
			continue
		}
		if !strings.HasSuffix(name, ".req") || len(jobs) >= 10 {
			continue
		}
		id := strings.TrimSuffix(name, ".req")
		b, err := os.ReadFile(filepath.Join(dir, name))
		if err != nil {
			continue
		}
		var j relayJob
		if json.Unmarshal(b, &j) != nil || j.ID != id {
			continue
		}
		if os.Rename(filepath.Join(dir, name), filepath.Join(dir, id+".sent")) == nil {
			jobs = append(jobs, j)
		}
	}
	return jobs
}

// jobDoneIn takes the answer to a step we handed out.
func (n *Net) jobDoneIn(env envelope, body []byte) (any, error) {
	var m jobDoneMsg
	if json.Unmarshal(body, &m) != nil || len(m.ID) != 24 || strings.Trim(m.ID, "0123456789abcdef") != "" {
		return nil, errors.New("bad answer")
	}
	dir := n.relayDir(env.From)
	if _, err := os.Stat(filepath.Join(dir, m.ID+".sent")); err != nil {
		return nil, errors.New("no such step (it may have timed out)")
	}
	b, _ := json.Marshal(m)
	tmp := filepath.Join(dir, m.ID+".anstmp")
	if err := os.WriteFile(tmp, b, 0o600); err != nil {
		return nil, err
	}
	return map[string]any{}, os.Rename(tmp, filepath.Join(dir, m.ID+".ans"))
}

// jobsLoop runs on an outbound-only town: it fetches raid steps from one linked town,
// referees them and sends back the results.
func (n *Net) jobsLoop(ctx context.Context, id string) {
	fails := 0
	for ctx.Err() == nil {
		p := n.load().peer(id)
		if p == nil || p.State != Linked || p.URL == "" {
			return
		}
		msg := jobsMsg{newEnvelope(n.ID, id)}
		rb, _, err := n.postWith(n.long, p.URL, "/fed/jobs", id, msg, msg.envelope)
		var ans jobsAns
		if err == nil {
			err = json.Unmarshal(rb, &ans)
		}
		if err != nil {
			fails++
			select {
			case <-ctx.Done():
			case <-time.After(loopWait(fails)):
			}
			continue
		}
		fails = 0
		for _, j := range ans.Jobs {
			if j.Tun != nil {
				// a message another town passes on to us through this one
				done := jobDoneMsg{envelope: newEnvelope(n.ID, id), ID: j.ID}
				done.TunBody, done.TunSig, done.Err = n.processTunnel(id, j.Tun)
				n.post(p.URL, "/fed/jobdone", id, done, done.envelope)
				continue
			}
			out, rerr := n.refereeRaid(id, j.Req)
			if ra, ok := out.(raidAns); ok && ra.Ans.Refused == "unknown" && rerr == nil {
				// the raider is new since our last sync: fetch their players and try again
				if n.SyncPeer(id) == nil {
					out, rerr = n.refereeRaid(id, j.Req)
				}
			}
			done := jobDoneMsg{envelope: newEnvelope(n.ID, id), ID: j.ID}
			if rerr != nil {
				done.Err = rerr.Error()
			} else if ra, ok := out.(raidAns); ok {
				done.Ans = ra.Ans
			}
			n.post(p.URL, "/fed/jobdone", id, done, done.envelope)
		}
	}
}

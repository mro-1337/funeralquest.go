package fqnet_test

import (
	"funeralquest/fqnet"
	"testing"
	"time"
)

// A door-only BBS (no fq net running) checks in when callers come and go.
func TestCheckIn(t *testing.T) {
	A := newTown(t, "Deathville")
	B := newTown(t, "Gravesend")
	B.a.SetSettings(map[string]string{"net_public_url": ""})
	A.a.SetSettings(map[string]string{"net_auto_accept": "1"})
	A.player(t, "Alice")
	B.player(t, "Bobby")
	if _, err := B.a.Net.AddPeer(A.srv.URL); err != nil {
		t.Fatal(err)
	}
	if !B.a.Net.HasLinks() {
		t.Fatal("no links")
	}
	n, ran := B.a.Net.CheckIn(10 * time.Second)
	if !ran || n != 1 {
		t.Fatalf("check-in: reached %d, ran %v", n, ran)
	}
	if !hasRemote(A, "Bobby") || !hasRemote(B, "Alice") {
		t.Fatal("players not exchanged")
	}
	// A now knows the address Gravesend's messages come from, and never bans it
	if got := A.a.Net.TownAt("127.0.0.1"); got != "Gravesend" {
		t.Fatalf("TownAt = %q", got)
	}
	B.a.Net.RefreshTownIPs() // Deathville's address comes from its URL
	if got := B.a.Net.TownAt("127.0.0.1"); got != "Deathville" {
		t.Fatalf("B's TownAt = %q", got)
	}
	// with the network program running, a check-in leaves it alone
	go B.a.Net.Run()
	time.Sleep(300 * time.Millisecond)
	other := B.a.Net // same program: allowed
	if _, ran := other.CheckIn(time.Second); !ran {
		t.Fatal("the program running the network should be able to check in")
	}
}

func TestRetryWait(t *testing.T) {
	want := []time.Duration{0, 2 * time.Minute, 4 * time.Minute, 8 * time.Minute, 15 * time.Minute, 30 * time.Minute, time.Hour, time.Hour}
	for i, w := range want {
		if got := fqnet.RetryWait(i); got != w {
			t.Errorf("RetryWait(%d) = %v, want %v", i, got, w)
		}
	}
}

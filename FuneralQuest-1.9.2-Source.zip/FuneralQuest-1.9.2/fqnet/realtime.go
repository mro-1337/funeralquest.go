package fqnet

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"sort"
	"strings"
	"time"

	"funeralquest/engine"
)

// ------------------------------------------------------------------ real-time chat
//
// Every linked server keeps one "listen" request open on each of its links. The other
// server holds it until one of its players says something in the Cafe (or 25 seconds pass),
// then answers with the new lines, and the listener asks again straight away. So chat goes
// from one town to another in a fraction of a second. It also works when only one side can
// reach the other: the side that can't be reached still hears everything it listens to, and
// its own lines go out on the regular sync push.

type listenMsg struct {
	envelope
	Since int `json:"since"` // newest of their lines we already have
}

type listenAns struct {
	envelope
	Chat []wireChat `json:"chat"`
	Top  int        `json:"top"`
	Off  bool       `json:"off,omitempty"`
}

const listenHold = 25 * time.Second

// watchChat notices new chat lines (from this process or the door nodes) within 0.15 s by
// watching chat.seq, wakes up the listen requests waiting on us, and pushes to linked towns.
func (n *Net) watchChat() {
	last := n.G.Store.ChatSeq()
	for {
		time.Sleep(150 * time.Millisecond)
		seq := n.G.Store.ChatSeq()
		if seq == last {
			continue
		}
		last = seq
		n.sigMu.Lock()
		close(n.sig)
		n.sig = make(chan struct{})
		n.sigMu.Unlock()
		n.Kick()
	}
}

// startWatch starts the chat watcher once per process (the runner, or whoever answers listens).
func (n *Net) startWatch() { n.watchOnce.Do(func() { go n.watchChat() }) }

func (n *Net) chatSignal() <-chan struct{} {
	n.startWatch()
	n.sigMu.Lock()
	defer n.sigMu.Unlock()
	return n.sig
}

// localSharedSince returns this town's public cafe lines newer than since.
func (n *Net) localSharedSince(since int) (lines []wireChat, top int) {
	n.G.Store.Read(func(w *engine.World) {
		top = w.NextChatID
		if since > top {
			since = 0 // our chat numbering started over
		}
		for _, l := range w.Chat {
			if l.ID > since && l.Share && l.Net == "" && l.To == 0 && len(lines) < maxChat {
				lines = append(lines, wireChat{l.ID, l.Text})
			}
		}
	})
	return
}

func (n *Net) listenIn(ctx context.Context, env envelope, body []byte) (any, error) {
	var m listenMsg
	if json.Unmarshal(body, &m) != nil {
		return nil, errors.New("bad listen")
	}
	p := n.view().peer(env.From)
	if p == nil || p.State != Linked {
		return nil, fmt.Errorf("not accepted by %s yet", n.cfg().ServerName)
	}
	if n.cfg().NetChatOff {
		return listenAns{Off: true}, nil
	}
	deadline := time.After(listenHold)
	for {
		sig := n.chatSignal() // take the signal before looking, so no line slips between
		lines, top := n.localSharedSince(m.Since)
		if len(lines) > 0 {
			return listenAns{Chat: lines, Top: top}, nil
		}
		select {
		case <-sig:
		case <-deadline:
			return listenAns{Top: top}, nil
		case <-ctx.Done():
			return nil, errors.New("gone")
		}
	}
}

// deliverChatLocked adds lines from a linked town to our Cafe (n.once must be held). Lines
// carry their own numbers, so lines that arrive twice (by push and by listen) appear once.
func (n *Net) deliverChatLocked(peerID, town string, lines []wireChat, top int) int {
	st := n.load()
	p := st.peer(peerID)
	if p == nil || p.State != Linked {
		return 0
	}
	recv := p.ChatRecv
	if top < recv {
		recv = 0 // their chat numbering started over (game reset)
	}
	if town == "" {
		town = p.Name
	}
	sort.Slice(lines, func(i, j int) bool { return lines[i].ID < lines[j].ID })
	var add []string
	for i, l := range lines {
		if i >= maxChat || l.ID <= recv {
			continue
		}
		recv = l.ID
		if t := engine.CleanRemote(strings.ReplaceAll(l.Text, "\n", " "), 300, true); t != "" {
			add = append(add, "`8["+town+"] "+t)
		}
	}
	if len(add) > 0 && !n.cfg().NetChatOff {
		n.G.Store.Tx(func(w *engine.World) error {
			for _, t := range add {
				w.AddNetChat(t, peerID)
			}
			return nil
		})
	}
	if recv != p.ChatRecv {
		n.tx(func(st *state) error {
			if pp := st.peer(peerID); pp != nil {
				pp.ChatRecv = recv
			}
			return nil
		})
	}
	return recv
}

// listenLoop keeps a listen request open on one linked town until ctx ends.
func (n *Net) listenLoop(ctx context.Context, id string) {
	fails := 0
	for ctx.Err() == nil {
		p := n.load().peer(id)
		if p == nil || p.State != Linked || p.URL == "" {
			return
		}
		msg := listenMsg{newEnvelope(n.ID, id), p.ChatRecv}
		rb, _, err := n.postWith(n.long, p.URL, "/fed/listen", id, msg, msg.envelope)
		var ans listenAns
		if err == nil {
			err = json.Unmarshal(rb, &ans)
		}
		if err != nil {
			// an older server without /fed/listen, or a network problem: wait and try again
			fails++
			wait := loopWait(fails)
			select {
			case <-ctx.Done():
			case <-time.After(wait):
			}
			continue
		}
		fails = 0
		if ans.Off {
			select {
			case <-ctx.Done():
			case <-time.After(time.Minute):
			}
			continue
		}
		if len(ans.Chat) > 0 {
			n.once.Lock()
			n.deliverChatLocked(id, "", ans.Chat, ans.Top)
			n.once.Unlock()
		}
	}
}

// ------------------------------------------------------------------ versions and game rules

// Diff is one game setting that's different in a linked town.
type Diff struct {
	Key    string `json:"key"`
	Label  string `json:"label"`
	Ours   string `json:"ours"`
	Theirs string `json:"theirs"`
}

// RuleDiffs lists the game settings a linked town has set differently from ours.
func RuleDiffs(ours engine.Config, p Peer) []Diff {
	if len(p.Rules) == 0 {
		return nil
	}
	var out []Diff
	mine := ours.Rules()
	for _, k := range engine.SharedSettings {
		theirs, ok := p.Rules[k]
		if !ok || theirs == mine[k] {
			continue
		}
		label := k
		if info := engine.SettingByKey(k); info != nil {
			label = info.Label
		}
		out = append(out, Diff{k, label, mine[k], theirs})
	}
	return out
}

// VersionNote says who should update, or "" when both towns run the same version.
func VersionNote(p Peer) string {
	switch {
	case p.GameVer == "" && p.LastIn.IsZero() && p.LastOK.IsZero():
		return "" // haven't heard from them yet
	case p.GameVer == "":
		return fmt.Sprintf("%s runs a version older than 1.3.0 (it doesn't report its version; you have %s). %s's sysop needs to update.", p.Name, engine.Version, p.Name)
	case engine.CompareVersions(p.GameVer, engine.Version) < 0:
		return fmt.Sprintf("%s runs an older version (%s, you have %s). %s's sysop needs to update.", p.Name, p.GameVer, engine.Version, p.Name)
	case engine.CompareVersions(p.GameVer, engine.Version) > 0:
		return fmt.Sprintf("%s runs a newer version (%s, you have %s). You need to update.", p.Name, p.GameVer, engine.Version)
	}
	return ""
}

// cleanRules keeps only the known game settings, as short plain text.
func cleanRules(in map[string]string) map[string]string {
	if len(in) == 0 {
		return nil
	}
	out := map[string]string{}
	for _, k := range engine.SharedSettings {
		if v, ok := in[k]; ok {
			out[k] = engine.CleanRemote(v, 40, false)
		}
	}
	return out
}

func cleanVersion(v string) string {
	v = engine.CleanRemote(v, 20, false)
	for _, c := range v {
		if (c < '0' || c > '9') && c != '.' {
			return ""
		}
	}
	return v
}

// noteRules stores a town's version and rules (inside a tx) and logs it when what differs changes.
func (n *Net) noteRules(p *Peer, ver string, rules map[string]string) {
	ver, rules = cleanVersion(ver), cleanRules(rules)
	if ver == "" && rules == nil {
		return
	}
	before := describe(n.cfg(), *p)
	if ver != "" {
		p.GameVer = ver
	}
	if rules != nil {
		p.Rules = rules
	}
	if after := describe(n.cfg(), *p); after != before && after != "" {
		n.Log("network: %s: %s", p.Name, after)
	}
}

// Problems is a one-line summary of version and settings differences with a town ("" if none).
func Problems(ours engine.Config, p Peer) string { return describe(ours, p) }

func describe(ours engine.Config, p Peer) string {
	var parts []string
	if v := VersionNote(p); v != "" {
		parts = append(parts, v)
	}
	if d := RuleDiffs(ours, p); len(d) > 0 {
		var s []string
		for _, x := range d {
			s = append(s, fmt.Sprintf("%s (here %s, there %s)", x.Label, x.Ours, x.Theirs))
		}
		parts = append(parts, fmt.Sprintf("%d game setting(s) differ: %s. Agree with %s's sysop which to use and change them so both towns play by the same rules.", len(d), strings.Join(s, "; "), p.Name))
	}
	return strings.Join(parts, " ")
}

// UseTheirs copies a linked town's value for the given settings (all differing ones if keys is empty).
func (n *Net) UseTheirs(a interface {
	SetSettings(map[string]string) error
}, id string, keys []string) error {
	var p *Peer
	for _, x := range n.Peers() {
		if x.ID == id {
			p = &x
		}
	}
	if p == nil {
		return errors.New("no such server")
	}
	diffs := RuleDiffs(n.cfg(), *p)
	want := map[string]bool{}
	for _, k := range keys {
		want[k] = true
	}
	kv := map[string]string{}
	for _, d := range diffs {
		if len(keys) == 0 || want[d.Key] {
			kv[d.Key] = d.Theirs
		}
	}
	if len(kv) == 0 {
		return errors.New("nothing to change")
	}
	return a.SetSettings(kv)
}

var _ = http.MethodPost

package fqnet_test

import (
	"strings"
	"testing"
	"time"

	"funeralquest/engine"
	"funeralquest/fqnet"
)

// Gravesend and Boneyard both connect out only, so they can never reach each other. Both
// link to Deathville, which can be reached. Deathville introduces them to each other and
// passes their messages on, so they link, see each other's parlors, write and raid.
func TestRelayBetweenOutboundTowns(t *testing.T) {
	H := newTown(t, "Deathville")
	O1 := newTown(t, "Gravesend")
	O2 := newTown(t, "Boneyard")
	for _, o := range []*town{O1, O2} {
		o.a.SetSettings(map[string]string{"net_public_url": ""})
	}
	H.a.SetSettings(map[string]string{"net_auto_accept": "1"})
	H.player(t, "Hank")
	gus := O1.player(t, "Gus")
	O2.player(t, "Bonnie")

	for _, o := range []*town{O1, O2} {
		if _, err := o.a.Net.AddPeer(H.srv.URL); err != nil {
			t.Fatal(err)
		}
	}
	for _, x := range []*town{H, O1, O2} {
		name := x.a.Config().ServerName
		x.a.Net.Log = func(f string, a ...any) { t.Logf(name+": "+f, a...) }
		go x.a.Net.Run()
	}

	// wait for the two outbound-only towns to find each other through Deathville
	o2ID := ""
	deadline := time.Now().Add(40 * time.Second)
	for time.Now().Before(deadline) {
		for _, p := range O1.a.Net.Peers() {
			if p.Name == "Boneyard" && p.State == fqnet.Linked && p.TheyOK {
				o2ID = p.ID
			}
		}
		if o2ID != "" && hasRemote(O1, "Bonnie") && hasRemote(O2, "Gus") {
			break
		}
		time.Sleep(200 * time.Millisecond)
	}
	if o2ID == "" {
		t.Fatalf("Gravesend never linked to Boneyard: intros %+v", O1.a.Net.Intros())
	}
	if !hasRemote(O1, "Bonnie") || !hasRemote(O2, "Gus") {
		t.Fatalf("players not shared: %+v / %+v", O1.a.Net.RemotePlayers(), O2.a.Net.RemotePlayers())
	}
	p := peerOf(O1, o2ID)
	if p.URL != "" || p.Via == "" {
		t.Fatalf("Boneyard should be reached through Deathville: %+v", p)
	}
	if r := fqnet.Reach(p); r != "" {
		t.Fatalf("Boneyard should count as reachable, got %q", r)
	}

	// a live raid step from Gravesend into Boneyard, passed on by Deathville
	ans, err := O1.a.Net.Raid(o2ID, engine.RaidReq{Op: "look", Target: "Bonnie",
		Att: engine.RaidFighter{Name: "Gus", Parlor: "Gus's Parlor"}})
	if err != nil {
		t.Fatalf("raid through Deathville: %v", err)
	}
	if ans.Refused != "" && ans.Refused != "unknown" {
		t.Logf("raid answer: %+v", ans)
	}

	// a letter from Gus to Bonnie
	if err := O1.a.Net.QueueMail(o2ID, "Bonnie", gus, "Gus", "Gus's Parlor", "Hello from behind the firewall"); err != nil {
		t.Fatal(err)
	}
	O1.a.Net.Kick()
	deadline = time.Now().Add(20 * time.Second)
	got := false
	for time.Now().Before(deadline) && !got {
		O2.a.G.View(func(w *engine.World) {
			for _, l := range w.Mail {
				got = got || strings.Contains(l.Text, "behind the firewall")
			}
		})
		time.Sleep(100 * time.Millisecond)
	}
	if !got {
		t.Fatal("letter didn't arrive through Deathville")
	}

	// with passing on turned off, Deathville refuses
	H.a.SetSettings(map[string]string{"net_relay_off": "1"})
	if _, err := O1.a.Net.Raid(o2ID, engine.RaidReq{Op: "look", Target: "Bonnie"}); err == nil || !strings.Contains(err.Error(), "doesn't pass on") {
		t.Fatalf("relay off: %v", err)
	}
}

func hasRemote(tw *town, name string) bool {
	for _, p := range tw.a.Net.RemotePlayers() {
		if p.Name == name {
			return true
		}
	}
	return false
}

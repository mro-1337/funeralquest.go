package fqnet_test

import (
	"strings"
	"testing"

	"funeralquest/engine"
)

// Gravesend can't be reached. Alice in Deathville plans night raids on Bobby there; they
// happen when Gravesend next checks in, and Alice hears how they went after the one after.
func TestNightRaidOnOutboundTown(t *testing.T) {
	A := newTown(t, "Deathville")
	B := newTown(t, "Gravesend")
	B.a.SetSettings(map[string]string{"net_public_url": ""})
	alice := A.player(t, "Alice")
	bobby := B.player(t, "Bobby")
	pa, err := B.a.Net.AddPeer(A.srv.URL)
	if err != nil {
		t.Fatal(err)
	}
	if err := A.a.Net.Accept(A.a.Net.Peers()[0].ID); err != nil {
		t.Fatal(err)
	}
	B.a.Net.SyncPeer(pa.ID)
	waitView()
	A.a.G.Store.Tx(func(w *engine.World) error {
		p := w.Player(alice)
		p.Strength, p.HPMax, p.HP, p.Exp, p.Coffins = 40, 200, 200, 3000, [3]int{0, 0, 10}
		return nil
	})
	B.a.G.Store.Tx(func(w *engine.World) error {
		p := w.Player(bobby)
		p.Exp, p.Coffins = 2000, [3]int{5, 5, 5}
		return nil
	})

	// the Look list marks Bobby for a night raid, and visiting him offers the plan
	s := A.a.G.NewSession(alice, "web")
	s.Act(engine.Action{Cmd: "main"})
	s.Act(engine.Action{Cmd: "main"})
	s.Act(engine.Action{Cmd: "comp"})
	sc := s.Act(engine.Action{Cmd: "comp", Sub: "look"})
	found := false
	for _, r := range sc.Rows.([]engine.RankRow) {
		found = found || (r.Name == "Bobby" && strings.Contains(r.Status, "night raid"))
	}
	if !found {
		t.Fatalf("Bobby isn't marked for a night raid: %+v", sc.Rows)
	}
	var ref string
	for _, rp := range A.a.Net.RemotePlayers() {
		if rp.Name == "Bobby" {
			ref = engine.NetRef(rp.Peer, rp.Name, rp.Town)
		}
	}
	sc = s.Act(engine.Action{Cmd: "xcomp", Sub: "visit", Section: ref})
	if !strings.Contains(sc.Text, "night raid") {
		t.Fatalf("visit: %s", sc.Text)
	}
	sc = s.Act(engine.Action{Cmd: "xcomp", Sub: "night_fight", Section: ref})
	if !strings.Contains(sc.Text, "sealed envelope") {
		t.Fatalf("plan: %s", sc.Text)
	}
	var mail0 int
	A.a.G.View(func(w *engine.World) { mail0 = w.MailCount(alice) })

	// Gravesend checks in: gets the plan and carries it out; next check-in sends the result
	if err := B.a.Net.SyncPeer(pa.ID); err != nil {
		t.Fatal(err)
	}
	var bob engine.Player
	B.a.G.View(func(w *engine.World) { bob = *w.Player(bobby) })
	if !bob.Police || bob.Exp >= 2000 {
		t.Fatalf("Bobby wasn't beaten: police %v exp %d", bob.Police, bob.Exp)
	}
	if err := B.a.Net.SyncPeer(pa.ID); err != nil {
		t.Fatal(err)
	}
	var al engine.Player
	var mail int
	A.a.G.View(func(w *engine.World) { al = *w.Player(alice); mail = w.MailCount(alice) })
	if mail != mail0+1 || al.Exp <= 3000 {
		t.Fatalf("Alice didn't hear back: mail %d->%d exp %d", mail0, mail, al.Exp)
	}
	// a third check-in doesn't run it again
	B.a.Net.SyncPeer(pa.ID)
	B.a.Net.SyncPeer(pa.ID)
	var bob2 engine.Player
	B.a.G.View(func(w *engine.World) { bob2 = *w.Player(bobby) })
	if bob2.Exp != bob.Exp {
		t.Fatalf("the raid ran twice: %d -> %d", bob.Exp, bob2.Exp)
	}

	// the Twins: gold paid up front
	// (compared with the gold just before: a level-up from the last raid may have paid some)
	A.a.G.Store.Tx(func(w *engine.World) error { w.Player(alice).Fights = 0; return nil })
	s.Act(engine.Action{Cmd: "comp"})
	A.a.G.View(func(w *engine.World) { al = *w.Player(alice) })
	gold0 := al.Coffins[engine.Gold]
	s.Act(engine.Action{Cmd: "xcomp", Sub: "night_arson", Section: ref})
	A.a.G.View(func(w *engine.World) { al = *w.Player(alice) })
	if gold0-al.Coffins[engine.Gold] != 6 {
		t.Fatalf("arson should cost 6 gold up front: %d -> %d", gold0, al.Coffins[engine.Gold])
	}
	B.a.Net.SyncPeer(pa.ID)
	B.a.Net.SyncPeer(pa.ID)
	A.a.G.View(func(w *engine.World) { mail = w.MailCount(alice) })
	if mail != mail0+2 {
		t.Fatalf("no letter about the fire: %d", mail)
	}
}

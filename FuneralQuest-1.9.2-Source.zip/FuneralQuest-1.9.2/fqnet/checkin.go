package fqnet

import (
	"sync"
	"sync/atomic"
	"time"
)

// CheckIn is one quick round with every linked town, for programs that don't run the network
// all the time: the BBS door (when a caller comes in and when they leave) and  fq net --once
// (run from a BBS timed event). It sends this town's players, chat, letters, news and planned
// night raids, and brings back theirs, plus night raids to carry out here. If another program
// already runs the network for this town (fq web, fq telnet or fq net), it does nothing.
// It returns how many towns it reached, and false if it left the work to another program.
func (n *Net) CheckIn(limit time.Duration) (int, bool) {
	if !n.runLock() {
		return 0, false
	}
	defer n.releaseRunLock()
	n.announce()
	n.nightSweep()
	var ok atomic.Int32
	var wg sync.WaitGroup
	for _, p := range n.Peers() {
		if p.State != Linked || !reachable(p) || backingOff(p) {
			continue
		}
		wg.Add(1)
		go func(id string) {
			defer wg.Done()
			if n.SyncPeer(id) == nil {
				ok.Add(1)
			}
		}(p.ID)
	}
	wg.Add(1)
	go func() { defer wg.Done(); n.FollowIntros() }()
	done := make(chan struct{})
	go func() { wg.Wait(); close(done) }()
	select {
	case <-done:
	case <-time.After(limit):
	}
	return int(ok.Load()), true
}

// HasLinks says whether this town is linked to any other.
func (n *Net) HasLinks() bool {
	for _, p := range n.Peers() {
		if p.State == Linked {
			return true
		}
	}
	return false
}

// ReleaseRunLock lets go of the network lock (when this program is about to restart for an
// update, so the new copy can take over the network at once).
func (n *Net) ReleaseRunLock() { n.releaseRunLock() }

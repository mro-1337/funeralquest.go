package guard

import "testing"

func TestLinkedTownsNeverBanned(t *testing.T) {
	g := New(t.TempDir())
	g.S.StrikeLimit = 3
	towns := map[string]string{"203.0.113.9": "Gravesend"}
	// a ban from before the town was known
	g.Ban("203.0.113.9", "failed log-ons", 0)
	g.Ban("198.51.100.4", "failed log-ons", 0)
	g.TownAt = func(ip string) string { return towns[ip] }
	if ok, why := g.Check("203.0.113.9"); !ok {
		t.Fatalf("linked town still banned: %s", why)
	}
	if ok, _ := g.Check("198.51.100.4"); ok {
		t.Fatal("other bans must stay")
	}
	for i := 0; i < 10; i++ {
		if g.Strike("203.0.113.9", "bad password", 1) {
			t.Fatal("a linked town's address got banned")
		}
	}
	if ok, _ := g.Check("203.0.113.9"); !ok {
		t.Fatal("linked town banned after strikes")
	}
	// lifting in one sweep
	g.TownAt = nil
	g.Ban("203.0.113.9", "failed log-ons", 0)
	g.TownAt = func(ip string) string { return towns[ip] }
	if l := g.LiftTownBans(); len(l) != 1 {
		t.Fatalf("lifted %v", l)
	}
	if len(g.Bans()) != 1 {
		t.Fatalf("bans left: %+v", g.Bans())
	}
	// IPv4 written as IPv6-mapped is the same address
	g.TownAt = func(ip string) string { return towns[ip] }
	if g.Strike("::ffff:203.0.113.9", "x", 5) {
		t.Fatal("mapped address banned")
	}
}

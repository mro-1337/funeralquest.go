package engine

import (
	"crypto/pbkdf2"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/hex"
	"errors"
	"fmt"
	"log"
	"os"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

const (
	Wood   = 0
	Silver = 1
	Gold   = 2
)

var casketName = [3]string{"Wood", "Silver", "Gold"}
var casketPrice = [3]int{800, 2600, 5300}

// Config are the sysop settings (the original's "game options" dialog).
type Config struct {
	TurnsPerDay          int     `json:"turns_per_day"`
	StartingLuck         int     `json:"starting_luck"`
	StartingHP           int     `json:"starting_hp"`
	StartingStrength     int     `json:"starting_strength"`
	StartingKarma        int     `json:"starting_karma"`
	StartingRating       int     `json:"starting_rating"`
	StartingMoney        int     `json:"starting_money"`
	CasketSP             [3]int  `json:"casket_sp"`
	PlotSP               int     `json:"plot_sp"`
	YangsPerDay          int     `json:"yangs_per_day"`
	Risk                 int     `json:"risk"`
	TournActive          bool    `json:"tourn_active"`
	TournDays            int     `json:"tourn_days"`
	BonusExp             int     `json:"bonus_exp"`
	BonusLuck            int     `json:"bonus_luck"`
	TradeBonus           int     `json:"trade_bonus"`
	VisitsPerDay         int     `json:"visits_per_day"`
	NormalOdds           float64 `json:"normal_odds"`
	LuckOdds             float64 `json:"luck_odds"`
	ScriptOdds           float64 `json:"script_odds"`
	TagsReceivablePerDay int     `json:"tags_receivable_per_day"`
	KarmaSin             int     `json:"karma_sin"`
	DonateKarmaPerDay    int     `json:"donate_karma_per_day"`
	ConfessCost          int     `json:"confess_cost"`
	ConfessKarma         int     `json:"confess_karma"`
	BlessKarma           int     `json:"bless_karma"`
	BlessLuck            int     `json:"bless_luck"`
	GraveQuestsPerDay    int     `json:"grave_quests_per_day"`
	ProfitMin            int     `json:"profit_min"`
	ProfitMax            int     `json:"profit_max"`
	TagPrices            [3]int  `json:"tag_prices"`
	AIPlayers            int     `json:"ai_players"`
	AISkill              int     `json:"ai_skill"`
	AIAttacksOff         bool    `json:"ai_attacks_off"`
	AIChatOff            bool    `json:"ai_chat_off"`
	ChurchInit           bool    `json:"church_init"`
	LevelPace            int     `json:"level_pace"`
	LevelGap             int     `json:"level_gap"`
	RestDays             int     `json:"rest_days"`
	ChallengesOff        bool    `json:"challenges_off"`
	SeasonDays           int     `json:"season_days"`
	BackupDays           int     `json:"backup_days"`
	BackupKeep           int     `json:"backup_keep"`
	NetRelayOff          bool    `json:"net_relay_off"`
	UpdateCheckOff       bool    `json:"update_check_off"`
	UpdateRepo           string  `json:"update_repo"`
	UpdateExitOnly       bool    `json:"update_exit_only"`
	HealCost             int     `json:"heal_cost"`
	MorgueCost           int     `json:"morgue_cost"`
	MorgueTurns          int     `json:"morgue_turns"`
	VolunteerKarma       int     `json:"volunteer_karma"`
	FightFullHP          bool    `json:"fight_full_hp"`
	HospitalInit         bool    `json:"hospital_init"` // hospital settings have their defaults
	LevelInit            bool    `json:"level_init"`    // level, season and backup settings have their defaults
	CashInit             bool    `json:"cash_init"`     // cash, tag prices and AI players have been given their defaults // church and graveyard settings have been given their defaults
	NameChangeCost       int     `json:"name_change_cost"`
	InactiveDays         int     `json:"inactive_days"`
	MaxPlayers           int     `json:"max_players"`
	MaintDelete          bool    `json:"maint_delete"`
	OnlineTimeoutMinutes int     `json:"online_timeout_minutes"`
	ServerName           string  `json:"server_name"`

	// security
	BanStrikes       int    `json:"ban_strikes"`
	BanMinutes       int    `json:"ban_minutes"`
	BanConnPerMinute int    `json:"ban_conn_per_minute"`
	BanMaxPerIP      int    `json:"ban_max_per_ip"`
	SysopAllow       string `json:"sysop_allow"`

	// server-to-server network
	NetPublicURL        string `json:"net_public_url"`
	NetAutoAccept       bool   `json:"net_auto_accept"`
	NetChatOff          bool   `json:"net_chat_off"`
	NetMailOff          bool   `json:"net_mail_off"`
	NetNewsOff          bool   `json:"net_news_off"`
	NetRaidsOff         bool   `json:"net_raids_off"`
	NetRaidsPerDay      int    `json:"net_raids_per_day"`
	NetVoteApplyOff     bool   `json:"net_vote_apply_off"`
	NetIntroOff         bool   `json:"net_intro_off"`
	NetShareLinksOff    bool   `json:"net_share_links_off"`
	NetAcceptIntroduced bool   `json:"net_accept_introduced"`

	// server options (used when the matching command-line switch isn't given; restart to apply)
	WebPort       int    `json:"web_port"`
	WebHost       string `json:"web_host"`
	WebCert       string `json:"web_cert"`
	WebKey        string `json:"web_key"`
	WebTrustProxy bool   `json:"web_trust_proxy"`
	TelnetPort    int    `json:"telnet_port"`
	NetPort       int    `json:"net_port"`
	NetPortHTTPS  bool   `json:"net_port_https"`
	NetPortOnly   bool   `json:"net_port_only"`

	// RLogin (BBS gateways, SyncTERM "RLogin")
	RLoginPort    int    `json:"rlogin_port"`
	RLoginTrusted string `json:"rlogin_trusted"`
	RLoginSecret  string `json:"rlogin_secret"`
	RLoginBBSID   string `json:"rlogin_bbs_id"`
	SoundOff      bool   `json:"sound_off"`
}

func DefaultConfig() Config {
	return Config{TurnsPerDay: 15, StartingLuck: 50, StartingHP: 10, StartingStrength: 3, StartingKarma: 50, StartingRating: 40,
		StartingMoney: 500, CasketSP: [3]int{1, 2, 3}, PlotSP: 1, YangsPerDay: 1, Risk: 50, TournDays: 30, BonusExp: 20,
		BonusLuck: 25, TradeBonus: 25, VisitsPerDay: 2, NormalOdds: 0.08, LuckOdds: 0.08, ScriptOdds: 0.05,
		TagsReceivablePerDay: 1, NameChangeCost: 1, InactiveDays: 15, MaxPlayers: 800, OnlineTimeoutMinutes: 10,
		ServerName: "Deathville", BanStrikes: 5, BanMinutes: 30, BanConnPerMinute: 8, BanMaxPerIP: 3, NetRaidsPerDay: 3,
		RLoginTrusted: "*", RLoginBBSID: "bbs",
		KarmaSin: 2, DonateKarmaPerDay: 8, ConfessCost: 2, ConfessKarma: 10, BlessKarma: 70, BlessLuck: 3, GraveQuestsPerDay: 4, ChurchInit: true,
		ProfitMin: 6, ProfitMax: 15, TagPrices: [3]int{500, 1000, 2000}, AIPlayers: 3, AISkill: 70, CashInit: true,
		LevelPace: 100, LevelGap: 15, RestDays: 3, BackupDays: 7, BackupKeep: 8, LevelInit: true,
		HealCost: 1, MorgueCost: 2, MorgueTurns: 2, VolunteerKarma: 2, HospitalInit: true}
}

// fillNew gives settings added in later versions their defaults in an older world.json.
func (c *Config) fillNew() {
	d := DefaultConfig()
	if c.BanStrikes == 0 {
		c.BanStrikes = d.BanStrikes
	}
	if c.BanMinutes == 0 {
		c.BanMinutes = d.BanMinutes
	}
	if c.BanConnPerMinute == 0 {
		c.BanConnPerMinute = d.BanConnPerMinute
	}
	if c.RLoginTrusted == "" && c.RLoginPort == 0 {
		c.RLoginTrusted = d.RLoginTrusted
	}
	if c.RLoginBBSID == "" {
		c.RLoginBBSID = d.RLoginBBSID
	}
	if c.NetRaidsPerDay == 0 {
		c.NetRaidsPerDay = d.NetRaidsPerDay
	}
	if c.BanMaxPerIP == 0 {
		c.BanMaxPerIP = d.BanMaxPerIP
	}
	if !c.ChurchInit {
		c.KarmaSin, c.DonateKarmaPerDay, c.ConfessCost, c.ConfessKarma = d.KarmaSin, d.DonateKarmaPerDay, d.ConfessCost, d.ConfessKarma
		c.BlessKarma, c.BlessLuck, c.GraveQuestsPerDay, c.ChurchInit = d.BlessKarma, d.BlessLuck, d.GraveQuestsPerDay, true
	}
	if !c.HospitalInit {
		c.HealCost, c.MorgueCost, c.MorgueTurns, c.VolunteerKarma, c.HospitalInit = d.HealCost, d.MorgueCost, d.MorgueTurns, d.VolunteerKarma, true
	}
	if !c.LevelInit {
		c.LevelPace, c.LevelGap, c.RestDays, c.BackupDays, c.BackupKeep, c.LevelInit = d.LevelPace, d.LevelGap, d.RestDays, d.BackupDays, d.BackupKeep, true
	}
	if !c.CashInit {
		c.ProfitMin, c.ProfitMax, c.TagPrices, c.AIPlayers, c.AISkill, c.CashInit = d.ProfitMin, d.ProfitMax, d.TagPrices, d.AIPlayers, d.AISkill, true
	}
}

// Game ties the shared store to the game data.
type Game struct {
	Net         Network // linked servers; nil when networking isn't set up
	Store       *Store
	Log         *log.Logger
	GamedataDir string

	data      atomic.Pointer[Data]
	dataMu    sync.Mutex
	dataCheck time.Time
	dataStamp string
}

// D returns the game texts, re-reading the gamedata folder when a sysop has edited a file
// (checked at most every 5 seconds), so edits take effect without restarting anything.
func (g *Game) D() *Data {
	g.dataMu.Lock()
	if time.Since(g.dataCheck) > 5*time.Second {
		g.dataCheck = time.Now()
		if st := dirStamp(g.GamedataDir); st != g.dataStamp {
			if d := LoadData(g.GamedataDir); len(d.Risks) > 0 && len(d.Options) > 0 {
				g.data.Store(d)
				g.dataStamp = st
			}
		}
	}
	g.dataMu.Unlock()
	return g.data.Load()
}

func dirStamp(dir string) string {
	ents, _ := os.ReadDir(dir)
	var b strings.Builder
	for _, e := range ents {
		if info, err := e.Info(); err == nil {
			fmt.Fprintf(&b, "%s:%d:%d;", e.Name(), info.Size(), info.ModTime().UnixNano())
		}
	}
	return b.String()
}

func NewGame(dataDir, gamedataDir string, logger *log.Logger) (*Game, error) {
	st, err := NewStore(dataDir)
	if err != nil {
		return nil, err
	}
	if logger == nil {
		logger = log.New(log.Writer(), "", log.LstdFlags)
	}
	g := &Game{Store: st, Log: logger, GamedataDir: gamedataDir}
	d := LoadData(gamedataDir)
	if len(d.Risks) == 0 || len(d.Options) == 0 {
		return nil, fmt.Errorf("game data files not found in %s", gamedataDir)
	}
	g.data.Store(d)
	g.dataStamp, g.dataCheck = dirStamp(gamedataDir), time.Now()
	return g, g.Store.Tx(func(w *World) error { g.MaintCheck(w, false); return nil })
}

func today() string { return time.Now().Format("2006-01-02") }

func tournEndsToday(w *World) bool {
	return w.Config.TournActive && w.Glo.GameAge == w.Config.TournDays+1
}
func tournEndsTomorrow(w *World) bool {
	return w.Config.TournActive && w.Glo.GameAge == w.Config.TournDays
}

func topOfDay(w *World) *Player {
	var best *Player
	for _, p := range w.Active() {
		if p.AI == nil && p.DayLast == w.Glo.GameAge && p.SP > 0 && (best == nil || p.SP > best.SP) {
			best = p
		}
	}
	return best
}

// MaintCheck runs the nightly maintenance once per calendar day (maint.cpp).
func (g *Game) MaintCheck(w *World, force bool) bool {
	g.upgrade(w)
	t := today()
	if !force && w.Glo.LastMaint == t {
		g.aiTick(w)
		return false
	}
	g.maintNewDay(w, t)
	g.aiTick(w)
	return true
}

func (g *Game) maintNewDay(w *World, t string) {
	c := w.Config
	g.Log.Printf("running maintenance for day %d", w.Glo.GameAge)
	if c.TournActive && w.Glo.GameAge == c.TournDays+1 {
		g.ResetGame(w, false)
	}
	// top seller of the day
	if top := topOfDay(w); top != nil {
		w.Glo.TopOld = &TopOld{top.Name, top.Parlor, top.SP}
		if !tournEndsTomorrow(w) {
			w.AddMail(Letter{To: top.ID, Luck: c.BonusLuck, BP: c.BonusExp, Pic: "stuff/lottery_win",
				Text: fmt.Sprintf("`wCongratulations!\n`$You were the top seller for yesterday.  You earn `w%s`$ luck and `w%s`$ Bury Points.\n", Cash(c.BonusLuck), Cash(c.BonusExp))})
		}
	} else {
		w.Glo.TopOld = nil
	}
	// top three parlors
	if !tournEndsTomorrow(w) {
		labels := []string{"ran the top parlor", "were the second highest parlor", "were the third highest parlor"}
		mult := []float64{1, 0.5, 0.25}
		n := 0
		for _, p := range w.Ranked() {
			if p.Exp <= 0 || n >= 3 {
				break
			}
			if p.AI != nil { // AI players never take the bonuses
				continue
			}
			l, b := int(float64(c.BonusLuck)*mult[n]), int(float64(c.BonusExp)*mult[n])
			w.AddMail(Letter{To: p.ID, Luck: l, BP: b, Pic: "stuff/money_bag_2",
				Text: fmt.Sprintf("`wCongratulations!\n`$You %s in town yesterday.  You earn `w%s`$ luck and `w%s`$ Bury Points.\n", labels[n], Cash(l), Cash(b))})
			n++
		}
	}
	w.Glo.GameAge++
	w.Glo.LastMaint = t
	g.autoBackup(w)
	g.seasonCheck(w)
	catchUp(w)
	online := map[int]bool{}
	for _, s := range w.Online() {
		online[s.PlayerID] = true
	}
	for _, p := range w.Active() {
		p.SP, p.YangsSent, p.TagsToday = 0, 0, 0
		if tournEndsToday(w) {
			p.YangsSent = c.YangsPerDay
		}
		if p.AI != nil {
			continue // AI parlors are opened and closed by the AI players setting
		}
		if p.DayLast+c.InactiveDays < w.Glo.GameAge {
			g.Broadcast(w, p.Name+" closes shop and leaves town.")
			p.Active = false
		}
		if p.DayLast+1 < w.Glo.GameAge {
			p.Police = false
		}
		if c.MaintDelete && !online[p.ID] && p.Exp == 0 && p.Active {
			g.Broadcast(w, p.Name+" closes shop and leaves town without a single sale.")
			p.Active = false
		}
	}
	g.randomNews(w)
}

func (g *Game) randomNews(w *World) {
	if tournEndsToday(w) {
		r := w.Ranked()
		if len(r) > 0 && r[0].Exp > 0 {
			win := r[0]
			w.AddNews("front", "`7TOURNAMENT WINNER HAS BEEN DECLARED!\r\n"+fmt.Sprintf("`^With %s Bury Points and %s plots, %s has been declared the victor.\r\n\r\n", Cash(win.Exp), Cash(win.Plots), win.Name))
			w.Deeds = append(w.Deeds, fmt.Sprintf("%s won the 'Best Funeral Directory In The Universe' award.", win.Name))
		}
		w.AddLocalNews("front", "`7GIANT METEOR TO DESTROY THE WORLD AT MIDNIGHT!\r\n`^\"This is a real bummer, but at least we have time to read our mail and stuff.  But who will bury us?,\" comments a local astronomer.\r\n\r\n")
		return
	}
	ev := computeEvent(g.D().NewsBlurbs, w.Glo.GameAge)
	if ev == nil {
		return
	}
	w.AddLocalNews("front", "`7"+ev.Title+"\r\n`^"+ev.Message+"\r\n\r\n")
	act := w.Active()
	if ev.GiveRandom == "" || len(act) == 0 {
		return
	}
	p := pick(act)
	l, b, t := evRoll(ev)
	bpName, tName := "Bury Points", "turns"
	if b == 1 {
		bpName = "Bury Point"
	}
	if t == 1 {
		tName = "turn"
	}
	logText := strings.NewReplacer("*NAME*", p.Name, "*HOME*", p.Parlor, "\\n", "\n").Replace(ev.AddLog)
	if logText != "" {
		logText += "\n\n"
	}
	pic := ev.Pic
	if pic == "" {
		pic = "stuff/money_bag_2"
	}
	w.AddMail(Letter{To: p.ID, Expire: w.Glo.GameAge + 1, Luck: l, BP: b, Turns: t, Pic: pic, Log: logText,
		Text: strings.ReplaceAll(ev.GiveRandom+rewardText([][2]any{{bpName, b}, {"luck", l}, {tName, t}}), "\\n", "\n")})
}

func evRoll(ev *Event) (luck, bp, turns int) {
	if ev.HasLuck {
		luck = randomRange(ev.Luck[0], ev.Luck[1])
	}
	if ev.HasBP {
		bp = randomRange(ev.BP[0], ev.BP[1])
	}
	if ev.HasTurns {
		turns = randomRange(ev.Turns[0], ev.Turns[1])
	}
	return
}

// ResetGame starts a new game. Without wipe, accounts stay but their stats are reset.
func (g *Game) ResetGame(w *World, wipe bool) {
	if wipe {
		w.Players = nil
	} else {
		for _, p := range w.Players {
			g.freshStats(w, p)
		}
	}
	w.Mail, w.Chat = nil, nil
	w.ClearNews()
	w.Glo = Glo{}
}

func (g *Game) freshStats(w *World, p *Player) {
	c := w.Config
	p.Turns, p.Money, p.Exp, p.Karma, p.Rating = 0, c.StartingMoney, 0, c.StartingKarma, c.StartingRating
	p.Coffins, p.Transport, p.Plots, p.DayLast, p.SP, p.Luck = [3]int{}, 0, 0, 0, 0, c.StartingLuck
	p.YangsSent, p.Psych, p.Kicked, p.Strength, p.HPMax, p.HP = 0, 0, false, c.StartingStrength, c.StartingHP, c.StartingHP
	p.Fights, p.Police, p.TagsToday, p.Custom, p.Church = 0, false, 0, Custom{}, Church{}
}

func (g *Game) Broadcast(w *World, text string) {
	w.AddChat("`w"+time.Now().Format("3:04pm")+":"+text, 0)
}
func (g *Game) Tv(w *World, text string) {
	if !w.Glo.TVOff {
		w.AddChat("`7The TV: `w"+text, 0)
	}
}

// ---------------------------------------------------------------- accounts

func HashPassword(pw string) string {
	salt := make([]byte, 16)
	rand.Read(salt)
	k, _ := pbkdf2.Key(sha256.New, pw, salt, 120000, 32)
	return "pbkdf2$" + hex.EncodeToString(salt) + "$" + hex.EncodeToString(k)
}
func CheckPassword(pw, stored string) bool {
	parts := strings.Split(stored, "$")
	if len(parts) != 3 || parts[0] != "pbkdf2" {
		return false
	}
	salt, _ := hex.DecodeString(parts[1])
	want, _ := hex.DecodeString(parts[2])
	k, _ := pbkdf2.Key(sha256.New, pw, salt, 120000, 32)
	return subtle.ConstantTimeCompare(k, want) == 1
}

type NewPlayer struct {
	Name, Parlor, Logon, Password, BBSKey string
	Email                                 string // optional here; the web and telnet sign-ups ask for it
	Male                                  bool
}

// ValidEmail does a sanity check of an e-mail address (something@somewhere.tld).
func ValidEmail(e string) bool {
	e = strings.TrimSpace(e)
	at := strings.LastIndex(e, "@")
	if len(e) < 6 || len(e) > 100 || at < 1 || strings.ContainsAny(e, " \t<>\"'`,;()[]\\") {
		return false
	}
	dom := e[at+1:]
	return strings.Count(e, "@") == 1 && strings.Contains(dom, ".") && !strings.HasPrefix(dom, ".") && !strings.HasSuffix(dom, ".")
}

// CreatePlayer validates and adds a new parlor (new_user.cpp).
func (g *Game) CreatePlayer(np NewPlayer) (*Player, error) {
	var out *Player
	err := g.Store.Tx(func(w *World) error {
		g.MaintCheck(w, false)
		name := swearCheck(stripDangerous(np.Name), g.D().Swears)
		parlor := swearCheck(stripDangerous(np.Parlor), g.D().Swears)
		switch {
		case len(w.Active()) >= w.Config.MaxPlayers:
			return fmt.Errorf("The town is full.  (this server allows %d players max)  Come back later!", w.Config.MaxPlayers)
		case len(name) < 3:
			return errors.New("Your name is too short.  Try a longer one.")
		case len(name) > 20:
			return errors.New("Your name is too long.  Try a shorter one.")
		case w.ByName(name) != nil:
			return fmt.Errorf("Someone is already using the name %s. Please try another.", name)
		case len(parlor) < 3:
			return errors.New("Your funeral parlor name is too short.  Try a longer one.")
		case len(parlor) > 20:
			return errors.New("Your funeral parlor name is too long.  Try a shorter one.")
		}
		if np.Email != "" && !ValidEmail(np.Email) {
			return errors.New("That e-mail address doesn't look right.  Check it and try again.")
		}
		p := &Player{Name: name, Parlor: parlor, Male: np.Male, BBSKey: np.BBSKey, Active: true, Created: time.Now().Unix(), Email: strings.TrimSpace(np.Email)}
		if np.Logon != "" {
			logon := strings.TrimSpace(np.Logon)
			switch {
			case len(logon) < 3:
				return errors.New("Your logon name is too short.  Try a longer one.")
			case len(logon) > 20:
				return errors.New("Your logon name is too long.  Try a shorter one.")
			case w.ByLogon(logon) != nil:
				return fmt.Errorf("Someone is already using the logon name of %s. Please try another.", logon)
			case np.Password == "":
				return errors.New("Your password is too short.  Try a longer one.")
			}
			p.Logon, p.Password = logon, HashPassword(np.Password)
		}
		g.freshStats(w, p)
		p.ID = w.NextID
		w.NextID++
		w.Players = append(w.Players, p)
		p.Level = 1
		catchUp(w)
		g.Broadcast(w, p.Name+" has just moved into town!")
		w.AddNews("front", fmt.Sprintf("`5A new parlor (%s) run by %s has been opened!\r\n\r\n", p.Parlor, p.Name))
		cp := *p
		out = &cp
		return nil
	})
	return out, err
}

func (g *Game) Login(logon, pw string) (*Player, error) {
	// check the password outside the lock (it's slow on purpose), and always do the same
	// amount of work so wrong logon names can't be told apart from wrong passwords
	hash, id := dummyHash, 0
	g.View(func(w *World) {
		if p := w.ByLogon(logon); p != nil && p.Password != "" {
			hash, id = p.Password, p.ID
		}
	})
	if !CheckPassword(pw, hash) || id == 0 {
		return nil, errors.New("Unknown logon name or wrong password.")
	}
	var out *Player
	err := g.Store.Tx(func(w *World) error {
		g.MaintCheck(w, false)
		p := w.Player(id)
		if p == nil {
			return errors.New("Unknown logon name or wrong password.")
		}
		if !p.Active {
			return errors.New("That parlor has closed down.  Create a new character.")
		}
		cp := *p
		out = &cp
		return nil
	})
	return out, err
}

var dummyHash = HashPassword("not a real password")

// FindBBSPlayer returns the parlor that belongs to a BBS caller, freeing closed ones.
func (g *Game) FindBBSPlayer(key string) *Player {
	var out *Player
	g.Store.Tx(func(w *World) error {
		g.MaintCheck(w, false)
		if p := w.ByBBSKey(key); p != nil {
			if !p.Active {
				p.BBSKey = ""
				return nil
			}
			cp := *p
			out = &cp
		}
		return nil
	})
	return out
}

// View runs a read-only (well, maintenance-aware) look at the world.
func (g *Game) View(fn func(w *World)) {
	g.Store.Tx(func(w *World) error { g.MaintCheck(w, false); fn(w); return nil })
}

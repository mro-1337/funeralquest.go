package engine

import (
	"fmt"
	"strings"
)

// The hospital. In the original it was only where you woke up after losing a fight. Now
// hit points carry from fight to fight (unless "Heal before every fight" is on), so being
// patched up matters, and there's a morgue attendant with tips, patients to sit with, and
// visiting hours for rivals who lost a fight today.

const hospInfo = "You are at the city hospital.  A nurse smiles at you.  It smells of floor wax and lime gelatin."

// fightHP is what this player brings to a fight.
func (s *Session) fightHP() int {
	me := s.me()
	if s.cfg().FightFullHP {
		return me.HPMax
	}
	return clamp(me.HP, 1, me.HPMax)
}

// tooHurt stops a player with no hit points from raiding (unless fights always start healed).
func (s *Session) tooHurt() (Screen, bool) {
	me := s.me()
	if s.cfg().FightFullHP || me.HP > 0 {
		return Screen{}, false
	}
	scr := s.compMenu()
	scr.Text = "You're in no shape to pick a fight.  Every step hurts.\n\nGet patched up at the hospital, or rest until tomorrow."
	scr.Buttons = []Button{B("Hospital", "hospital", "").K("h"), B("Continue", "comp", "menu").D()}
	return scr, true
}

func (s *Session) healCost() int {
	me := s.me()
	n := 0
	if me.Church.HealDay == s.age() {
		n = me.Church.Heals
	}
	return s.cfg().HealCost * (n + 1)
}

func (s *Session) hospScr(text string) Screen {
	me := s.me()
	c := s.cfg()
	bs := []Button{}
	if c.HealCost > 0 {
		bs = append(bs, B("Get patched up", "hospital", "heal").K("p"))
	}
	if c.MorgueCost > 0 && c.MorgueTurns > 0 {
		bs = append(bs, B("The morgue", "hospital", "morgue").K("m"))
	}
	if c.VolunteerKarma > 0 {
		bs = append(bs, B("Volunteer", "hospital", "volunteer").K("v"))
	}
	bs = append(bs, B("Visiting hours", "hospital", "visit").K("i"), B("Leave", "map", "").K("l").D())
	info := hospInfo + fmt.Sprintf("\n\nYour hit points: %d of %d.", max(0, me.HP), me.HPMax)
	return Screen{View: "generic", BG: "places/hospital_desk", Info: info, Text: text, Buttons: bs}
}

// patients are the parlor owners who lost a fight today.
func (s *Session) patients() []*Player {
	me := s.me()
	var out []*Player
	for _, p := range s.w.Active() {
		if p.ID != me.ID && (p.Police || p.HP < 1) && !s.w.IsOnline(p.ID) {
			out = append(out, p)
		}
	}
	return out
}

func (s *Session) cmdHospital(a Action) Screen {
	me := s.me()
	c := s.cfg()
	day := s.age()
	switch a.Sub {
	case "room": // after losing a fight
		return Screen{View: "generic", BG: "places/hospital_room", Info: "You are lying on a bed, it doesn't look like your own.", Text: "`$Your whole body aches.",
			Buttons: []Button{B("Leave", "hospital", "leave_room").D()}}
	case "leave_room":
		return s.hospScr(fmt.Sprintf("`wNurse: `$\"I see you finally woke up, %s.  Hope you'll be more careful next time.\"", ifs(me.Male, "prince charming", "sleeping beauty")))

	case "heal":
		if c.HealCost <= 0 {
			return s.hospScr("`wNurse: `$\"We don't do walk-ins.  Insurance reasons.\"")
		}
		if me.HP >= me.HPMax {
			return s.hospScr("`wNurse: `$\"You look fine to me.  Next!\"")
		}
		cost := s.healCost()
		if me.Coffins[Gold] < cost {
			return s.hospScr(fmt.Sprintf("`wNurse: `$\"That'll be %d gold tag(s).  ...No?  Then take two aspirin and come back tomorrow.\"", cost))
		}
		if me.Church.HealDay != day {
			me.Church.HealDay, me.Church.Heals = day, 0
		}
		me.Church.Heals++
		me.Coffins[Gold] -= cost
		me.HP = me.HPMax
		return s.hospScr(fmt.Sprintf("`yA doctor who looks about fifteen stitches you up, gives you a lollipop and sends you on your way.\n\n`$You're back to `w%d`$ hit points.  That cost `w%d`$ gold tag(s)%s.", me.HPMax, cost,
			ifs(c.HealCost > 0, fmt.Sprintf("; next time today it's %d", s.healCost()), "")))

	case "morgue":
		if c.MorgueCost <= 0 || c.MorgueTurns <= 0 {
			return s.hospScr("`yThe morgue door is locked.  A sign says STAFF ONLY.")
		}
		if me.Church.MorgueDay == day {
			return s.hospScr("`wMorgue attendant: `$\"Already gave you my best leads today, pal.  Come back tomorrow.\"")
		}
		if me.Coffins[Gold] < c.MorgueCost {
			return s.hospScr(fmt.Sprintf("`yThe morgue attendant looks up from his sandwich.\n\n`wMorgue attendant: `$\"Tips cost %d gold tag(s).  I've got a mortgage.\"", c.MorgueCost))
		}
		me.Coffins[Gold] -= c.MorgueCost
		me.Church.MorgueDay = day
		me.Turns += c.MorgueTurns
		return s.hospScr(fmt.Sprintf("`yYou slip the morgue attendant `w%d`y gold tag(s).  He checks the hall, then hands you a napkin with names scribbled on it.\n\n`wMorgue attendant: `$\"Their families don't have anybody yet.  You didn't get this from me.\"\n\n`$You have time for `w%d`$ more customer(s) today.", c.MorgueCost, c.MorgueTurns))

	case "volunteer":
		if c.VolunteerKarma <= 0 {
			return s.hospScr("`wNurse: `$\"We have enough volunteers, thanks.\"")
		}
		if me.Church.VolunteerDay == day {
			return s.hospScr("`wNurse: `$\"You've done your good deed for today.  Mrs. Peabody is asleep anyway.\"")
		}
		if me.Turns < 1 {
			return s.hospScr("`yYou're too tired to sit with anyone today.")
		}
		me.Turns--
		me.Church.VolunteerDay = day
		gain := min(c.VolunteerKarma, 100-me.Karma)
		me.Karma += gain
		s.progress("volunteer", 1)
		txt := fmt.Sprintf("`yYou spend the afternoon reading to Mrs. Peabody in room 12.  She thinks you're her nephew.  You don't correct her.\n\n`$You feel like a good person.  (karma +%d)", gain)
		if random(5) == 0 {
			me.Coffins[Wood]++
			txt += "\n\nOn your way out she presses a `wwood tag`$ into your hand.  \"For when it's my turn, dear.\""
		}
		return s.hospScr(txt)

	case "visit":
		if me.Church.VisitDay == day {
			return s.hospScr("`wNurse: `$\"Visiting hours are over for you today.\"")
		}
		ps := s.patients()
		if len(ps) == 0 {
			return s.hospScr("`wNurse: `$\"Nobody's in today.  Quiet day.  Too quiet.  I hate quiet days.\"")
		}
		t := "`wNurse: `$\"Who are you here to see?\"\n\n"
		var bs []Button
		for i, p := range ps {
			if i == 6 {
				break
			}
			id := p.ID
			t += fmt.Sprintf("`w%d. `$%s of %s\n", i+1, p.Name, p.Parlor)
			b := B(p.Name, "hospital", "patient").K(fmt.Sprint(i + 1))
			b.HisID = &id
			bs = append(bs, b)
		}
		bs = append(bs, B("Back", "hospital", "").K("b").D())
		scr := s.hospScr(t)
		scr.Buttons = bs
		return scr

	case "patient", "flowers", "unplug":
		t := s.w.Player(hisID(a))
		if t == nil || t.ID == me.ID || me.Church.VisitDay == day {
			return s.cmdHospital(Action{Sub: "visit"})
		}
		ok := false
		for _, p := range s.patients() {
			ok = ok || p.ID == t.ID
		}
		if !ok {
			return s.hospScr(fmt.Sprintf("`wNurse: `$\"%s checked out already.\"", t.Name))
		}
		id := t.ID
		if a.Sub == "patient" {
			fl := B("Bring flowers", "hospital", "flowers").K("f")
			fl.HisID = &id
			un := B("Unplug something", "hospital", "unplug").K("u")
			un.HisID = &id
			scr := s.hospScr(fmt.Sprintf("`y%s is asleep in room %d, hooked up to more machines than seems necessary.  A monitor beeps.  A tube gurgles.", t.Name, randomRange(3, 40)))
			scr.Buttons = []Button{fl, un, B("Leave", "hospital", "").K("l").D()}
			return scr
		}
		me.Church.VisitDay = day
		if a.Sub == "flowers" {
			gain := min(2, 100-me.Karma)
			me.Karma += gain
			luckMod(t, 1)
			s.w.AddMail(Letter{To: t.ID, Pic: "stuff/red_rose", Text: fmt.Sprintf("\n`$While you were in the hospital, `w%s`$ dropped off flowers with a card:\n\n`w\"Get well soon.  Not too soon.\"\n\n`$You feel a little luckier.\n", me.Name)})
			return s.hospScr(fmt.Sprintf("`yYou leave a vase of roses by %s's bed, with a card.  The nurse says it's the nicest thing she's seen all week.\n\n`$(karma +%d)", t.Name, gain))
		}
		// unplug: petty, and it costs karma
		if tooBig(c, lvl(me), lvl(t)) {
			return s.hospScr(fmt.Sprintf("`yYou reach for the plug... and stop.  %s is barely out of mortician school.  Even you have limits.", t.Name))
		}
		txt := "`yYou wait until the nurse turns around, then trip over a cord.  Accidentally.  On purpose.  Somewhere an alarm goes off.\n\n"
		if random(4) == 0 {
			luckMod(me, -2)
			txt += "`4The nurse catches you!  `$She chases you down the hall with a bedpan.  (luck -2)"
		} else {
			lost := min(max(1, t.Exp/100), 50)
			expModForce(t, -lost)
			expMod(me, lost/2)
			s.w.AddMail(Letter{To: t.ID, Pic: "places/hospital_room", Text: fmt.Sprintf("\n`$You had a rough night in the hospital.  Somebody unplugged your machines and you woke up on the floor.  The nurse says a visitor named `w%s`$ was the last one in your room.\n\n`$You lose `w%d`$ Bury Points while you recover.\n", me.Name, lost)})
			txt += fmt.Sprintf("`$%s loses `w%d`$ Bury Points while the doctors sort it out.  You feel smug.  You earn `w%d`$ Bury Points.", t.Name, lost, lost/2)
		}
		if n := 2 * c.KarmaSin; n > 0 { // twice a normal bad deed: it's a hospital
			me.Karma = clamp(me.Karma-n, 1, 100)
			txt += fmt.Sprintf("\n\n`8Somewhere, a church bell rings.  Twice.  (karma -%d)", n)
		}
		return s.hospScr(txt)
	}
	s.setLocation("Hospital")
	greet := fmt.Sprintf("`wNurse: `$\"Hi %s.  I don't recall you having a pick-up today.\"", me.Name)
	if me.HP < me.HPMax {
		greet = fmt.Sprintf("`wNurse: `$\"Oh dear, %s, you look terrible.  Want me to get the doctor?\"", me.Name)
	}
	return s.hospScr(strings.TrimSpace(greet))
}

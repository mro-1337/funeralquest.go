package engine

import (
	"strings"
	"testing"
)

func TestValidEmail(t *testing.T) {
	for e, want := range map[string]bool{"bob@example.com": true, "a.b+c@mail.co.uk": true, "bob": false, "bob@": false, "@x.com": false,
		"bob@localhost": false, "b ob@x.com": false, "bob@x.com.": false, "a@b@c.com": false, "<b@x.com>": false} {
		if ValidEmail(e) != want {
			t.Errorf("ValidEmail(%q) != %v", e, want)
		}
	}
}

func TestAskForMissingEmail(t *testing.T) {
	g := newTestGame(t)
	if _, err := g.CreatePlayer(NewPlayer{Name: "Bad", Parlor: "Bad's", Logon: "bad", Password: "secret", Email: "nope"}); err == nil {
		t.Fatal("bad e-mail accepted")
	}
	p, err := g.CreatePlayer(NewPlayer{Name: "Edna", Parlor: "Edna's", Logon: "edna", Password: "secret"})
	if err != nil {
		t.Fatal(err)
	}
	s := g.NewSession(p.ID, "web")
	scr := s.Act(Action{Cmd: "main"})
	for i := 0; i < 6 && (scr.Input == nil || scr.Input.Cmd != "email"); i++ {
		scr = s.Act(Action{Cmd: "main"}) // past the morning's events
	}
	if scr.Input == nil || scr.Input.Cmd != "email" || !strings.Contains(scr.Text, "only used") {
		t.Fatalf("not asked for an e-mail address: %+v", scr)
	}
	bad := "not an address"
	if scr = s.Act(Action{Cmd: "email", Sub: "set", Value: &bad}); scr.Input == nil {
		t.Fatal("bad address accepted")
	}
	good := "edna@example.com"
	s.Act(Action{Cmd: "email", Sub: "set", Value: &good})
	g.View(func(w *World) {
		if w.Player(p.ID).Email != good {
			t.Fatal("not saved")
		}
	})
	// skipping: asked once per session only
	q, _ := g.CreatePlayer(NewPlayer{Name: "Skip", Parlor: "Skip's", Logon: "skip", Password: "secret"})
	s2 := g.NewSession(q.ID, "web")
	for i := 0; i < 6; i++ {
		if scr := s2.Act(Action{Cmd: "main"}); scr.Input != nil && scr.Input.Cmd == "email" {
			break
		}
	}
	empty := ""
	s2.Act(Action{Cmd: "email", Sub: "set", Value: &empty})
	if scr := s2.Act(Action{Cmd: "main"}); scr.Input != nil && scr.Input.Cmd == "email" {
		t.Fatal("asked twice in one session")
	}
}

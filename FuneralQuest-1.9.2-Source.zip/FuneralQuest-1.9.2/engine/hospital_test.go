package engine

import (
	"strings"
	"testing"
)

func TestHospital(t *testing.T) {
	g := newTestGame(t)
	a, _ := g.CreatePlayer(NewPlayer{Name: "Patient", Parlor: "Sick Rest", Logon: "patient", Password: "x"})
	b, _ := g.CreatePlayer(NewPlayer{Name: "Beaten", Parlor: "Sore Rest", Logon: "beaten", Password: "x"})
	g.Store.Tx(func(w *World) error {
		w.Config.AIPlayers = 0
		me := w.Player(a.ID)
		me.Coffins, me.Karma, me.Exp = [3]int{5, 5, 10}, 40, 5000
		w.Player(b.ID).Exp = 4000
		return nil
	})
	s := g.NewSession(a.ID, "web")
	s.Act(Action{Cmd: "main"})
	s.Act(Action{Cmd: "main"})
	get := func(id int) (p Player) { g.View(func(w *World) { p = *w.Player(id) }); return }

	// knocked out: can't raid until patched up
	g.Store.Tx(func(w *World) error { w.Player(a.ID).HP = 0; return nil })
	s.Act(Action{Cmd: "comp"})
	sc := s.Act(Action{Cmd: "comp", Sub: "gotname", HisID: &b.ID})
	if !strings.Contains(sc.Text, "no shape") {
		t.Fatalf("raiding at 0 HP: %s", sc.Text)
	}
	s.Act(Action{Cmd: "hospital"})
	gold := get(a.ID).Coffins[Gold]
	s.Act(Action{Cmd: "hospital", Sub: "heal"})
	if p := get(a.ID); p.HP != p.HPMax || p.Coffins[Gold] != gold-1 {
		t.Fatalf("heal: hp %d/%d gold %d", p.HP, p.HPMax, p.Coffins[Gold])
	}
	g.Store.Tx(func(w *World) error { w.Player(a.ID).HP = 1; return nil })
	s.Act(Action{Cmd: "hospital", Sub: "heal"})
	if p := get(a.ID); p.Coffins[Gold] != gold-3 {
		t.Fatalf("second heal should cost 2: gold %d", p.Coffins[Gold])
	}

	// morgue tip: more customers, once a day
	turns := get(a.ID).Turns
	s.Act(Action{Cmd: "hospital", Sub: "morgue"})
	s.Act(Action{Cmd: "hospital", Sub: "morgue"})
	if p := get(a.ID); p.Turns != turns+2 || p.Coffins[Gold] != gold-5 {
		t.Fatalf("morgue: turns %d->%d gold %d", turns, p.Turns, p.Coffins[Gold])
	}

	// volunteering: a turn for karma, once a day
	k, turns := get(a.ID).Karma, get(a.ID).Turns
	s.Act(Action{Cmd: "hospital", Sub: "volunteer"})
	s.Act(Action{Cmd: "hospital", Sub: "volunteer"})
	if p := get(a.ID); p.Karma != k+2 || p.Turns != turns-1 {
		t.Fatalf("volunteer: karma %d->%d turns %d->%d", k, p.Karma, turns, p.Turns)
	}

	// visiting hours: only patients, flowers send a letter and luck
	sc = s.Act(Action{Cmd: "hospital", Sub: "visit"})
	if !strings.Contains(sc.Text, "Nobody") {
		t.Fatalf("no patients yet: %s", sc.Text)
	}
	g.Store.Tx(func(w *World) error { w.Player(b.ID).Police = true; return nil })
	sc = s.Act(Action{Cmd: "hospital", Sub: "visit"})
	if !strings.Contains(sc.Text, "Beaten") {
		t.Fatalf("patient list: %s", sc.Text)
	}
	luck := get(b.ID).Luck
	s.Act(Action{Cmd: "hospital", Sub: "flowers", HisID: &b.ID})
	if p := get(b.ID); p.Luck != min(100, luck+1) {
		t.Fatalf("flowers: luck %d -> %d", luck, p.Luck)
	}
	var mail int
	g.View(func(w *World) { mail = w.MailCount(b.ID) })
	if mail == 0 {
		t.Fatal("no get-well letter")
	}
	sc = s.Act(Action{Cmd: "hospital", Sub: "unplug", HisID: &b.ID})
	if get(b.ID).Exp != 4000 {
		t.Fatal("second visit the same day went through")
	}

	// unplugging (a new day's visit): the patient loses a little, it costs double karma
	g.Store.Tx(func(w *World) error { w.Player(a.ID).Church.VisitDay = 0; return nil })
	k = get(a.ID).Karma
	for i := 0; i < 8 && get(b.ID).Exp == 4000; i++ { // the nurse catches you one time in four
		g.Store.Tx(func(w *World) error { w.Player(a.ID).Church.VisitDay = 0; return nil })
		s.Act(Action{Cmd: "hospital", Sub: "unplug", HisID: &b.ID})
	}
	if p := get(b.ID); p.Exp != 4000-40 {
		t.Fatalf("unplug: exp %d", p.Exp)
	}
	if get(a.ID).Karma >= k {
		t.Fatal("unplugging didn't cost karma")
	}

	// the old rule: everyone fights at full strength
	g.Store.Tx(func(w *World) error { w.Config.FightFullHP = true; w.Player(a.ID).HP = 0; return nil })
	s.Act(Action{Cmd: "comp"})
	sc = s.Act(Action{Cmd: "comp", Sub: "gotname", HisID: &b.ID})
	if strings.Contains(sc.Text, "no shape") {
		t.Fatal("with heal-before-every-fight on, 0 HP shouldn't stop a raid")
	}
}

func TestCafeWall(t *testing.T) {
	g := newTestGame(t)
	a, _ := g.CreatePlayer(NewPlayer{Name: "Talker", Parlor: "Talk Rest", Logon: "talker", Password: "x"})
	b, _ := g.CreatePlayer(NewPlayer{Name: "Lurker", Parlor: "Lurk Rest", Logon: "lurker", Password: "x"})
	g.Store.Tx(func(w *World) error {
		w.Config.AIPlayers = 0
		w.Chat = nil
		w.AddSharedChat("`$Old: `wthis is from last week")
		w.Chat[0].TS -= 5 * 24 * 3600 * 1000
		return nil
	})
	s := g.NewSession(a.ID, "web")
	s.Act(Action{Cmd: "main"})
	s.Act(Action{Cmd: "cafe"})
	s.ChatUpdate("anyone here?")
	s.Act(Action{Cmd: "map"})
	s2 := g.NewSession(b.ID, "web")
	s2.Act(Action{Cmd: "main"})
	sc := s2.Act(Action{Cmd: "cafe"})
	if !strings.Contains(sc.Text, "anyone here?") || strings.Contains(sc.Text, "last week") || strings.Contains(sc.Text, "saunters in") {
		t.Fatalf("cafe wall: %s", sc.Text)
	}
}

func TestKeepColors(t *testing.T) {
	for in, want := range map[string]string{"`9HIYAHHH!": "`9HIYAHHH!", "a`fxb": "afxb", "`$gold`w white`": "`$gold`w white", "``9x": "`9x"} {
		if got := KeepColors(in); got != want {
			t.Errorf("KeepColors(%q) = %q, want %q", in, got, want)
		}
	}
}

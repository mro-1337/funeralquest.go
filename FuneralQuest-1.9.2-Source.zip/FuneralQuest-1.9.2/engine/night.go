package engine

import (
	"fmt"
	"strings"
	"time"
)

// Night raids: raids on towns that can't be reached right now (they connect out only, and
// aren't fetching raid steps at the moment, e.g. a door-only BBS between callers).
//
// The raider plans the raid here (steal, fight or the Twins), and it's queued. The next time
// that town checks in with us, it gets the plan, carries out the whole raid at once with its
// own rules on its own player (the same steps as a live raid, through DefendRaid), and sends
// back what happened. Then the raider gets a letter and the spoils. A plan nobody picks up
// within three days is called off and anything paid is given back.

// NightRaid is a planned raid, as sent to the other town.
type NightRaid struct {
	ID     string      `json:"id"`
	Kind   string      `json:"kind"` // steal, fight, arson
	Target string      `json:"target"`
	Att    RaidFighter `json:"att"`
	Picks  int         `json:"picks,omitempty"` // lockpicks the raider brings (at most 3)
}

// NightPending is the raider's side of a planned raid, kept until the result comes back.
type NightPending struct {
	NightRaid
	Peer    string `json:"peer"`
	Town    string `json:"town"`
	AttID   int    `json:"att_id"`
	SnapExp int    `json:"snap_exp"` // the target's Bury Points as last reported (caps the winnings)
	Paid    int    `json:"paid,omitempty"`
	Created int64  `json:"created"`
}

// NightResult is what happened, sent back to the raider's town.
type NightResult struct {
	ID        string `json:"id"`
	Refused   string `json:"refused,omitempty"`
	Name      string `json:"name,omitempty"`
	Parlor    string `json:"parlor,omitempty"`
	Held      bool   `json:"held,omitempty"`       // the padlock held
	UsedPicks int    `json:"used_picks,omitempty"` // lockpicks used up
	Safe      bool   `json:"safe,omitempty"`
	Stolen    int    `json:"stolen,omitempty"`
	TagType   int    `json:"tag_type,omitempty"`
	Outcome   string `json:"outcome,omitempty"` // fights: won, lost
	WinBP     int    `json:"win_bp,omitempty"`
	AttHP     int    `json:"att_hp,omitempty"`
	Saved     bool   `json:"saved,omitempty"` // fires: the smoke detector saved them
	Burned    int    `json:"burned,omitempty"`
	Lost      int    `json:"lost,omitempty"`
}

const NightRaidDays = 3

// planNight shows the night-raid choices for a player in a town that can't be reached now.
func (s *Session) planNight(peer, name, town string, a Action) Screen {
	me := s.me()
	ref := NetRef(peer, name, town)
	info := fmt.Sprintf("%s can't be reached right now: it only connects out, and it isn't checking in at the moment.", town)
	leave := []Button{B("Leave", "comp", "menu").D()}
	if a.Sub == "visit" {
		t := fmt.Sprintf("You can't get to %s tonight.  But you can `wplan a night raid`$ on `w%s`$: it happens the next time %s checks in, usually within a day, and you'll get a letter telling you how it went.  If %s doesn't check in within %d days, the plan is called off.\n\nWhat's the plan?", town, name, town, town, NightRaidDays)
		mk := func(label, kind, key string) Button {
			b := B(label, "xcomp", "night_"+kind).K(key)
			b.Section = ref
			return b
		}
		bs := []Button{mk("Steal tags", "steal", "s"), mk("Pick a fight", "fight", "f")}
		if me.Coffins[Gold] >= arsonCost {
			bs = append(bs, mk(fmt.Sprintf("Send the Twins (%d gold)", arsonCost), "arson", "t"))
		}
		return enemyScr(info, t, append(bs, leave...))
	}
	kind := strings.TrimPrefix(a.Sub, "night_")
	if kind != "steal" && kind != "fight" && kind != "arson" {
		return s.compMenu()
	}
	paid := 0
	if kind == "arson" {
		if me.Coffins[Gold] < arsonCost {
			return enemyScr(info, "The Twins want their gold up front.", leave)
		}
		paid = arsonCost
	}
	snap := 0
	for _, rp := range s.G.Net.RemotePlayers() {
		if rp.Peer == peer && strings.EqualFold(rp.Name, name) {
			snap = rp.Exp
		}
	}
	p := NightPending{NightRaid: NightRaid{ID: newID(), Kind: kind, Target: name, Att: s.me2fighter(), Picks: min(me.Custom.Lockpick, 3)},
		Peer: peer, Town: town, AttID: me.ID, SnapExp: snap, Paid: paid, Created: time.Now().Unix()}
	if err := s.G.Net.QueueNightRaid(p); err != nil {
		return enemyScr(info, "You can't find anyone to drive you there: "+err.Error(), leave)
	}
	me.Fights++
	me.Coffins[Gold] -= paid
	what := map[string]string{"steal": "slip in and take whatever tags aren't nailed down", "fight": "wake " + name + " up and settle things", "arson": "let the Twins take care of " + name + "'s parlor"}[kind]
	return enemyScr(info, fmt.Sprintf("You leave a sealed envelope with the night bus driver to %s.  The plan: %s.\n\nYou'll get a letter when it's done.", town, what), leave)
}

func newID() string {
	const hex = "0123456789abcdef"
	b := make([]byte, 20)
	for i := range b {
		b[i] = hex[random(16)]
	}
	return string(b)
}

// DoNightRaid carries out a planned raid from town (peer) on a player here, all at once, and
// returns what happened. Called with the world lock held.
func (g *Game) DoNightRaid(w *World, peer, town string, q NightRaid) NightResult {
	now := time.Now()
	st := &RaidState{ID: "night-" + q.ID, Peer: peer, Town: town, Created: now, Seen: now}
	res := NightResult{ID: q.ID}
	if q.Kind == "arson" {
		a := g.DefendRaid(w, st, RaidReq{Op: "arson", Target: q.Target, Att: q.Att}, false)
		res.Refused, res.Name, res.Parlor, res.Saved, res.Burned, res.Lost, res.Safe = a.Refused, a.Name, a.Parlor, a.Saved, a.Burned, a.Lost, a.Safe
		return res
	}
	a := g.DefendRaid(w, st, RaidReq{Op: "look", Target: q.Target, Att: q.Att}, false)
	res.Refused, res.Name, res.Parlor = a.Refused, a.Name, a.Parlor
	if a.Refused != "" {
		return res
	}
	if a.Padlock {
		for picks := clamp(q.Picks, 0, 3); picks > 0 && a.Padlock; picks-- {
			res.UsedPicks++
			a = g.DefendRaid(w, st, RaidReq{Op: "picklock", Att: q.Att}, false)
		}
		if a.Padlock {
			res.Held = true
			g.DefendRaid(w, st, RaidReq{Op: "leave", Att: q.Att}, false)
			return res
		}
	}
	if q.Kind == "steal" {
		a = g.DefendRaid(w, st, RaidReq{Op: "steal", Att: q.Att}, false)
		res.Safe, res.Stolen, res.TagType = a.Safe, max(0, a.Stolen), a.TagType
		return res
	}
	a = g.DefendRaid(w, st, RaidReq{Op: "fight", Att: q.Att}, false)
	for i := 0; i < 200 && a.Outcome == "" && a.Refused == ""; i++ {
		a = g.DefendRaid(w, st, RaidReq{Op: "round", Att: q.Att}, false)
	}
	res.Outcome, res.WinBP, res.Stolen, res.TagType, res.AttHP = a.Outcome, a.WinBP, a.Stolen, a.TagType, a.AttHP
	g.DefendRaid(w, st, RaidReq{Op: "yell", Att: q.Att}, false) // puts it in the crime news
	return res
}

// NightRaidDone gives the raider the result of a planned raid. Called with the world lock held.
func (g *Game) NightRaidDone(w *World, p NightPending, r NightResult) {
	me := w.Player(p.AttID)
	if me == nil || !me.Active {
		return
	}
	name := CleanRemote(r.Name, 20, false)
	if name == "" {
		name = p.Target
	}
	head := fmt.Sprintf("\n`wYOUR NIGHT RAID ON %s IN %s\n\n", strings.ToUpper(name), strings.ToUpper(p.Town))
	refund := func(why string) {
		me.Coffins[Gold] += p.Paid
		t := head + "`$" + why
		if p.Paid > 0 {
			t += fmt.Sprintf("\n\nThe Twins give you back your `w%d`$ gold tags.", p.Paid)
		}
		w.AddMail(Letter{To: me.ID, Pic: "places/palors", Text: t + "\n"})
	}
	switch r.Refused {
	case "":
	case "online":
		refund(name + " was up all night working.  Your people came home.")
		return
	case "police":
		refund("The police were parked outside " + name + "'s parlor all night.  Your people came home.")
		return
	case "small":
		refund(name + " is just starting out.  Your people didn't have the heart.")
		return
	case "limit":
		refund("The neighbors in " + p.Town + " are watching " + name + "'s place after all the visitors.  Your people came home.")
		return
	case "off":
		refund(p.Town + " doesn't allow out-of-town business any more.")
		return
	case "expired":
		refund(fmt.Sprintf("%s never checked in, so the plan was called off after %d days.", p.Town, NightRaidDays))
		return
	default:
		refund("Your people couldn't find " + name + "'s parlor anywhere in " + p.Town + ".")
		return
	}
	sin := func() { me.Karma = clamp(me.Karma-w.Config.KarmaSin, 1, 100) }
	if r.UsedPicks > 0 {
		me.Custom.Lockpick = max(0, me.Custom.Lockpick-r.UsedPicks)
	}
	switch {
	case p.Kind == "arson" && r.Saved:
		sin()
		w.AddMail(Letter{To: me.ID, Pic: "stuff/fire_alarm", Text: head + fmt.Sprintf("`$The Twins lit the fire, but a smoke detector went off and it was put out in minutes.  `4%s's parlor is fine.`$  The Twins keep your gold.\n", name)})
	case p.Kind == "arson":
		sin()
		t := fmt.Sprintf("`$The Twins did the job.  %s's parlor burned: `w%d`$ gravestone(s) gone", name, r.Burned)
		if r.Safe {
			t += ", but a safe saved the tags."
		} else {
			t += fmt.Sprintf(" and `w%d`$ wood tag(s) with them.", r.Lost)
		}
		w.AddMail(Letter{To: me.ID, Pic: "places/fire", Text: head + t + "\n"})
	case r.Held:
		w.AddMail(Letter{To: me.ID, Pic: "places/funeral_enemy", Text: head + fmt.Sprintf("`$%s's padlock held.  %s.  Nobody got in.\n", name, ifs(r.UsedPicks > 0, fmt.Sprintf("Your people broke `w%d`$ lockpick(s) on it", r.UsedPicks), "You didn't send any lockpicks"))})
	case p.Kind == "steal":
		t := "`$Your people slipped inside while " + name + " slept.  "
		switch {
		case r.Safe:
			t += "Everything was locked in a safe.  They came back empty-handed."
		case r.Stolen > 0:
			typ := clamp(r.TagType, 0, 2)
			n := clamp(r.Stolen, 0, 3)
			me.Coffins[typ] += n
			sin()
			t += fmt.Sprintf("They came back with `w%d %s tag(s)`$.", n, strings.ToLower(casketName[typ]))
		default:
			t += name + " woke up and they ran for it before they could take anything."
		}
		w.AddMail(Letter{To: me.ID, Pic: "people/man_prowl", Text: head + t + "\n"})
	case r.Outcome == "won":
		win := clamp(r.WinBP, 0, int(float64(p.SnapExp)*0.02)+1)
		expModForce(me, win)
		t := fmt.Sprintf("`$You caught %s asleep and won the fight!  You earn `w%s`$ Bury Points.", name, Cash(win))
		if r.Stolen > 0 {
			typ := clamp(r.TagType, 0, 2)
			n := clamp(r.Stolen, 0, 4)
			me.Coffins[typ] += n
			t += fmt.Sprintf("  You went through %s pockets and found `w%d %s tag(s)`$.", "their", n, strings.ToLower(casketName[typ]))
		}
		sin()
		w.AddMail(Letter{To: me.ID, Pic: "stuff/money_bag_2", Text: head + t + "\n"})
	case r.Outcome == "lost":
		lose := int(float64(me.Exp) * 0.005)
		expModForce(me, -lose)
		me.HP = 0
		w.AddMail(Letter{To: me.ID, Pic: "stuff/battle_lose", Text: head + fmt.Sprintf("`$%s woke up and beat you senseless.  You were driven home in an ambulance.  You lose `w%s`$ Bury Points.\n", name, Cash(lose))})
	default:
		w.AddMail(Letter{To: me.ID, Pic: "places/funeral_enemy", Text: head + "`$Nothing much happened.  Your people got bored and came home.\n"})
	}
}

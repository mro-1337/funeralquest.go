package engine

import (
	"strings"
	"testing"
)

func TestAIPlayers(t *testing.T) {
	g := newTestGame(t)
	var humans []int
	for _, n := range []string{"Alice", "Bobby", "Carla"} {
		p, err := g.CreatePlayer(NewPlayer{Name: n, Parlor: n + " Rest", Logon: strings.ToLower(n), Password: "x"})
		if err != nil {
			t.Fatal(err)
		}
		humans = append(humans, p.ID)
	}
	g.Store.Tx(func(w *World) error {
		for _, id := range humans {
			p := w.Player(id)
			p.Exp, p.Coffins, p.Plots = 2000, [3]int{5, 5, 5}, 20
		}
		return nil
	})
	hits := map[int]map[int]int{} // day -> human -> AI raids
	for day := 0; day < 20; day++ {
		g.Store.Tx(func(w *World) error {
			if day > 0 {
				g.MaintCheck(w, true)
			}
			for step := 0; step < 40; step++ {
				for _, p := range w.Players {
					if p.AI != nil {
						p.AI.Next = 0
					}
				}
				before := map[int]int{}
				for _, id := range humans {
					before[id] = w.Player(id).AIHitDay
				}
				g.aiTick(w)
				for _, id := range humans {
					if hd := w.Player(id).AIHitDay; hd == w.Glo.GameAge && before[id] != hd {
						if hits[hd] == nil {
							hits[hd] = map[int]int{}
						}
						hits[hd][id]++
					}
				}
			}
			return nil
		})
	}
	g.View(func(w *World) {
		ai, str, hp := 0, 0, 0
		for _, p := range w.Active() {
			if p.AI == nil {
				continue
			}
			ai++
			if p.Exp <= 0 || p.Plots <= 0 {
				t.Errorf("%s never sold anything: %d BP %d plots", p.Name, p.Exp, p.Plots)
			}
			if p.Logon != "" || p.Password != "" {
				t.Errorf("%s can be logged into", p.Name)
			}
			str, hp = max(str, p.Strength), max(hp, p.HPMax)
		}
		if ai != 3 {
			t.Fatalf("want 3 AI players, have %d", ai)
		}
		hs, hh := humanAverage(w, &w.Config)
		if str > hs || hp > hh+5 {
			t.Errorf("AI trained past humans: str %d (avg %d) hp %d (avg %d)", str, hs, hp, hh)
		}
		news := w.News(w.Glo.GameAge, "front") + w.News(w.Glo.GameAge, "crime")
		if strings.Contains(news, "%!") {
			t.Errorf("bad news format: %s", news)
		}
		for _, l := range w.Chat {
			if strings.Contains(l.Text, "%!") {
				t.Errorf("bad chat: %s", l.Text)
			}
		}
	})
	for d, m := range hits {
		for id, n := range m {
			if n > 1 {
				t.Errorf("day %d: player %d raided by AI %d times", d, id, n)
			}
		}
	}
	// turning the setting down closes AI parlors
	g.Store.Tx(func(w *World) error { w.Config.AIPlayers = 1; g.aiTick(w); return nil })
	g.View(func(w *World) {
		n := 0
		for _, p := range w.Active() {
			if p.AI != nil {
				n++
			}
		}
		if n != 1 {
			t.Errorf("want 1 AI player after lowering the setting, have %d", n)
		}
	})
}

func TestBankSellsTags(t *testing.T) {
	g := newTestGame(t)
	p, _ := g.CreatePlayer(NewPlayer{Name: "Buyer", Parlor: "Buy Inc", Logon: "buy", Password: "x"})
	g.Store.Tx(func(w *World) error { w.Config.AIPlayers = 0; w.Player(p.ID).Money = 4500; return nil })
	s := g.NewSession(p.ID, "web")
	s.Act(Action{Cmd: "main"})
	s.Act(Action{Cmd: "bank"})
	s.Act(Action{Cmd: "bank", Sub: "buy"})
	var gold0 int
	g.View(func(w *World) { gold0 = w.Player(p.ID).Coffins[Gold] }) // a morning event may have handed out tags
	gold := Gold
	sc := s.Act(Action{Cmd: "bank", Sub: "buy_pick", From: &gold})
	if sc.Input == nil {
		t.Fatal("no amount prompt: " + sc.Text)
	}
	v := "2"
	s.Act(Action{Cmd: "input", Value: &v})
	g.View(func(w *World) {
		me := w.Player(p.ID)
		if me.Money != 500 || me.Coffins[Gold] != gold0+2 {
			t.Fatalf("bought: money %d gold %d", me.Money, me.Coffins[Gold])
		}
	})
	v = "1"
	s.Act(Action{Cmd: "bank", Sub: "buy_pick", From: &gold})
	sc = s.Act(Action{Cmd: "input", Value: &v})
	g.View(func(w *World) {
		if w.Player(p.ID).Coffins[Gold] != gold0+2 {
			t.Fatal("bought a tag without the cash: " + sc.Text)
		}
	})
}

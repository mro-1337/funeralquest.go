package engine

import (
	"fmt"
	"math/rand/v2"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"testing"
)

// TestEveryPictureExists plays the game at random for a long time (rich players, all
// places, the graveyard, church, AI players, letters, maintenance days) and checks that every
// picture and sound a screen or letter asks for is in assets/: the web art (.jxl), the
// door's art (.jxl for JPEG XL terminals and .png for sixel ones) and assets/sound.
func TestEveryPictureExists(t *testing.T) {
	root := filepath.Join("..", "assets")
	if _, err := os.Stat(filepath.Join(root, "web")); err != nil {
		t.Skip("no assets folder")
	}
	pics := map[string]string{}   // key -> where it was seen
	sounds := map[string]string{} // key -> where
	note := func(m map[string]string, k, where string) {
		if k != "" && m[k] == "" {
			m[k] = where
		}
	}
	for run := 0; run < 4; run++ {
		g := newTestGame(t)
		names := []string{"Skelly", "Morticia", "Digger", "Bones"}
		var ss []*Session
		for i, n := range names {
			p, err := g.CreatePlayer(NewPlayer{Name: n, Parlor: n + " Rest", Male: i%2 == 0, Logon: strings.ToLower(n), Password: "pw"})
			if err != nil {
				t.Fatal(err)
			}
			ss = append(ss, g.NewSession(p.ID, "web"))
		}
		g.Store.Tx(func(w *World) error {
			for i, p := range w.Players {
				p.Coffins, p.Money, p.Custom.Lockpick = [3]int{80, 80, 120}, 200000, 3
				p.Exp, p.Plots, p.Karma, p.Luck = 5000+i*3000, 100, 30+run*20, 20+run*20
				if run == 3 {
					p.XP = levelXP(60, 100) // retirement screens
				}
			}
			return nil
		})
		scr := make([]Screen, len(ss))
		for i, s := range ss {
			scr[i] = s.Act(Action{Cmd: "main"})
		}
		for step := 0; step < 8000; step++ {
			i := step % len(ss)
			s, sc := ss[i], scr[i]
			where := sc.Location + " " + sc.View
			note(pics, sc.Pic, where)
			note(pics, sc.BG, where)
			note(sounds, sc.Music, where)
			note(sounds, sc.Sound, where)
			if sc.View == "quit" || sc.View == "gone" {
				s.greeted = false
				scr[i] = s.Act(Action{Cmd: "main"})
				continue
			}
			var a Action
			switch {
			case sc.Input != nil:
				v := "hello there"
				switch sc.Input.Kind {
				case "name":
					v = names[rand.IntN(len(names))][:3]
				case "number":
					v = string(rune('0' + rand.IntN(6)))
				}
				a = Action{Cmd: "input", Value: &v}
			case sc.View == "chat" && rand.IntN(10) < 6:
				s.ChatUpdate("hi")
				continue
			default:
				if len(sc.Buttons) == 0 {
					s.greeted = false
					scr[i] = s.Act(Action{Cmd: "main"})
					continue
				}
				b := sc.Buttons[rand.IntN(len(sc.Buttons))]
				if b.Cmd == "quit" {
					b = sc.Buttons[0]
				}
				a = b.Action
			}
			scr[i] = s.Act(a)
			if step%2000 == 1999 {
				g.Store.Tx(func(w *World) error {
					g.MaintCheck(w, true)
					for _, p := range w.Players {
						p.Coffins[Gold] += 50
						p.HP = p.HPMax
					}
					return nil
				})
			}
		}
		g.View(func(w *World) {
			for _, l := range w.Mail {
				pic := l.Pic
				if pic == "" || pic == "note" {
					pic = "places/desk" // what the desk shows (see the letter screen)
				}
				note(pics, pic, "letter: "+strings.SplitN(StripCodes(l.Text), "\n", 3)[min(1, len(strings.SplitN(StripCodes(l.Text), "\n", 3))-1)])
				note(pics, l.BG, "letter background")
			}
		})
	}
	// every picture the game's data files can name, whether or not the random walk hit it
	g := newTestGame(t)
	d := g.D()
	for _, r := range d.Risks {
		for _, k := range []string{r.StartURL, r.StartBG, r.FailURL, r.FailBG, r.SuccessURL, r.SuccessBG, r.AcceptURL, r.AcceptBG} {
			note(pics, PicKey(k), "risks.txt: "+r.StartMessage[:min(30, len(r.StartMessage))])
		}
	}
	for _, rs := range [][]eventRange{d.Events, d.Yangs, d.YangsNice, d.NoCustomers, d.NewsBlurbs} {
		for _, r := range rs {
			for _, e := range r.Entries {
				note(pics, PicKey(e.Pic), "event: "+e.Title)
			}
		}
	}
	for _, tr := range d.Transport {
		note(pics, PicKey(tr.URL), "transport: "+tr.Name)
	}
	for _, k := range []string{"m_teen", "m_teen_2", "m_adult", "m_adult_2", "m_adult_3", "m_adult_4", "m_old", "m_old_2", "m_old_5", "m_old_6", "f_teen", "f_teen_2", "f_adult", "f_adult_2", "f_old", "f_old_2"} {
		note(pics, "people/"+k, "customer")
	}
	for i := 1; i <= 4; i++ {
		note(pics, fmt.Sprintf("background/background_%d", i), "customer background")
	}
	// every picture named in the Go code
	lit := regexp.MustCompile(`"((?:people|places|stuff|background|animals|hearse|mother|music|ring|ui)/[a-z0-9_.-]+)"`)
	files, _ := filepath.Glob("*.go")
	for _, f := range files {
		b, _ := os.ReadFile(f)
		for _, m := range lit.FindAllStringSubmatch(string(b), -1) {
			if !strings.HasPrefix(m[1], "ui/") {
				note(pics, m[1], f)
			}
		}
	}
	// pictures named in the web pages
	re := regexp.MustCompile(`data-jxl="([^"]+)"`)
	for _, f := range []string{"../web/public/index.html"} {
		b, _ := os.ReadFile(f)
		for _, m := range re.FindAllStringSubmatch(string(b), -1) {
			note(pics, m[1], f)
		}
	}

	var bad []string
	for k, where := range pics {
		if _, err := os.Stat(filepath.Join(root, "web", k+".jxl")); err != nil {
			bad = append(bad, "web art missing: "+k+"  (seen at "+where+")")
		}
		if strings.HasPrefix(where, "../web") {
			continue // web page decoration, not drawn by the door
		}
		if _, err := os.Stat(filepath.Join(root, "door", k+".jxl")); err != nil {
			bad = append(bad, "door JPEG XL art missing: "+k+"  (seen at "+where+")")
		}
		if _, err := os.Stat(filepath.Join(root, "door", k+".png")); err != nil {
			bad = append(bad, "door sixel art missing: "+k+"  (seen at "+where+")")
		}
	}
	for k, where := range sounds {
		if _, err := os.Stat(filepath.Join(root, "sound", k+".ogg")); err != nil {
			bad = append(bad, "sound missing: "+k+"  (heard at "+where+")")
		}
	}
	sort.Strings(bad)
	for _, b := range bad {
		t.Error(b)
	}
	t.Logf("checked %d pictures and %d sounds", len(pics), len(sounds))
}

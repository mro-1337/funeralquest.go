package web_test

import (
	"strings"
	"testing"

	"funeralquest/captcha"
)

func TestSignupEmailForgotContact(t *testing.T) {
	a, ts, _ := setup(t)
	reg := map[string]any{"logon": "edna", "password": "secret1", "password2": "secret1", "name": "Edna", "parlor": "Edna's Rest", "male": false}
	if _, r := post(t, ts.URL+"/api/register", reg, nil); r["error"] == nil {
		t.Fatal("sign-up without an e-mail address accepted")
	}
	reg["email"] = "edna@example.com"
	if _, r := post(t, ts.URL+"/api/register", reg, nil); r["error"] != nil {
		t.Fatalf("sign-up: %v", r["error"])
	}
	// the stone picture
	_, c := post(t, ts.URL+"/api/captcha", map[string]any{}, nil)
	id, _ := c["id"].(string)
	code, img, hdr := get(t, ts.URL+"/api/captcha/"+id+".png", nil)
	if code != 200 || hdr.Get("Content-Type") != "image/png" || len(img) < 500 {
		t.Fatalf("captcha image: %d %s", code, hdr.Get("Content-Type"))
	}
	// wrong letters
	if _, r := post(t, ts.URL+"/api/forgot", map[string]any{"logon": "edna", "email": "edna@example.com", "captchaID": id, "captcha": "nope"}, nil); r["captcha"] != true {
		t.Fatalf("wrong captcha: %v", r)
	}
	// right letters
	id, ans := captcha.New()
	if _, r := post(t, ts.URL+"/api/forgot", map[string]any{"logon": "edna", "email": "edna@example.com", "note": "my parlor is Edna's Rest", "captchaID": id, "captcha": strings.ToLower(ans)}, nil); r["error"] != nil {
		t.Fatalf("forgot: %v", r["error"])
	}
	id, ans = captcha.New()
	if _, r := post(t, ts.URL+"/api/contact", map[string]any{"name": "Vern", "email": "vern@example.com", "note": "love the game", "captchaID": id, "captcha": ans}, nil); r["error"] != nil {
		t.Fatalf("contact: %v", r["error"])
	}
	notes := a.Notes.Unread()
	if len(notes) != 2 {
		t.Fatalf("notes: %+v", notes)
	}
	f := notes[0]
	if f.Logon != "edna" || f.OnFile != "edna@example.com" || !strings.Contains(f.Account, "Edna") || !strings.Contains(f.Text, "Edna's Rest") {
		t.Fatalf("forgot note: %+v", f)
	}
	if notes[1].Name != "Vern" || notes[1].Text != "love the game" {
		t.Fatalf("contact note: %+v", notes[1])
	}
	// a captcha works only once
	if _, r := post(t, ts.URL+"/api/contact", map[string]any{"name": "Vern", "email": "vern@example.com", "note": "again", "captchaID": id, "captcha": ans}, nil); r["captcha"] != true {
		t.Fatal("captcha reused")
	}
}

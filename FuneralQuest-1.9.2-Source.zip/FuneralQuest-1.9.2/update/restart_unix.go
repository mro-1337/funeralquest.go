//go:build !windows

package update

import (
	"os"
	"syscall"
)

// restartSelf replaces this process with the (new) program, keeping its arguments and process
// ID, so service managers such as systemd don't notice.
func restartSelf(exe string) error {
	return syscall.Exec(exe, os.Args, append(os.Environ(), "FQ_RESTARTED=1"))
}

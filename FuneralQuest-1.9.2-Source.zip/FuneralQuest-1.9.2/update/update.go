// Package update checks GitHub for a newer Funeral Quest release and installs it in place:
// it downloads the Windows or Linux package from the project's Releases page, backs up the
// data folder, keeps a copy of every file it replaces (so the update can be undone), never
// touches data/, keeps gamedata/*.txt files the sysop has edited, and restarts the program.
package update

import (
	"archive/tar"
	"archive/zip"
	"compress/gzip"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path"
	"path/filepath"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

// DefaultRepo is where official releases are published.
const DefaultRepo = "mro-1337/funeralquest.go"

// API is GitHub's API address (tests point it at a local server, also through FQ_UPDATE_API).
var API = func() string {
	if a := os.Getenv("FQ_UPDATE_API"); a != "" {
		return strings.TrimRight(a, "/")
	}
	return "https://api.github.com"
}()

const maxPackage = 400 << 20

// Release is the newest release found on GitHub.
type Release struct {
	Version   string    `json:"version"` // "1.9.1"
	Tag       string    `json:"tag"`
	Name      string    `json:"name"`
	Notes     string    `json:"notes"`
	Page      string    `json:"page"`
	Published time.Time `json:"published"`
	Asset     Asset     `json:"asset"`
}

// Asset is the package for this kind of computer.
type Asset struct {
	Name   string `json:"name"`
	URL    string `json:"url"`
	Size   int64  `json:"size"`
	Digest string `json:"digest,omitempty"` // "sha256:..." when GitHub gives one
}

// PackageSuffix is the end of the release file name for this operating system.
func PackageSuffix() (string, bool) {
	switch runtime.GOOS {
	case "windows":
		return "-Windows.zip", true
	case "linux":
		return "-Linux.tar.gz", true
	}
	return "", false
}

// Programs are the names of fq and fqedit for this operating system and processor, as they are
// in the release packages.
func Programs() (fq, fqedit string) {
	suf := map[string]string{
		"windows/amd64": ".exe", "windows/386": "32.exe", "windows/arm64": "-arm64.exe",
		"linux/amd64": "-linux", "linux/386": "-linux32", "linux/arm64": "-linux-arm64", "linux/arm": "-linux-arm",
	}[runtime.GOOS+"/"+runtime.GOARCH]
	if suf == "" {
		return "", ""
	}
	return "fq" + suf, "fqedit" + suf
}

// Newer reports whether version a is newer than b ("1.10.0" > "1.9.2").
func Newer(a, b string) bool {
	pa, pb := nums(a), nums(b)
	for i := 0; i < len(pa) || i < len(pb); i++ {
		x, y := at(pa, i), at(pb, i)
		if x != y {
			return x > y
		}
	}
	return false
}

func nums(v string) []int {
	v = strings.TrimPrefix(strings.TrimSpace(v), "v")
	if i := strings.IndexAny(v, "-+ "); i >= 0 {
		v = v[:i]
	}
	var out []int
	for _, p := range strings.Split(v, ".") {
		n, _ := strconv.Atoi(p)
		out = append(out, n)
	}
	return out
}

func at(s []int, i int) int {
	if i < len(s) {
		return s[i]
	}
	return 0
}

var client = &http.Client{Timeout: 10 * time.Minute}

// Latest asks GitHub for the newest published release of repo ("owner/name").
func Latest(ctx context.Context, repo string) (*Release, error) {
	if repo == "" {
		repo = DefaultRepo
	}
	if strings.Count(repo, "/") != 1 || strings.ContainsAny(repo, " ?#\\") {
		return nil, fmt.Errorf("%q isn't a GitHub project; it should look like owner/name", repo)
	}
	ctx, cancel := context.WithTimeout(ctx, 30*time.Second)
	defer cancel()
	req, _ := http.NewRequestWithContext(ctx, "GET", API+"/repos/"+repo+"/releases/latest", nil)
	req.Header.Set("Accept", "application/vnd.github+json")
	req.Header.Set("User-Agent", "FuneralQuest-updater")
	resp, err := client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("couldn't reach GitHub: %v", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode == 404 {
		return nil, fmt.Errorf("no releases found on github.com/%s (the project has to publish releases on its Releases page)", repo)
	}
	if resp.StatusCode != 200 {
		var e struct{ Message string }
		json.NewDecoder(io.LimitReader(resp.Body, 64<<10)).Decode(&e)
		if (resp.StatusCode == 403 || resp.StatusCode == 429) && strings.Contains(strings.ToLower(e.Message), "rate limit") {
			return nil, errors.New("GitHub is limiting how often this address may ask; try again in an hour")
		}
		if e.Message != "" {
			return nil, fmt.Errorf("GitHub answered %s: %s", resp.Status, e.Message)
		}
		return nil, fmt.Errorf("GitHub answered %s", resp.Status)
	}
	var r struct {
		Tag       string    `json:"tag_name"`
		Name      string    `json:"name"`
		Body      string    `json:"body"`
		Page      string    `json:"html_url"`
		Draft     bool      `json:"draft"`
		Pre       bool      `json:"prerelease"`
		Published time.Time `json:"published_at"`
		Assets    []struct {
			Name   string `json:"name"`
			URL    string `json:"browser_download_url"`
			Size   int64  `json:"size"`
			Digest string `json:"digest"`
		} `json:"assets"`
	}
	if err := json.NewDecoder(io.LimitReader(resp.Body, 4<<20)).Decode(&r); err != nil {
		return nil, fmt.Errorf("couldn't read GitHub's answer: %v", err)
	}
	rel := &Release{Version: strings.TrimPrefix(strings.TrimSpace(r.Tag), "v"), Tag: r.Tag, Name: r.Name,
		Notes: r.Body, Page: r.Page, Published: r.Published}
	if len(nums(rel.Version)) < 2 {
		return nil, fmt.Errorf("the newest release's tag %q isn't a version number like v1.9.1", r.Tag)
	}
	suf, ok := PackageSuffix()
	if !ok {
		return rel, nil
	}
	for _, a := range r.Assets {
		if strings.HasSuffix(a.Name, suf) {
			rel.Asset = Asset{a.Name, a.URL, a.Size, a.Digest}
			break
		}
	}
	return rel, nil
}

// ---- status shared by the web pages ----

// Status is what the sysop pages show.
type Status struct {
	Current   string    `json:"current"`
	Checked   time.Time `json:"checked"`
	Latest    *Release  `json:"latest,omitempty"`
	Available bool      `json:"available"`
	Error     string    `json:"error,omitempty"`
	Busy      string    `json:"busy,omitempty"`    // what an install is doing right now
	Message   string    `json:"message,omitempty"` // how the last install or undo went
	Last      *Record   `json:"last,omitempty"`    // the last update installed here
	CanUndo   bool      `json:"can_undo"`
	Supported bool      `json:"supported"`
}

var (
	mu     sync.Mutex
	status Status
)

// Check asks GitHub and remembers the answer for Current.
func Check(ctx context.Context, repo, current string) Status {
	rel, err := Latest(ctx, repo)
	mu.Lock()
	defer mu.Unlock()
	status.Current, status.Checked, status.Error = current, time.Now(), ""
	if err != nil {
		status.Error = err.Error()
	} else {
		status.Latest = rel
		status.Available = Newer(rel.Version, current)
	}
	return status
}

// Current returns the last check's result plus what's installed in home.
func Current(home, current string) Status {
	mu.Lock()
	s := status
	mu.Unlock()
	s.Current = current
	_, s.Supported = PackageSuffix()
	if fq, _ := Programs(); fq == "" {
		s.Supported = false
	}
	if s.Latest != nil {
		s.Available = Newer(s.Latest.Version, current)
	}
	if r, err := LastRecord(home); err == nil {
		s.Last = r
		s.CanUndo = r.Previous != "" && dirExists(filepath.Join(home, r.Previous))
	}
	return s
}

// Shipped holds the sha256 of each gamedata file as this version shipped it (set by main), so an
// update can tell which ones the sysop has edited.
var Shipped map[string]string

// Start installs the newest release (checking GitHub again first) in the background. When it's
// done, restart is called to run the new version. Progress shows in Current.
func Start(o Options, repo string, restart func()) error {
	if !installMu.TryLock() {
		return errors.New("an update is already being installed")
	}
	installMu.Unlock()
	setBusy("asking GitHub for the newest release")
	mu.Lock()
	status.Message, status.Error = "", ""
	mu.Unlock()
	go func() {
		st := Check(context.Background(), repo, o.Current)
		if st.Error != "" {
			setBusy("")
			return
		}
		if !st.Available {
			finish("You already have the newest version ("+o.Current+").", nil)
			return
		}
		if o.Shipped == nil {
			o.Shipped = Shipped
		}
		rec, err := Install(context.Background(), st.Latest, o)
		if err != nil {
			finish("", err)
			return
		}
		msg := "Funeral Quest " + rec.To + " is installed. Restarting..."
		if len(rec.Kept) > 0 {
			msg += " Your edited " + strings.Join(rec.Kept, ", ") + " were kept; the new versions are beside them as .new files."
		}
		finish(msg, nil)
		if restart != nil {
			time.Sleep(3 * time.Second) // let the page see the message
			restart()
		}
	}()
	return nil
}

// StartUndo puts the previous version back in the background, then calls restart.
func StartUndo(home, current string, restart func()) error {
	setBusy("putting the previous version back")
	go func() {
		r, err := Undo(home, "")
		if err != nil {
			finish("", err)
			return
		}
		finish("Funeral Quest "+r.From+" is back. Restarting... (The data folder wasn't changed. If the newer version changed it, its backup "+r.Backup+" is in data/backups.)", nil)
		if restart != nil {
			time.Sleep(3 * time.Second)
			restart()
		}
	}()
	return nil
}

func finish(msg string, err error) {
	mu.Lock()
	status.Busy, status.Message, status.Error = "", msg, ""
	if err != nil {
		status.Error = err.Error()
	}
	mu.Unlock()
}

func setBusy(b string) {
	mu.Lock()
	status.Busy = b
	mu.Unlock()
}

// ---- installing ----

// Options for Install.
type Options struct {
	Home    string            // install folder (holds gamedata/ and data/)
	Exe     string            // the running program; empty = os.Executable()
	Current string            // running version
	Shipped map[string]string // gamedata file name -> sha256 of the copy this version shipped with
	Backup  func(label string) (string, error)
	Log     func(format string, args ...any)
}

// Record describes an installed update (data/update/last.json).
type Record struct {
	From     string    `json:"from"`
	To       string    `json:"to"`
	When     time.Time `json:"when"`
	Backup   string    `json:"backup"`
	Previous string    `json:"previous"` // folder (relative to home) with the replaced files
	Added    []string  `json:"added"`    // files that didn't exist before
	Kept     []string  `json:"kept"`     // edited gamedata files left alone (new copy saved as .new)
	UndoneAt time.Time `json:"undone_at,omitempty"`
}

func workDir(home string) string { return filepath.Join(home, "data", "update") }

// LastRecord reads the last update's record.
func LastRecord(home string) (*Record, error) {
	b, err := os.ReadFile(filepath.Join(workDir(home), "last.json"))
	if err != nil {
		return nil, err
	}
	var r Record
	return &r, json.Unmarshal(b, &r)
}

var installMu sync.Mutex

// Install downloads rel and puts it in place. The caller restarts the program afterwards.
func Install(ctx context.Context, rel *Release, o Options) (*Record, error) {
	if !installMu.TryLock() {
		return nil, errors.New("an update is already being installed")
	}
	defer installMu.Unlock()
	defer setBusy("")
	logf := o.Log
	if logf == nil {
		logf = func(string, ...any) {}
	}
	if rel == nil || rel.Asset.URL == "" {
		return nil, errors.New("this release has no package for this kind of computer")
	}
	if !Newer(rel.Version, o.Current) {
		return nil, fmt.Errorf("version %s is already installed", o.Current)
	}
	fqName, _ := Programs()
	if fqName == "" {
		return nil, fmt.Errorf("there are no ready-made programs for %s/%s; build from source instead", runtime.GOOS, runtime.GOARCH)
	}
	exe := o.Exe
	if exe == "" {
		e, err := os.Executable()
		if err != nil {
			return nil, err
		}
		exe = e
	}
	if e, err := filepath.EvalSymlinks(exe); err == nil {
		exe = e
	}
	work := workDir(o.Home)
	stage := filepath.Join(work, "stage")
	os.RemoveAll(stage)
	if err := os.MkdirAll(stage, 0o755); err != nil {
		return nil, err
	}
	defer os.RemoveAll(stage)

	setBusy("downloading " + rel.Asset.Name)
	logf("update: downloading %s", rel.Asset.URL)
	pkg := filepath.Join(work, rel.Asset.Name)
	if err := download(ctx, rel.Asset, pkg); err != nil {
		os.Remove(pkg)
		return nil, err
	}
	defer os.Remove(pkg)

	setBusy("unpacking")
	if err := extract(pkg, stage); err != nil {
		return nil, fmt.Errorf("couldn't unpack %s: %v", rel.Asset.Name, err)
	}
	if v, err := os.ReadFile(filepath.Join(stage, "VERSION")); err != nil || strings.TrimSpace(string(v)) != rel.Version {
		return nil, fmt.Errorf("%s doesn't look like Funeral Quest %s (its VERSION file is missing or different)", rel.Asset.Name, rel.Version)
	}
	if !fileExists(filepath.Join(stage, fqName)) {
		return nil, fmt.Errorf("%s has no %s in it", rel.Asset.Name, fqName)
	}

	setBusy("backing up the data folder")
	rec := &Record{From: o.Current, To: rel.Version, When: time.Now()}
	if o.Backup != nil {
		b, err := o.Backup("before-update-" + rel.Version)
		if err != nil {
			return nil, fmt.Errorf("couldn't back up the data folder first: %v", err)
		}
		rec.Backup = filepath.Base(b)
	}

	setBusy("installing")
	files, err := listFiles(stage)
	if err != nil {
		return nil, err
	}
	prevRel := filepath.Join("data", "update", "previous-"+safe(o.Current))
	prev := filepath.Join(o.Home, prevRel)
	os.RemoveAll(prev)
	// where each staged file goes; the running program also gets the new fq if it was renamed
	type move struct{ src, dst, rel string }
	var moves []move
	for _, f := range files {
		if f == "data" || strings.HasPrefix(f, "data/") {
			continue // never touch players, settings or backups
		}
		moves = append(moves, move{filepath.Join(stage, filepath.FromSlash(f)), filepath.Join(o.Home, filepath.FromSlash(f)), f})
	}
	if !samePath(exe, filepath.Join(o.Home, fqName)) {
		moves = append(moves, move{filepath.Join(stage, fqName), exe, "@exe"})
	}
	// first save every file that will be replaced, so nothing is half done if the disk is full
	for _, m := range moves {
		if !fileExists(m.dst) {
			if m.rel != "@exe" {
				rec.Added = append(rec.Added, m.rel)
			}
			continue
		}
		keep := m.rel
		if keep == "@exe" {
			keep = "@exe/" + filepath.Base(exe)
		}
		if err := copyFile(m.dst, filepath.Join(prev, filepath.FromSlash(keep))); err != nil {
			return nil, fmt.Errorf("couldn't keep a copy of %s: %v", m.dst, err)
		}
	}
	rec.Previous = filepath.ToSlash(prevRel)
	// gamedata: keep the sysop's edits
	var failed []string
	for _, m := range moves {
		if strings.HasPrefix(m.rel, "gamedata/") && fileExists(m.dst) {
			cur, newer := sum(m.dst), sum(m.src)
			if cur != newer && cur != o.Shipped[path.Base(m.rel)] {
				if err := copyFile(m.src, m.dst+".new"); err == nil {
					rec.Kept = append(rec.Kept, m.rel)
				}
				continue
			}
		}
		if err := replace(m.src, m.dst); err != nil {
			failed = append(failed, fmt.Sprintf("%s (%v)", m.dst, err))
		}
	}
	sort.Strings(rec.Kept)
	b, _ := json.MarshalIndent(rec, "", "  ")
	os.WriteFile(filepath.Join(work, "last.json"), b, 0o644)
	if len(failed) > 0 {
		logf("update: some files couldn't be replaced: %s", strings.Join(failed, "; "))
		return rec, fmt.Errorf("%d files couldn't be replaced (are they open in another program?): %s. Use Undo to go back, or close the other program and try again", len(failed), strings.Join(first(failed, 5), "; "))
	}
	logf("update: installed %s (was %s); data backed up to %s", rel.Version, o.Current, rec.Backup)
	return rec, nil
}

// Undo puts back the files the last update replaced and removes the ones it added.
// The data folder isn't changed; the record names the backup made before the update.
func Undo(home, exe string) (*Record, error) {
	if !installMu.TryLock() {
		return nil, errors.New("an update is being installed")
	}
	defer installMu.Unlock()
	r, err := LastRecord(home)
	if err != nil {
		return nil, errors.New("there's no update to undo")
	}
	prev := filepath.Join(home, filepath.FromSlash(r.Previous))
	if r.Previous == "" || !dirExists(prev) {
		return nil, errors.New("the copy of the previous version is gone")
	}
	if exe == "" {
		exe, _ = os.Executable()
	}
	files, err := listFiles(prev)
	if err != nil {
		return nil, err
	}
	var failed []string
	for _, f := range files {
		dst := filepath.Join(home, filepath.FromSlash(f))
		if strings.HasPrefix(f, "@exe/") {
			dst = exe
		}
		if err := replace(filepath.Join(prev, filepath.FromSlash(f)), dst); err != nil {
			failed = append(failed, dst)
		}
	}
	for _, f := range r.Added {
		os.Remove(filepath.Join(home, filepath.FromSlash(f)))
	}
	for _, f := range r.Kept {
		os.Remove(filepath.Join(home, filepath.FromSlash(f)) + ".new")
	}
	if len(failed) > 0 {
		return r, fmt.Errorf("couldn't put back: %s", strings.Join(first(failed, 5), "; "))
	}
	os.RemoveAll(prev)
	r.UndoneAt, r.Previous = time.Now(), ""
	b, _ := json.MarshalIndent(r, "", "  ")
	os.WriteFile(filepath.Join(workDir(home), "last.json"), b, 0o644)
	return r, nil
}

func first(s []string, n int) []string {
	if len(s) > n {
		return append(s[:n:n], "...")
	}
	return s
}

func safe(v string) string {
	return strings.Map(func(r rune) rune {
		if r >= '0' && r <= '9' || r == '.' || r >= 'a' && r <= 'z' || r >= 'A' && r <= 'Z' {
			return r
		}
		return '_'
	}, v)
}

func download(ctx context.Context, a Asset, to string) error {
	if a.Size > maxPackage {
		return fmt.Errorf("%s is too big (%d MB)", a.Name, a.Size>>20)
	}
	if !strings.HasPrefix(a.URL, "https://") && !strings.HasPrefix(a.URL, API) {
		return fmt.Errorf("refusing to download from %s", a.URL)
	}
	req, _ := http.NewRequestWithContext(ctx, "GET", a.URL, nil)
	req.Header.Set("User-Agent", "FuneralQuest-updater")
	resp, err := client.Do(req)
	if err != nil {
		return fmt.Errorf("download failed: %v", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return fmt.Errorf("download failed: %s", resp.Status)
	}
	f, err := os.Create(to)
	if err != nil {
		return err
	}
	h := sha256.New()
	n, err := io.Copy(io.MultiWriter(f, h), io.LimitReader(resp.Body, maxPackage+1))
	if cerr := f.Close(); err == nil {
		err = cerr
	}
	if err != nil {
		return fmt.Errorf("download failed: %v", err)
	}
	if n > maxPackage || (a.Size > 0 && n != a.Size) {
		return fmt.Errorf("download of %s was incomplete (%d of %d bytes)", a.Name, n, a.Size)
	}
	if d, ok := strings.CutPrefix(a.Digest, "sha256:"); ok && !strings.EqualFold(d, hex.EncodeToString(h.Sum(nil))) {
		return fmt.Errorf("download of %s is damaged (its checksum doesn't match GitHub's)", a.Name)
	}
	return nil
}

// extract unpacks a .zip or .tar.gz into dir, dropping the top folder (FuneralQuest-1.9.1/).
func extract(pkg, dir string) error {
	put := func(name string, mode os.FileMode, r io.Reader) error {
		name = strings.ReplaceAll(name, "\\", "/")
		if i := strings.Index(name, "/"); i >= 0 {
			name = name[i+1:]
		} else {
			return nil // a file outside the top folder
		}
		clean := path.Clean(name)
		if name == "" || clean == "." || strings.HasPrefix(clean, "../") || clean == ".." || path.IsAbs(clean) || strings.Contains(clean, ":") {
			return nil
		}
		dst := filepath.Join(dir, filepath.FromSlash(clean))
		if err := os.MkdirAll(filepath.Dir(dst), 0o755); err != nil {
			return err
		}
		if mode&0o111 != 0 || isProgram(path.Base(clean)) {
			mode = 0o755
		} else {
			mode = 0o644
		}
		f, err := os.OpenFile(dst, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, mode)
		if err != nil {
			return err
		}
		_, err = io.Copy(f, io.LimitReader(r, maxPackage))
		if cerr := f.Close(); err == nil {
			err = cerr
		}
		return err
	}
	if strings.HasSuffix(pkg, ".zip") {
		z, err := zip.OpenReader(pkg)
		if err != nil {
			return err
		}
		defer z.Close()
		for _, f := range z.File {
			if f.FileInfo().IsDir() || !f.Mode().IsRegular() {
				continue
			}
			r, err := f.Open()
			if err != nil {
				return err
			}
			err = put(f.Name, f.Mode(), r)
			r.Close()
			if err != nil {
				return err
			}
		}
		return nil
	}
	fh, err := os.Open(pkg)
	if err != nil {
		return err
	}
	defer fh.Close()
	gz, err := gzip.NewReader(fh)
	if err != nil {
		return err
	}
	tr := tar.NewReader(gz)
	for {
		h, err := tr.Next()
		if err == io.EOF {
			return nil
		}
		if err != nil {
			return err
		}
		if h.Typeflag != tar.TypeReg {
			continue
		}
		if err := put(h.Name, os.FileMode(h.Mode), tr); err != nil {
			return err
		}
	}
}

func isProgram(name string) bool {
	return strings.HasSuffix(name, ".exe") || strings.HasSuffix(name, ".sh") ||
		(strings.HasPrefix(name, "fq") && strings.Contains(name, "-linux"))
}

func listFiles(root string) ([]string, error) {
	var out []string
	err := filepath.WalkDir(root, func(p string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if d.Type().IsRegular() {
			r, _ := filepath.Rel(root, p)
			out = append(out, filepath.ToSlash(r))
		}
		return nil
	})
	return out, err
}

// replace puts a copy of src at dst. A running program can't be overwritten on Windows but can
// be renamed, so dst is moved aside to dst.old first when needed.
func replace(src, dst string) error {
	if err := os.MkdirAll(filepath.Dir(dst), 0o755); err != nil {
		return err
	}
	tmp := dst + ".update-tmp"
	if err := copyFile(src, tmp); err != nil {
		os.Remove(tmp)
		return err
	}
	if err := os.Rename(tmp, dst); err == nil {
		return nil
	}
	old := dst + ".old"
	if err := os.Remove(old); err != nil && !os.IsNotExist(err) {
		old = fmt.Sprintf("%s.%d.old", dst, time.Now().UnixNano())
	}
	if err := os.Rename(dst, old); err != nil {
		os.Remove(tmp)
		return err
	}
	if err := os.Rename(tmp, dst); err != nil {
		os.Rename(old, dst)
		os.Remove(tmp)
		return err
	}
	return nil
}

func copyFile(src, dst string) error {
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	st, err := in.Stat()
	if err != nil {
		return err
	}
	if err := os.MkdirAll(filepath.Dir(dst), 0o755); err != nil {
		return err
	}
	out, err := os.OpenFile(dst, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, st.Mode().Perm()|0o200)
	if err != nil {
		return err
	}
	_, err = io.Copy(out, in)
	if cerr := out.Close(); err == nil {
		err = cerr
	}
	if err == nil {
		os.Chmod(dst, st.Mode().Perm())
	}
	return err
}

// CleanOld removes the .old copies an earlier update left beside files it couldn't overwrite
// (programs that were running; they can only be deleted once nothing runs them).
func CleanOld(home string) {
	filepath.WalkDir(home, func(p string, d os.DirEntry, err error) error {
		if err != nil {
			return nil
		}
		if d.IsDir() && (d.Name() == "data" || d.Name() == ".git") {
			return filepath.SkipDir
		}
		if !d.IsDir() && strings.HasSuffix(d.Name(), ".old") && fileExists(strings.TrimSuffix(p, ".old")) {
			os.Remove(p)
		}
		return nil
	})
}

func sum(p string) string {
	f, err := os.Open(p)
	if err != nil {
		return ""
	}
	defer f.Close()
	h := sha256.New()
	io.Copy(h, f)
	return hex.EncodeToString(h.Sum(nil))
}

// Sums hashes every file in a folder (for the gamedata files a version ships with).
func Sums(files map[string][]byte) map[string]string {
	out := map[string]string{}
	for n, b := range files {
		h := sha256.Sum256(b)
		out[n] = hex.EncodeToString(h[:])
	}
	return out
}

func fileExists(p string) bool {
	st, err := os.Stat(p)
	return err == nil && st.Mode().IsRegular()
}

func dirExists(p string) bool {
	st, err := os.Stat(p)
	return err == nil && st.IsDir()
}

func samePath(a, b string) bool {
	if x, err := filepath.Abs(a); err == nil {
		a = x
	}
	if x, err := filepath.Abs(b); err == nil {
		b = x
	}
	if runtime.GOOS == "windows" {
		return strings.EqualFold(a, b)
	}
	return a == b
}

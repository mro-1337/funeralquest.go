package update

import (
	"archive/tar"
	"archive/zip"
	"bytes"
	"compress/gzip"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
)

func TestNewer(t *testing.T) {
	for _, c := range []struct {
		a, b string
		want bool
	}{{"1.9.1", "1.9.0", true}, {"v1.10.0", "1.9.9", true}, {"1.9.0", "1.9.0", false}, {"1.8.2", "1.9.0", false}, {"2.0", "1.99.99", true}, {"1.9.0-beta", "1.8.0", true}} {
		if got := Newer(c.a, c.b); got != c.want {
			t.Errorf("Newer(%s,%s) = %v", c.a, c.b, got)
		}
	}
}

// pkg builds a release package for this OS with the given files (under FuneralQuest-<v>/).
func pkg(t *testing.T, v string, files map[string]string) []byte {
	var buf bytes.Buffer
	top := "FuneralQuest-" + v + "/"
	if runtime.GOOS == "windows" {
		z := zip.NewWriter(&buf)
		for n, c := range files {
			w, _ := z.Create(top + n)
			w.Write([]byte(c))
		}
		z.Close()
		return buf.Bytes()
	}
	gz := gzip.NewWriter(&buf)
	tw := tar.NewWriter(gz)
	for n, c := range files {
		mode := int64(0o644)
		if strings.HasPrefix(n, "fq") {
			mode = 0o755
		}
		tw.WriteHeader(&tar.Header{Name: top + n, Mode: mode, Size: int64(len(c)), Typeflag: tar.TypeReg})
		tw.Write([]byte(c))
	}
	// a file trying to escape the install folder must be ignored
	evil := "nope"
	tw.WriteHeader(&tar.Header{Name: top + "../../evil.txt", Mode: 0o644, Size: int64(len(evil)), Typeflag: tar.TypeReg})
	tw.Write([]byte(evil))
	tw.Close()
	gz.Close()
	return buf.Bytes()
}

func TestInstallAndUndo(t *testing.T) {
	suf, ok := PackageSuffix()
	fq, fqedit := Programs()
	if !ok || fq == "" {
		t.Skip("no packages for this platform")
	}
	home := t.TempDir()
	write := func(rel, c string) {
		p := filepath.Join(home, filepath.FromSlash(rel))
		os.MkdirAll(filepath.Dir(p), 0o755)
		os.WriteFile(p, []byte(c), 0o644)
	}
	read := func(rel string) string {
		b, _ := os.ReadFile(filepath.Join(home, filepath.FromSlash(rel)))
		return string(b)
	}
	// the installed 1.9.0
	write("VERSION", "1.9.0\n")
	write(fq, "old fq")
	write(fqedit, "old fqedit")
	write("assets/web/map.jxl", "old map")
	write("gamedata/events.txt", "old events")         // as shipped
	write("gamedata/risks.txt", "my own risks")        // edited by the sysop
	write("gamedata/karma.txt", "old karma")           // as shipped
	write("data/world.json", `{"players":"precious"}`) // must never change
	shipped := Sums(map[string][]byte{"events.txt": []byte("old events"), "risks.txt": []byte("old risks"), "karma.txt": []byte("old karma")})

	files := map[string]string{
		"VERSION": "1.9.1\n", fq: "new fq", fqedit: "new fqedit", "assets/web/map.jxl": "new map",
		"assets/web/new.jxl": "brand new", "gamedata/events.txt": "new events", "gamedata/risks.txt": "new risks",
		"gamedata/karma.txt": "old karma", "data/world.json": "EMPTY WORLD",
	}
	body := pkg(t, "1.9.1", files)
	h := sha256.Sum256(body)
	name := "FuneralQuest-1.9.1" + suf
	var srv *httptest.Server
	srv = httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/repos/me/fq/releases/latest":
			json.NewEncoder(w).Encode(map[string]any{"tag_name": "v1.9.1", "name": "1.9.1", "body": "Hospital!", "html_url": "x",
				"assets": []map[string]any{
					{"name": "FuneralQuest-1.9.1-Source.zip", "browser_download_url": srv.URL + "/src", "size": 3},
					{"name": name, "browser_download_url": srv.URL + "/dl", "size": len(body), "digest": "sha256:" + hex.EncodeToString(h[:])},
				}})
		case "/dl":
			w.Write(body)
		default:
			http.NotFound(w, r)
		}
	}))
	defer srv.Close()
	API = srv.URL

	rel, err := Latest(context.Background(), "me/fq")
	if err != nil {
		t.Fatal(err)
	}
	if rel.Version != "1.9.1" || rel.Asset.Name != name {
		t.Fatalf("latest = %+v", rel)
	}
	if _, err := Latest(context.Background(), "me/none"); err == nil || !strings.Contains(err.Error(), "no releases") {
		t.Fatalf("missing project: %v", err)
	}
	backed := ""
	rec, err := Install(context.Background(), rel, Options{Home: home, Exe: filepath.Join(home, fq), Current: "1.9.0", Shipped: shipped,
		Backup: func(l string) (string, error) { backed = l; return "b.zip", nil }})
	if err != nil {
		t.Fatal(err)
	}
	if backed != "before-update-1.9.1" {
		t.Errorf("backup label %q", backed)
	}
	for rel, want := range map[string]string{"VERSION": "1.9.1\n", fq: "new fq", fqedit: "new fqedit", "assets/web/map.jxl": "new map",
		"assets/web/new.jxl": "brand new", "gamedata/events.txt": "new events", "gamedata/risks.txt": "my own risks",
		"gamedata/risks.txt.new": "new risks", "data/world.json": `{"players":"precious"}`} {
		if got := read(rel); got != want {
			t.Errorf("%s = %q, want %q", rel, got, want)
		}
	}
	if _, err := os.Stat(filepath.Join(filepath.Dir(home), "evil.txt")); err == nil {
		t.Error("a file escaped the install folder")
	}
	if len(rec.Kept) != 1 || rec.Kept[0] != "gamedata/risks.txt" {
		t.Errorf("kept = %v", rec.Kept)
	}
	if runtime.GOOS != "windows" {
		if st, _ := os.Stat(filepath.Join(home, fq)); st.Mode()&0o100 == 0 {
			t.Error("fq isn't executable")
		}
	}
	st := Current(home, "1.9.1")
	if !st.CanUndo || st.Last.To != "1.9.1" {
		t.Errorf("status %+v", st)
	}
	if _, err := Install(context.Background(), rel, Options{Home: home, Current: "1.9.1"}); err == nil {
		t.Error("installed the same version twice")
	}

	if _, err := Undo(home, filepath.Join(home, fq)); err != nil {
		t.Fatal(err)
	}
	for rel, want := range map[string]string{"VERSION": "1.9.0\n", fq: "old fq", "assets/web/map.jxl": "old map",
		"gamedata/events.txt": "old events", "gamedata/risks.txt": "my own risks", "data/world.json": `{"players":"precious"}`} {
		if got := read(rel); got != want {
			t.Errorf("after undo %s = %q, want %q", rel, got, want)
		}
	}
	for _, gone := range []string{"assets/web/new.jxl", "gamedata/risks.txt.new"} {
		if _, err := os.Stat(filepath.Join(home, gone)); err == nil {
			t.Errorf("%s should be gone after undo", gone)
		}
	}
	if Current(home, "1.9.0").CanUndo {
		t.Error("undo offered twice")
	}
}

func TestDamagedDownload(t *testing.T) {
	suf, ok := PackageSuffix()
	if fq, _ := Programs(); !ok || fq == "" {
		t.Skip()
	}
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { w.Write([]byte("garbage")) }))
	defer srv.Close()
	API = srv.URL
	home := t.TempDir()
	rel := &Release{Version: "9.0.0", Asset: Asset{Name: "FuneralQuest-9.0.0" + suf, URL: srv.URL + "/dl", Size: 7, Digest: "sha256:00"}}
	_, err := Install(context.Background(), rel, Options{Home: home, Current: "1.9.0"})
	if err == nil || !strings.Contains(err.Error(), "damaged") {
		t.Fatalf("err = %v", err)
	}
}

//go:build windows

package update

import (
	"os"
	"os/exec"
)

// restartSelf starts the (new) program with the same arguments in the same window, and exits.
// The new copy waits a moment (FQ_RESTART_WAIT) so this one can let go of its ports.
func restartSelf(exe string) error {
	cmd := exec.Command(exe, os.Args[1:]...)
	cmd.Stdin, cmd.Stdout, cmd.Stderr = os.Stdin, os.Stdout, os.Stderr
	cmd.Env = append(os.Environ(), "FQ_RESTART_WAIT=1", "FQ_RESTARTED=1")
	if err := cmd.Start(); err != nil {
		return err
	}
	os.Exit(0)
	return nil
}

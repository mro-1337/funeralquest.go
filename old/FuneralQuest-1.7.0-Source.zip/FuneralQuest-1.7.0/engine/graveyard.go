package engine

import (
	"fmt"
	"strings"
)

// The church and the graveyard. The original's church was only a greeting and its graveyard
// button was "removed until I have a use for it" (history.txt), so both are new here: karma
// now goes down for bad deeds and up at church, a high karma earns a daily blessing, and the
// graveyard has quests that cost a turn each.

const churchInfo = "Father Smyth greets you warmly, as always.  The smell of candle wax and old hymn books fills the air.\n\nA donation box by the door reads: THE LORD LOVES A CHEERFUL GIVER."

func churchScr(me *Player, text string, c *Config) Screen {
	bs := []Button{}
	if c.DonateKarmaPerDay > 0 {
		bs = append(bs, B("Donate", "church", "donate").K("d"))
	}
	if c.ConfessKarma > 0 {
		bs = append(bs, B("Confession", "church", "confess").K("c"))
	}
	if c.BlessLuck > 0 {
		bs = append(bs, B("Ask for a blessing", "church", "bless").K("b"))
	}
	bs = append(bs, B("Say hi", "church", "hi").K("s"), B("Leave", "map", "").K("l").D())
	return Screen{View: "generic", BG: "background/background_church", Pic: "people/churchguy_h",
		Info: churchInfo + fmt.Sprintf("\n\nYour karma: %d (%s)", me.Karma, karmaWord(me.Karma)), Text: text, Buttons: bs}
}

func karmaWord(k int) string {
	switch {
	case k >= 85:
		return "saintly"
	case k >= 70:
		return "good"
	case k >= 50:
		return "fair"
	case k >= 25:
		return "shady"
	}
	return "wicked"
}

// sin lowers karma for a bad deed and returns a line to add to the screen.
func (s *Session) sin() string {
	n := s.cfg().KarmaSin
	me := s.me()
	if n <= 0 || me == nil {
		return ""
	}
	me.Karma = clamp(me.Karma-n, 1, 100)
	return fmt.Sprintf("\n\n`8Somewhere, a church bell rings.  You feel a little less holy.  (karma -%d)", n)
}

func (s *Session) cmdChurch(a Action) Screen {
	me := s.me()
	c := s.cfg()
	day := s.age()
	if a.Sub == "" {
		s.setLocation("Church")
		return churchScr(me, fmt.Sprintf("`wFather Smyth: `y\"Why hello there, %s.  Isn't it a wonderfully fantastic day today?  Praise the Lord.\"", me.Name), c)
	}
	say := func(t string) Screen { return churchScr(me, "`wFather Smyth: `y\""+t+"\"", c) }
	if me.Church.DonateDay != day {
		me.Church.DonateDay, me.Church.Donated = day, 0
	}
	switch a.Sub {
	case "hi":
		return say("Hi there.  I already said hi though.")

	case "donate":
		if c.DonateKarmaPerDay <= 0 {
			return say("The collection plate is away being polished.")
		}
		bs := []Button{}
		for t, k := range []string{"w", "s", "g"} {
			if me.Coffins[t] > 0 {
				bs = append(bs, B(casketName[t]+" tag", "church", "give_"+k).K(k))
			}
		}
		bs = append(bs, B("Back", "church", "").K("b").D())
		left := c.DonateKarmaPerDay - me.Church.Donated
		txt := "`wFather Smyth: `y\"Every tag helps keep the roof over the Lord's head.\"\n\n`$A wood tag is worth `w1`$ karma, silver `w2`$, gold `w4`$."
		if left <= 0 {
			txt = "`wFather Smyth: `y\"You've been more than generous today, my child.  Save some for tomorrow.\""
			bs = []Button{B("Back", "church", "").K("b").D()}
		} else {
			txt += fmt.Sprintf("  You can still earn `w%d`$ karma by giving today.", left)
		}
		return Screen{View: "generic", BG: "background/background_church", Pic: "people/churchguy_h", Info: churchInfo, Text: txt, Buttons: bs}

	case "give_w", "give_s", "give_g":
		t := strings.Index("wsg", a.Sub[5:])
		gain := []int{1, 2, 4}[t]
		left := c.DonateKarmaPerDay - me.Church.Donated
		switch {
		case c.DonateKarmaPerDay <= 0:
			return say("The collection plate is away being polished.")
		case me.Coffins[t] < 1:
			return say("Bless you, but your pockets look empty.")
		case left <= 0:
			return say("You've been more than generous today, my child.  Save some for tomorrow.")
		case me.Karma >= 100:
			return say("Your soul is already as clean as they come.  Keep your tags.")
		}
		gain = min(gain, left, 100-me.Karma)
		me.Coffins[t]--
		me.Karma += gain
		me.Church.Donated += gain
		return churchScr(me, fmt.Sprintf("`yYou drop a %s tag into the donation box.  It lands with a satisfying clunk.\n\n`wFather Smyth: `y\"The Lord thanks you.\"  `$(karma +%d)", strings.ToLower(casketName[t]), gain), c)

	case "confess":
		switch {
		case c.ConfessKarma <= 0:
			return say("The confession booth is closed for repairs.  Termites.")
		case me.Church.ConfessDay == day:
			return say("Once a day is plenty, my child.  The Lord needs a break too.")
		case me.Karma >= 50:
			return say("Confess?  You?  You've got nothing worth my time.  Go in peace.")
		case me.Coffins[Wood] < c.ConfessCost:
			return say(fmt.Sprintf("The booth takes a small offering of %d wood tag(s).  Candles don't grow on trees.  Well... wax doesn't.", c.ConfessCost))
		}
		me.Coffins[Wood] -= c.ConfessCost
		gain := min(c.ConfessKarma, 50-me.Karma)
		me.Karma += gain
		me.Church.ConfessDay = day
		sins := pick([]string{"overcharged a widow for a velvet lining", "told a family the 'eternal flame' was included", "napped in the display casket",
			"sold the same plot twice", "embalmed with discount fluid", "laughed during a eulogy"})
		return churchScr(me, fmt.Sprintf("`yIn the dark booth you admit that you %s.\n\n`wFather Smyth: `y\"Say ten Hail Marys and don't do it again.  Mostly don't get caught.\"\n\n`$You feel lighter.  (karma +%d)", sins, gain), c)

	case "bless":
		switch {
		case c.BlessLuck <= 0:
			return say("Blessings are on back order.")
		case me.Church.BlessDay == day:
			return say("You've had your blessing today.  Don't be greedy.")
		case me.Karma < c.BlessKarma:
			return say(fmt.Sprintf("Come back when your soul is a little cleaner, my child.  (You need %d karma.)", c.BlessKarma))
		}
		me.Church.BlessDay = day
		luckMod(me, c.BlessLuck)
		return churchScr(me, fmt.Sprintf("`yFather Smyth makes the sign of the cross over you and sprinkles you with holy water.  Some gets in your eye.\n\n`$You feel lucky today.  (luck +%d)", c.BlessLuck), c)
	}
	return s.cmdChurch(Action{})
}

// ======================================================================== graveyard

const graveInfo = "Rows of crooked headstones lean in the fog.  A crow watches you from the top of the old mausoleum, and somewhere a shovel scrapes."

var epitaphs = []string{
	"HERE LIES LESTER MOORE.  FOUR SLUGS FROM A .44.  NO LES, NO MORE.",
	"I TOLD YOU I WAS SICK.",
	"HE ORDERED THE SPECIAL AT THE PALE HORSE CAFE.",
	"SHE ALWAYS SAID HER FEET WERE KILLING HER.  WE DIDN'T BELIEVE HER.",
	"BELOVED HUSBAND.  TERRIBLE DRIVER.",
	"HERE LIES A MAN WHO NEVER READ THE FINE PRINT.  BURIED BY THE LOWEST BIDDER.",
	"GONE FISHING.  PERMANENTLY.",
	"REST IN PEACE.  NO REFUNDS.",
	"HE TRIED YANG'S DRAGON SPECIAL.",
	"SHE DIED DOING WHAT SHE LOVED: ARGUING WITH THE COOK.",
	"FINALLY, A QUIET NEIGHBOR.",
	"WIFE OF THE ABOVE.  STILL NOT SPEAKING TO HIM.",
}

type riddle struct{ q, a, w1, w2 string }

var riddles = []riddle{
	{"The man who makes it doesn't want it.  The man who buys it doesn't need it.  The man who uses it doesn't know it.  What is it?", "A coffin", "A wedding ring", "A tax return"},
	{"The more you take, the more you leave behind.  What are they?", "Footsteps", "Breaths", "Tags"},
	{"What gets wetter the more it dries?", "A towel", "A sponge", "A widow's hankie"},
	{"What has hands but cannot clap?", "A clock", "A corpse", "A scarecrow"},
	{"I have cities but no houses, forests but no trees, and water but no fish.  What am I?", "A map", "A dream", "A painting"},
	{"What can you catch but never throw?", "A cold", "A ball", "A train"},
	{"What is always coming but never arrives?", "Tomorrow", "The bus", "Your inheritance"},
	{"What has one eye but cannot see?", "A needle", "A potato", "A pirate"},
	{"What goes up but never comes down?", "Your age", "A balloon", "The rent"},
}

func (s *Session) graveScr(text string) Screen {
	me := s.me()
	c := s.cfg()
	left := s.questsLeft()
	info := graveInfo + fmt.Sprintf("\n\nYou have filled %d plot(s) here.", me.Plots)
	if c.GraveQuestsPerDay > 0 {
		info += fmt.Sprintf("  Quests left today: %d.", left)
	}
	bs := []Button{}
	if c.GraveQuestsPerDay > 0 {
		bs = append(bs, B("Dig up a grave", "graveyard", "dig").K("d"), B("Explore the mausoleum", "graveyard", "crypt").K("m"),
			B("Hunt the ghoul", "graveyard", "ghoul").K("h"), B("Help the gravedigger", "graveyard", "work").K("g"))
	}
	bs = append(bs, B("Tend the graves", "graveyard", "tend").K("t"), B("Read headstones", "graveyard", "read").K("r"),
		B("Biggest plots", "graveyard", "top").K("b"), B("Leave", "map", "").K("l").D())
	return Screen{View: "generic", BG: "background/background_celemony", Pic: "places/funeral-ceremony", Info: info, Text: text, Buttons: bs}
}

func (s *Session) questsLeft() int {
	me := s.me()
	if me.Church.GraveDay != s.age() {
		return s.cfg().GraveQuestsPerDay
	}
	return max(0, s.cfg().GraveQuestsPerDay-me.Church.GraveQuests)
}

// quest checks the daily limit and turns, then uses one of each. "" means go ahead.
func (s *Session) quest() string {
	me := s.me()
	switch {
	case s.cfg().GraveQuestsPerDay <= 0:
		return "`yThe gates are chained shut.  A sign reads: CLOSED BY ORDER OF CITY HALL."
	case s.questsLeft() <= 0:
		return "`yThe groundskeeper rattles his keys at you.  \"Closing time, friend.  Come back tomorrow.\""
	case me.Turns < 1:
		return "`yYou're too tired for any more graveyard business today."
	}
	if me.Church.GraveDay != s.age() {
		me.Church.GraveDay, me.Church.GraveQuests = s.age(), 0
	}
	me.Church.GraveQuests++
	me.Turns--
	return ""
}

func (s *Session) hurt(n int) int {
	me := s.me()
	n = min(n, me.HP-1)
	if n < 0 {
		n = 0
	}
	me.HP -= n
	return n
}

func (s *Session) cmdGraveyard(a Action) Screen {
	me := s.me()
	c := s.cfg()
	if a.Sub == "" {
		s.setLocation("Graveyard")
		s.riddle = 0
		return s.graveScr("`$The gate creaks open.  What brings you here?")
	}
	switch a.Sub {
	case "read":
		if random(8) == 0 {
			s.digHint = true
			return s.graveScr("`yOne old stone has no name, just a crude arrow scratched into it pointing at the ground and the words:\n\n`w\"X MARKS THE SPOT\"\n\n`$You make a note of it.  Your next dig should go better.")
		}
		return s.graveScr("`yYou read a weathered headstone:\n\n`w" + pick(epitaphs))

	case "top":
		var top []*Player
		for _, p := range s.w.Players {
			if p.Active && p.Plots > 0 {
				top = append(top, p)
			}
		}
		for i := 1; i < len(top); i++ {
			for j := i; j > 0 && top[j].Plots > top[j-1].Plots; j-- {
				top[j], top[j-1] = top[j-1], top[j]
			}
		}
		total := 0
		for _, p := range top {
			total += p.Plots
		}
		txt := fmt.Sprintf("`yA map by the gate shows who buried whom.  `w%d`y plot(s) are filled in all.\n\n", total)
		if len(top) == 0 {
			txt += "`$Nobody has buried anyone yet.  Business is dead.  Well, not dead enough."
		}
		for i, p := range top {
			if i == 10 {
				break
			}
			txt += fmt.Sprintf("`w%2d. `$%-30s `w%d\n", i+1, p.Parlor, p.Plots)
		}
		return s.graveScr(txt)

	case "tend":
		if me.Church.TendDay == s.age() {
			return s.graveScr("`yThe graves you tended this morning still look nice.  Fresh flowers and everything.")
		}
		me.Church.TendDay = s.age()
		txt := "`yYou pull weeds, straighten a few headstones and leave fresh flowers by the forgotten ones."
		if me.Karma < 100 {
			me.Karma++
			txt += "  `$(karma +1)"
		}
		if random(10) == 0 {
			me.Coffins[Wood]++
			txt += "\n\n`$Under a pile of leaves you find a `wwood tag`$ someone dropped."
		}
		return s.graveScr(txt)

	case "dig":
		if msg := s.quest(); msg != "" {
			return s.graveScr(msg)
		}
		return s.dig()

	case "crypt":
		if msg := s.quest(); msg != "" {
			return s.graveScr(msg)
		}
		r := random(len(riddles))
		s.riddle = r + 1
		q := riddles[r]
		ans := []string{q.a, q.w1, q.w2}
		order := []int{0, 1, 2}
		for i := 2; i > 0; i-- {
			j := random(i + 1)
			order[i], order[j] = order[j], order[i]
		}
		bs := []Button{}
		for n, i := range order {
			if i == 0 {
				s.riddleAns = n
			}
			bs = append(bs, B(ans[i], "graveyard", fmt.Sprintf("ans%d", n)).K(fmt.Sprint(n+1)))
		}
		return Screen{View: "generic", BG: "background/background_celemony", Pic: "places/funeral-ceremony", Info: graveInfo,
			Text:    "`yYou push open the heavy door of the mausoleum.  The candles light by themselves.\n\nA pale old man floats out of a stone coffin.\n\n`wGhost of Old Mortimer: `y\"Nobody visits anymore.  Answer my riddle and I'll make it worth your while.\"\n\n`w\"" + q.q + "\"",
			Buttons: bs}

	case "ans0", "ans1", "ans2":
		if s.riddle == 0 {
			return s.graveScr("`yThe mausoleum is quiet.  Too quiet.")
		}
		s.riddle = 0
		if a.Sub == fmt.Sprintf("ans%d", s.riddleAns) {
			bp := randomRange(5, 12)
			expMod(me, bp)
			luckMod(me, 3)
			return s.graveScr(fmt.Sprintf("`wGhost of Old Mortimer: `y\"Correct!  You're smarter than the last fellow.  He's in the next drawer over.\"\n\n`$The ghost whispers the names of three families about to need a funeral.  You earn `w%d`$ Bury Points and feel lucky.  (luck +3)", bp))
		}
		luckMod(me, -2)
		return s.graveScr("`wGhost of Old Mortimer: `y\"WRONG!\"\n\n`$The candles blow out and an icy wind howls through the crypt.  You run all the way to the gate.  (luck -2)")

	case "ghoul":
		if msg := s.quest(); msg != "" {
			return s.graveScr(msg)
		}
		odds := clamp(40+(me.Strength-c.StartingStrength)*5+(me.Luck-50)/5, 10, 90)
		if random(100) < odds {
			bp := randomRange(6, 15)
			expMod(me, bp)
			txt := fmt.Sprintf("`yYou wait behind the toolshed until the ghoul crawls out of an open grave.  You hit it with a shovel.  Then again.  Then once more to be safe.\n\n`$The ghoul flees into the woods.  The neighbors are grateful.  You earn `w%d`$ Bury Points.", bp)
			if random(4) == 0 {
				me.Coffins[Gold]++
				txt += "\n\nIt dropped a `wgold tag`$ on the way out.  Where did it get that?"
			}
			if me.Karma < 100 {
				me.Karma++
				txt += "  (karma +1)"
			}
			return s.graveScr(txt)
		}
		n := s.hurt(randomRange(2, 4))
		return s.graveScr(fmt.Sprintf("`yThe ghoul is bigger than you expected.  Much bigger.  It throws you over a fence.\n\n`$You lose `w%d`$ hit point(s).  Maybe visit Spirit University and get stronger.", n))

	case "work":
		if msg := s.quest(); msg != "" {
			return s.graveScr(msg)
		}
		n := randomRange(1, 2)
		me.Coffins[Wood] += n
		txt := fmt.Sprintf("`yYou help old Digby the gravedigger fill in a few holes.  He talks the whole time about his bunions.\n\n`$He pays you `w%d`$ wood tag(s).", n)
		if random(8) == 0 {
			me.Coffins[Silver]++
			txt += "  He also slips you a `wsilver tag`$.  \"Don't tell the boss.\""
		}
		return s.graveScr(txt)
	}
	return s.cmdGraveyard(Action{})
}

func (s *Session) dig() Screen {
	me := s.me()
	r := random(100) + (me.Luck-50)/5
	if s.digHint {
		r += 20
		s.digHint = false
	}
	var txt string
	switch {
	case me.Karma < 25 && random(4) == 0:
		luckMod(me, -3)
		txt = "`yAs your shovel hits the coffin lid, a cold wind blows out your lantern.  A voice in the dark says your name.\n\n`4You've been cursed!  `$(luck -3)"
	case r < 25:
		txt = "`yYou dig for an hour and find... bones and dirt.  Mostly dirt."
	case r < 40:
		txt = "`yA lantern swings toward you.  The groundskeeper!\n\n"
		if me.Coffins[Wood] > 0 {
			me.Coffins[Wood]--
			txt += "`$You bribe him with a `wwood tag`$ to keep quiet."
		} else {
			luckMod(me, -2)
			txt += "`$You run, but he gets a good look at you.  (luck -2)"
			if random(3) == 0 {
				s.news("front", fmt.Sprintf("`7GRAVE ROBBER SPOTTED\n`^The groundskeeper at the town cemetery chased off a grave robber last night.  \"Looked a lot like %s,\" he told the Times.\n\n", me.Name))
			}
		}
	case r < 50:
		n := s.hurt(randomRange(1, 3))
		txt = fmt.Sprintf("`yA bony hand shoots out of the dirt and grabs your ankle!  You kick free, but not before it gets a few good scratches in.\n\n`$You lose `w%d`$ hit point(s).", n)
	case r < 75:
		n := randomRange(1, 3)
		me.Coffins[Wood] += n
		txt = fmt.Sprintf("`yYou pry open the coffin.  The deceased was buried with `w%d wood tag(s)`y.  He won't be needing them.", n)
	case r < 90:
		n := randomRange(1, 2)
		me.Coffins[Silver] += n
		txt = fmt.Sprintf("`yUnder a rotten velvet pillow you find `w%d silver tag(s)`y!", n)
	case r < 100:
		me.Coffins[Gold]++
		txt = "`yA glint in the dirt... a `wgold tag`y, still tied to a big toe!"
	default:
		me.Coffins[Gold] += 2
		bp := randomRange(10, 20)
		expMod(me, bp)
		txt = fmt.Sprintf("`yYour shovel hits an old iron chest.  An old sea captain's treasure!\n\n`$Inside are `w2 gold tags`$ and a stack of old papers that impress the historical society.  You earn `w%d`$ Bury Points.", bp)
	}
	return s.graveScr("`yYou pick a grave, look both ways, and start digging.\n\n" + txt + s.sin())
}

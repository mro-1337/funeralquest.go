package engine

// Raids between linked towns: breaking in, picking locks, stealing tags, fighting, and hiring
// the Twins to set a fire.
//
// The defender's own server is the referee. The attacker's server sends one signed step at a
// time (look, picklock, steal, fight, round, run, yell, arson) with the attacker's fighting
// stats; the defender's server runs the same rules as a local raid against its own player,
// changes only its own player, and answers with numbers (hits, damage, tags taken, BP won).
// The attacker's server writes the story from those numbers and changes only its own player.
// Both ends cap everything the other side claims.

import (
	"fmt"
	"strings"
	"time"
)

// RaidFighter is what the attacker's server says about the attacker.
type RaidFighter struct {
	Name     string `json:"name"`
	Parlor   string `json:"parlor"`
	Male     bool   `json:"male"`
	Strength int    `json:"strength"`
	HPMax    int    `json:"hp_max"`
	Plots    int    `json:"plots"`
	Exp      int    `json:"exp"`
}

type RaidReq struct {
	Op     string      `json:"op"` // look, picklock, steal, fight, round, run, yell, arson
	Raid   string      `json:"raid,omitempty"`
	Target string      `json:"target,omitempty"`
	Att    RaidFighter `json:"att"`
	Text   string      `json:"text,omitempty"`
}

// RaidHit is one swing. By is "att" or "def"; Dmg 0 is a miss.
type RaidHit struct {
	By   string `json:"by"`
	Dmg  int    `json:"dmg"`
	Soul bool   `json:"soul,omitempty"`
}

type RaidAns struct {
	Raid        string    `json:"raid,omitempty"`
	Refused     string    `json:"refused,omitempty"` // off, gone, online, police, busy, limit, over, unknown
	Name        string    `json:"name,omitempty"`
	Parlor      string    `json:"parlor,omitempty"`
	Male        bool      `json:"male,omitempty"`
	Transport   string    `json:"transport,omitempty"`
	Padlock     bool      `json:"padlock,omitempty"`
	PadStrength int       `json:"pad_strength,omitempty"`
	Broke       bool      `json:"broke,omitempty"`
	Safe        bool      `json:"safe,omitempty"`
	HPMax       int       `json:"hp_max,omitempty"`
	Stolen      int       `json:"stolen,omitempty"` // -1: nothing of that kind to take
	TagType     int       `json:"tag_type,omitempty"`
	First       string    `json:"first,omitempty"`
	Hits        []RaidHit `json:"hits,omitempty"`
	AttHP       int       `json:"att_hp,omitempty"`
	DefHP       int       `json:"def_hp,omitempty"`
	Outcome     string    `json:"outcome,omitempty"` // "", won (attacker won), lost
	WinBP       int       `json:"win_bp,omitempty"`
	Saved       bool      `json:"saved,omitempty"`
	Burned      int       `json:"burned,omitempty"`
	Lost        int       `json:"lost,omitempty"`
}

// RaidState is what the defender's server remembers about a raid in progress.
type RaidState struct {
	ID       string
	Peer     string
	Town     string
	Att      RaidFighter
	DefID    int
	AttHP    int
	DefHP    int
	Fighting bool
	Done     bool
	Yelled   bool
	Outcome  string
	Created  time.Time
	Seen     time.Time // last step; a raid idle for 5 minutes no longer blocks others
}

// Active says whether this raid still keeps other visitors away from the defender.
func (st *RaidState) Active() bool { return !st.Done && time.Since(st.Seen) < 5*time.Minute }

const arsonCost = 6

func (g *Game) raidCaps(w *World, a RaidFighter) RaidFighter {
	maxStr, maxHP, maxPlots := 10, 50, 100
	for _, p := range w.Active() {
		maxStr, maxHP, maxPlots = max(maxStr, p.Strength), max(maxHP, p.HPMax), max(maxPlots, p.Plots)
	}
	// nobody from out of town is more than twice as tough as the toughest local
	a.Strength = clamp(a.Strength, 0, maxStr*2)
	a.HPMax = clamp(a.HPMax, 1, maxHP*2)
	a.Plots = clamp(a.Plots, 0, maxPlots*2)
	a.Exp = clamp(a.Exp, 0, 2e9)
	a.Name = CleanRemote(a.Name, 20, false)
	a.Parlor = CleanRemote(a.Parlor, 30, false)
	return a
}

// who names the attacker in letters and the paper: "Alice of Deathville".
func (st *RaidState) who() string { return st.Att.Name + " of " + st.Town }

func pronoun(male bool, m, f string) string {
	if male {
		return m
	}
	return f
}

// DefendRaid runs one raid step against a player on this server. busy says whether another
// out-of-town raid on the same player is already going on.
func (g *Game) DefendRaid(w *World, st *RaidState, req RaidReq, busy bool) RaidAns {
	c := w.Config
	if c.NetRaidsOff {
		return RaidAns{Refused: "off"}
	}
	att := g.raidCaps(w, req.Att)
	st.Seen = time.Now()
	switch req.Op {
	case "look", "arson":
		t := w.ByName(CleanRemote(req.Target, 20, false))
		if t == nil || !t.Active {
			return RaidAns{Refused: "gone"}
		}
		if w.IsOnline(t.ID) {
			return RaidAns{Refused: "online", Name: t.Name}
		}
		if req.Op == "look" {
			if t.Police {
				return RaidAns{Refused: "police", Name: t.Name, Parlor: t.Parlor}
			}
			if busy {
				return RaidAns{Refused: "busy", Name: t.Name}
			}
			for _, x := range w.Online() {
				if x.Status == fmt.Sprintf("visit:%d", t.ID) {
					return RaidAns{Refused: "busy", Name: t.Name}
				}
			}
		}
		if t.NetRaidDay == w.Glo.GameAge && t.NetRaids >= c.NetRaidsPerDay {
			return RaidAns{Refused: "limit", Name: t.Name}
		}
		if t.NetRaidDay != w.Glo.GameAge {
			t.NetRaidDay, t.NetRaids = w.Glo.GameAge, 0
		}
		t.NetRaids++
		st.DefID, st.Att = t.ID, att
		if req.Op == "arson" {
			st.Done = true
			return g.defendArson(w, st, t)
		}
		tr := ""
		if d := g.D(); t.Transport >= 0 && t.Transport < len(d.Transport) {
			tr = d.Transport[t.Transport].Name
		}
		return RaidAns{Name: t.Name, Parlor: t.Parlor, Male: t.Male, Transport: tr, Padlock: t.Custom.Padlock > 0,
			PadStrength: t.Custom.PadlockStrength, Safe: t.Custom.Safe > 0, HPMax: t.HPMax}
	}

	t := w.Player(st.DefID)
	if t == nil || !t.Active {
		st.Done = true
		return RaidAns{Refused: "gone"}
	}
	if req.Op == "yell" {
		return g.defendYell(w, st, t, req.Text)
	}
	if st.Done {
		return RaidAns{Refused: "over"}
	}
	switch req.Op {
	case "picklock":
		if st.Fighting || t.Custom.Padlock == 0 {
			return RaidAns{Padlock: false}
		}
		dmg := randomRange(5, 10)
		t.Custom.PadlockStrength -= dmg
		if t.Custom.PadlockStrength < 1 {
			t.Custom.Padlock, t.Custom.PadlockStrength = 0, 0
			w.AddMail(Letter{To: t.ID, Text: fmt.Sprintf("`yYour padlock is `4damaged beyond repair`y by a prowler from `w%s`y and falls off!", st.Town)})
			return RaidAns{Broke: true}
		}
		w.AddMail(Letter{To: t.ID, Text: fmt.Sprintf("`yYour padlock is weakened by `4%d`y down to `w%d percent strength`y by a prowler from `w%s`y.", dmg, t.Custom.PadlockStrength, st.Town)})
		return RaidAns{Padlock: true, PadStrength: t.Custom.PadlockStrength}

	case "steal":
		if st.Fighting {
			return RaidAns{Refused: "over"}
		}
		st.Done = true
		if t.Custom.Safe > 0 {
			return RaidAns{Safe: true, Stolen: -1}
		}
		n, name := stealTags(3, &Player{}, t)
		typ := tagIndex(name)
		m := fmt.Sprintf("\n`wYou caught %s sneaking around inside your parlor!`$\n", st.who())
		switch {
		case n == 1:
			m += fmt.Sprintf("You scare %s off.  You notice `w1 %s tag `$is missing.", pronoun(att.Male, "him", "her"), name)
		case n > 1:
			m += fmt.Sprintf("You scare %s off.  You notice `w%d %s tags `$are missing.", pronoun(att.Male, "him", "her"), n, name)
		default:
			m += fmt.Sprintf("You scare %s off before %s could steal anything.", pronoun(att.Male, "him", "her"), pronoun(att.Male, "he", "she"))
		}
		w.AddMail(Letter{To: t.ID, Text: m, Pic: "people/man_prowl"})
		return RaidAns{Stolen: n, TagType: typ}

	case "fight":
		if st.Fighting {
			return RaidAns{Refused: "over"}
		}
		st.Fighting = true
		st.Att = att
		st.AttHP, st.DefHP = att.HPMax, t.HPMax
		t.HP = t.HPMax
		ans := RaidAns{First: "att"}
		if att.Plots <= t.Plots {
			ans.First = "def"
			ans.Hits = append(ans.Hits, st.defSwing(t))
			g.raidCheckDeath(w, st, t, &ans)
		}
		ans.AttHP, ans.DefHP = max(0, st.AttHP), max(0, st.DefHP)
		return ans

	case "round":
		if !st.Fighting {
			return RaidAns{Refused: "over"}
		}
		ans := RaidAns{}
		ans.Hits = append(ans.Hits, st.attSwing())
		if !g.raidCheckDeath(w, st, t, &ans) {
			ans.Hits = append(ans.Hits, st.defSwing(t))
			g.raidCheckDeath(w, st, t, &ans)
		}
		t.HP = max(0, st.DefHP)
		ans.AttHP, ans.DefHP = max(0, st.AttHP), max(0, st.DefHP)
		return ans

	case "leave":
		if !st.Fighting {
			st.Done = true
		}
		return RaidAns{}
	case "run":
		st.Done = true
		w.AddMail(Letter{To: t.ID, Pic: "people/man_prowl", Text: fmt.Sprintf("\n`wYou were attacked in your sleep by %s!`$\n\n%s got scared and ran off.\n\n", st.who(), pronoun(att.Male, "He", "She"))})
		return RaidAns{}
	}
	return RaidAns{Refused: "over"}
}

func tagIndex(name string) int {
	switch name {
	case "silver":
		return 1
	case "gold":
		return 2
	}
	return 0
}

func (st *RaidState) attSwing() RaidHit {
	hit := int(frandom(float64(st.Att.Strength+1)/2) + float64(st.Att.Strength+1)/2)
	h := RaidHit{By: "att", Dmg: hit}
	if hit > 0 && random(10) == 0 {
		h.Dmg, h.Soul = hit*2, true
	}
	st.DefHP -= h.Dmg
	return h
}

func (st *RaidState) defSwing(t *Player) RaidHit {
	hit := int(frandom(float64(t.Strength+1)/2) + float64(t.Strength+1)/2)
	if random(20) == 0 {
		hit = 0
	}
	st.AttHP -= hit
	return RaidHit{By: "def", Dmg: hit}
}

// raidCheckDeath ends the fight if somebody dropped, and settles the defender's side.
func (g *Game) raidCheckDeath(w *World, st *RaidState, t *Player, ans *RaidAns) bool {
	switch {
	case st.DefHP < 1:
		st.DefHP, t.HP, t.Police = 0, 0, true
		n, name := stealTags(4, &Player{}, t)
		win, lose := int(float64(t.Exp)*0.02), int(float64(t.Exp)*0.01)
		expModForce(t, -lose)
		stolen := " Nothing was stolen."
		if n == 1 {
			stolen = fmt.Sprintf(" `w1`$ %s tag was stolen from your pocket.", name)
		} else if n > 1 {
			stolen = fmt.Sprintf(" `w%d`$ %s tags were stolen from your pockets.", n, name)
		}
		g.Tv(w, fmt.Sprintf("It looks like %s was taken to the hospital after a visitor from %s dropped by.", t.Name, st.Town))
		w.AddMail(Letter{To: t.ID, Pic: "stuff/battle_lose", Text: fmt.Sprintf("\n`wYou were attacked in your sleep by %s!`$\n\nYou are badly injured.  You vaguely remember riding in an ambulance.\n\n`$You lose `w%s `$Bury Points.%s", st.who(), Cash(lose), stolen)})
		st.Done, st.Fighting, st.Outcome = true, false, "won"
		ans.Outcome, ans.WinBP, ans.Stolen, ans.TagType = "won", win, n, tagIndex(name)
		return true
	case st.AttHP < 1:
		st.AttHP = 0
		win := int(float64(st.Att.Exp) * 0.01)
		expModForce(t, win)
		t.HP = max(0, st.DefHP)
		w.AddMail(Letter{To: t.ID, Pic: "places/hospital_ambulance", Text: fmt.Sprintf("\n`wYou were attacked in your sleep by %s!`$\n\nYou woke up and kicked %s ass!\n\n`$You earn `w%s `$Bury Points. (applied to day %d)", st.who(), pronoun(st.Att.Male, "his", "her"), Cash(win), w.Glo.GameAge)})
		g.Tv(w, fmt.Sprintf("It looks like %s, a visitor from %s, was taken to the hospital.", st.Att.Name, st.Town))
		st.Done, st.Fighting, st.Outcome = true, false, "lost"
		ans.Outcome = "lost"
		return true
	}
	return false
}

func (g *Game) defendYell(w *World, st *RaidState, t *Player, text string) RaidAns {
	if st.Outcome == "" || st.Yelled {
		return RaidAns{Refused: "over"}
	}
	st.Yelled = true
	text = strings.TrimSpace(swearCheck(CleanRemote(StripCodes(text), 120, false), g.D().Swears))
	if st.Outcome == "won" {
		if len(text) < 2 {
			w.AddLocalNews("crime", fmt.Sprintf("`8%s brutally assaulted %s!\r\n\r\n", st.who(), t.Name))
		} else {
			w.AddLocalNews("crime", fmt.Sprintf("`8%s brutally assaulted %s!`6\r\n\"%s\" `8justified %s.\r\n\r\n", st.who(), t.Name, text, st.Att.Name))
			w.AddMail(Letter{To: t.ID, Pic: "places/hospital_room", Text: fmt.Sprintf("`$While recovering you can't get what %s yelled while escaping out of your head...\n\n`w\"%s\"`$", st.Att.Name, text)})
		}
	} else {
		if len(text) < 2 {
			w.AddLocalNews("crime", fmt.Sprintf("`8%s assaulted %s in self defense!\r\n\r\n", t.Name, st.who()))
		} else {
			w.AddLocalNews("crime", fmt.Sprintf("`8%s assaulted %s in self defense!`6\r\n\"%s\" `8moaned %s from the ambulance.\r\n\r\n", t.Name, st.who(), text, st.Att.Name))
			w.AddMail(Letter{To: t.ID, Pic: "places/hospital_ambulance", Text: fmt.Sprintf("`$As %s is leaving you hear %s moaning from the ambulance...\n\n`w\"%s\"`$", st.Att.Name, pronoun(st.Att.Male, "him", "her"), text)})
		}
	}
	return RaidAns{}
}

func (g *Game) defendArson(w *World, st *RaidState, t *Player) RaidAns {
	if t.Custom.FireAlarm == 1 && randomRange(1, 10) > 2 {
		w.AddNews("front", fmt.Sprintf("`7EARLY WARNING SAVES PARLOR\n`^A small fire was quickly put out at local business %s before any damage was done. \"It was a close call,\" said a relieved %s.  Witnesses saw two strangers leaving town on the road to %s.\n\n", t.Parlor, t.Name, st.Town))
		g.Tv(w, fmt.Sprintf("You see some breaking news.  It looks like %s's parlor was saved by a smoke detector.", t.Name))
		w.AddMail(Letter{To: t.ID, Pic: "stuff/fire_alarm", Tags: [3]int{0, 0, 3},
			Text: fmt.Sprintf("\n`yA mysterious fire was started on your property.  Thanks to your smoke detector the fire was put out before any serious damage was done.  The police chief awards you `w3`y gold tags!\n\nThe sheriff says the fire bugs came from `w%s`y.\n", st.Town)})
		return RaidAns{Saved: true, Name: t.Name, Parlor: t.Parlor}
	}
	burned := int(float64(t.Plots) * 0.05)
	ans := RaidAns{Name: t.Name, Parlor: t.Parlor, Burned: burned}
	if t.Custom.Safe > 0 {
		ans.Safe = true
		w.AddMail(Letter{To: t.ID, Pic: "stuff/fire_alarm", Text: fmt.Sprintf("\n`yA mysterious fire was started on your property.  You lost `4%d`y gravestone(s) but your `wSafe`y protected all your tags.\n\nThe sheriff says the fire bugs came from `w%s`y.\n", burned, st.Town)})
	} else {
		ans.Lost = t.Coffins[Wood]
		w.AddMail(Letter{To: t.ID, Pic: "stuff/fire_alarm", Text: fmt.Sprintf("\n`yA mysterious fire was started on your property.  You lost `4%d`y gravestone(s) and `4%d`y wood tag(s).\n\nThe sheriff says the fire bugs came from `w%s`y.\n", burned, ans.Lost, st.Town)})
		t.Coffins[Wood] = 0
	}
	t.Plots = max(0, t.Plots-burned)
	w.AddNews("front", fmt.Sprintf("`7PARLOR DAMAGED BY FIRE, OUT-OF-TOWNERS SUSPECTED\n`^A small fire was not noticed until too late at %s today.  \"Somebody from %s is gonna pay for this!\" said a distraught %s.\n\n", t.Parlor, st.Town, t.Name))
	g.Tv(w, fmt.Sprintf("You see some breaking news.  It looks like %s's parlor caught on fire.", t.Name))
	return ans
}

// ======================================================================== attacker's side

// netRaid is the attacker's view of a raid on another town.
type netRaid struct {
	Peer, Town, Raid string
	T                *Player // the victim as we know them (not in our world; never saved)
	Padlock          bool
	PadStrength      int
	Safe             bool
	SnapExp          int // victim's BP as their town last reported it (caps what we can win)
	Locked           bool
	Fighting         bool
	Outcome          string
}

// netCall is a network step that runs after the world lock is released (see Act).
type netCall struct {
	peer string
	req  RaidReq
	then func(RaidAns, error) Screen
}

func (s *Session) raidsOn() bool { return s.netOn() && !s.cfg().NetRaidsOff }

func (s *Session) me2fighter() RaidFighter {
	me := s.me()
	return RaidFighter{Name: me.Name, Parlor: me.Parlor, Male: me.Male, Strength: me.Strength, HPMax: me.HPMax, Plots: me.Plots, Exp: me.Exp}
}

func (s *Session) call(peer string, req RaidReq, then func(RaidAns, error) Screen) Screen {
	s.pendingCall = &netCall{peer, req, then}
	return Screen{View: "generic", Text: "`$..."}
}

func roadClosed(town string, err error) string {
	return fmt.Sprintf("You head for %s, but the road is closed.  (%s)", town, CleanRemote(err.Error(), 120, false))
}

func (s *Session) snapExp(peer, name string) int {
	for _, rp := range s.G.Net.RemotePlayers() {
		if rp.Peer == peer && strings.EqualFold(rp.Name, name) {
			return rp.Exp
		}
	}
	return 0
}

// cmdXComp is the rival-parlor visit for a parlor in a linked town.
func (s *Session) cmdXComp(a Action) Screen {
	me := s.me()
	nr := s.st.Net
	if a.Sub == "visit" {
		peer, name, town, ok := splitNetRef(a.Section)
		if !ok || !s.raidsOn() {
			return s.compMenu()
		}
		if me.Fights >= s.cfg().VisitsPerDay {
			return s.compMenu()
		}
		s.st = custStatus{}
		return s.call(peer, RaidReq{Op: "look", Target: name, Att: s.me2fighter()}, func(ans RaidAns, err error) Screen {
			leave := []Button{B("Leave", "comp", "menu").D()}
			if err != nil {
				return enemyScr("", roadClosed(town, err), leave)
			}
			tname := CleanRemote(ans.Name, 20, false)
			if tname == "" {
				tname = name
			}
			parlor := CleanRemote(ans.Parlor, 30, false)
			info := fmt.Sprintf("You drive all the way to %s and stop in front of a funeral parlor.  The sign above the door proudly announces the name, \"%s\". ", town, parlor)
			switch ans.Refused {
			case "":
			case "online":
				return enemyScr(info, fmt.Sprintf("You see %s through the window talking earnestly to a young couple, perhaps later would be better...", tname), leave)
			case "police":
				scr := enemyScr(info, fmt.Sprintf("You park your %s a few blocks away.  As you approach you see %s talking to some cops, maybe you should come back after things cool down.", s.transportName(me), tname), leave)
				scr.BG = "places/funeral_enemy_police"
				return scr
			case "busy":
				return enemyScr(info, fmt.Sprintf("As you take your position behind a bush, you notice somebody else already crouching there, staring at %s's parlor.  You decide to come back later.", tname), leave)
			case "limit":
				return enemyScr("", fmt.Sprintf("The neighbors in %s are watching %s's place closely after all the visitors today.  Better come back tomorrow.", town, tname), leave)
			case "off":
				return enemyScr("", fmt.Sprintf("A sign at the edge of %s says: NO OUT-OF-TOWN BUSINESS.  You turn around.", town), leave)
			case "unknown":
				return enemyScr("", fmt.Sprintf("The guard at the gate of %s doesn't know who you are yet.  Try again in a minute.", town), leave)
			default:
				return enemyScr("", fmt.Sprintf("You can't find %s's parlor anywhere in %s.", name, town), leave)
			}
			t := &Player{Name: tname, Parlor: parlor, Male: ans.Male, HPMax: clamp(ans.HPMax, 1, 1e6)}
			t.HP = t.HPMax
			s.st.Net = &netRaid{Peer: peer, Town: town, Raid: ans.Raid, T: t, Padlock: ans.Padlock, PadStrength: clamp(ans.PadStrength, 0, 100),
				Safe: ans.Safe, SnapExp: s.snapExp(peer, tname), Locked: true}
			me := s.me()
			me.Fights++
			tr := CleanRemote(ans.Transport, 30, false)
			if tr == "" {
				tr = "hearse"
			}
			return enemyScr(info, fmt.Sprintf("The lights are off, the parlor is silent.  %s must be sleeping inside.\n\nNobody seems to be looking, you could try the door-knob if you like.\n\nYou see a `w%s`$ parked nearby.", tname, tr),
				[]Button{B("Try Door", "xcomp", "try_door").K("t"), B("Leave", "comp", "menu").K("l")})
		})
	}
	if nr == nil || !nr.Locked {
		return s.compMenu()
	}
	t := nr.T
	doorBtns := []Button{B("Pick Lock", "xcomp", "picklock").K("p"), B("Leave", "comp", "menu").K("l")}
	switch a.Sub {
	case "try_door":
		if nr.Padlock {
			txt := fmt.Sprintf("There is a heavy padlock on the door at `w%d percent strength`y.  What do you want to do?", nr.PadStrength)
			if me.Custom.Lockpick > 0 {
				txt += fmt.Sprintf("\n\nYou are holding `w%s`y lockpick(s).", Cash(me.Custom.Lockpick))
			}
			return enemyScr("", txt, doorBtns)
		}
		return s.xInside()
	case "picklock":
		if me.Custom.Lockpick < 1 {
			return enemyScr("", "You attempt to pick the lock with your finger.  No go.  Perhaps if you had a real lockpick...", doorBtns)
		}
		return s.call(nr.Peer, RaidReq{Op: "picklock", Raid: nr.Raid, Att: s.me2fighter()}, func(ans RaidAns, err error) Screen {
			if err != nil || ans.Refused != "" {
				s.st = custStatus{}
				return enemyScr("", "A dog starts barking and lights come on all down the street.  You run back to your car.", []Button{B("Leave", "comp", "menu").D()})
			}
			me := s.me()
			me.Custom.Lockpick--
			var txt string
			if ans.Broke || !ans.Padlock {
				nr.Padlock, nr.PadStrength = false, 0
				txt = "As you are picking the lock the whole thing breaks and falls off!  Too bad your lockpick got stuck inside it."
			} else {
				old := nr.PadStrength
				nr.PadStrength = clamp(ans.PadStrength, 0, 100)
				txt = fmt.Sprintf("`yYou successfully pick the lock.  Your lockpick breaks as you try to get it out which causes the padlock `w%d`y points of damage.", max(0, old-nr.PadStrength))
			}
			return enemyScr("", txt, []Button{B("Continue", "xcomp", "inside").D()})
		})
	case "inside":
		return s.xInside()
	case "steal":
		if nr.Safe || nr.Fighting {
			return s.compMenu()
		}
		return s.call(nr.Peer, RaidReq{Op: "steal", Raid: nr.Raid, Att: s.me2fighter()}, func(ans RaidAns, err error) Screen {
			s.st = custStatus{}
			if err != nil || ans.Refused != "" {
				return enemyScr("", "You hear sirens!  You run out the back door empty-handed.", []Button{B("Leave", "comp", "menu").D()})
			}
			me := s.me()
			n := clamp(ans.Stolen, -1, 3)
			typ := clamp(ans.TagType, 0, 2)
			name := []string{"wooden", "silver", "gold"}[typ]
			var txt string
			switch {
			case n < 0 || ans.Safe:
				txt = "You look around but can't find anything of value."
			case n == 0:
				txt = "You begin wildly opening drawers and things looking for anything of value."
			case n == 1:
				txt = fmt.Sprintf("You look around and find `w1 %s`$ tag hidden on top of the refrigerator!", name)
			default:
				txt = fmt.Sprintf("You look around and find `w%d %s`$ tags in a drawer!", n, name)
			}
			if n > 0 {
				me.Coffins[typ] += n
			}
			sexy := ifs(me.Male && !t.Male, "lingerie", "pajamas")
			txt += fmt.Sprintf("\n\nYou are startled by a noise behind you.  It's %s in %s %s! You crash through a window and drive like hell all the way back from %s.", t.Name, his(t), sexy, nr.Town)
			if n > 0 && !ans.Safe {
				txt += s.sin()
			}
			return enemyScr("", txt, []Button{B("Leave", "comp", "menu").D()})
		})
	case "attack":
		if nr.Fighting {
			return s.compMenu()
		}
		me.HP = me.HPMax
		return s.call(nr.Peer, RaidReq{Op: "fight", Raid: nr.Raid, Att: s.me2fighter()}, func(ans RaidAns, err error) Screen {
			if err != nil || ans.Refused != "" {
				s.st = custStatus{}
				return enemyScr("", "Lights come on all over the house.  You run for it before anything starts.", []Button{B("Leave", "comp", "menu").D()})
			}
			nr.Fighting = true
			s.st.Battle = true
			cry := pick([]string{"Stop stealing my customers!", "I will BURY you!", fmt.Sprintf("Messing with me was a grave mistake, dear %s.", t.Name),
				"Go back to " + nr.Town + "? I came FROM " + s.cfg().ServerName + "!", "This town isn't big enough for the both of us... wait.", "You're an amateur! You don't belong here!"})
			txt := fmt.Sprintf("`w\"%s\" `$you scream as you break into %s room.\n\n", cry, his(t))
			if ans.First == "att" {
				txt += t.Name + " is completely surprised, you get first swing!\n\n"
			} else {
				txt += fmt.Sprintf("%s's eyes flick open, %s knew you were in the house!\n\n", t.Name, he(t))
			}
			return s.xRound(ans, txt)
		})
	}
	return s.compMenu()
}

func (s *Session) xInside() Screen {
	nr := s.st.Net
	t := nr.T
	txt := fmt.Sprintf("You quickly slip in and close the door.  You hear %s softly snoring in the back room.", t.Name)
	if nr.Safe {
		txt += "\n\nYou see a large combination `wSafe`$ in the corner.  You won't be able to steal tags."
	}
	txt += fmt.Sprintf("\n\nJudging from the room, you would guess %s has `w%d`$ hitpoints.", t.Name, t.HPMax)
	var bs []Button
	if !nr.Safe {
		bs = append(bs, B("Steal", "xcomp", "steal").K("s"))
	}
	bs = append(bs, B("Attack", "xcomp", "attack").K("a"))
	return Screen{View: "generic", BG: "places/desk_enemy", Info: fmt.Sprintf("You have broken into %s, in %s.", t.Parlor, nr.Town), Text: txt, Buttons: bs, Music: "music/music_sneak"}
}

// xRound shows one exchange of blows (numbers from the defender's server) and settles our side.
func (s *Session) xRound(ans RaidAns, txt string) Screen {
	nr := s.st.Net
	t := nr.T
	me := s.me()
	for i, h := range ans.Hits {
		if i >= 3 {
			break
		}
		dmg := clamp(h.Dmg, 0, 1e6)
		if h.By == "att" {
			switch {
			case dmg == 0:
				txt += t.Name + " dodges your swing.\n\n"
			case h.Soul:
				txt += fmt.Sprintf("You `wsoul smash`$ %s for `4%d`$ damage!\n\n", t.Name, dmg)
			default:
				txt += fmt.Sprintf("You %s %s for `4%d`$ damage.\n\n", hitName(dmg, false), t.Name, dmg)
			}
		} else {
			if dmg == 0 {
				txt += t.Name + " swings but you sidestep the blow.\n\n"
			} else {
				txt += fmt.Sprintf("%s %s you for `4%d`$ damage.\n\n", t.Name, hitName(dmg, true), dmg)
			}
		}
	}
	me.HP = clamp(ans.AttHP, 0, me.HPMax)
	t.HP = clamp(ans.DefHP, 0, t.HPMax)
	switch ans.Outcome {
	case "won":
		t.HP = 0
		nr.Fighting, nr.Outcome, s.st.Battle = false, "won", false
		win := clamp(ans.WinBP, 0, int(float64(nr.SnapExp)*0.02)+1)
		expModForce(me, win)
		n := clamp(ans.Stolen, -1, 4)
		typ := clamp(ans.TagType, 0, 2)
		name := []string{"wooden", "silver", "gold"}[typ]
		found := fmt.Sprintf("You go through %s pockets but find nothing.", his(t))
		if n >= 1 {
			me.Coffins[typ] += n
			found = fmt.Sprintf("You go through %s pockets and find `w%d `$%s tag%s.", his(t), n, name, ifs(n == 1, "", "s"))
		}
		s.G.Tv(s.w, fmt.Sprintf("%s is back from %s with a black eye and a big grin.", me.Name, nr.Town))
		txt += fmt.Sprintf("%s crumples to the floor. You have won the battle!\n\nYou earn `w%s `$Bury Points. %s", t.Name, Cash(win), found)
		scr := s.battleScr(t, txt, []Button{B("Continue", "xbattle", "yell_win").D()})
		scr.Pic = "stuff/money_bag_2"
		return scr
	case "lost":
		me.HP = 0
		nr.Fighting, nr.Outcome, s.st.Battle = false, "lost", false
		lose := int(float64(me.Exp) * 0.005)
		expModForce(me, -lose)
		s.G.Tv(s.w, fmt.Sprintf("It looks like %s was brought back from %s in an ambulance.", me.Name, nr.Town))
		txt += fmt.Sprintf("You fall down, unable to get up.\n\nYou lose `w%s `$Bury Points.", Cash(lose))
		scr := s.battleScr(t, txt, []Button{B("Continue", "xbattle", "yell_lost").D()})
		scr.BG, scr.Pic = "", "stuff/battle_lose"
		return scr
	}
	return s.battleScr(t, txt, []Button{B("Attack", "xbattle", "attack").K("a").D(), B("Run", "xbattle", "run").K("r")})
}

func (s *Session) cmdXBattle(a Action) Screen {
	nr := s.st.Net
	if nr == nil {
		return s.cmdMain()
	}
	t := nr.T
	me := s.me()
	switch a.Sub {
	case "attack":
		if !nr.Fighting {
			return s.cmdMain()
		}
		return s.call(nr.Peer, RaidReq{Op: "round", Raid: nr.Raid, Att: s.me2fighter()}, func(ans RaidAns, err error) Screen {
			if err != nil || ans.Refused != "" {
				s.st = custStatus{}
				scr := s.compMenu()
				scr.Text = "Everything goes black for a second.  When you come to, you're back in your car outside town and the fight is over."
				scr.Buttons = []Button{B("Continue", "comp", "").D()}
				return scr
			}
			return s.xRound(ans, "")
		})
	case "run":
		if !nr.Fighting {
			return s.cmdMain()
		}
		return s.call(nr.Peer, RaidReq{Op: "run", Raid: nr.Raid, Att: s.me2fighter()}, func(ans RaidAns, err error) Screen {
			s.st = custStatus{}
			scr := s.compMenu()
			scr.Text = "You backflip through an open window and drive back to " + s.cfg().ServerName + " as fast as you can."
			scr.Buttons = []Button{B("Continue", "comp", "").D()}
			return scr
		})
	case "yell_win", "yell_lost":
		win := a.Sub == "yell_win"
		if nr.Outcome != map[bool]string{true: "won", false: "lost"}[win] {
			return s.cmdMain()
		}
		prompt := "`wYou feel yourself being lifted into an ambulance.  Mutter something or just hit ENTER to continue."
		if win {
			prompt = "`wYou hear police sirens in the distance... you can yell something as you leave or just hit ENTER to continue."
		}
		scr := s.battleScr(t, prompt, []Button{})
		if !win {
			scr.BG = ""
		}
		scr.Input = &Input{Kind: "text", Prompt: ifs(win, "Yell:", "Mutter:"), Cmd: "xbattle", Sub: ifs(win, "got_win", "got_lost"), MaxLen: 120, AllowEmpty: true}
		return scr
	case "got_win", "got_lost":
		win := a.Sub == "got_win"
		if nr.Outcome != map[bool]string{true: "won", false: "lost"}[win] {
			return s.cmdMain()
		}
		v, _ := val(a)
		text := strings.TrimSpace(swearCheck(strings.ReplaceAll(v, "`", ""), s.data().Swears))
		if len(text) > 120 {
			text = text[:120]
		}
		if win {
			if len(text) < 2 {
				s.news("crime", fmt.Sprintf("`8%s drove to %s and brutally assaulted %s!\r\n\r\n", me.Name, nr.Town, t.Name))
			} else {
				s.news("crime", fmt.Sprintf("`8%s drove to %s and brutally assaulted %s!`6\r\n\"%s\" `8justified %s.\r\n\r\n", me.Name, nr.Town, t.Name, text, me.Name))
			}
		} else {
			s.news("crime", fmt.Sprintf("`8%s went to %s looking for trouble and found it: %s put %s in the hospital!\r\n\r\n", me.Name, nr.Town, t.Name, him(me)))
		}
		peer, raid := nr.Peer, nr.Raid
		return s.call(peer, RaidReq{Op: "yell", Raid: raid, Text: text, Att: s.me2fighter()}, func(RaidAns, error) Screen {
			s.st = custStatus{}
			if win {
				return s.cmdComp(Action{})
			}
			return s.cmdHospital(Action{Sub: "room"})
		})
	}
	return s.cmdMain()
}

// xArson hires the Twins to visit a parlor in a linked town.
func (s *Session) xArson(ref string) Screen {
	peer, name, town, ok := splitNetRef(ref)
	me := s.me()
	if !ok || !s.raidsOn() || me.Coffins[Gold] < arsonCost {
		return s.cmdMain()
	}
	s.st = custStatus{}
	twins := func(t string) Screen {
		return cont(Screen{View: "desk", BG: "background/background_5", Pic: "people/m_old_3", Text: t}, "", "")
	}
	return s.call(peer, RaidReq{Op: "arson", Target: name, Att: s.me2fighter()}, func(ans RaidAns, err error) Screen {
		if err != nil {
			return twins("`wThe Twins: `y\"" + roadClosed(town, err) + "  Keep your gold.\"")
		}
		switch ans.Refused {
		case "":
		case "online":
			return twins(fmt.Sprintf("`yThe twins come back from %s shaking their heads.  Apparently they saw %s working in the yard.  They keep the gas money but give you back your gold.", town, name))
		case "limit":
			return twins(fmt.Sprintf("`yThe twins come back from %s.  \"Too many cops around %s's place today.  Try tomorrow.\"", town, name))
		case "off":
			return twins(fmt.Sprintf("`wThe Twins: `y\"%s doesn't let our kind in.  Keep your gold.\"", town))
		default:
			return twins(fmt.Sprintf("`wThe Twins: `y\"We drove all over %s.  Nobody by that name.\"", town))
		}
		me := s.me()
		me.Coffins[Gold] -= arsonCost
		sin := s.sin()
		tn := CleanRemote(ans.Name, 20, false)
		parlor := CleanRemote(ans.Parlor, 30, false)
		if ans.Saved {
			return twins(fmt.Sprintf("`yThe twins come back from %s smelling of smoke.\n\n`4\"The fire was put out before it could do any serious damage!\"\n\n`yDamn smoke detectors!", town) + sin)
		}
		burned, lost := clamp(ans.Burned, 0, 1e9), clamp(ans.Lost, 0, 1e9)
		text := fmt.Sprintf("`yThe twins come back from %s smelling of smoke and grinning.\n\n`wA fire engulfed %s!\n\n`y%s lost `w%d`y gravestone(s)", town, parlor, tn, burned)
		if ans.Safe {
			text += ".  They saw a shiny safe through a window."
		} else {
			text += fmt.Sprintf(" and `w%d`y wood tag(s).", lost)
		}
		scr := cont(Screen{View: "desk", Pic: "places/fire", Text: text + sin}, "", "")
		return scr
	})
}

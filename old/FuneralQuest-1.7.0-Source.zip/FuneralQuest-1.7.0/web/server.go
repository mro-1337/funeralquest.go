// Package web serves the browser version of Funeral Quest and its JSON API.
package web

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net/http"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"funeralquest/admin"
	"funeralquest/engine"
)

type Server struct {
	A         *admin.Admin
	G         *engine.Game
	PublicDir string // web/public
	ArtDir    string // assets/web
	Idle      time.Duration
	Opt       Options
	SecLog    *log.Logger

	mu       sync.Mutex
	sessions map[string]*websess
	tries    *limiter // log-on / sign-up attempts
	signups  *limiter // new accounts per address
	general  *limiter // all requests
	sysopTry *limiter
	sysop    map[string]*sysopSess
	setup    string // one-time admin setup code (only while no admin password is set)

	portOnlyAt  time.Time
	portOnlyVal bool
}

// netPortOnly says whether linked servers must use the network port (checked every few seconds).
func (srv *Server) netPortOnly() bool {
	srv.mu.Lock()
	defer srv.mu.Unlock()
	if time.Since(srv.portOnlyAt) > 3*time.Second {
		c := srv.A.Config()
		srv.portOnlyVal = c.NetPortOnly && c.NetPort > 0
		srv.portOnlyAt = time.Now()
	}
	return srv.portOnlyVal
}

func (srv *Server) secLog(format string, a ...any) {
	if srv.SecLog != nil {
		srv.SecLog.Printf(format, a...)
	}
}

type websess struct {
	s    *engine.Session
	seen time.Time
	mu   sync.Mutex // one request at a time per game session
}

func New(a *admin.Admin, publicDir, artDir string, opt Options) *Server {
	srv := &Server{A: a, G: a.G, PublicDir: publicDir, ArtDir: artDir, Idle: 20 * time.Minute, Opt: opt,
		sessions: map[string]*websess{}, tries: newLimiter(10, time.Minute), signups: newLimiter(3, time.Hour),
		general: newLimiter(900, time.Minute), sysopTry: newLimiter(5, time.Minute), sysop: map[string]*sysopSess{}}
	go srv.reaper()
	return srv
}

func (srv *Server) reaper() {
	for range time.Tick(time.Minute) {
		srv.mu.Lock()
		for tok, ws := range srv.sessions {
			if time.Since(ws.seen) > srv.Idle {
				go ws.s.Disconnect()
				delete(srv.sessions, tok)
			}
		}
		for tok, ss := range srv.sysop {
			if ss.expired(srv.A.SysopPasswordChanged()) {
				delete(srv.sysop, tok)
			}
		}
		srv.mu.Unlock()
		srv.G.Store.Tx(func(w *engine.World) error { srv.G.MaintCheck(w, false); return nil })
		srv.A.ApplyGuardSettings()
	}
}

func (srv *Server) start(p *engine.Player) (string, engine.Screen) {
	srv.mu.Lock()
	for tok, ws := range srv.sessions { // one browser session per player
		if ws.s.PID == p.ID {
			go ws.s.Disconnect()
			delete(srv.sessions, tok)
		}
	}
	tok := newToken()
	s := srv.G.NewSession(p.ID, "web")
	srv.sessions[tok] = &websess{s: s, seen: time.Now()}
	srv.mu.Unlock()
	return tok, s.Act(engine.Action{Cmd: "main"})
}

func (srv *Server) get(tok string) *websess {
	srv.mu.Lock()
	defer srv.mu.Unlock()
	ws := srv.sessions[tok]
	if ws == nil {
		return nil
	}
	ws.seen = time.Now()
	return ws
}

// run does fn with the session locked.
func (ws *websess) run(fn func(s *engine.Session)) {
	ws.mu.Lock()
	defer ws.mu.Unlock()
	fn(ws.s)
}

func newToken() string {
	b := make([]byte, 32)
	rand.Read(b)
	return hex.EncodeToString(b)
}

func send(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	json.NewEncoder(w).Encode(v)
}
func errJSON(err error) map[string]any { return map[string]any{"error": err.Error()} }

// Handler is the whole site, wrapped in the security layer.
func (srv *Server) Handler() http.Handler {
	mux := http.NewServeMux()
	fedH := srv.A.Net.Handler(srv.A.Guard)
	fed := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if srv.netPortOnly() {
			http.Error(w, "This town takes other Funeral Quest servers on its network port only.", http.StatusNotFound)
			return
		}
		fedH.ServeHTTP(w, r)
	})
	mux.Handle("GET /fed/", fed)
	mux.Handle("POST /fed/", fed)
	srv.sysopRoutes(mux)
	mux.HandleFunc("GET /api/info", func(w http.ResponseWriter, r *http.Request) {
		var out map[string]any
		srv.G.View(func(wd *engine.World) {
			on := map[int]bool{}
			for _, s := range wd.Online() {
				on[s.PlayerID] = true
			}
			out = map[string]any{"day": wd.Glo.GameAge, "players": len(wd.Active()), "online": len(on), "name": wd.Config.ServerName, "version": engine.Version}
		})
		send(w, out)
	})
	mux.HandleFunc("GET /api/rankings", func(w http.ResponseWriter, r *http.Request) {
		rows := []engine.RankRow{}
		town := ""
		srv.G.View(func(wd *engine.World) {
			town = wd.Config.ServerName
			on := map[int]bool{}
			for _, s := range wd.Online() {
				on[s.PlayerID] = true
			}
			for _, p := range wd.Ranked() {
				st := ""
				if on[p.ID] {
					st = "on now"
				}
				if r.URL.Query().Get("net") == "1" {
					st = strings.TrimSpace(town + " " + map[bool]string{true: "(" + st + ")", false: ""}[st != ""])
				}
				rows = append(rows, engine.RankRow{Name: p.Name, Male: p.Male, Parlor: p.Parlor, Exp: p.Exp, Status: st})
			}
		})
		towns := 0
		if srv.G.Net != nil {
			towns = len(srv.G.Net.Towns())
			if r.URL.Query().Get("net") == "1" {
				for _, rp := range srv.G.Net.RemotePlayers() {
					st := rp.Town
					if rp.Status != "" {
						st += " (" + rp.Status + ")"
					}
					rows = append(rows, engine.RankRow{Name: rp.Name, Male: rp.Male, Parlor: rp.Parlor, Exp: rp.Exp, Status: st})
				}
				sortRows(rows)
			}
		}
		send(w, map[string]any{"rows": rows, "towns": towns})
	})
	mux.HandleFunc("POST /api/{call}", func(w http.ResponseWriter, r *http.Request) {
		r.Body = http.MaxBytesReader(w, r.Body, 65536)
		if !strings.HasPrefix(r.Header.Get("Content-Type"), "application/json") {
			w.WriteHeader(415)
			send(w, errJSON(errors.New("bad request")))
			return
		}
		var b struct {
			Token, Logon, Password, Password2, Name, Parlor string
			Male                                            bool
			Action                                          *engine.Action
			Say                                             *string
			Wait                                            bool
		}
		if err := json.NewDecoder(r.Body).Decode(&b); err != nil {
			w.WriteHeader(400)
			send(w, errJSON(errors.New("bad request")))
			return
		}
		ip := srv.clientIP(r)
		switch r.PathValue("call") {
		case "login":
			if !srv.tries.allow(ip) {
				srv.A.Guard.Strike(ip, "too many web log-on tries", 1)
				send(w, errJSON(errors.New("Too many tries.  Wait a minute.")))
				return
			}
			if len(b.Logon) > 40 || len(b.Password) > 200 {
				send(w, errJSON(errors.New("Unknown logon name or wrong password.")))
				return
			}
			p, err := srv.G.Login(strings.TrimSpace(b.Logon), b.Password)
			if err != nil {
				if strings.Contains(err.Error(), "wrong password") {
					srv.secLog("failed web logon %q from %s", b.Logon, ip)
					if srv.A.Guard.Strike(ip, "failed web logons", 1) {
						srv.secLog("banned %s: failed web logons", ip)
					}
				}
				send(w, errJSON(err))
				return
			}
			tok, scr := srv.start(p)
			send(w, map[string]any{"token": tok, "screen": scr})
		case "register":
			if !srv.tries.allow(ip) {
				send(w, errJSON(errors.New("Too many tries.  Wait a minute.")))
				return
			}
			if len(b.Password) < 4 || len(b.Password) > 200 {
				send(w, errJSON(errors.New("Pick a password of at least 4 characters.")))
				return
			}
			if !srv.signups.allow(ip) {
				send(w, errJSON(errors.New("Too many new parlors from your address.  Try again later.")))
				return
			}
			if b.Password != b.Password2 {
				send(w, errJSON(errors.New("Your passwords don't match!  Try again, genius.")))
				return
			}
			p, err := srv.G.CreatePlayer(engine.NewPlayer{Logon: b.Logon, Password: b.Password, Name: b.Name, Parlor: b.Parlor, Male: b.Male})
			if err != nil {
				send(w, errJSON(err))
				return
			}
			tok, _ := srv.start(p)
			// the original showed brand new players the newspaper first
			var scr engine.Screen
			srv.get(tok).run(func(s *engine.Session) { scr = s.Act(engine.Action{Cmd: "news"}) })
			send(w, map[string]any{"token": tok, "screen": scr})
		case "act":
			if len(b.Token) != 64 {
				send(w, map[string]any{"error": "Your session expired.  Please log on again.", "expired": true})
				return
			}
			ws := srv.get(b.Token)
			if ws == nil {
				send(w, map[string]any{"error": "Your session expired.  Please log on again.", "expired": true})
				return
			}
			a := engine.Action{Cmd: "main"}
			if b.Action != nil {
				a = *b.Action
			}
			var scr engine.Screen
			ws.run(func(s *engine.Session) { scr = s.Act(a) })
			if scr.View == "quit" {
				srv.mu.Lock()
				delete(srv.sessions, b.Token)
				srv.mu.Unlock()
			}
			send(w, map[string]any{"screen": scr})
		case "chat":
			ws := srv.get(b.Token)
			if ws == nil {
				send(w, map[string]any{"error": "Your session expired.", "expired": true})
				return
			}
			say := ""
			if b.Say != nil {
				say = *b.Say
				if len(say) > 300 {
					say = say[:300]
				}
			}
			// with "wait", hold the request open (up to 20 s) until somebody says something:
			// lines then show up at once, in this town and from linked towns
			if b.Wait && say == "" {
				deadline := time.Now().Add(20 * time.Second)
				for time.Now().Before(deadline) && r.Context().Err() == nil {
					pending := false
					ws.run(func(s *engine.Session) { pending = s.ChatPending() })
					if pending {
						break
					}
					time.Sleep(150 * time.Millisecond)
				}
				if r.Context().Err() != nil {
					return
				}
			}
			var lines []string
			ws.run(func(s *engine.Session) { lines = s.ChatUpdate(say) })
			if lines == nil {
				lines = []string{}
			}
			send(w, map[string]any{"lines": lines})
		default:
			w.WriteHeader(404)
			send(w, errJSON(errors.New("no such call")))
		}
	})
	art := http.StripPrefix("/art/", http.FileServer(staticFS{http.Dir(srv.ArtDir)}))
	mux.Handle("GET /art/", http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if strings.HasSuffix(r.URL.Path, ".jxl") {
			w.Header().Set("Content-Type", "image/jxl")
		}
		w.Header().Set("Cache-Control", "public, max-age=86400")
		art.ServeHTTP(w, r)
	}))
	snd := http.StripPrefix("/sound/", http.FileServer(staticFS{http.Dir(filepath.Join(filepath.Dir(srv.ArtDir), "sound"))}))
	mux.Handle("GET /sound/", http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if strings.HasSuffix(r.URL.Path, ".ogg") {
			w.Header().Set("Content-Type", "audio/ogg")
		}
		w.Header().Set("Cache-Control", "public, max-age=86400")
		snd.ServeHTTP(w, r)
	}))
	pub := http.FileServer(staticFS{http.Dir(srv.PublicDir)})
	mux.Handle("GET /", http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch filepath.Ext(r.URL.Path) {
		case ".wasm":
			w.Header().Set("Content-Type", "application/wasm")
		case ".js":
			w.Header().Set("Content-Type", "text/javascript; charset=utf-8")
		}
		if strings.HasPrefix(r.URL.Path, "/sysop") && !srv.sysopAllowed(r) {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Cache-Control", "no-cache") // check for a newer version each time (a quick 304 when unchanged)
		pub.ServeHTTP(w, r)
	}))
	return srv.protect(mux)
}

func sortRows(rows []engine.RankRow) {
	for i := 1; i < len(rows); i++ {
		for j := i; j > 0 && rows[j].Exp > rows[j-1].Exp; j-- {
			rows[j], rows[j-1] = rows[j-1], rows[j]
		}
	}
}

var _ = fmt.Sprintf

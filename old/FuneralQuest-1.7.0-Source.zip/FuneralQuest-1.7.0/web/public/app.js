// Funeral Quest browser client. Talks to /api and draws the screens the engine sends.
// All artwork is JPEG XL. Browsers that can't show JPEG XL natively get it decoded by a WASM libjxl build.

// ---------------------------------------------------------------- JPEG XL
const PROBE = 'data:image/jxl;base64,/woAEAwExYUIAgEAHABLGIsVwhAO';
const jxlCache = new Map();
let nativeJxl = null;
let decoder = null;

function detectNative() {
  return new Promise((res) => {
    const im = new Image();
    im.onload = () => res(im.width === 1);
    im.onerror = () => res(false);
    im.src = PROBE;
  });
}
async function decodeJxl(url) {
  if (!decoder) decoder = import('./vendor/jxl/decode.js').then((m) => m.default);
  const decode = await decoder;
  const buf = await (await fetch(url)).arrayBuffer();
  const img = await decode(buf);
  const c = document.createElement('canvas');
  c.width = img.width; c.height = img.height;
  c.getContext('2d').putImageData(img, 0, 0);
  const blob = await new Promise((r) => c.toBlob(r, 'image/png'));
  return URL.createObjectURL(blob);
}
const ART_REV = 2; // raise when a picture changes, so browsers don't keep showing the old one
function jxlUrl(key) {
  const url = `art/${key}.jxl?r=${ART_REV}`;
  if (jxlCache.has(url)) return jxlCache.get(url);
  const p = (async () => {
    if (nativeJxl === null) nativeJxl = await detectNative();
    return nativeJxl ? url : decodeJxl(url);
  })();
  jxlCache.set(url, p);
  return p;
}
async function setImg(img, key) {
  img.dataset.key = key || '';
  if (!key) { img.removeAttribute('src'); img.classList.remove('loaded'); return; }
  try {
    const src = await jxlUrl(key);
    if (img.dataset.key !== key) return;
    img.onload = () => img.classList.add('loaded');
    img.src = src;
  } catch (e) { console.warn('art', key, e); }
}
function loadStaticArt() { document.querySelectorAll('img[data-jxl]').forEach((i) => setImg(i, i.dataset.jxl)); }

// ---------------------------------------------------------------- helpers
const $ = (id) => document.getElementById(id);
const COLORS = { 1: '#0000A8', 2: '#007000', 3: '#008080', 4: '#FF0000', 5: '#CC66CC', 6: '#A85400', 7: '#808080', 8: '#505050', 9: '#5454FC',
  0: '#00B000', '!': '#00A0A0', '@': '#FC5454', '#': '#FC54FC', $: '#FFFF33', y: '#FFFF33', w: '#FFFFFF', '^': '#000000' };
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
// LORD-style `x color codes -> HTML
function lord(text, base = '#FFFF33', remap = {}) {
  let out = `<span style="color:${base}">`;
  const s = String(text ?? '').replace(/\r/g, '');
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (ch === '`' && i + 1 < s.length) {
      const c = s[++i];
      if (c === 'f') { i++; continue; }
      const col = remap[c] || COLORS[c];
      if (col) out += `</span><span style="color:${col}">`;
      continue;
    }
    out += esc(ch);
  }
  return out + '</span>';
}
const strip = (s) => String(s ?? '').replace(/`f./g, '').replace(/`./g, '');
const cash = (n) => Number(n || 0).toLocaleString('en-US');

async function api(call, body) {
  const r = await fetch('api/' + call, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body || {}) });
  return r.json();
}

// ---------------------------------------------------------------- sound
// Same rules as the door: each scene picture has its own sound (looping ambience or a one-shot),
// plus music for battles, sneaking and the town map. Files are Ogg Vorbis from /sound/.
let SOUNDS = {};
fetch('sound/sounds.json').then((r) => r.json()).then((j) => { SOUNDS = j; }).catch(() => {});
let muted = localStorage.getItem('fq_mute') === '1';
const loops = new Map(); // key -> Audio
let sndBG = null, sndPic = null;
function hasSound(k) { return !!k && Object.prototype.hasOwnProperty.call(SOUNDS, k); }
function playOnce(k) {
  if (muted || !hasSound(k)) return;
  const a = new Audio(`sound/${k}.ogg`);
  a.volume = 0.7;
  a.play().catch(() => {});
}
function setLoops(keys) {
  for (const [k, a] of loops) if (!keys.includes(k)) { a.pause(); loops.delete(k); }
  if (muted) return;
  for (const k of keys) {
    if (loops.has(k)) continue;
    const a = new Audio(`sound/${k}.ogg`);
    a.loop = true; a.volume = 0.5;
    a.play().catch(() => {});
    loops.set(k, a);
  }
}
function soundScene(s) {
  if (['popup', 'news', 'ranking', 'stats', 'view'].includes(s.view)) { if (s.sound) playOnce(s.sound); return; }
  const want = [];
  const add = (k, changed) => { if (!hasSound(k)) return; if (SOUNDS[k].loop) want.push(k); else if (changed) playOnce(k); };
  add(s.bg, s.bg !== sndBG);
  add(s.pic, s.pic !== sndPic);
  if (hasSound(s.music)) want.push(s.music);
  if (s.sound && (s.bg !== sndBG || s.pic !== sndPic)) playOnce(s.sound);
  sndBG = s.bg; sndPic = s.pic;
  setLoops(want.slice(-2));
}
function updateSoundBtn() { $('soundBtn').classList.toggle('off', muted); $('soundBtn').innerHTML = muted ? '&#128263;' : '&#128266;'; }

// ---------------------------------------------------------------- state
let token = sessionStorage.getItem('fq_token') || null;
let screen = null;
let busy = false;
let chatTimer = null;
let chatRun = 0; // bumped to stop the chat long-poll loop

function show(id) {
  for (const s of document.querySelectorAll('.screen')) s.classList.toggle('hidden', s.id !== id);
}

// ---------------------------------------------------------------- logon
async function initLogon() {
  show('logon');
  try {
    const info = await (await fetch('api/info')).json();
    $('serverInfo').textContent = `${info.name}: day ${info.day} · ${info.players} parlor${info.players === 1 ? '' : 's'} in town · ${info.online} open right now · v${info.version}`;
  } catch { /* offline */ }
}
$('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const f = new FormData(e.target);
  const r = await api('login', { logon: f.get('logon'), password: f.get('password') });
  enterGame(r);
});
$('newForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const f = new FormData(e.target);
  const r = await api('register', { logon: f.get('logon'), password: f.get('password'), password2: f.get('password2'),
    name: f.get('name'), parlor: f.get('parlor'), male: f.get('sex') === 'm' });
  enterGame(r);
});
function enterGame(r) {
  if (r.error) { $('logonError').textContent = r.error; return; }
  $('logonError').textContent = '';
  token = r.token;
  sessionStorage.setItem('fq_token', token);
  show('game');
  render(r.screen);
}
async function showRanks(net) {
  const r = await (await fetch('api/rankings' + (net ? '?net=1' : ''))).json();
  const toggle = r.towns ? ` <a href="#" id="rankToggle" class="small">${net ? 'This town only' : 'All linked towns'}</a>` : '';
  $('overlayContent').innerHTML = `<h2>${net ? 'Network Rankings' : 'Parlor Rankings'}${toggle}</h2>` + rankTable(r.rows);
  if (r.towns) $('rankToggle').addEventListener('click', (e) => { e.preventDefault(); showRanks(!net); });
  $('overlayPage').classList.remove('hidden');
}
$('showRankings').addEventListener('click', (e) => { e.preventDefault(); showRanks(false); });
$('showRules').addEventListener('click', (e) => {
  e.preventDefault();
  $('overlayContent').innerHTML = `<h2>Funeral Quest</h2>
  <p>You run a funeral parlor in Deathville.  Each day you get a number of turns to <b>wait for customers</b>.  Grieving customers come in;
  talk them up with <b>Soft Sell</b> (extras like flowers or live piano), <b>Hard Sell</b> (a better casket, then the big-ticket items),
  <b>Sympathy</b> (works on those who loved the deceased) and <b>Guilt</b> (works on those who didn't).  Push too hard and they storm off to a rival.
  Hit <b>Done</b> to close the sale.  Getting the bill close to what they can afford earns a bonus.</p>
  <p>Sales earn <b>Bury Points</b> (your score) and casket tags.  Spend gold tags at <b>Spirit University</b> (psychology, hitpoints, strength),
  <b>Di-Mart</b> (hearses for extra turns, padlocks, smoke detectors, safes, lockpicks) and trade tags at the <b>Bank</b>.
  Visit rival parlors at night to steal tags or beat up the owner, send cursed take-out from <b>Yang's</b>, hire arsonists, and gossip in the
  <b>Pale Horse Cafe</b>, shared live with players calling in from the BBS.</p>
  <p>Keyboard: every button has a hot key (underlined).  Enter picks the highlighted button.</p>`;
  $('overlayPage').classList.remove('hidden');
});
$('overlayClose').addEventListener('click', () => $('overlayPage').classList.add('hidden'));

// ---------------------------------------------------------------- game rendering
function updateCard(s) {
  const st = s.stats || {};
  $('sp').textContent = cash(st.sp);
  $('turns').textContent = cash(st.turns);
  $('luckFill').style.height = Math.max(0, Math.min(100, st.luck || 0)) + '%';
  $('luckFill').parentElement.title = `Luck ${st.luck}%`;
  $('tagWood').textContent = cash(st.tags?.[0]);
  $('tagSilver').textContent = cash(st.tags?.[1]);
  $('tagGold').textContent = cash(st.tags?.[2]);
  $('cardInfo').innerHTML = s.info ? esc(s.info.replace(/`./g, '')) : ''; // the parchment card shows plain text
  let extra = `<div>Total Bury Points: <b>${cash(st.exp)}</b> &nbsp; Cash <b>$${cash(st.money)}</b> &nbsp; Day <b>${st.day}</b></div>`;
  if (s.battle) {
    const b = s.battle;
    extra += `<div>${esc(b.me.name)} - ${b.me.hp} of ${b.me.max} hitpoints</div><div class="hp"><i style="width:${(100 * b.me.hp) / b.me.max}%"></i></div>`
      + `<div>${esc(b.him.name)} - ${b.him.hp} of ${b.him.max} hitpoints</div><div class="hp him"><i style="width:${(100 * b.him.hp) / b.him.max}%"></i></div>`;
  } else if (st.mail) extra += `<div style="color:#8a1a00"><b>${st.mail}</b> letter${st.mail === 1 ? '' : 's'} waiting at your desk.</div>`;
  $('extraStats').innerHTML = extra;
}

function setMode(mode) {
  const main = $('mainArea');
  main.className = 'main-area ' + (mode || '');
  $('game').classList.toggle('on-map', mode === 'map');
  $('card').classList.toggle('hidden', mode === 'map' || mode === 'paper' || mode === 'table');
  document.querySelector('.frame').classList.toggle('hidden', mode === 'map' || mode === 'paper' || mode === 'table');
  $('mapView').classList.toggle('hidden', mode !== 'map');
  $('paperView').classList.toggle('hidden', mode !== 'paper');
  $('tableView').classList.toggle('hidden', mode !== 'table');
}

function rankTable(rows) {
  if (!rows.length) return '<p>Nobody is in town yet.</p>';
  return '<table><tr><th>#</th><th>Name</th><th></th><th>Parlor</th><th class="num">Bury Points</th><th>Status</th></tr>'
    + rows.map((r, i) => `<tr><td>${i + 1}</td><td>${esc(r.name)}</td><td class="${r.male ? 'm' : 'f'}">${r.male ? 'M' : 'F'}</td><td>${esc(r.parlor)}</td><td class="num">${cash(r.exp)}</td><td class="on">${esc(r.status || '')}</td></tr>`).join('')
    + '</table>';
}

const HOTSPOTS = [
  ['spirit', 'Spirit University', 3.6, 0.8, 17.2, 19.3], ['yangs', "Yang's", 6.1, 29.2, 16.7, 17.7], ['cafe', 'Pale Horse Cafe', 43.8, 10.8, 12.0, 22.4],
  ['church', 'Church', 34.4, 36.2, 12.0, 17.0], ['main', 'Your parlor', 60.0, 33.8, 15.6, 19.9], ['comp', 'Rival parlors', 82.0, 31.5, 17.8, 32.3],
  ['store', 'Di-Mart', 57.2, 58.4, 15.4, 17.0], ['hospital', 'Hospital', 34.9, 68.4, 13.6, 23.0], ['bank', 'Bank', 2.5, 73.8, 13.6, 21.5], ['graveyard', 'Graveyard', 68.0, 5.5, 22.5, 26.9],
];
function drawHotspots() {
  $('hotspots').innerHTML = '';
  for (const [cmd, label, l, t, w, h] of HOTSPOTS) {
    const a = document.createElement('a');
    a.href = '#'; a.style.cssText = `left:${l}%;top:${t}%;width:${w}%;height:${h}%`;
    a.innerHTML = `<span>${esc(label)}</span>`; a.setAttribute('aria-label', label);
    a.addEventListener('click', (e) => { e.preventDefault(); act({ cmd }); });
    $('hotspots').appendChild(a);
  }
}

function renderButtons(buttons) {
  const nav = $('buttons');
  nav.innerHTML = '';
  for (const b of buttons || []) {
    const el = document.createElement('button');
    el.className = 'btn' + (b.def ? ' def' : '');
    const k = b.key && b.key.length === 1 ? b.key : null;
    const i = k ? b.label.toLowerCase().indexOf(k) : -1;
    el.innerHTML = i >= 0 ? `${esc(b.label.slice(0, i))}<span class="hk">${esc(b.label[i])}</span>${esc(b.label.slice(i + 1))}` : esc(b.label) + (k ? ` <small>(${esc(k)})</small>` : '');
    el.title = k ? `Hot key: ${k.toUpperCase()}` : '';
    el.addEventListener('click', () => { playOnce('ui/click'); const { label, key, def, ...a } = b; act(a); });
    nav.appendChild(el);
  }
}

function render(s) {
  if (!s) return;
  screen = s;
  stopChat();
  $('chatForm').classList.add('hidden');
  if (s.view === 'quit' || s.view === 'gone') {
    setLoops([]);
    sessionStorage.removeItem('fq_token'); token = null;
    $('text').innerHTML = lord(s.text) + lord('\n\n`wThanks for playing Funeral Quest!');
    renderButtons([{ label: 'Log on again', cmd: '_logon', key: 'l', def: true }]);
    return;
  }
  $('locationName').textContent = s.location || '';
  updateCard(s);
  soundScene(s);
  const popup = s.view === 'popup';
  if (!popup) {
    if (s.view === 'map') { setMode('map'); }
    else if (s.view === 'news') {
      setMode('paper');
      $('topToday').textContent = s.topToday; $('topYesterday').textContent = strip(s.topYesterday);
      $('paperDay').textContent = `Day ${s.day}`; $('paperSection').textContent = s.section === 'crime' ? 'Crime' : 'Front Page';
      $('paperText').innerHTML = lord(s.text, '#000', { '^': '#000', 7: '#333', w: '#000', $: '#6a4a00', y: '#6a4a00' });
    } else if (s.view === 'ranking') {
      setMode('table');
      $('tableView').innerHTML = `<h2>${esc(s.title || 'Parlor Rankings')}</h2>` + rankTable(s.rows);
    } else if (s.view === 'stats') {
      setMode('table');
      $('tableView').innerHTML = `<h2>${esc(s.stats.name)} of ${esc(s.stats.parlor)}</h2><dl class="stats-grid">`
        + s.rows.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`).join('')
        + `<dt>Rating</dt><dd>${esc(s.rating)}</dd><dt>Karma</dt><dd>${esc(s.karma)}</dd></dl>`;
    } else {
      setMode('');
      setImg($('picBg'), s.bg || '');
      setImg($('picFg'), s.pic || '');
      $('overlay').textContent = s.sale ? `Class: ${s.cls}\nMood: ${s.mood}` : '';
    }
  }
  let text = s.text || '';
  if (s.view === 'news') text = '`$The paper is on the rack.';
  if (s.view === 'ranking' || s.view === 'stats') text = s.view === 'stats' ? (s.text || '') : '';
  $('text').innerHTML = lord(text);
  $('text').scrollTop = 0;
  renderButtons(s.buttons);
  if (s.view === 'chat') startChat(s);
  if (s.input) openDialog(s.input, s.text);
}

// ---------------------------------------------------------------- input dialog
let dialogInput = null;
function openDialog(inp, text) {
  dialogInput = inp;
  const multi = !!inp.multiline;
  $('dialogPrompt').innerHTML = lord(inp.prompt || strip(text), '#241608', { $: '#241608', y: '#241608', w: '#000' })
    + (inp.kind === 'name' ? '<br><small>(type part of a name)</small>' : '');
  const el = multi ? $('dialogArea') : $('dialogInput');
  $('dialogInput').classList.toggle('hidden', multi);
  $('dialogArea').classList.toggle('hidden', !multi);
  $('dialogInput').type = inp.kind === 'password' ? 'password' : inp.kind === 'number' ? 'number' : 'text';
  el.value = inp.def || '';
  el.maxLength = inp.maxLen || 200;
  $('dialog').classList.remove('hidden');
  setTimeout(() => { el.focus(); el.select?.(); }, 30);
}
function closeDialog(value) {
  $('dialog').classList.add('hidden');
  dialogInput = null;
  act({ cmd: 'input', value });
}
$('dialogForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const v = (dialogInput && dialogInput.multiline ? $('dialogArea') : $('dialogInput')).value;
  closeDialog(v);
});
$('dialogCancel').addEventListener('click', () => closeDialog(null));

// ---------------------------------------------------------------- chat
function appendChat(lines) {
  if (!lines || !lines.length) return;
  const t = $('text');
  for (const l of lines) t.insertAdjacentHTML('beforeend', lord('\n' + l));
  t.scrollTop = t.scrollHeight;
}
function startChat() {
  $('chatForm').classList.remove('hidden');
  $('chatInput').value = '';
  setTimeout(() => $('chatInput').focus(), 30);
  // real-time chat: the server holds each request until somebody speaks (or 20 s pass)
  const run = ++chatRun;
  const poll = async () => {
    while (run === chatRun) {
      try {
        const r = await api('chat', { token, wait: true });
        if (run !== chatRun) return;
        if (r.expired) return expired();
        appendChat(r.lines);
      } catch {
        await new Promise((ok) => setTimeout(ok, 3000)); // network hiccup: try again shortly
      }
    }
  };
  chatTimer = true;
  poll();
}
function stopChat() { chatRun++; chatTimer = null; }
$('chatForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const say = $('chatInput').value;
  $('chatInput').value = '';
  if (/^\/q(uit)?$/i.test(say.trim())) return act({ cmd: 'map' });
  const r = await api('chat', { token, say });
  if (r.expired) return expired();
  appendChat(r.lines);
});

// ---------------------------------------------------------------- actions & keys
function expired() {
  stopChat();
  sessionStorage.removeItem('fq_token'); token = null;
  initLogon();
  $('logonError').textContent = 'Your session expired.  Please log on again.';
}
async function act(a) {
  if (busy) return;
  if (a.cmd === '_logon') return initLogon();
  busy = true;
  try {
    const r = await api('act', { token, action: a });
    if (r.expired) return expired();
    if (r.error) { $('text').innerHTML = lord('`4' + r.error); return; }
    render(r.screen);
  } finally { busy = false; }
}
$('exitBtn').addEventListener('click', () => act({ cmd: 'quit' }));
$('soundBtn').addEventListener('click', () => {
  muted = !muted;
  localStorage.setItem('fq_mute', muted ? '1' : '0');
  updateSoundBtn();
  if (muted) setLoops([]); else if (screen) { sndBG = sndPic = null; soundScene(screen); }
});
// the intro music plays on the log-on page once the visitor clicks or types (browsers need a gesture)
let introPlayed = false;
document.addEventListener('pointerdown', () => {
  if (!introPlayed && !$('logon').classList.contains('hidden') && !muted) { introPlayed = true; playOnce('ui/intro'); }
}, { capture: true });
document.addEventListener('keydown', (e) => {
  if ($('game').classList.contains('hidden') || !screen) return;
  if (!$('dialog').classList.contains('hidden')) { if (e.key === 'Escape') closeDialog(null); return; }
  const tag = (e.target.tagName || '').toLowerCase();
  if (tag === 'input' || tag === 'textarea') { if (e.key === 'Escape' && screen.view === 'chat') act({ cmd: 'map' }); return; }
  if (e.ctrlKey || e.metaKey || e.altKey) return;
  const bs = screen.buttons || [];
  let b = null;
  if (e.key === 'Enter') b = bs.find((x) => x.def);
  else if (e.key === 'Escape') b = bs.find((x) => x.key === 'esc') || bs.find((x) => /^(leave|back|cancel)$/i.test(x.label));
  else b = bs.find((x) => x.key === e.key.toLowerCase());
  if (b) { e.preventDefault(); playOnce('ui/click'); const { label, key, def, ...a } = b; act(a); }
});

// ---------------------------------------------------------------- boot
(async () => {
  const brick = await jxlUrl('ui/brick').catch(() => null);
  if (brick) document.documentElement.style.setProperty('--brick', `url("${brick}")`);
  loadStaticArt();
  drawHotspots();
  updateSoundBtn();
  detectNative().then((n) => { nativeJxl = n; $('jxlMode').textContent = n ? ' (native decoder)' : ' (decoded by libjxl/WASM)'; });
  if (token) {
    const r = await api('act', { token, action: { cmd: 'main' } });
    if (r.screen) { show('game'); return render(r.screen); }
  }
  initLogon();
})();

package engine

import (
	"fmt"
	"strings"
	"time"
	"unicode"
)

// RemotePlayer is a player on a linked Funeral Quest server, as that server last reported it.
// Linked servers only ever see these public fields; they can't change anything here.
type RemotePlayer struct {
	Peer   string `json:"peer"` // linked server's ID
	Town   string `json:"town"`
	Name   string `json:"name"`
	Parlor string `json:"parlor"`
	Male   bool   `json:"male"`
	Exp    int    `json:"exp"`
	Status string `json:"status,omitempty"` // "", "on now", "in cafe"
}

// Town is a linked server.
type Town struct {
	ID      string    `json:"id"`
	Name    string    `json:"name"`
	Day     int       `json:"day"`
	Players int       `json:"players"`
	Online  int       `json:"online"`
	LastOK  time.Time `json:"last_ok"`
	OutOnly bool      `json:"out_only,omitempty"` // can't be connected to: its players can't be visited
}

// Network is what the game needs from the server-to-server link (package fqnet).
type Network interface {
	RemotePlayers() []RemotePlayer
	Towns() []Town
	// QueueMail hands a letter to the network for delivery to a player on a linked server.
	QueueMail(peer, toName string, fromID int, fromName, fromParlor, text string) error
	// Raid sends one raid step to a linked town and returns its answer.
	Raid(peer string, req RaidReq) (RaidAns, error)
}

// CleanRemote makes text from another server safe to show: no control characters or escape
// sequences, LORD colour codes allowed only when codes is true, and at most max characters.
func CleanRemote(s string, max int, codes bool) string {
	var b strings.Builder
	n := 0
	rs := []rune(s)
	for i := 0; i < len(rs) && n < max; i++ {
		c := rs[i]
		switch {
		case c == '`':
			if codes && i+1 < len(rs) && strings.ContainsRune("1234567890!@#$yw^", rs[i+1]) {
				b.WriteRune(c)
				b.WriteRune(rs[i+1])
				i++
			}
			continue
		case c == '\n':
			if codes {
				b.WriteRune('\n')
				n++
			}
			continue
		case c < 0x20 || c == 0x7f || (c >= 0x80 && c < 0xa0) || !unicode.IsPrint(c) && c != ' ':
			continue
		}
		b.WriteRune(c)
		n++
	}
	return strings.TrimSpace(b.String())
}

func (s *Session) netOn() bool { return s.G.Net != nil }

// remoteMatches finds players on linked servers whose name contains q. For raids, towns that
// can't be connected to (outbound only) are left out, since nobody can visit them.
func (s *Session) remoteMatches(q string, raid bool) []RemotePlayer {
	if !s.netOn() {
		return nil
	}
	skip := map[string]bool{}
	if raid {
		for _, t := range s.G.Net.Towns() {
			skip[t.ID] = t.OutOnly
		}
	}
	var out []RemotePlayer
	for _, rp := range s.G.Net.RemotePlayers() {
		if !skip[rp.Peer] && strings.Contains(strings.ToLower(rp.Name), q) {
			out = append(out, rp)
		}
	}
	return out
}

// NetRef packs a remote player's address into one string for buttons and inputs.
func NetRef(peer, name, town string) string { return peer + "\t" + name + "\t" + town }
func splitNetRef(r string) (peer, name, town string, ok bool) {
	f := strings.Split(r, "\t")
	if len(f) != 3 || f[0] == "" || f[1] == "" {
		return "", "", "", false
	}
	return f[0], f[1], f[2], true
}

// netMail is cmdMailWrite for players on linked servers.
func (s *Session) netMail(a Action) Screen {
	peer, name, town, ok := splitNetRef(a.Section)
	if !ok || !s.netOn() || s.cfg().NetMailOff {
		return s.desk("`$The post office can't send letters out of town right now.")
	}
	if a.Sub != "netsend" {
		return Screen{View: "popup", Text: fmt.Sprintf("`$Writing a letter to `w%s`$ in %s.", name, town),
			Input: &Input{Kind: "text", Prompt: "Letter to " + name + ":", Cmd: "mail_write", Sub: "netsend", Extra: &Action{Section: a.Section}, MaxLen: 1500, Multiline: true}}
	}
	v, ok := val(a)
	if !ok || strings.TrimSpace(v) == "" {
		return s.desk("`$You crumple up the letter.")
	}
	me := s.me()
	content := swearCheck(strings.ReplaceAll(v, "\r\n", "\n"), s.data().Swears)
	if err := s.G.Net.QueueMail(peer, name, me.ID, me.Name, me.Parlor, content); err != nil {
		return s.desk("`$The post office won't take it: " + err.Error())
	}
	return s.desk(fmt.Sprintf("`$Your letter to `w%s`$ in %s is on its way.", name, town))
}

// netRankingRows ranks local and linked players together.
func (s *Session) netRankingRows() []RankRow {
	type row struct {
		r   RankRow
		exp int
	}
	var all []row
	town := s.cfg().ServerName
	for _, r := range s.rankingRows(false) {
		r.Status = strings.TrimSpace(town + " " + ifs(r.Status != "", "("+r.Status+")", ""))
		all = append(all, row{r, r.Exp})
	}
	for _, rp := range s.G.Net.RemotePlayers() {
		st := rp.Town
		if rp.Status != "" {
			st += " (" + rp.Status + ")"
		}
		all = append(all, row{RankRow{rp.Name, rp.Male, rp.Parlor, rp.Exp, st}, rp.Exp})
	}
	// simple insertion sort, highest BP first
	for i := 1; i < len(all); i++ {
		for j := i; j > 0 && all[j].exp > all[j-1].exp; j-- {
			all[j], all[j-1] = all[j-1], all[j]
		}
	}
	out := make([]RankRow, 0, len(all))
	for _, r := range all {
		out = append(out, r.r)
	}
	return out
}

func (s *Session) netTownsText() string {
	if !s.netOn() {
		return "`5This town isn't linked to any others."
	}
	towns := s.G.Net.Towns()
	if len(towns) == 0 {
		return "`5This town isn't linked to any others."
	}
	players := s.G.Net.RemotePlayers()
	var b strings.Builder
	b.WriteString("\n`wLinked towns\n`$-----------------------------------------------\n")
	for _, t := range towns {
		var on []string
		for _, p := range players {
			if p.Peer == t.ID && p.Status != "" {
				on = append(on, p.Name+ifs(p.Status == "in cafe", " (cafe)", ""))
			}
		}
		fmt.Fprintf(&b, "`w%s`$: day %d, %d parlors", t.Name, t.Day, t.Players)
		if len(on) > 0 {
			b.WriteString(", on now: `w" + strings.Join(on, ", "))
		}
		if t.OutOnly {
			b.WriteString(" `8(connects out only: can't be visited)")
		} else if time.Since(t.LastOK) > 5*time.Minute {
			b.WriteString(" `8(not reachable lately)")
		}
		b.WriteString("\n")
	}
	return strings.TrimRight(b.String(), "\n")
}

package engine

import (
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
)

// SettingInfo describes one sysop setting for the editors (fqedit, the web sysop pages, fq admin).
type SettingInfo struct {
	Key   string  `json:"key"`
	Group string  `json:"group"`
	Label string  `json:"label"`
	Help  string  `json:"help"`
	Kind  string  `json:"kind"` // int, float, bool, text, ints3
	Min   float64 `json:"min"`
	Max   float64 `json:"max"`
}

var Settings = []SettingInfo{
	{"server_name", "Game", "Town name", "Name of the town, shown on the log-on screen and to linked servers.", "text", 1, 30},
	{"turns_per_day", "Game", "Turns per day", "How many customers' worth of turns each player gets every day.", "int", 1, 500},
	{"max_players", "Game", "Maximum players", "New parlors are refused once this many are open.", "int", 1, 100000},
	{"inactive_days", "Game", "Days before closing idle parlors", "Parlors not played for this many days are closed at maintenance.", "int", 1, 3650},
	{"maint_delete", "Game", "Delete closed parlors", "Remove closed parlors from the data file at maintenance, instead of keeping them.", "bool", 0, 0},
	{"online_timeout_minutes", "Game", "Online timeout (minutes)", "A player who does nothing this long no longer shows as online.", "int", 1, 600},
	{"name_change_cost", "Game", "Name change cost (luck)", "Luck it costs to change your name at City Hall.", "int", 0, 1000},

	{"starting_money", "New players", "Starting money", "Cash a new parlor starts with.", "int", 0, 100000000},
	{"starting_luck", "New players", "Starting luck", "", "int", 0, 10000},
	{"starting_hp", "New players", "Starting hit points", "", "int", 1, 10000},
	{"starting_strength", "New players", "Starting strength", "", "int", 0, 10000},
	{"starting_karma", "New players", "Starting karma", "0-100.", "int", 0, 100},
	{"starting_rating", "New players", "Starting rating", "0-100.", "int", 0, 100},

	{"casket_sp", "Scoring", "Casket points (wood,silver,gold)", "Sale points for each casket type, e.g. 1,2,3.", "ints3", 0, 1000},
	{"plot_sp", "Scoring", "Plot points", "Sale points for selling a plot.", "int", 0, 1000},
	{"bonus_exp", "Scoring", "Top seller BP bonus", "Bury points given to the day's top seller.", "int", 0, 100000},
	{"bonus_luck", "Scoring", "Top seller luck bonus", "", "int", 0, 100000},
	{"trade_bonus", "Scoring", "Trade bonus (%)", "", "int", 0, 1000},

	{"risk", "Odds", "Double-or-nothing risk", "Chance (0-100) that a double-or-nothing risk goes badly.", "int", 0, 100},
	{"normal_odds", "Odds", "Random event odds", "Chance of a random parlor event per turn (0-1).", "float", 0, 1},
	{"luck_odds", "Odds", "Luck event odds", "Chance of a luck event per turn (0-1).", "float", 0, 1},
	{"script_odds", "Odds", "Special event odds", "Chance of a special event per turn (0-1).", "float", 0, 1},
	{"yangs_per_day", "Odds", "Fortune cookies per day", "How many fortune cookies (yangs) a player may send per day.", "int", 0, 100},
	{"visits_per_day", "Odds", "Rival visits per day", "How many times a player may break into rival parlors per day.", "int", 0, 100},
	{"tags_receivable_per_day", "Odds", "Tags received per day", "How many toe tags a player may be sent per day.", "int", 0, 100},

	{"tourn_active", "Tournament", "Tournament mode", "Run the game as a tournament that ends after a set number of days.", "bool", 0, 0},
	{"tourn_days", "Tournament", "Tournament length (days)", "", "int", 1, 3650},

	{"ban_strikes", "Security", "Strikes before a ban", "Failed logons or attacks from one address within 10 minutes that cause a temporary ban.", "int", 1, 100},
	{"ban_minutes", "Security", "First ban length (minutes)", "Each repeat ban for the same address is twice as long (up to 7 days).", "int", 1, 10080},
	{"ban_conn_per_minute", "Security", "Connections per minute", "More new telnet connections than this per minute from one address is a flood and gets banned.", "int", 1, 1000},
	{"ban_max_per_ip", "Security", "Connections at once per address", "", "int", 1, 100},
	{"sysop_allow", "Security", "Admin pages allowed from", "IPs/ranges allowed to open the web admin pages (/sysop/), comma separated (e.g. 127.0.0.1, 192.168.0.0/16). Empty = anywhere.", "text", 0, 500},

	{"web_port", "Server (restart to apply)", "Web server port", "Port for the web game, sysop pages and the network link. 0 = 8080. Restart fq web after changing it, and update This server's web address to match.", "int", 0, 65535},
	{"web_host", "Server (restart to apply)", "Web server listens on", "IP address to listen on. Empty = every network card. 127.0.0.1 = only this machine (behind your own proxy).", "text", 0, 60},
	{"web_cert", "Server (restart to apply)", "HTTPS certificate file", "Full path of a PEM certificate (e.g. fullchain.pem). Set this and the key file to serve HTTPS. Empty = plain HTTP.", "text", 0, 300},
	{"web_key", "Server (restart to apply)", "HTTPS key file", "Full path of the PEM private key that goes with the certificate.", "text", 0, 300},
	{"web_trust_proxy", "Server (restart to apply)", "Behind my own proxy", "Yes if Caddy, IIS or nginx on this machine or your LAN passes requests on, so bans hit the real caller's address.", "bool", 0, 0},
	{"telnet_port", "Server (restart to apply)", "Telnet server port", "Port for  fq telnet  (the stand-alone telnet server, not needed when running as a door). 0 = 2323.", "int", 0, 65535},
	{"net_port", "Server (restart to apply)", "Network port (without the web server)", "When the web server isn't running: port where  fq telnet  or  fq net  lets other Funeral Quest servers reach this town. 0 = none: this town connects out to linked towns only (works behind a firewall, but players from other towns can't raid yours).", "int", 0, 65535},
	{"sound_off", "Server (restart to apply)", "No sound for callers", "Never send sound to door and telnet callers.", "bool", 0, 0},

	{"rlogin_port", "RLogin", "RLogin port", "Port for RLogin callers (BBS gateways, SyncTERM's RLogin). 0 = RLogin off. The standard port is 513 (needs admin rights on Linux); BBS games often use something like 1513. Runs with  fq telnet  or  fq rlogin. Restart to apply.", "int", 0, 65535},
	{"rlogin_trusted", "RLogin", "Hosts allowed to connect", "IPs or ranges allowed to use RLogin, comma separated. * = anyone (then the gateway secret and players' own passwords protect logins). If your BBS is on this machine, 127.0.0.1 is safest.", "text", 0, 500},
	{"rlogin_secret", "RLogin", "BBS gateway secret", "Shared secret your BBS sends with the caller's name (Synchronet rlogin_gate, Mystic IR /pass=). Whoever has it can enter under any name, so make it long and private. Empty = no gateway logins; callers must send their own game logon and password.", "text", 0, 120},
	{"rlogin_bbs_id", "RLogin", "BBS ID for gateway callers", "Gateway callers are the same players as door callers from the BBS with this ID (the door's --bbs-id, normally bbs), so a caller keeps their parlor whichever way they come in.", "text", 1, 30},

	{"net_public_url", "Network", "This server's web address", "The address other Funeral Quest servers use to reach you, e.g. http://bbs.example.com:8080", "text", 0, 200},
	{"net_auto_accept", "Network", "Accept link requests automatically", "Off: link requests from other servers wait for you to accept them.", "bool", 0, 0},
	{"net_chat_off", "Network", "Turn off network chat", "Stop sharing Cafe chat with linked servers.", "bool", 0, 0},
	{"net_mail_off", "Network", "Turn off network mail", "Stop letters to and from players on linked servers.", "bool", 0, 0},
	{"net_raids_off", "Network", "Turn off out-of-town raids", "Stop break-ins, fights and arson between your players and linked towns (both ways).", "bool", 0, 0},
	{"net_intro_off", "Network", "Don't follow introductions", "No (normal): when a linked town introduces the other towns it's linked to, this town sends them link requests, so every town ends up linked to every other. Yes: link only to towns you add yourself.", "bool", 0, 0},
	{"net_share_links_off", "Network", "Don't introduce my links", "No (normal): tell linked towns which other towns you're linked to, so they can link to them too. Yes: keep your list of links to yourself.", "bool", 0, 0},
	{"net_accept_introduced", "Network", "Accept introduced towns automatically", "Yes: a link request from a town that one of your linked towns is linked to is accepted without asking. (Two towns that both follow introductions link up by themselves anyway; this matters for towns that connect out only.)", "bool", 0, 0},
	{"net_vote_apply_off", "Network", "Don't apply settings votes", "No (normal): when a settings vote among linked towns passes, this town switches to those settings even if you voted no. Yes: votes never change your settings.", "bool", 0, 0},
	{"net_raids_per_day", "Network", "Out-of-town raids per player per day", "How many times visitors from linked towns can raid or burn one of your players each day.", "int", 1, 100},
}

// Version is the release number of the game (major.minor.patch). Linked towns compare
// versions and tell the sysop running the older one to update. See CHANGES.md.
const Version = "1.4.0"

// SharedSettings are the game rules linked towns should agree on, so nobody gets an edge
// (turns, starting stats, scoring, odds, limits). Local things like the town name, security
// and housekeeping aren't compared.
var SharedSettings = []string{"turns_per_day", "name_change_cost", "starting_money", "starting_luck", "starting_hp",
	"starting_strength", "starting_karma", "starting_rating", "casket_sp", "plot_sp", "bonus_exp", "bonus_luck",
	"trade_bonus", "risk", "normal_odds", "luck_odds", "script_odds", "yangs_per_day", "visits_per_day",
	"tags_receivable_per_day", "tourn_active", "tourn_days", "net_raids_per_day"}

// Rules returns this town's shared settings.
func (c *Config) Rules() map[string]string {
	m := map[string]string{}
	for _, k := range SharedSettings {
		m[k] = c.Get(k)
	}
	return m
}

// CompareVersions returns -1, 0 or 1 for versions like "1.3.0".
func CompareVersions(a, b string) int {
	pa, pb := strings.Split(a, "."), strings.Split(b, ".")
	for i := 0; i < max(len(pa), len(pb)); i++ {
		var x, y int
		if i < len(pa) {
			x, _ = strconv.Atoi(pa[i])
		}
		if i < len(pb) {
			y, _ = strconv.Atoi(pb[i])
		}
		if x != y {
			if x < y {
				return -1
			}
			return 1
		}
	}
	return 0
}

func SettingByKey(k string) *SettingInfo {
	for i := range Settings {
		if Settings[i].Key == k {
			return &Settings[i]
		}
	}
	return nil
}

func (c *Config) asMap() map[string]any {
	m := map[string]any{}
	b, _ := json.Marshal(c)
	json.Unmarshal(b, &m)
	return m
}

// Get returns a setting as text.
func (c *Config) Get(key string) string {
	v, ok := c.asMap()[key]
	if !ok {
		return ""
	}
	switch x := v.(type) {
	case []any:
		var parts []string
		for _, e := range x {
			parts = append(parts, fmt.Sprint(e))
		}
		return strings.Join(parts, ",")
	case float64:
		return strconv.FormatFloat(x, 'f', -1, 64)
	}
	return fmt.Sprint(v)
}

// Set checks and changes one setting given as text.
func (c *Config) Set(key, val string) error {
	info := SettingByKey(key)
	if info == nil {
		return fmt.Errorf("unknown setting %q", key)
	}
	val = strings.TrimSpace(val)
	m := c.asMap()
	num := func(s string) (float64, error) {
		f, err := strconv.ParseFloat(strings.TrimSpace(s), 64)
		if err != nil {
			return 0, fmt.Errorf("%s: %q is not a number", info.Label, s)
		}
		if f < info.Min || f > info.Max {
			return 0, fmt.Errorf("%s must be between %v and %v", info.Label, info.Min, info.Max)
		}
		if info.Kind != "float" && f != float64(int64(f)) {
			return 0, fmt.Errorf("%s must be a whole number", info.Label)
		}
		return f, nil
	}
	switch info.Kind {
	case "bool":
		switch strings.ToLower(val) {
		case "true", "yes", "on", "1", "y":
			m[key] = true
		case "false", "no", "off", "0", "n":
			m[key] = false
		default:
			return fmt.Errorf("%s: use yes or no", info.Label)
		}
	case "int", "float":
		f, err := num(val)
		if err != nil {
			return err
		}
		m[key] = f
	case "ints3":
		parts := strings.Split(val, ",")
		if len(parts) != 3 {
			return fmt.Errorf("%s: give three numbers separated by commas", info.Label)
		}
		var arr []float64
		for _, p := range parts {
			f, err := num(p)
			if err != nil {
				return err
			}
			arr = append(arr, f)
		}
		m[key] = arr
	case "text":
		if strings.ContainsAny(val, "\r\n\x00\x1b") {
			return fmt.Errorf("%s: one line of plain text, please", info.Label)
		}
		if float64(len(val)) < info.Min || float64(len(val)) > info.Max {
			return fmt.Errorf("%s must be %v to %v characters", info.Label, info.Min, info.Max)
		}
		m[key] = val
	}
	b, _ := json.Marshal(m)
	var nc Config
	if err := json.Unmarshal(b, &nc); err != nil {
		return err
	}
	*c = nc
	return nil
}

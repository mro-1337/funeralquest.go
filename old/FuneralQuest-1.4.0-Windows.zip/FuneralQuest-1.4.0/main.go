// Funeral Quest — BBS door + web server in one program.
//
//	fq door <DOOR32.SYS | node dir> [--stdio] [--bbs-id NAME]   run as a BBS door
//	fq web [--port 8080] [--host 0.0.0.0] [--cert FILE --key FILE] [--trust-proxy]
//	fq telnet [--port 2323]                                     stand-alone telnet server
//	fq admin ...                                                sysop commands (see usage)
//
// Global option: --home DIR  folder holding assets/, gamedata/, web/ and data/ (default: next to the exe)
package main

import (
	"crypto/tls"
	"flag"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"

	"funeralquest/admin"
	"funeralquest/door"
	"funeralquest/engine"
	"funeralquest/fqnet"
	"funeralquest/rlogin"
	"funeralquest/web"
)

func usage() {
	fmt.Fprint(os.Stderr, `Funeral Quest

  fq door <DOOR32.SYS or node dir> [--stdio] [--bbs-id NAME] [--nosound]
  fq web [--port 8080] [--host 0.0.0.0] [--cert FILE --key FILE] [--trust-proxy]
  fq telnet [--port 2323] [--net-port 8081]      also runs the network link
  fq net [--port 8081]                          only the network link (door-only BBSes)
  fq rlogin [--port 1513]                       only the RLogin server (plus the network link)
  (fq telnet also takes RLogin callers when the rlogin_port setting or --rlogin-port is set)

  fq admin players | config [key=value ...] | maint | reset [--wipe] | delete <name> | news <text>
  fq admin sysop-password [password]        turn on the web sysop pages (/sysop)
  fq admin bans | ban <ip> [minutes] | unban <ip>
  fq admin links | link <address:port> | accept <id> | unlink <id> | block-link <id>
  fq admin test-link <address:port>         check the way to another town step by step
  fq admin id                               show this server's version, network ID and fingerprint
  fq admin use-theirs <town> [setting ...]  copy a linked town's game settings (all differing ones if none named)
  fq admin propose                          ask every linked town to switch to this town's game settings
  fq admin votes | vote <id> yes|no         settings votes
  fq admin make-cert [host ...]             make a self-signed HTTPS certificate (and use it)
  fq admin cert | https-off                 show the certificate / go back to plain HTTP
  fq version                                show the version

  The full-screen editor is the separate program fqedit.

  --home DIR   folder with assets/, gamedata/, web/ and data/ (default: the exe's folder)
`)
	os.Exit(2)
}

func homeDir(flagVal string) string {
	if flagVal != "" {
		return flagVal
	}
	if exe, err := os.Executable(); err == nil {
		dir := filepath.Dir(exe)
		if _, err := os.Stat(filepath.Join(dir, "gamedata")); err == nil {
			return dir
		}
	}
	wd, _ := os.Getwd()
	return wd
}

func openAdmin(home string, logw io.Writer) *admin.Admin {
	a, err := admin.Open(home, logw)
	if err != nil {
		fmt.Fprintln(os.Stderr, "fq:", err)
		os.Exit(1)
	}
	return a
}

// logFile opens a log in the data folder (appending).
func logFile(home, name string) *os.File {
	os.MkdirAll(filepath.Join(home, "data"), 0o755)
	f, err := os.OpenFile(filepath.Join(home, "data", name), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644)
	if err != nil {
		return os.Stderr
	}
	return f
}

// flagSet records the command-line switches given; settings fill in the rest.
var flagSet = map[string]bool{}

func main() {
	if len(os.Args) < 2 {
		usage()
	}
	cmd := os.Args[1]
	if cmd == "version" || cmd == "--version" || cmd == "-v" {
		fmt.Println("Funeral Quest", engine.Version)
		return
	}
	fs := flag.NewFlagSet(cmd, flag.ExitOnError)
	home := fs.String("home", "", "install folder")
	port := fs.Int("port", 0, "port")
	host := fs.String("host", "0.0.0.0", "listen address")
	stdio := fs.Bool("stdio", false, "door: use standard input/output instead of the DOOR32.SYS socket")
	bbsID := fs.String("bbs-id", "", "door: prefix for player keys when several BBSes share one game")
	wipe := fs.Bool("wipe", false, "admin reset: delete accounts too")
	noSound := fs.Bool("nosound", false, "door/telnet: never send sound to callers")
	cert := fs.String("cert", "", "web: TLS certificate file (PEM) to serve HTTPS")
	keyf := fs.String("key", "", "web: TLS key file (PEM)")
	trustProxy := fs.Bool("trust-proxy", false, "web: believe X-Forwarded-For from a proxy on this machine/LAN")
	fs.IntVar(&rloginPortFlag, "rlogin-port", 0, "telnet: also take RLogin callers on this port (0 = use the rlogin_port setting)")
	fs.IntVar(&netPortFlag, "net-port", 0, "telnet/net: port for linked Funeral Quest servers to reach this town (0 = connect out only)")
	// allow flags after positional arguments
	var pos []string
	args := os.Args[2:]
	for len(args) > 0 {
		fs.Parse(args)
		fs.Visit(func(f *flag.Flag) { flagSet[f.Name] = true })
		args = fs.Args()
		if len(args) > 0 {
			pos = append(pos, args[0])
			args = args[1:]
		}
	}
	h := homeDir(*home)

	switch cmd {
	case "door":
		if len(pos) < 1 {
			usage()
		}
		runDoor(h, pos[0], *stdio, *bbsID, *noSound)
	case "web":
		runWeb(h, *host, *port, *cert, *keyf, *trustProxy)
	case "telnet":
		runTelnet(h, *host, *port, *noSound)
	case "net":
		runNet(h, *host, *port)
	case "rlogin":
		runRLogin(h, *host, *port, *noSound)
	case "admin":
		runAdmin(h, pos, *wipe)
	default:
		usage()
	}
}

func runDoor(home, dropPath string, useStdio bool, bbsID string, noSound bool) {
	lf := logFile(home, "door.log")
	logger := log.New(lf, "", log.LstdFlags)
	defer func() {
		if r := recover(); r != nil {
			logger.Printf("door crashed: %v", r)
		}
	}()
	d, err := door.ReadDropfile(dropPath)
	if err != nil {
		logger.Printf("drop file: %v", err)
		fmt.Fprintln(os.Stderr, "fq:", err)
		os.Exit(1)
	}
	a := openAdmin(home, lf)
	g := a.G
	noSound = noSound || a.Config().SoundOff
	var rw io.ReadWriter = struct {
		io.Reader
		io.Writer
	}{os.Stdin, os.Stdout}
	telnet := false
	if !useStdio && d.Handle > 0 && d.Comm != 0 {
		s, err := door.OpenSocket(d.Handle)
		if err != nil {
			logger.Printf("socket %d: %v", d.Handle, err)
			os.Exit(1)
		}
		rw, telnet = s, true
	}
	t := door.NewTerm(rw, rw, telnet)
	dr := door.New(t, g, filepath.Join(home, "assets", "door"), time.Duration(d.TimeLeft)*time.Minute)
	dr.NoSound = noSound
	if bbsID == "" {
		bbsID = "bbs"
	}
	dr.BBSKey = bbsID + ":" + strings.ToLower(d.Alias)

	// make sure the "online" mark is cleared if the BBS kills us
	sig := make(chan os.Signal, 1)
	signal.Notify(sig, os.Interrupt, syscall.SIGTERM)
	go func() { <-sig; os.Exit(0) }()

	t.Write(csiClear + "\x1b[1;33mFuneral Quest\x1b[0m  - checking your terminal...")
	t.Detect()
	logger.Printf("caller %q node %d: cols=%d rows=%d syncterm=%v jpegxl=%v sixel=%v audio=%v cell=%dx%d",
		d.Alias, d.Node, t.Cols, t.Rows, t.CTerm, t.JXL, t.Sixel, t.Audio && !noSound, t.CellW, t.CellH)
	p := g.FindBBSPlayer(dr.BBSKey)
	if p == nil {
		p = dr.NewPlayer(d.Alias)
	}
	if p != nil {
		dr.Play(p.ID, "bbs")
	}
	t.Write("\x1b[0m\r\n")
	time.Sleep(300 * time.Millisecond)
}

const csiClear = "\x1b[0m\x1b[2J\x1b[H"

func runWeb(home, host string, port int, cert, key string, trustProxy bool) {
	lf := logFile(home, "server.log")
	out := io.MultiWriter(os.Stdout, lf)
	log.SetOutput(out)
	a := openAdmin(home, out)
	c := a.Config()
	if !flagSet["port"] {
		port = c.WebPort
	}
	if port == 0 {
		port = 8080
	}
	if !flagSet["host"] && c.WebHost != "" {
		host = c.WebHost
	}
	if !flagSet["cert"] && !flagSet["key"] && c.WebCert != "" && c.WebKey != "" {
		cert, key = c.WebCert, c.WebKey
	}
	if !flagSet["trust-proxy"] {
		trustProxy = trustProxy || c.WebTrustProxy
	}
	sec := log.New(io.MultiWriter(os.Stdout, logFile(home, "security.log")), "", log.LstdFlags)
	a.Guard.Log = sec.Printf
	a.Net.Log = log.Printf
	srv := web.New(a, filepath.Join(home, "web", "public"), filepath.Join(home, "assets", "web"),
		web.Options{TLS: cert != "", TrustProxy: trustProxy})
	srv.SecLog = sec
	srv.PrepareSetup()
	go a.Net.Run()

	addr := net.JoinHostPort(host, strconv.Itoa(port))
	hs := &http.Server{
		Addr:              addr,
		Handler:           srv.Handler(),
		ReadHeaderTimeout: 10 * time.Second,
		ReadTimeout:       30 * time.Second,
		WriteTimeout:      60 * time.Second,
		IdleTimeout:       120 * time.Second,
		MaxHeaderBytes:    16 << 10,
		ErrorLog:          log.New(io.Discard, "", 0), // TLS handshake noise from scanners
	}

	if a.Config().NetPublicURL == "" {
		log.Printf("Network: set net_public_url so linked servers can reach you (fqedit, /sysop, or  fq admin config net_public_url=http://yourhost:%d)", port)
	}
	if cert != "" {
		hs.TLSConfig = &tls.Config{MinVersion: tls.VersionTLS12}
		if ci := a.Cert(); ci != nil && ci.SelfSigned && ci.File == cert {
			log.Printf("HTTPS with a self-signed certificate (SHA-256 %s). Browsers will warn until visitors accept it.", ci.Fingerprint)
		}
		log.Printf("Funeral Quest %s web server on https://%s/  (data in %s)", engine.Version, addr, filepath.Join(home, "data"))
		log.Fatal(hs.ListenAndServeTLS(cert, key))
	}
	log.Printf("Funeral Quest %s web server on http://%s/  (data in %s)", engine.Version, addr, filepath.Join(home, "data"))
	log.Fatal(hs.ListenAndServe())
}

func runTelnet(home, host string, port int, noSound bool) {
	a := openAdmin(home, os.Stdout)
	g := a.G
	if c := a.Config(); !flagSet["port"] {
		port = c.TelnetPort
	}
	if port == 0 {
		port = 2323
	}
	noSound = noSound || a.Config().SoundOff
	sec := log.New(io.MultiWriter(os.Stdout, logFile(home, "security.log")), "", log.LstdFlags)
	a.Guard.Log = sec.Printf
	ln, err := net.Listen("tcp", net.JoinHostPort(host, strconv.Itoa(port)))
	if err != nil {
		log.Fatal(err)
	}
	log.Printf("Funeral Quest %s telnet server on port %d", engine.Version, port)
	startNetwork(a, host, sec)
	startRLogin(a, home, host, noSound, sec)
	var mu sync.Mutex
	active := 0
	const maxSessions = 100
	go func() {
		for range time.Tick(time.Minute) {
			a.ApplyGuardSettings()
		}
	}()
	for {
		c, err := ln.Accept()
		if err != nil {
			time.Sleep(50 * time.Millisecond)
			continue
		}
		ip, _, _ := net.SplitHostPort(c.RemoteAddr().String())
		release, ok, why := a.Guard.Connect(ip)
		if !ok {
			sec.Printf("telnet: refused %s: %s", ip, why)
			c.SetWriteDeadline(time.Now().Add(2 * time.Second))
			c.Write([]byte("\r\nAccess denied: " + why + "\r\n"))
			c.Close()
			continue
		}
		mu.Lock()
		if active >= maxSessions {
			mu.Unlock()
			c.Write([]byte("\r\nThe game is full. Try again later.\r\n"))
			c.Close()
			release()
			continue
		}
		active++
		mu.Unlock()
		go func(c net.Conn) {
			defer func() {
				c.Close()
				release()
				mu.Lock()
				active--
				mu.Unlock()
			}()
			defer func() {
				if r := recover(); r != nil {
					log.Printf("session crashed: %v", r)
				}
			}()
			// three minutes to log on, or the connection is dropped
			loggedIn := make(chan struct{})
			go func() {
				select {
				case <-loggedIn:
				case <-time.After(3 * time.Minute):
					sec.Printf("telnet: %s took too long to log on", ip)
					c.Close()
				}
			}()
			c.Write([]byte{255, 251, 1, 255, 251, 3, 255, 253, 3}) // WILL ECHO, WILL SGA, DO SGA
			t := door.NewTerm(c, c, true)
			dr := door.New(t, g, filepath.Join(home, "assets", "door"), 2*time.Hour)
			dr.NoSound = noSound
			dr.LoginFail = func(logon string, bot bool) bool {
				if bot {
					sec.Printf("telnet: %s tried attack logon %q", ip, logon)
					a.Guard.Strike(ip, "telnet attack logon "+strings.ToLower(logon), 1000)
					return true
				}
				if logon == "" {
					return a.Guard.Strike(ip, "too many bad telnet logons", 1)
				}
				sec.Printf("telnet: failed logon %q from %s", logon, ip)
				return a.Guard.Strike(ip, "failed telnet logons", 1)
			}
			t.Write(csiClear + "\x1b[1;33mFuneral Quest\x1b[0m  - checking your terminal...")
			t.Detect()
			p := dr.TelnetLogin()
			close(loggedIn)
			if p != nil {
				dr.Play(p.ID, "bbs")
			}
		}(c)
	}
}

// startNetwork runs the town's link to other Funeral Quest servers from the telnet server or
// fq net (the web server does it itself). With a network port set, other servers can reach
// this town on it; without one, this town connects out only.
func startNetwork(a *admin.Admin, host string, sec *log.Logger) {
	a.Net.Log = log.Printf
	go a.Net.Run()
	c := a.Config()
	port := c.NetPort
	if flagSet["net-port"] {
		port = netPortFlag
	}
	if port > 0 {
		addr := net.JoinHostPort(host, strconv.Itoa(port))
		log.Printf("Network port %d open for linked Funeral Quest servers", port)
		go func() {
			if err := a.Net.ServeNetwork(addr, a.Guard); err != nil {
				log.Printf("network: can't open network port %d: %v (linked towns can still be reached by connecting out)", port, err)
			}
		}()
	} else if len(a.Net.Peers()) > 0 || c.NetPublicURL == "" {
		log.Printf("Network: no network port set, so this town connects out to linked towns only")
	}
}

// runNet runs only the network link, for BBSes that run the door but neither web nor telnet.
func runNet(home, host string, port int) {
	lf := logFile(home, "server.log")
	out := io.MultiWriter(os.Stdout, lf)
	log.SetOutput(out)
	a := openAdmin(home, out)
	sec := log.New(io.MultiWriter(os.Stdout, logFile(home, "security.log")), "", log.LstdFlags)
	a.Guard.Log = sec.Printf
	if flagSet["port"] {
		flagSet["net-port"], netPortFlag = true, port
	}
	log.Printf("Funeral Quest %s network service for %s (data in %s)", engine.Version, a.Config().ServerName, filepath.Join(home, "data"))
	startNetwork(a, host, sec)
	select {}
}

var netPortFlag, rloginPortFlag int

// runRLogin runs only the RLogin server (and the network link).
func runRLogin(home, host string, port int, noSound bool) {
	a := openAdmin(home, os.Stdout)
	sec := log.New(io.MultiWriter(os.Stdout, logFile(home, "security.log")), "", log.LstdFlags)
	a.Guard.Log = sec.Printf
	if flagSet["port"] {
		flagSet["rlogin-port"], rloginPortFlag = true, port
	}
	if !flagSet["rlogin-port"] && a.Config().RLoginPort == 0 {
		fmt.Fprintln(os.Stderr, "fq: set the RLogin port first (rlogin_port setting, or  fq rlogin --port 1513)")
		os.Exit(1)
	}
	startNetwork(a, host, sec)
	startRLogin(a, home, host, noSound || a.Config().SoundOff, sec)
	select {}
}

// startRLogin takes RLogin callers, identified the rlogin-kit way: a BBS gateway (shared
// secret plus the caller's name, in either field order), the caller's own game logon and
// password (either order), or else the normal log-on screen. A name alone is never trusted.
func startRLogin(a *admin.Admin, home, host string, noSound bool, sec *log.Logger) {
	c := a.Config()
	port := c.RLoginPort
	if flagSet["rlogin-port"] {
		port = rloginPortFlag
	}
	if port == 0 {
		return
	}
	g := a.G
	conf := func() rlogin.Config {
		c := a.Config()
		var trusted []string
		for _, t := range strings.Split(c.RLoginTrusted, ",") {
			if t = strings.TrimSpace(t); t != "" {
				trusted = append(trusted, t)
			}
		}
		return rlogin.Config{Trusted: trusted, Secret: c.RLoginSecret, FailLimit: c.BanStrikes,
			Check:  a.Guard.Check,
			OnFail: func(ip string) { a.Guard.Strike(ip, "failed rlogin logons", 1) }}
	}
	auth := func(logon, pw string) (string, bool) {
		if len(logon) > 40 || len(pw) > 200 {
			return "", false
		}
		p, err := g.Login(logon, pw)
		if err != nil || p == nil {
			return "", false
		}
		return p.Logon, true
	}
	srv := rlogin.New(conf(), auth, func(s *rlogin.Session) {
		// callers through a BBS gateway all come from the BBS's address, so the per-address
		// connection limits only apply to everyone else
		if s.Method != rlogin.Gateway {
			release, ok, why := a.Guard.Connect(s.IP)
			if !ok {
				sec.Printf("rlogin: refused %s: %s", s.IP, why)
				s.Write([]byte("\r\nAccess denied: " + why + "\r\n"))
				return
			}
			defer release()
		}
		defer func() {
			if r := recover(); r != nil {
				log.Printf("rlogin session crashed: %v", r)
			}
		}()
		cfg := a.Config()
		t := door.NewTerm(s, s, false) // RLogin is a raw 8-bit stream: no telnet commands
		dr := door.New(t, g, filepath.Join(home, "assets", "door"), 2*time.Hour)
		dr.NoSound = noSound
		dr.LoginFail = func(logon string, bot bool) bool {
			if bot {
				sec.Printf("rlogin: %s tried attack logon %q", s.IP, logon)
				a.Guard.Strike(s.IP, "rlogin attack logon "+strings.ToLower(logon), 1000)
				return true
			}
			s.LoginFailed()
			if logon != "" {
				sec.Printf("rlogin: failed logon %q from %s", logon, s.IP)
			}
			return s.Blocked()
		}
		t.Write(csiClear + "\x1b[1;33mFuneral Quest\x1b[0m  - checking your terminal...")
		t.Detect()
		var p *engine.Player
		switch s.Method {
		case rlogin.Gateway:
			// the same player the door uses for this BBS's callers
			name := engine.CleanRemote(s.Name, 30, false)
			dr.BBSKey = cfg.RLoginBBSID + ":" + strings.ToLower(name)
			if p = g.FindBBSPlayer(dr.BBSKey); p == nil {
				p = dr.NewPlayer(name)
			}
		case rlogin.Password:
			g.View(func(w *engine.World) {
				if x := w.ByLogon(s.Name); x != nil {
					cp := *x
					p = &cp
				}
			})
		default:
			loggedIn := make(chan struct{})
			go func() {
				select {
				case <-loggedIn:
				case <-time.After(3 * time.Minute):
					s.Conn.Close()
				}
			}()
			if s.Reason == "no match" {
				t.Write("\r\n\x1b[1;31mThat logon didn't match a Funeral Quest account. Log on or create a parlor below.\x1b[0m\r\n")
				time.Sleep(1500 * time.Millisecond)
			}
			p = dr.TelnetLogin()
			close(loggedIn)
			if p != nil {
				s.LoginOK()
			}
		}
		if p != nil {
			dr.Play(p.ID, "bbs")
		}
		t.Write("\x1b[0m\r\n")
	})
	srv.Log = sec.Printf
	go func() {
		for range time.Tick(30 * time.Second) {
			srv.SetConfig(conf()) // settings changed in fqedit or /sysop apply at once
		}
	}()
	addr := net.JoinHostPort(host, strconv.Itoa(port))
	log.Printf("Funeral Quest %s RLogin server on port %d (gateway %s)", engine.Version, port,
		map[bool]string{true: "on", false: "off: no BBS gateway secret set"}[c.RLoginSecret != ""])
	go func() {
		if err := srv.ListenAndServe(addr); err != nil {
			log.Printf("rlogin: can't listen on port %d: %v", port, err)
		}
	}()
}

func runAdmin(home string, pos []string, wipe bool) {
	a := openAdmin(home, io.Discard)
	if len(pos) == 0 {
		usage()
	}
	arg := func(i int) string {
		if i < len(pos) {
			return pos[i]
		}
		return ""
	}
	die := func(err error) {
		if err != nil {
			fmt.Fprintln(os.Stderr, "fq:", err)
			os.Exit(1)
		}
	}
	switch pos[0] {
	case "players":
		fmt.Printf("Day %d\n", a.Status().Day)
		for _, p := range a.Players() {
			flags := ""
			if !p.Active {
				flags += " (closed)"
			}
			if p.Online {
				flags += " (online)"
			}
			if p.BBSKey != "" {
				flags += " bbs:" + p.BBSKey
			}
			if p.Logon != "" {
				flags += " web:" + p.Logon
			}
			fmt.Printf("%4d %-21s %-21s %8d BP%s\n", p.ID, p.Name, p.Parlor, p.Exp, flags)
		}
	case "config":
		kv := map[string]string{}
		for _, x := range pos[1:] {
			k, v, _ := strings.Cut(x, "=")
			kv[k] = v
		}
		die(a.SetSettings(kv))
		c := a.Config()
		group := ""
		for _, s := range engine.Settings {
			if s.Group != group {
				group = s.Group
				fmt.Printf("\n[%s]\n", group)
			}
			fmt.Printf("  %-24s = %-12s %s\n", s.Key, c.Get(s.Key), s.Label)
		}
	case "maint":
		day, err := a.Maint()
		die(err)
		fmt.Println("Maintenance done, now day", day)
	case "reset":
		die(a.Reset(wipe))
		fmt.Println("Game reset. Day", a.Status().Day)
	case "delete":
		name := strings.Join(pos[1:], " ")
		for _, p := range a.Players() {
			if strings.EqualFold(p.Name, name) {
				die(a.UpdatePlayer(p.ID, map[string]string{"active": "no"}))
				fmt.Println("Closed", p.Name)
				return
			}
		}
		fmt.Println("No such parlor")
	case "news":
		die(a.PostNews(strings.Join(pos[1:], " ")))
		fmt.Println("Posted.")
	case "sysop-password":
		pw := arg(1)
		if pw == "" {
			fmt.Print("New sysop password (10+ characters): ")
			fmt.Scanln(&pw)
		}
		if pw == "off" {
			die(a.DisableSysopPassword())
			fmt.Println("Sysop web pages turned off.")
			return
		}
		die(a.SetSysopPassword(pw))
		fmt.Println("Sysop password set. The sysop pages are at http://yourhost:port/sysop/")
	case "bans":
		for _, b := range a.Guard.Bans() {
			fmt.Printf("%-40s until %s  (%s, ban #%d)\n", b.IP, b.Until.Local().Format("Jan 2 15:04"), b.Reason, b.Count)
		}
	case "ban":
		mins, _ := strconv.Atoi(arg(2))
		if mins <= 0 {
			mins = 60
		}
		a.Guard.Ban(arg(1), "banned by sysop", time.Duration(mins)*time.Minute)
		fmt.Println("Banned", arg(1), "for", mins, "minutes")
	case "unban":
		if a.Guard.Unban(arg(1)) {
			fmt.Println("Unbanned", arg(1))
		} else {
			fmt.Println(arg(1), "wasn't banned")
		}
	case "propose":
		p, err := a.Net.Propose()
		die(err)
		fmt.Printf("Asked %d linked town(s) to accept this town's game settings. See  fq admin votes\n", len(p.Voters))
	case "votes":
		for _, p := range a.Net.Proposals() {
			fmt.Printf("%s  %s\n", p.ID, fqnet.VoteSummary(a.Net.ID, p))
			if p.From != a.Net.ID {
				for _, d := range fqnet.RuleDiffs(a.Config(), fqnet.Peer{Rules: p.Rules}) {
					fmt.Printf("    %-36s yours %-10s proposed %s\n", d.Label, d.Ours, d.Theirs)
				}
			}
			if p.Note != "" {
				fmt.Println("    note:", p.Note)
			}
		}
	case "vote":
		yes := strings.EqualFold(arg(2), "yes")
		if !yes && !strings.EqualFold(arg(2), "no") {
			fmt.Fprintln(os.Stderr, "fq: fq admin vote <vote id> yes|no   (see  fq admin votes)")
			os.Exit(1)
		}
		die(a.Net.CastVote(arg(1), yes))
		fmt.Println("Vote sent.")
	case "make-cert":
		info, err := a.MakeSelfSignedCert(pos[1:])
		die(err)
		fmt.Printf("Made a self-signed certificate for %s\n  %s\n  valid until %s\n  SHA-256 %s\nRestart fq web to use HTTPS. This server's web address is now %s\n",
			strings.Join(info.Names, ", "), info.File, info.Expires.Format("Jan 2 2006"), info.Fingerprint, a.Config().NetPublicURL)
	case "cert":
		if c := a.Cert(); c == nil {
			fmt.Println("HTTPS is off (no certificate set).")
		} else if c.Error != "" {
			fmt.Println(c.File+":", c.Error)
		} else {
			fmt.Printf("%s\n  for %s\n  valid until %s, self-signed %v\n  SHA-256 %s\n", c.File, strings.Join(c.Names, ", "), c.Expires.Format("Jan 2 2006"), c.SelfSigned, c.Fingerprint)
		}
	case "https-off":
		die(a.TurnOffHTTPS())
		fmt.Println("HTTPS turned off. Restart fq web.")
	case "use-theirs":
		id := findPeer(a, arg(1))
		die(a.Net.UseTheirs(a, id, pos[2:]))
		fmt.Println("Done. Settings now match.")
	case "id":
		fmt.Println("Version:    ", engine.Version)
		fmt.Println("Network ID: ", a.Net.ID)
		fmt.Println("Fingerprint:", fqnet.Fingerprint(a.Net.ID))
		fmt.Println("Address:    ", ifEmpty(a.Config().NetPublicURL, "(not set: outbound only, other towns can't connect to this one)"))
	case "links":
		for _, in := range a.Net.Intros() {
			fmt.Printf("introduced: %-20s %s  by %s  %s\n", in.Name, in.URL, in.ByName, ifEmpty(in.LastErr, "(linking soon)"))
		}
		q := a.Net.QueuedMail()
		for _, p := range a.Net.Peers() {
			fmt.Printf("%-20s %-10s %s  %s\n    id %s\n", p.Name, p.State, ifEmpty(p.URL, "(connects out only)"), fqnet.Fingerprint(p.ID), p.ID)
			if !p.TheyOK && p.State == fqnet.Linked {
				fmt.Println("    waiting for them to accept")
			}
			if p.LastErr != "" {
				fmt.Println("    last error:", p.LastErr)
			}
			if q[p.ID] > 0 {
				fmt.Println("    letters waiting:", q[p.ID])
			}
			if p.Note != "" {
				fmt.Println("    note:", p.Note)
			}
			if r := fqnet.Reach(p); r != "" {
				fmt.Println("    reach:", r)
			}
			if p.State == fqnet.Linked {
				fmt.Println("    version:", ifEmpty(p.GameVer, "unknown (older than 1.3.0)"))
				if v := fqnet.VersionNote(p); v != "" {
					fmt.Println("    UPDATE:", v)
				}
				for _, d := range fqnet.RuleDiffs(a.Config(), p) {
					fmt.Printf("    differs: %-36s here %-10s there %s\n", d.Label, d.Ours, d.Theirs)
				}
			}
		}
	case "link":
		p, err := a.Net.AddPeer(arg(1))
		die(err)
		fmt.Printf("Linked to %s (%s), fingerprint %s\n", p.Name, p.URL, fqnet.Fingerprint(p.ID))
		if !p.TheyOK {
			fmt.Println("They have to accept the link too (or add your address).")
		}
	case "test-link":
		if arg(1) == "" {
			fmt.Fprintln(os.Stderr, "fq: fq admin test-link <their address:port>")
			os.Exit(1)
		}
		a.Net.TestLink(arg(1), func(f string, x ...any) { fmt.Printf(f+"\n", x...) })
	case "accept", "unlink", "block-link":
		id := findPeer(a, arg(1))
		var err error
		switch pos[0] {
		case "accept":
			err = a.Net.Accept(id)
		case "unlink":
			err = a.Net.Remove(id)
		default:
			err = a.Net.Block(id)
		}
		die(err)
		fmt.Println("Done.")
	default:
		usage()
	}
}

// findPeer accepts a full ID, the start of one, a fingerprint or a town name.
func findPeer(a *admin.Admin, q string) string {
	var hits []string
	for _, p := range a.Net.Peers() {
		if q != "" && (strings.HasPrefix(p.ID, q) || strings.EqualFold(p.Name, q) || strings.EqualFold(fqnet.Fingerprint(p.ID), q)) {
			hits = append(hits, p.ID)
		}
	}
	if len(hits) != 1 {
		fmt.Fprintln(os.Stderr, "fq: give one linked server (ID, fingerprint or town name); see  fq admin links")
		os.Exit(1)
	}
	return hits[0]
}

func ifEmpty(s, def string) string {
	if s == "" {
		return def
	}
	return s
}

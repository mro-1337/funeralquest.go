package door

import (
	"errors"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
)

// DropInfo is what the door needs from the BBS drop file.
type DropInfo struct {
	File       string
	Comm       int // DOOR32.SYS: 0=local 1=serial 2=telnet
	Handle     int // DOOR32.SYS: socket handle
	BBS        string
	UserNumber int
	RealName   string
	Alias      string
	TimeLeft   int // minutes
	Emulation  int
	Node       int
}

// ReadDropfile reads DOOR32.SYS (preferred), DOOR.SYS or DORINFO*.DEF. p may be the file or the
// folder holding it (e.g. the node directory).
func ReadDropfile(p string) (*DropInfo, error) {
	file := p
	if st, err := os.Stat(p); err == nil && st.IsDir() {
		ents, _ := os.ReadDir(p)
		find := func(re *regexp.Regexp) string {
			for _, e := range ents {
				if re.MatchString(e.Name()) {
					return e.Name()
				}
			}
			return ""
		}
		n := find(regexp.MustCompile(`(?i)^door32\.sys$`))
		if n == "" {
			n = find(regexp.MustCompile(`(?i)^door\.sys$`))
		}
		if n == "" {
			n = find(regexp.MustCompile(`(?i)^dorinfo\d*\.def$`))
		}
		if n == "" {
			return nil, errors.New("no DOOR32.SYS, DOOR.SYS or DORINFO*.DEF in " + p)
		}
		file = filepath.Join(p, n)
	}
	b, err := os.ReadFile(file)
	if err != nil {
		return nil, err
	}
	lines := strings.Split(strings.ReplaceAll(string(b), "\r\n", "\n"), "\n")
	l := func(i int) string {
		if i < len(lines) {
			return strings.TrimSpace(lines[i])
		}
		return ""
	}
	n := func(i int) int { v, _ := strconv.Atoi(l(i)); return v }
	d := &DropInfo{File: file, TimeLeft: 60, Node: 1, Handle: -1}
	switch strings.ToLower(filepath.Base(file)) {
	case "door32.sys":
		d.Comm, d.Handle, d.BBS = n(0), n(1), l(3)
		d.UserNumber, d.RealName, d.Alias = n(4), l(5), l(6)
		d.TimeLeft, d.Emulation, d.Node = n(8), n(9), n(10)
	case "door.sys":
		d.Node, d.RealName, d.TimeLeft = n(3), l(9), n(18)
		d.UserNumber, d.Alias, d.BBS = n(25), l(35), l(0)
	default: // DORINFO
		d.BBS = l(0)
		d.RealName = strings.TrimSpace(l(6) + " " + l(7))
		d.Emulation, d.TimeLeft = n(9), n(11)
	}
	if d.Alias == "" {
		d.Alias = d.RealName
	}
	if d.TimeLeft <= 0 {
		d.TimeLeft = 60
	}
	if d.Node <= 0 {
		d.Node = 1
	}
	return d, nil
}

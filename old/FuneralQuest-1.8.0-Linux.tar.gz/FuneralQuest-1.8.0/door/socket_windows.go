//go:build windows

package door

import (
	"errors"
	"io"
	"syscall"
)

// winSocket reads and writes the telnet socket handle a 32/64-bit Windows BBS passes in DOOR32.SYS.
type winSocket struct{ h syscall.Handle }

func (s winSocket) Read(p []byte) (int, error) {
	if len(p) == 0 {
		return 0, nil
	}
	buf := syscall.WSABuf{Len: uint32(len(p)), Buf: &p[0]}
	var n, flags uint32
	if err := syscall.WSARecv(s.h, &buf, 1, &n, &flags, nil, nil); err != nil {
		return 0, err
	}
	if n == 0 {
		return 0, io.EOF
	}
	return int(n), nil
}

func (s winSocket) Write(p []byte) (int, error) {
	total := 0
	for total < len(p) {
		buf := syscall.WSABuf{Len: uint32(len(p) - total), Buf: &p[total]}
		var n uint32
		if err := syscall.WSASend(s.h, &buf, 1, &n, 0, nil, nil); err != nil {
			return total, err
		}
		if n == 0 {
			return total, errors.New("socket closed")
		}
		total += int(n)
	}
	return total, nil
}

// OpenSocket wraps an inherited socket handle.
func OpenSocket(handle int) (io.ReadWriter, error) {
	var d syscall.WSAData
	if err := syscall.WSAStartup(uint32(0x202), &d); err != nil {
		return nil, err
	}
	return winSocket{syscall.Handle(handle)}, nil
}

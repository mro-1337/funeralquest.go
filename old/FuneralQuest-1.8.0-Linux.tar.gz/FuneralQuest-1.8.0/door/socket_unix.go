//go:build !windows

package door

import (
	"io"
	"net"
	"os"
)

// OpenSocket wraps an inherited socket file descriptor (DOOR32.SYS handle on Linux BBSes).
func OpenSocket(handle int) (io.ReadWriter, error) {
	f := os.NewFile(uintptr(handle), "door32-socket")
	c, err := net.FileConn(f)
	if err != nil {
		return f, nil // not a socket (e.g. a tty): use it as a plain file
	}
	return c, nil
}

package door

import (
	"bytes"
	"fmt"
	"image"
	"image/png"
	"math"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
)

// Sixel fallback for terminals without JPEG XL. The door art ships as JPEG XL for SyncTERM
// plus a PNG twin that Go's standard library can decode for this path.

type picture struct {
	w, h int
	rgb  []byte
	mask []byte
}

var picCache sync.Map

func loadPic(dir, key string) *picture {
	if key == "" {
		return nil
	}
	if v, ok := picCache.Load(key); ok {
		return v.(*picture)
	}
	f, err := os.Open(filepath.Join(dir, key+".png"))
	if err != nil {
		return nil
	}
	defer f.Close()
	img, err := png.Decode(f)
	if err != nil {
		return nil
	}
	b := img.Bounds()
	p := &picture{w: b.Dx(), h: b.Dy(), rgb: make([]byte, b.Dx()*b.Dy()*3)}
	for y := 0; y < p.h; y++ {
		for x := 0; x < p.w; x++ {
			r, g, bl, _ := img.At(b.Min.X+x, b.Min.Y+y).RGBA()
			i := (y*p.w + x) * 3
			p.rgb[i], p.rgb[i+1], p.rgb[i+2] = byte(r>>8), byte(g>>8), byte(bl>>8)
		}
	}
	p.mask = readPBM(filepath.Join(dir, key+".pbm"), p.w, p.h)
	picCache.Store(key, p)
	return p
}

func readPBM(path string, w, h int) []byte {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil
	}
	// header: P4 <w> <h> then packed bits (1 = draw)
	fields, i := 0, 0
	for fields < 3 && i < len(b) {
		for i < len(b) && (b[i] == ' ' || b[i] == '\n' || b[i] == '\r' || b[i] == '\t') {
			i++
		}
		for i < len(b) && b[i] > ' ' {
			i++
		}
		fields++
	}
	i++
	rb := (w + 7) / 8
	if len(b) < i+rb*h {
		return nil
	}
	m := make([]byte, w*h)
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			m[y*w+x] = (b[i+y*rb+x/8] >> (7 - uint(x%8))) & 1
		}
	}
	return m
}

// composite layers fg over bg and scales the result to outW x outH (bilinear).
func composite(dir, bg, fg string, outW, outH int) *picture {
	B, F := loadPic(dir, bg), loadPic(dir, fg)
	base := B
	if base == nil {
		base = F
	}
	if base == nil {
		return nil
	}
	w, h := base.w, base.h
	rgb := make([]byte, w*h*3)
	for i := 0; i < w*h; i++ {
		var src []byte
		switch {
		case F != nil && (B == nil || F.mask == nil || F.mask[i] == 1):
			src = F.rgb
		case B != nil:
			src = B.rgb
		}
		if src != nil {
			copy(rgb[i*3:i*3+3], src[i*3:i*3+3])
		}
	}
	if outW == w && outH == h {
		return &picture{w: w, h: h, rgb: rgb}
	}
	out := make([]byte, outW*outH*3)
	for y := 0; y < outH; y++ {
		sy := max(0, (float64(y)+0.5)*float64(h)/float64(outH)-0.5)
		y0 := int(sy)
		y1 := min(h-1, y0+1)
		fy := sy - float64(y0)
		for x := 0; x < outW; x++ {
			sx := max(0, (float64(x)+0.5)*float64(w)/float64(outW)-0.5)
			x0 := int(sx)
			x1 := min(w-1, x0+1)
			fx := sx - float64(x0)
			for c := 0; c < 3; c++ {
				a := float64(rgb[(y0*w+x0)*3+c])*(1-fx) + float64(rgb[(y0*w+x1)*3+c])*fx
				b := float64(rgb[(y1*w+x0)*3+c])*(1-fx) + float64(rgb[(y1*w+x1)*3+c])*fx
				out[(y*outW+x)*3+c] = byte(a*(1-fy) + b*fy + 0.5)
			}
		}
	}
	return &picture{w: outW, h: outH, rgb: out}
}

// medianCut builds a palette of up to n colours.
func medianCut(rgb []byte, count, n int) [][3]int {
	idx := make([]int, count)
	for i := range idx {
		idx[i] = i
	}
	boxes := [][]int{idx}
	rangeOf := func(b []int) (int, int) {
		lo, hi := [3]int{255, 255, 255}, [3]int{}
		for _, i := range b {
			for c := 0; c < 3; c++ {
				v := int(rgb[i*3+c])
				lo[c], hi[c] = min(lo[c], v), max(hi[c], v)
			}
		}
		best, ax := -1, 0
		for c := 0; c < 3; c++ {
			if hi[c]-lo[c] > best {
				best, ax = hi[c]-lo[c], c
			}
		}
		return best, ax
	}
	for len(boxes) < n {
		bi, bestScore, axis := -1, 0.0, 0
		for k, b := range boxes {
			if len(b) < 2 {
				continue
			}
			r, ax := rangeOf(b)
			score := float64(r) * float64(len(b))
			if score > bestScore {
				bi, bestScore, axis = k, score, ax
			}
		}
		if bi < 0 {
			break
		}
		b := boxes[bi]
		sort.Slice(b, func(i, j int) bool { return rgb[b[i]*3+axis] < rgb[b[j]*3+axis] })
		mid := len(b) / 2
		boxes = append(boxes[:bi], append([][]int{b[:mid], b[mid:]}, boxes[bi+1:]...)...)
	}
	pal := make([][3]int, len(boxes))
	for k, b := range boxes {
		var s [3]int
		for _, i := range b {
			for c := 0; c < 3; c++ {
				s[c] += int(rgb[i*3+c])
			}
		}
		for c := 0; c < 3; c++ {
			pal[k][c] = (s[c] + len(b)/2) / len(b)
		}
	}
	return pal
}

// encodeSixel turns a picture into a DCS sixel string (256 colours, light Floyd-Steinberg dither).
func encodeSixel(p *picture) string {
	w, h := p.w, p.h
	pal := medianCut(p.rgb, w*h, 256)
	cache := map[int]int{}
	nearest := func(r, g, b int) int {
		k := (r>>2)<<12 | (g>>2)<<6 | b>>2
		if v, ok := cache[k]; ok {
			return v
		}
		best, bd := 0, math.MaxInt32
		for i, c := range pal {
			d := 3*(r-c[0])*(r-c[0]) + 4*(g-c[1])*(g-c[1]) + 2*(b-c[2])*(b-c[2])
			if d < bd {
				best, bd = i, d
			}
		}
		cache[k] = best
		return best
	}
	f := make([]float64, len(p.rgb))
	for i, v := range p.rgb {
		f[i] = float64(v)
	}
	idx := make([]int, w*h)
	const k = 0.6
	cl := func(v float64) int { return int(max(0, min(255, v))) }
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			i := y*w + x
			r, g, b := cl(f[i*3]), cl(f[i*3+1]), cl(f[i*3+2])
			c := nearest(r, g, b)
			idx[i] = c
			e := [3]float64{float64(r-pal[c][0]) * k, float64(g-pal[c][1]) * k, float64(b-pal[c][2]) * k}
			add := func(j int, wt float64) {
				for q := 0; q < 3; q++ {
					f[j*3+q] += e[q] * wt
				}
			}
			if x+1 < w {
				add(i+1, 7.0/16)
			}
			if y+1 < h {
				if x > 0 {
					add(i+w-1, 3.0/16)
				}
				add(i+w, 5.0/16)
				if x+1 < w {
					add(i+w+1, 1.0/16)
				}
			}
		}
	}
	var s bytes.Buffer
	fmt.Fprintf(&s, "\x1bP0;1;0q\"1;1;%d;%d", w, h)
	for i, c := range pal {
		fmt.Fprintf(&s, "#%d;2;%d;%d;%d", i, c[0]*100/255, c[1]*100/255, c[2]*100/255)
	}
	for band := 0; band < h; band += 6 {
		used := []int{}
		seen := map[int]bool{}
		for y := band; y < min(h, band+6); y++ {
			for x := 0; x < w; x++ {
				if c := idx[y*w+x]; !seen[c] {
					seen[c] = true
					used = append(used, c)
				}
			}
		}
		for n, c := range used {
			if n > 0 {
				s.WriteByte('$')
			}
			s.WriteString("#" + strconv.Itoa(c))
			prev, run := -1, 0
			flush := func() {
				if run > 0 {
					ch := string(rune(63 + prev))
					if run > 3 {
						s.WriteString("!" + strconv.Itoa(run) + ch)
					} else {
						s.WriteString(strings.Repeat(ch, run))
					}
				}
			}
			for x := 0; x < w; x++ {
				bits := 0
				for r := 0; r < 6; r++ {
					if y := band + r; y < h && idx[y*w+x] == c {
						bits |= 1 << r
					}
				}
				if bits == prev {
					run++
				} else {
					flush()
					prev, run = bits, 1
				}
			}
			flush()
		}
		s.WriteByte('-')
	}
	s.WriteString("\x1b\\")
	return s.String()
}

var _ = image.Rect

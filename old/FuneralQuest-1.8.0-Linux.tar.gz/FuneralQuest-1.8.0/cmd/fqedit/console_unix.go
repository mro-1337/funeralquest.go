//go:build linux || darwin || freebsd || openbsd || netbsd || dragonfly

package main

import (
	"os"
	"syscall"
	"unsafe"
)

func makeRaw() (restore func(), ok bool) {
	fd := os.Stdin.Fd()
	var old syscall.Termios
	if _, _, e := syscall.Syscall(syscall.SYS_IOCTL, fd, tcGet, uintptr(unsafe.Pointer(&old))); e != 0 {
		return func() {}, false
	}
	raw := old
	raw.Iflag &^= syscall.IGNBRK | syscall.BRKINT | syscall.PARMRK | syscall.ISTRIP | syscall.INLCR | syscall.IGNCR | syscall.ICRNL | syscall.IXON
	raw.Lflag &^= syscall.ECHO | syscall.ECHONL | syscall.ICANON | syscall.ISIG | syscall.IEXTEN
	raw.Cflag &^= syscall.CSIZE | syscall.PARENB
	raw.Cflag |= syscall.CS8
	raw.Cc[syscall.VMIN], raw.Cc[syscall.VTIME] = 1, 0
	syscall.Syscall(syscall.SYS_IOCTL, fd, tcSet, uintptr(unsafe.Pointer(&raw)))
	return func() { syscall.Syscall(syscall.SYS_IOCTL, fd, tcSet, uintptr(unsafe.Pointer(&old))) }, true
}

func termSize() (int, int) {
	var ws struct{ Row, Col, X, Y uint16 }
	if _, _, e := syscall.Syscall(syscall.SYS_IOCTL, os.Stdout.Fd(), syscall.TIOCGWINSZ, uintptr(unsafe.Pointer(&ws))); e != 0 || ws.Col == 0 {
		return 80, 24
	}
	return int(ws.Col), int(ws.Row)
}

func defaultEditor() []string {
	if e := os.Getenv("VISUAL"); e != "" {
		return []string{e}
	}
	if e := os.Getenv("EDITOR"); e != "" {
		return []string{e}
	}
	return []string{"nano"}
}

// readStdin reads keys; short=true waits at most 0.1 s (to tell Esc from an arrow key).
func readStdin(b []byte, short bool) (int, error) {
	fd := os.Stdin.Fd()
	if short {
		var t syscall.Termios
		syscall.Syscall(syscall.SYS_IOCTL, fd, tcGet, uintptr(unsafe.Pointer(&t)))
		t2 := t
		t2.Cc[syscall.VMIN], t2.Cc[syscall.VTIME] = 0, 1
		syscall.Syscall(syscall.SYS_IOCTL, fd, tcSet, uintptr(unsafe.Pointer(&t2)))
		defer syscall.Syscall(syscall.SYS_IOCTL, fd, tcSet, uintptr(unsafe.Pointer(&t)))
		n, _ := syscall.Read(int(fd), b)
		return max(n, 0), nil
	}
	for {
		n, err := syscall.Read(int(fd), b)
		if err == syscall.EINTR {
			continue
		}
		if n <= 0 && err == nil {
			return 0, os.ErrClosed
		}
		return n, err
	}
}

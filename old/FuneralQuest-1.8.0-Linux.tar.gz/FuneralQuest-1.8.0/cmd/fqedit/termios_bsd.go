//go:build darwin || freebsd || openbsd || netbsd || dragonfly

package main

import "syscall"

const (
	tcGet = syscall.TIOCGETA
	tcSet = syscall.TIOCSETA
)

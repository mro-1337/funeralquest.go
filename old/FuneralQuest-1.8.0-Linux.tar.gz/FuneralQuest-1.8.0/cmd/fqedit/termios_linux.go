package main

import "syscall"

const (
	tcGet = syscall.TCGETS
	tcSet = syscall.TCSETS
)

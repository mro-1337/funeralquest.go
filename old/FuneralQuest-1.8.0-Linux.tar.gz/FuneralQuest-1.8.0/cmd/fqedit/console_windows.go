//go:build windows

package main

import (
	"os"
	"syscall"
	"unsafe"
)

var (
	kernel32                       = syscall.NewLazyDLL("kernel32.dll")
	procGetConsoleMode             = kernel32.NewProc("GetConsoleMode")
	procSetConsoleMode             = kernel32.NewProc("SetConsoleMode")
	procGetConsoleScreenBufferInfo = kernel32.NewProc("GetConsoleScreenBufferInfo")
	procSetConsoleOutputCP         = kernel32.NewProc("SetConsoleOutputCP")
	procSetConsoleTitleW           = kernel32.NewProc("SetConsoleTitleW")
)

const (
	enableProcessedInput      = 0x0001
	enableLineInput           = 0x0002
	enableEchoInput           = 0x0004
	enableVirtualTerminalIn   = 0x0200
	enableProcessedOutput     = 0x0001
	enableVirtualTerminalProc = 0x0004
)

type consoleState struct{ in, out uint32 }

func getMode(h syscall.Handle) (uint32, bool) {
	var m uint32
	r, _, _ := procGetConsoleMode.Call(uintptr(h), uintptr(unsafe.Pointer(&m)))
	return m, r != 0
}

func setMode(h syscall.Handle, m uint32) bool {
	r, _, _ := procSetConsoleMode.Call(uintptr(h), uintptr(m))
	return r != 0
}

// makeRaw switches the Windows console to raw key input with VT (ANSI) sequences.
// Needs Windows 10 or later.
func makeRaw() (restore func(), ok bool) {
	in := syscall.Handle(os.Stdin.Fd())
	out := syscall.Handle(os.Stdout.Fd())
	im, ok1 := getMode(in)
	om, ok2 := getMode(out)
	if !ok1 || !ok2 {
		return func() {}, false
	}
	procSetConsoleOutputCP.Call(65001)
	title, _ := syscall.UTF16PtrFromString("Funeral Quest Editor")
	procSetConsoleTitleW.Call(uintptr(unsafe.Pointer(title)))
	if !setMode(out, om|enableProcessedOutput|enableVirtualTerminalProc) {
		return func() {}, false
	}
	setMode(in, (im&^(enableLineInput|enableEchoInput|enableProcessedInput))|enableVirtualTerminalIn)
	return func() { setMode(in, im); setMode(out, om) }, true
}

type coord struct{ X, Y int16 }
type smallRect struct{ Left, Top, Right, Bottom int16 }
type screenBufferInfo struct {
	Size              coord
	CursorPosition    coord
	Attributes        uint16
	Window            smallRect
	MaximumWindowSize coord
}

func termSize() (int, int) {
	var info screenBufferInfo
	r, _, _ := procGetConsoleScreenBufferInfo.Call(os.Stdout.Fd(), uintptr(unsafe.Pointer(&info)))
	if r == 0 {
		return 80, 25
	}
	return int(info.Window.Right-info.Window.Left) + 1, int(info.Window.Bottom-info.Window.Top) + 1
}

func defaultEditor() []string { return []string{"notepad.exe"} }

// readStdin reads keys. Windows hands over a whole escape sequence in one read, so a
// "short" read (looking for the rest of one) has nothing to wait for.
func readStdin(b []byte, short bool) (int, error) {
	if short {
		return 0, nil
	}
	for {
		n, err := os.Stdin.Read(b)
		if n > 0 || err != nil {
			return n, err
		}
	}
}

package main

import (
	"fmt"
	"os"
	"strings"
	"unicode/utf8"
)

// A small full-screen text UI on ANSI escape codes (Windows 10+ console, any Linux terminal).

const (
	esc     = "\x1b["
	cReset  = esc + "0m"
	cTitle  = esc + "0;30;43m" // black on gold bar
	cText   = esc + "0;37m"
	cDim    = esc + "0;90m"
	cHi     = esc + "1;33m"
	cSel    = esc + "0;30;47m"
	cErr    = esc + "1;31m"
	cOK     = esc + "1;32m"
	cField  = esc + "0;97;44m"
	cHeader = esc + "1;36m"
)

// Keys are read only while the UI waits for one, so nothing is left reading the console
// while an external editor (nano, Notepad) runs.
var pend []byte

func readSome(short bool) bool {
	buf := make([]byte, 256)
	n, err := readStdin(buf, short)
	if err != nil {
		quit()
	}
	pend = append(pend, buf[:n]...)
	return n > 0
}

var seqs = map[string]string{
	"[A": "up", "[B": "down", "[C": "right", "[D": "left", "OA": "up", "OB": "down", "OC": "right", "OD": "left",
	"[H": "home", "[F": "end", "OH": "home", "OF": "end", "[1~": "home", "[4~": "end", "[7~": "home", "[8~": "end",
	"[5~": "pgup", "[6~": "pgdn", "[3~": "del", "[2~": "ins", "[Z": "backtab",
}

func parseKey(b []byte) (string, int) {
	switch b[0] {
	case 0x1b:
		if len(b) == 1 {
			return "", 0
		}
		if b[1] != '[' && b[1] != 'O' {
			return "esc", 1
		}
		for i := 2; i < len(b) && i < 12; i++ {
			if b[i] >= 0x40 && b[i] <= 0x7e {
				s := string(b[1 : i+1])
				if k, ok := seqs[s]; ok {
					return k, i + 1
				}
				return "", i + 1 // unknown sequence: ignore it
			}
		}
		if len(b) >= 12 {
			return "esc", 1
		}
		return "", 0
	case '\r', '\n':
		return "enter", 1
	case 0x7f, 0x08:
		return "bs", 1
	case '\t':
		return "tab", 1
	case 0x03:
		return "ctrl-c", 1
	}
	if b[0] < 0x20 {
		return "", 1
	}
	r, size := utf8.DecodeRune(b)
	if r == utf8.RuneError && size <= 1 && !utf8.FullRune(b) {
		return "", 0
	}
	return string(r), size
}

func getKey() string {
	for {
		if len(pend) == 0 {
			readSome(false)
			continue
		}
		k, used := parseKey(pend)
		if used == 0 {
			// part of an escape sequence: a moment for the rest, else it was a lone Esc
			if !readSome(true) {
				pend = pend[1:]
				return "esc"
			}
			continue
		}
		pend = pend[used:]
		if k == "ctrl-c" {
			quit()
		}
		if k != "" {
			return k
		}
	}
}

var W, H = 80, 25

func out(s string) { os.Stdout.WriteString(s) }
func at(row, col int) string {
	return fmt.Sprintf("%s%d;%dH", esc, row, col)
}

func fit(s string, w int) string {
	r := []rune(s)
	if len(r) > w {
		if w > 1 {
			return string(r[:w-1]) + "…"
		}
		return string(r[:w])
	}
	return s + strings.Repeat(" ", w-len(r))
}

// frame clears the screen and draws the title bar and the help line.
func frame(title, help string) {
	W, H = termSize()
	W = max(W, 60)
	H = max(H, 20)
	out(cReset + esc + "2J" + esc + "?25l")
	out(at(1, 1) + cTitle + fit(" Funeral Quest Editor  │  "+title, W) + cReset)
	out(at(H, 1) + cDim + fit(" "+help, W-1) + cReset)
}

func status(msg string, isErr bool) {
	c := cOK
	if isErr {
		c = cErr
	}
	out(at(H-1, 1) + esc + "2K" + c + " " + fit(msg, W-2) + cReset)
}

// item is one row in a menu.
type item struct {
	Label string
	Value string // shown in a second column
	Help  string // shown at the bottom while selected
	Head  bool   // section heading (not selectable)
	Dim   bool
}

// menu shows a scrolling list. It returns the chosen index and the key that ended it:
// "enter", "esc", or one of the extra hotkeys.
func menu(title, help string, items []item, sel int, hot string, msg string, msgErr bool) (int, string) {
	labelW := 0
	for _, it := range items {
		labelW = max(labelW, len([]rune(it.Label)))
	}
	labelW = min(labelW+2, W/2)
	if sel < 0 || sel >= len(items) || items[sel].Head {
		sel = 0
		for sel < len(items)-1 && items[sel].Head {
			sel++
		}
	}
	top := 0
	frame(title, help)
	for {
		W, H = termSize()
		rows := H - 5
		if sel < top {
			top = sel
		}
		if sel >= top+rows {
			top = sel - rows + 1
		}
		for i := 0; i < rows; i++ {
			out(at(3+i, 1) + esc + "2K")
			n := top + i
			if n >= len(items) {
				continue
			}
			it := items[n]
			switch {
			case it.Head:
				out(cHeader + " " + fit(it.Label, W-2) + cReset)
			case n == sel:
				out(cSel + "  " + fit(it.Label, labelW) + fit(it.Value, W-labelW-4) + cReset)
			case it.Dim:
				out(cDim + "  " + fit(it.Label, labelW) + fit(it.Value, W-labelW-4) + cReset)
			default:
				out(cText + "  " + fit(it.Label, labelW) + cHi + fit(it.Value, W-labelW-4) + cReset)
			}
		}
		if len(items) > rows {
			out(at(2, W-14) + cDim + fmt.Sprintf("%3d of %-3d", sel+1, len(items)) + cReset)
		}
		if msg != "" {
			status(msg, msgErr)
		} else if sel < len(items) {
			out(at(H-1, 1) + esc + "2K" + cDim + " " + fit(items[sel].Help, W-2) + cReset)
		}
		k := getKey()
		msg = ""
		move := func(d int) {
			for i := sel + d; i >= 0 && i < len(items); i += d {
				if !items[i].Head {
					sel = i
					return
				}
			}
		}
		switch k {
		case "up":
			move(-1)
		case "down", "tab":
			move(1)
		case "pgup":
			for i := 0; i < rows-1; i++ {
				move(-1)
			}
		case "pgdn":
			for i := 0; i < rows-1; i++ {
				move(1)
			}
		case "home":
			sel = -1
			move(1)
		case "end":
			for i := 0; i < len(items); i++ {
				move(1)
			}
		case "enter", "esc":
			return sel, k
		default:
			if len(k) == 1 && strings.ContainsAny(strings.ToLower(k), hot) && hot != "" {
				return sel, strings.ToLower(k)
			}
		}
	}
}

// input reads a line at the bottom of the screen. ok=false if Esc was pressed.
func input(prompt, def string, hidden bool) (string, bool) {
	W, H = termSize()
	row := H - 2
	buf := []rune(def)
	pos := len(buf)
	out(esc + "?25h")
	defer out(esc + "?25l")
	for {
		fieldW := W - len([]rune(prompt)) - 4
		start := max(0, pos-fieldW+1)
		shown := buf[start:]
		if len(shown) > fieldW {
			shown = shown[:fieldW]
		}
		txt := string(shown)
		if hidden {
			txt = strings.Repeat("*", len(shown))
		}
		out(at(row, 1) + esc + "2K" + cHi + " " + prompt + " " + cField + fit(txt, fieldW) + cReset)
		out(at(row, len([]rune(prompt))+3+pos-start))
		k := getKey()
		switch k {
		case "enter":
			out(at(row, 1) + esc + "2K")
			return strings.TrimSpace(string(buf)), true
		case "esc":
			out(at(row, 1) + esc + "2K")
			return "", false
		case "bs":
			if pos > 0 {
				buf = append(buf[:pos-1], buf[pos:]...)
				pos--
			}
		case "del":
			if pos < len(buf) {
				buf = append(buf[:pos], buf[pos+1:]...)
			}
		case "left":
			pos = max(0, pos-1)
		case "right":
			pos = min(len(buf), pos+1)
		case "home":
			pos = 0
		case "end":
			pos = len(buf)
		default:
			if utf8.RuneCountInString(k) == 1 && len(buf) < 500 {
				r := []rune(k)[0]
				buf = append(buf[:pos], append([]rune{r}, buf[pos:]...)...)
				pos++
			}
		}
	}
}

// confirm asks a yes/no question.
func confirm(q string) bool {
	W, H = termSize()
	out(at(H-2, 1) + esc + "2K" + cErr + " " + q + " (y/N) " + cReset)
	k := strings.ToLower(getKey())
	out(at(H-2, 1) + esc + "2K")
	return k == "y"
}

// pager shows text a page at a time.
func pager(title string, text string) {
	lines := strings.Split(strings.ReplaceAll(text, "\r", ""), "\n")
	top := max(0, len(lines)-(H-4))
	frame(title, "↑↓ PgUp PgDn Home End to scroll   Esc to go back")
	for {
		W, H = termSize()
		rows := H - 4
		top = max(0, min(top, len(lines)-rows))
		for i := 0; i < rows; i++ {
			out(at(3+i, 1) + esc + "2K")
			if top+i < len(lines) {
				out(cText + " " + fit(lines[top+i], W-2) + cReset)
			}
		}
		switch getKey() {
		case "up":
			top--
		case "down", "enter":
			top++
		case "pgup":
			top -= rows - 1
		case "pgdn", " ":
			top += rows - 1
		case "home":
			top = 0
		case "end":
			top = len(lines)
		case "esc", "q", "Q":
			return
		}
	}
}

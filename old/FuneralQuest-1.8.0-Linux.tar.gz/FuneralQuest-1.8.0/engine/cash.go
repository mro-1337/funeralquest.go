package engine

import (
	"fmt"
	"strconv"
)

// Cash. The original gave every parlor starting money that nothing ever used. Here players
// keep a cut of each sale (the rest goes to operating costs and insurance) and the bank sells
// tags for cash at the prices the sysop sets.

// profitPercent is the net profit a parlor keeps from one sale after operating costs and
// insurance: a random percent between the settings, plus 2 for a sale close to the
// customer's limit (a well-run sale).
func profitPercent(c *Config, good bool) int {
	lo, hi := c.ProfitMin, c.ProfitMax
	if hi < lo {
		lo, hi = hi, lo
	}
	if hi <= 0 {
		return 0
	}
	pct := randomRange(lo, hi)
	if good {
		pct += 2
	}
	return min(pct, 100)
}

func (s *Session) bankBuy(a Action) Screen {
	me := s.me()
	pr := s.cfg().TagPrices
	menu := func(text string) Screen {
		var bs []Button
		for t, k := range []string{"w", "s", "g"} {
			if pr[t] > 0 {
				tt := t
				b := B(casketName[t], "bank", "buy_pick").K(k)
				b.From = &tt
				bs = append(bs, b)
			}
		}
		bs = append(bs, B("Back", "bank", "").K("b").D())
		return bankScr(text, bs)
	}
	prices := ""
	for t := 0; t < 3; t++ {
		if pr[t] > 0 {
			prices += fmt.Sprintf("\n  `w%-6s`$ $%s", casketName[t], Cash(pr[t]))
		}
	}
	if prices == "" {
		return bankHome("`wTeller: `$\"Sorry, the bank isn't selling tags right now.\"")
	}
	head := fmt.Sprintf("`wTeller: `$\"Tags for sale, one each:%s\n\n`$You have `w$%s`$.  Which kind would you like?\"", prices, Cash(me.Money))
	switch a.Sub {
	case "buy":
		return menu(head)
	case "buy_pick":
		if a.From == nil || *a.From < 0 || *a.From > 2 || pr[*a.From] <= 0 {
			return menu(head)
		}
		t := *a.From
		can := me.Money / pr[t]
		if can < 1 {
			return menu(fmt.Sprintf("`wTeller: `$\"A %s tag is $%s and you have $%s.  Come back after a few more funerals.\"", casketName[t], Cash(pr[t]), Cash(me.Money)))
		}
		scr := bankScr(fmt.Sprintf("`wTeller: `$\"%s tags are $%s each.  You can afford %d.  How many?\"", casketName[t], Cash(pr[t]), can), []Button{})
		tt := t
		scr.Input = &Input{Kind: "number", Prompt: "How many " + casketName[t] + " tags?", Cmd: "bank", Sub: "buy_do", Extra: &Action{From: &tt}, Def: strconv.Itoa(can), MaxLen: 9}
		return scr
	case "buy_do":
		v, ok := val(a)
		if !ok || a.From == nil || *a.From < 0 || *a.From > 2 || pr[*a.From] <= 0 {
			return menu(head)
		}
		t, n := *a.From, atoi(v)
		switch {
		case n == 0:
			return menu(head)
		case n < 0:
			return menu(fmt.Sprintf("`wTeller: `$\"You are very amusing %s.\"", sir(me)))
		case n > me.Money/pr[t]:
			return menu("`wTeller: `$\"You can't afford that many.  I'm trying to be nice here.\"")
		}
		me.Money -= n * pr[t]
		me.Coffins[t] += n
		s.progress("bank", 1)
		return menu(fmt.Sprintf("`wTeller: `$\"Here are your %d %s tag(s).  That's $%s.  Anything else?\"\n\n`$You have `w$%s`$ left.", n, casketName[t], Cash(n*pr[t]), Cash(me.Money)))
	}
	return menu(head)
}

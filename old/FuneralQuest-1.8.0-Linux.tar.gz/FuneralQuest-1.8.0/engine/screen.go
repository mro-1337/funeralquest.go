package engine

// Action is what a front end sends: a command, a sub-command and optional values.
type Action struct {
	Cmd     string  `json:"cmd"`
	Sub     string  `json:"sub,omitempty"`
	Value   *string `json:"value,omitempty"`
	HisID   *int    `json:"his_id,omitempty"`
	Day     *int    `json:"day,omitempty"`
	Section string  `json:"section,omitempty"`
	From    *int    `json:"from,omitempty"`
	To      *int    `json:"to,omitempty"`
	N       int     `json:"n,omitempty"`
	Kind2   string  `json:"kind2,omitempty"`
}

type Button struct {
	Label string `json:"label"`
	Key   string `json:"key,omitempty"`
	Def   bool   `json:"def,omitempty"`
	Action
}

type Input struct {
	Kind       string  `json:"kind"` // text | name | number | password
	Prompt     string  `json:"prompt"`
	Cmd        string  `json:"cmd"`
	Sub        string  `json:"sub,omitempty"`
	Extra      *Action `json:"extra,omitempty"`
	MaxLen     int     `json:"maxLen,omitempty"`
	Def        string  `json:"def,omitempty"`
	Multiline  bool    `json:"multiline,omitempty"`
	AllowEmpty bool    `json:"allowEmpty,omitempty"`
}

type Stats struct {
	Name       string `json:"name"`
	Parlor     string `json:"parlor"`
	SP         int    `json:"sp"`
	Exp        int    `json:"exp"`
	Turns      int    `json:"turns"`
	Luck       int    `json:"luck"`
	Tags       [3]int `json:"tags"`
	Money      int    `json:"money"`
	Level      int    `json:"level"`
	Title      string `json:"title"`
	HP         int    `json:"hp"`
	HPMax      int    `json:"hp_max"`
	Day        int    `json:"day"`
	Mail       int    `json:"mail"`
	VisitsLeft int    `json:"visits_left"`
}

type Fighter struct {
	Name string `json:"name"`
	HP   int    `json:"hp"`
	Max  int    `json:"max"`
}
type Battle struct {
	Me  Fighter `json:"me"`
	Him Fighter `json:"him"`
}

type RankRow struct {
	Name   string `json:"name"`
	Male   bool   `json:"male"`
	Parlor string `json:"parlor"`
	Exp    int    `json:"exp"`
	Status string `json:"status"`
	Level  int    `json:"level,omitempty"`
}

// Screen is what the engine returns for the front end to draw.
type Screen struct {
	View         string      `json:"view"` // desk generic popup map news ranking stats view chat quit gone
	Text         string      `json:"text"`
	Pic          string      `json:"pic"`
	BG           string      `json:"bg"`
	Info         string      `json:"info,omitempty"`
	Status       string      `json:"status,omitempty"`
	Location     string      `json:"location"`
	Buttons      []Button    `json:"buttons"`
	Input        *Input      `json:"input,omitempty"`
	Stats        Stats       `json:"stats"`
	Sale         bool        `json:"sale,omitempty"`
	Mood         string      `json:"mood,omitempty"`
	Cls          string      `json:"cls,omitempty"`
	Battle       *Battle     `json:"battle,omitempty"`
	Music        string      `json:"music,omitempty"` // looping music/ambience key (assets/sound)
	Sound        string      `json:"sound,omitempty"` // one-shot sound key
	RankRows     []RankRow   `json:"-"`
	StatRows     [][2]string `json:"-"`
	Rows         any         `json:"rows,omitempty"`
	Title        string      `json:"title,omitempty"`
	Rating       string      `json:"rating,omitempty"`
	Karma        string      `json:"karma,omitempty"`
	Day          int         `json:"day,omitempty"`
	Section      string      `json:"section,omitempty"`
	TopToday     string      `json:"topToday,omitempty"`
	TopYesterday string      `json:"topYesterday,omitempty"`
}

package engine

import (
	"math"
	"math/rand/v2"
	"regexp"
	"strconv"
	"strings"
)

func random(n int) int {
	if n <= 0 {
		return 0
	}
	return rand.IntN(n)
}
func randomRange(lo, hi int) int {
	if hi < lo {
		return lo
	}
	return lo + rand.IntN(hi-lo+1)
}
func frandom(f float64) float64 { return rand.Float64() * f }
func clamp(v, lo, hi int) int {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}
func fclamp(v, lo, hi float64) float64 { return math.Max(lo, math.Min(hi, v)) }
func pick[T any](a []T) T              { return a[rand.IntN(len(a))] }
func abs(n int) int {
	if n < 0 {
		return -n
	}
	return n
}

// Cash formats 12345 as "12,345".
func Cash(n int) string {
	s := strconv.Itoa(abs(n))
	var b strings.Builder
	for i, c := range s {
		if i > 0 && (len(s)-i)%3 == 0 {
			b.WriteByte(',')
		}
		b.WriteRune(c)
	}
	if n < 0 {
		return "-" + b.String()
	}
	return b.String()
}

// randomYesNo is get_random_yes_no() from funeral_util.cpp.
func randomYesNo(luck int, weight float64) bool {
	r := random(100)
	luck += int(float64(50-luck) * (1.0 - weight))
	return r <= luck
}

var codeRe = regexp.MustCompile("`f.|`.")

// StripCodes removes the LORD-style `x colour codes.
func StripCodes(s string) string { return codeRe.ReplaceAllString(s, "") }

func stripDangerous(s string) string {
	var b strings.Builder
	for _, c := range s {
		if strings.ContainsRune("?|=/\\;:,{}@+`<>%$", c) || c < 0x20 || c > 0x7a {
			continue
		}
		b.WriteRune(c)
	}
	return strings.TrimSpace(b.String())
}

func swearCheck(s string, swears [][2]string) string {
	for _, w := range swears {
		re := regexp.MustCompile("(?i)" + regexp.QuoteMeta(w[0]))
		s = re.ReplaceAllLiteralString(s, w[1])
	}
	return s
}

func rewardText(items [][2]any) string {
	out := ""
	n := 0
	for _, it := range items {
		name := it[0].(string)
		amt := it[1].(int)
		if amt == 0 {
			continue
		}
		n++
		if n == 1 {
			if amt > 0 {
				out += "\n\n`$You earn `w" + strconv.Itoa(amt) + "`$ " + name
			} else {
				out += "\n\n`4You lose `w" + strconv.Itoa(-amt) + "`4 " + name
			}
		} else if amt > 0 {
			out += " and `w" + strconv.Itoa(amt) + "`$ " + name
		} else {
			out += " and `w" + strconv.Itoa(-amt) + "`4 " + name
		}
	}
	if n > 0 {
		out += "."
	}
	return out
}

package engine

import (
	"fmt"
	"strings"
	"time"
)

// AI players: computer-run parlors that do what players do (sell funerals, shop, raid,
// set fires, talk in the cafe, put announcements in the paper) and can be raided back.
//
// They're kept a step behind real players on purpose: they work only part of a day
// (ai_skill), never get the daily top-seller bonuses, never train past the town's average
// human player, only raid players at least half as big as they are, and each human can be
// raided by AI players at most once a day.

// AIState is set on a computer-run parlor.
type AIState struct {
	Persona int   `json:"persona"`
	Next    int64 `json:"next"`              // unix time of its next move
	Day     int   `json:"day"`               // game day its turns were last handed out
	Raids   int   `json:"raids,omitempty"`   // raids left today
	Said    int   `json:"said,omitempty"`    // day of its last newspaper announcement
	Burned  int   `json:"burned,omitempty"`  // day it last hired the Twins
	Grudge  int   `json:"grudge,omitempty"`  // player who last broke into its parlor
	Chatted int64 `json:"chatted,omitempty"` // unix time it last talked in the cafe
}

// A persona is an AI player's way of talking. Names and parlors are made up separately, so
// every town gets different AI players. In News, %s is the AI's parlor; in Brag, the loser.
type persona struct {
	Chat []string
	Brag []string
	News []string
}

var personas = []persona{
	{ // old-school businessman
		[]string{"Business is good.  For me, anyway.", "Anyone know where I can get a cheap hearse?  Asking for a friend.", "My father always said: bury the competition.  Then he buried him.", "Nice weather today.  Bad for business though."},
		[]string{"Nothing personal, %s.  Just business.", "%s should have bought a better padlock."},
		[]string{"%s: three generations of putting people in the ground.  Ask about our family plan!", "This week only at %s: free embalming with every gold casket.  Some restrictions apply."}},
	{ // southern charm
		[]string{"Bless your heart, y'all.", "I make the best funeral potato salad in town and I will fight anyone who says otherwise.", "Somebody keeps leaving fake flowers on my graves.", "Sugar, the dead don't tip but their families sure do."},
		[]string{"Bless your heart, %s.", "Momma always said I had a mean right hook.  Sorry, %s."},
		[]string{"%s: we treat your loved ones like family.  Our family, not yours.", "Free sweet tea at every %s service!"}},
	{ // mad scientist
		[]string{"Statistically, someone in this cafe will need my services soon.", "I have a doctorate.  In what is none of your business.", "Has anyone seen my bone saw?  It's for... woodworking.", "The coffee here is to die for.  Literally, at this rate."},
		[]string{"Science wins again, %s.", "%s, your form was atrocious."},
		[]string{"%s: precision funerals for the discerning deceased.", "The management of %s would like to remind the public that the owner is a real doctor."}},
	{ // tough guy
		[]string{"Anybody wanna buy a shovel?  Lightly used.", "My brother says hi.  He's in the back.  Forever.", "I don't dig graves, I dig dreams.", "Yo, who parked the hearse in my spot?"},
		[]string{"You got shoveled, %s.", "That's what you get, %s."},
		[]string{"%s: we dig deeper so you don't have to!", "%s is under new management.  Same as the old management."}},
	{ // creepy gardener
		[]string{"My roses grow best near the old graves.  I won't say why.", "Silence is golden.  So are my caskets.", "I've buried three spouses.  All natural causes.  Mostly.", "Has anyone tried the new embalming fluid?  It smells like lavender."},
		[]string{"You should have stayed home, %s.", "Pruning is part of gardening, %s."},
		[]string{"%s: rest among the roses.", "%s is now offering moonlight burials."}},
	{ // cheapskate
		[]string{"Why pay more to be dead?", "Two-for-one coffins this week.  Bring a friend!", "My caskets are made from 100 percent recycled shipping pallets.", "Price match guarantee!  I'll beat any funeral in town."},
		[]string{"Discount beatdown, %s.  No refunds.", "%s just got the bargain package."},
		[]string{"%s: why pay more to be dead?  Pine boxes from $799!", "%s: if you find a cheaper funeral, you weren't looking hard enough."}},
	{ // snob
		[]string{"Darling, black is always in fashion.", "Velvet linings are not a luxury, they're a lifestyle.", "I only cry at funerals I'm paid to attend.", "Who invited the person in the plaid suit?  Ghastly."},
		[]string{"Darling %s, you were simply outclassed.", "%s, that outfit deserved worse."},
		[]string{"%s: leave this world in style.", "%s announces its fall casket collection.  Velvet is back."}},
	{ // good ol' boy
		[]string{"Funerals are the game and I'm the name.  Wait.", "My cousin runs a funeral home two towns over.  Don't trust him.", "Anybody got a jump?  The hearse died.  Ironic.", "If you can't afford a funeral, I know a guy with a wood chipper.  Kidding.  Mostly."},
		[]string{"Me 1, %s 0.", "Don't mess with the best, %s."},
		[]string{"%s: twice the service, half the price!", "%s would like everyone to know it is not affiliated with that other place."}},
}

var aiFirstM = []string{"Earl", "Vincent", "Chester", "Ronnie", "Harold", "Walter", "Gus", "Lloyd", "Clyde", "Mortimer", "Otis", "Floyd", "Herb", "Barry", "Doug", "Phil", "Stan", "Melvin", "Vern", "Duane", "Cletus", "Ike", "Morty", "Rex"}
var aiFirstF = []string{"Bettie", "Agatha", "Lucinda", "Mabel", "Gertrude", "Doris", "Edna", "Ruth", "Wanda", "Pearl", "Hazel", "Opal", "Velma", "Myrtle", "Dottie", "Ida", "Ima", "Constance", "Prudence", "Mavis"}
var aiLast = []string{"Graves", "Coffin", "Digby", "Bonesteel", "Mortimer", "Shroud", "Crane", "Pruitt", "Fell", "Malone", "Thorne", "Bigelow", "Vex", "Hatch", "Plotz", "Stiffler", "Ashby", "Barrow", "Gravely", "Toombs", "Lidd", "Payne", "Doolittle", "Wormwood", "Mudd", "Bury", "Sexton", "Moody", "Cryer", "Dedman"}

// Parlors: %s is the AI's last name where there is one.
var aiParlors = []string{"%s & Sons", "%s Bros Burials", "%s's Last Stop", "%s Eternal Rest", "%s Final Snooze", "%s & Daughters", "%s Cut-Rate Rites",
	"Dead & Breakfast", "Six Feet Under Inc", "Dirt Nap Chapel", "Casket Case", "Grave Expectations", "Urn Your Keep", "Rest Easy Mortuary",
	"Stiff Competition", "Ashes To Go", "The Pine Box", "Over My Dead Body", "Plot Twist Funerals", "Last Call Mortuary", "Bargain Burials",
	"Eternal Slumber Co", "Dearly Departed", "Bury Me Not Chapel", "Shovel Ready", "The Final Curtain", "Box & Go Burials", "Lights Out Chapel"}

// aiName makes up a name and parlor nobody in town is using.
func aiName(w *World) (name, parlor string, male bool) {
	for try := 0; try < 200; try++ {
		male = random(2) == 0
		first := pick(aiFirstF)
		if male {
			first = pick(aiFirstM)
		}
		last := pick(aiLast)
		name = first + " " + last
		tmpl := pick(aiParlors)
		parlor = tmpl
		if strings.Contains(tmpl, "%s") {
			parlor = fmt.Sprintf(tmpl, last)
		}
		if len(name) > 20 || len(parlor) > 20 || w.ByName(name) != nil {
			continue
		}
		// no two parlors in town share a first name, last name or kind of parlor name
		suffix := strings.ToLower(strings.TrimPrefix(tmpl, "%s"))
		taken := false
		for _, p := range w.Active() {
			f := strings.Fields(strings.ToLower(p.Name))
			taken = taken || strings.HasSuffix(strings.ToLower(p.Parlor), suffix) ||
				(len(f) > 0 && (f[0] == strings.ToLower(first) || f[len(f)-1] == strings.ToLower(last)))
		}
		if !taken {
			return name, parlor, male
		}
	}
	return "", "", false
}

func (p *Player) persona() persona { return personas[clamp(p.AI.Persona, 0, len(personas)-1)] }

// aiTick moves the AI players along. It's called with the world lock held whenever anything
// happens in the game (MaintCheck), and does nothing until an AI player's next move is due.
func (g *Game) aiTick(w *World) {
	c := &w.Config
	now := time.Now().Unix()
	var ai []*Player
	for _, p := range w.Players {
		if p.AI != nil && p.Active {
			ai = append(ai, p)
		}
	}
	// open or close AI parlors to match the setting
	if len(ai) > c.AIPlayers {
		for _, p := range ai[c.AIPlayers:] {
			p.Active = false
			g.Broadcast(w, p.Name+" sells "+p.Parlor+" and leaves town.")
		}
		ai = ai[:c.AIPlayers]
	}
	for len(ai) < c.AIPlayers && len(w.Active()) < c.MaxPlayers {
		p := g.newAI(w)
		if p == nil {
			break
		}
		ai = append(ai, p)
	}
	for _, p := range ai {
		for w.TakeMail(p.ID) != nil { // nobody reads an AI's letters
		}
		if p.AI.Day != w.Glo.GameAge {
			g.aiNewDay(w, p)
		}
		if now < p.AI.Next {
			continue
		}
		p.AI.Next = now + int64(randomRange(8, 30))*60
		g.aiMove(w, p)
		g.levelUp(w, p)
	}
}

func (g *Game) newAI(w *World) *Player {
	used := map[int]bool{}
	for _, p := range w.Players {
		if p.AI != nil && p.Active {
			used[p.AI.Persona] = true
		}
	}
	voice := random(len(personas))
	for _, i := range randPerm(len(personas)) {
		if !used[i] {
			voice = i
			break
		}
	}
	// reopen a closed AI parlor if there is one (it keeps its score), else make a new one
	var p *Player
	for _, q := range w.Players {
		if q.AI != nil && !q.Active && w.ByName(q.Name) == nil {
			p = q
			break
		}
	}
	if p == nil {
		name, parlor, male := aiName(w)
		if name == "" {
			return nil
		}
		p = &Player{Name: name, Parlor: parlor, Male: male, Created: time.Now().Unix()}
		g.freshStats(w, p)
		p.ID = w.NextID
		w.NextID++
		w.Players = append(w.Players, p)
	}
	p.Active = true
	p.AI = &AIState{Persona: voice, Next: time.Now().Unix() + int64(randomRange(1, 20))*60}
	g.Broadcast(w, p.Name+" has just moved into town!")
	return p
}

func randPerm(n int) []int {
	a := make([]int, n)
	for i := range a {
		a[i] = i
		j := random(i + 1)
		a[i], a[j] = a[j], a[i]
	}
	return a
}

func (g *Game) aiNewDay(w *World, p *Player) {
	c := &w.Config
	p.AI.Day = w.Glo.GameAge
	if p.Transport < 0 || p.Transport >= len(g.D().Transport) {
		p.Transport = 0
	}
	p.Turns = (c.TurnsPerDay + g.D().Transport[p.Transport].Bonus) * clamp(c.AISkill, 10, 100) / 100
	p.SP, p.Kicked, p.DayLast, p.Fights, p.Police, p.HP = 0, false, w.Glo.GameAge, 0, false, p.HPMax
	p.AI.Raids = 1
}

// humanAverage is the average strength and hit points of active human players, the most
// an AI player will train to.
func humanAverage(w *World, c *Config) (str, hp int) {
	n := 0
	for _, p := range w.Active() {
		if p.AI == nil {
			str += p.Strength
			hp += p.HPMax
			n++
		}
	}
	if n == 0 {
		return c.StartingStrength, c.StartingHP
	}
	return str / n, hp / n
}

func (g *Game) aiMove(w *World, p *Player) {
	c := &w.Config
	r := random(100)
	switch {
	case p.Turns > 0 && r < 60:
		g.aiWork(w, p)
	case r < 72 && p.AI.Raids > 0 && !c.AIAttacksOff:
		g.aiRaid(w, p)
	case r < 85 && !c.AIChatOff:
		g.aiTalk(w, p)
	default:
		g.aiShop(w, p)
	}
}

// aiWork sells funerals: one to three turns, each about as good as a plain sale by a player
// with no psychology training.
func (g *Game) aiWork(w *World, p *Player) {
	c := &w.Config
	best := 0
	for n := randomRange(1, 3); n > 0 && p.Turns > 0; n-- {
		p.Turns--
		if random(100) >= 65 {
			continue
		}
		var budget int
		switch random(4) {
		case 0:
			budget = randomRange(casketPrice[0]+1, 2800)
		case 1:
			budget = randomRange(1900, 5400)
		case 2:
			budget = randomRange(3700, 7530)
		default:
			budget = randomRange(4600, 18500)
		}
		price := budget * randomRange(55, 95) / 100
		casket := Wood
		if price >= casketPrice[Gold]+1500 {
			casket = Gold
		} else if price >= casketPrice[Silver]+1000 {
			casket = Silver
		}
		bp := int(float64(price) * 0.0064)
		if random(10) == 0 {
			bp += c.TradeBonus
		}
		expMod(p, bp)
		p.Coffins[casket]++
		p.Plots++
		p.Money = clamp(p.Money+price*profitPercent(c, false)/100, 0, 2e9)
		best = max(best, bp)
	}
	if best > 69 {
		g.Tv(w, fmt.Sprintf("\"It appears %s just made a %d BP sale,\" a guy reports.", p.Name, best))
	}
}

// aiShop spends tags and cash like a sensible player: security first, then training (never
// past the average human), lockpicks, and tags from the bank.
func (g *Game) aiShop(w *World, p *Player) {
	c := &w.Config
	// trade cash for gold tags, and wood/silver up to gold, keeping a few wood tags around
	if pr := c.TagPrices[Gold]; pr > 0 && p.Money >= pr {
		n := p.Money / pr
		p.Money -= n * pr
		p.Coffins[Gold] += n
	}
	if p.Coffins[Wood] > 8 {
		n := (p.Coffins[Wood] - 4) / 4
		p.Coffins[Wood] -= n * 4
		p.Coffins[Gold] += n
	}
	if p.Coffins[Silver] > 4 {
		n := p.Coffins[Silver] / 2
		p.Coffins[Silver] -= n * 2
		p.Coffins[Gold] += n
	}
	const smoke, safe, pad = 8, 6, 6
	cu := &p.Custom
	gold := &p.Coffins[Gold]
	str, hp := humanAverage(w, c)
	switch {
	case cu.Padlock == 0 && *gold >= pad:
		*gold -= pad
		cu.Padlock, cu.PadlockStrength = 1, 100
	case cu.FireAlarm == 0 && *gold >= smoke:
		*gold -= smoke
		cu.FireAlarm = 1
	case cu.Safe == 0 && *gold >= safe+4:
		*gold -= safe
		cu.Safe = 1
	case p.Strength < str && *gold >= strCost(p):
		*gold -= strCost(p)
		p.Strength++
	case p.HPMax+4 <= hp && *gold >= hpCost(p):
		*gold -= hpCost(p)
		p.HPMax += randomRange(4, 5)
	case cu.Lockpick < 2 && *gold >= 1:
		*gold--
		cu.Lockpick++
	}
}

func (g *Game) aiTalk(w *World, p *Player) {
	pe := p.persona()
	now := time.Now().Unix()
	if p.AI.Said != w.Glo.GameAge && random(3) == 0 {
		p.AI.Said = w.Glo.GameAge
		w.AddNews("front", fmt.Sprintf("`8%s of %s makes an announcement:`6\r\n", p.Name, p.Parlor)+fmt.Sprintf(pick(pe.News), p.Parlor)+"\r\n\r\n")
		return
	}
	if now-p.AI.Chatted < 20*60 {
		return
	}
	p.AI.Chatted = now
	w.AddSharedChat(fmt.Sprintf("`$%s: `w%s", p.Name, pick(pe.Chat)))
}

// aiTarget picks someone to raid: whoever broke in last if they're fair game, else a random
// parlor that isn't online, isn't under police protection, wasn't raided by an AI today and
// is at least half as big as this one.
func aiTarget(w *World, p *Player) *Player {
	ok := func(t *Player) bool {
		return t != nil && t.Active && t.ID != p.ID && !t.Police && !w.IsOnline(t.ID) && t.Exp > 0 &&
			(t.AI != nil || t.AIHitDay != w.Glo.GameAge) && !tooBig(&w.Config, lvl(p), lvl(t))
	}
	if t := w.Player(p.AI.Grudge); ok(t) {
		return t
	}
	var list []*Player
	for _, t := range w.Active() {
		if ok(t) && t.Exp*2 >= p.Exp {
			list = append(list, t)
		}
	}
	if len(list) == 0 {
		return nil
	}
	return pick(list)
}

func (g *Game) aiRaid(w *World, p *Player) {
	t := aiTarget(w, p)
	if t == nil {
		return
	}
	p.AI.Raids--
	p.Fights++
	if t.AI == nil {
		t.AIHitDay = w.Glo.GameAge
	}
	if t.ID == p.AI.Grudge {
		p.AI.Grudge = 0
	}
	sin := func() { p.Karma = clamp(p.Karma-w.Config.KarmaSin, 1, 100) }
	// a rare fire instead of a break-in, for parlors ahead of this one
	if p.Coffins[Gold] >= arsonCost+2 && t.Exp > p.Exp && p.AI.Burned+3 <= w.Glo.GameAge && random(4) == 0 {
		p.AI.Burned = w.Glo.GameAge
		p.Coffins[Gold] -= arsonCost
		sin()
		burnParlor(g, w, t)
		return
	}
	if t.Custom.Padlock > 0 {
		if p.Custom.Lockpick < 1 {
			return // the padlock did its job; nobody even knows
		}
		p.Custom.Lockpick--
		dmg := randomRange(5, 10)
		t.Custom.PadlockStrength -= dmg
		if t.Custom.PadlockStrength < 1 {
			t.Custom.Padlock, t.Custom.PadlockStrength = 0, 0
			w.AddMail(Letter{To: t.ID, Text: "`yYour padlock is `4damaged beyond repair`y by a prowler and falls off!"})
		} else {
			w.AddMail(Letter{To: t.ID, Text: fmt.Sprintf("`yYour padlock is weakened by `4%d`y down to `w%d percent strength`y by a prowler.", dmg, t.Custom.PadlockStrength)})
		}
	}
	if t.Custom.Safe == 0 && random(2) == 0 {
		n, name := stealTags(3, p, t)
		m := fmt.Sprintf("\n`wYou caught %s sneaking around inside your parlor!`$\n", p.Name)
		switch {
		case n == 1:
			m += fmt.Sprintf("You scare %s off.  You notice `w1 %s tag `$is missing.", him(p), name)
		case n > 1:
			m += fmt.Sprintf("You scare %s off.  You notice `w%d %s tags `$are missing.", him(p), n, name)
		default:
			m += fmt.Sprintf("You scare %s off before %s could steal anything.", him(p), he(p))
		}
		if n > 0 {
			sin()
		}
		w.AddMail(Letter{To: t.ID, Text: m, Pic: "people/man_prowl"})
		return
	}
	// fight it out, with the same blows as a player's battle
	hit := func(s int) int { return int(frandom(float64(s+1)/2) + float64(s+1)/2) }
	php, thp := p.HPMax, t.HPMax
	for i := 0; php > 0 && thp > 0 && i < 200; i++ {
		thp -= hit(p.Strength)
		if thp > 0 {
			php -= hit(t.Strength)
		}
	}
	if thp <= 0 {
		t.HP, t.Police = 0, true
		n, name := stealTags(4, p, t)
		win, lose := battleBP(p, t, false)
		stolen := " Nothing was stolen."
		if n == 1 {
			stolen = fmt.Sprintf(" `w1`$ %s tag was stolen from your pocket.", name)
		} else if n > 1 {
			stolen = fmt.Sprintf(" `w%d`$ %s tags were stolen from your pockets.", n, name)
		}
		g.Tv(w, fmt.Sprintf("It looks like %s was taken to the hospital.", t.Name))
		w.AddMail(Letter{To: t.ID, Pic: "stuff/battle_lose", Text: fmt.Sprintf("\n`wYou were attacked in your sleep by %s!`$\n\nYou are badly injured.  You vaguely remember riding in an ambulance.\n\n`$You lose `w%s `$Bury Points.%s", p.Name, Cash(lose), stolen)})
		_ = win
		w.AddNews("crime", fmt.Sprintf("`8%s brutally assaulted %s!`6\r\n\"%s\" `8justified %s.\r\n\r\n", p.Name, t.Name, fmt.Sprintf(pick(p.persona().Brag), t.Name), p.Name))
		sin()
		if t.AI != nil {
			t.AI.Grudge = p.ID
		}
		return
	}
	p.HP = 0
	win, _ := battleBP(t, p, true)
	w.AddMail(Letter{To: t.ID, Pic: "places/hospital_ambulance", Text: fmt.Sprintf("\n`wYou were attacked in your sleep by %s!`$\n\nYou woke up and kicked %s ass!\n\n`$You earn `w%s `$Bury Points. (applied to day %d)", p.Name, his(p), Cash(win), w.Glo.GameAge)})
	w.AddNews("crime", fmt.Sprintf("`8%s assaulted %s in self defense!\r\n\r\n", t.Name, p.Name))
	g.Tv(w, fmt.Sprintf("It looks like %s was taken to the hospital.", p.Name))
	p.Police = true // patched up; leaves everyone alone for the rest of the day
	p.AI.Raids = 0
}

// burnParlor is the Twins' fire, for AI players (same odds and damage as a player hiring them).
func burnParlor(g *Game, w *World, t *Player) {
	if t.Custom.FireAlarm == 1 && randomRange(1, 10) > 2 {
		w.AddNews("front", fmt.Sprintf("`7EARLY WARNING SAVES PARLOR\n`^A small fire was quickly put out at local business %s before any damage was done. \"It was a close call,\" said a relieved %s.\n\n", t.Parlor, t.Name))
		w.AddMail(Letter{To: t.ID, Pic: "stuff/fire_alarm", Tags: [3]int{0, 0, 3},
			Text: "\n`yA mysterious fire was started on your property.  Thanks to your smoke detector the fire was put out before any serious damage was done.  The police chief awards you `w3`y gold tags!\n"})
		return
	}
	burned := int(float64(t.Plots) * 0.05)
	if t.Custom.Safe > 0 {
		w.AddMail(Letter{To: t.ID, Pic: "stuff/fire_alarm", Text: fmt.Sprintf("\n`yA mysterious fire was started on your property.  You lost `4%d`y gravestone(s) but your `wSafe`y protected all your tags.\n", burned)})
	} else {
		w.AddMail(Letter{To: t.ID, Pic: "stuff/fire_alarm", Text: fmt.Sprintf("\n`yA mysterious fire was started on your property.  You lost `4%d`y gravestone(s) and `4%d`y wood tag(s).\n", burned, t.Coffins[Wood])})
		t.Coffins[Wood] = 0
	}
	t.Plots = max(0, t.Plots-burned)
	w.AddNews("front", fmt.Sprintf("`7PARLOR DAMAGED BY FIRE, ARSON SUSPECTED\n`^A small fire was not noticed until too late at %s today.  \"This isn't happening!\" said %s, still in shock.\n\n", t.Parlor, t.Name))
	g.Tv(w, fmt.Sprintf("You see some breaking news.  It looks like %s's parlor caught on fire.", t.Name))
}

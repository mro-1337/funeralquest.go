// Package engine is a Go port of Seth A. Robinson's Funeral Quest server (2001):
// the game rules from commands_*.cpp, create_customer.cpp, maint.cpp and the server's .c scripts.
package engine

import (
	"math/rand/v2"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
)

// Risk is one entry of risks.txt.
type Risk struct {
	StartMessage, StartURL, StartBG       string
	Accept, Risk                          string
	FailMessage, FailURL, FailBG          string
	SuccessMessage, SuccessURL, SuccessBG string
	AcceptMessage, AcceptURL, AcceptBG    string
}

// SellItem is an entry of soft_sell.txt / hard_sell.txt.
type SellItem struct {
	A, Name string
	Price   int
}

// Event is one "start_entry" of a CEvent-style file (events.txt, yangs.txt, news_blurbs.txt...).
type Event struct {
	Message, Title, GiveRandom, AddLog, Pic string
	BP, Luck, Turns                         [2]int
	HasBP, HasLuck, HasTurns                bool
}

type eventRange struct {
	Low, High int
	Entries   []*Event
}

type Transport struct {
	Name  string
	Price int
	Bonus int
	Desc  string
	URL   string
}

// Data holds all text data the game reads from the gamedata folder.
type Data struct {
	Risks       []Risk
	Options     []SellItem
	Upgrades    []SellItem
	Events      []eventRange
	Yangs       []eventRange
	YangsNice   []eventRange
	NoCustomers []eventRange
	NewsBlurbs  []eventRange
	Karma       []string
	Ratings     []string
	Swears      [][2]string
	Transport   []Transport
}

func readLines(dir, name string) []string {
	b, err := os.ReadFile(filepath.Join(dir, name))
	if err != nil {
		return nil
	}
	return strings.Split(strings.ReplaceAll(string(b), "\r\n", "\n"), "\n")
}

func field(w []string, i int) string {
	if i < len(w) {
		return w[i]
	}
	return ""
}

func atoi(s string) int {
	n, _ := strconv.Atoi(strings.TrimSpace(s))
	return n
}

func loadRisks(dir string) []Risk {
	var out []Risk
	var r Risk
	for _, line := range readLines(dir, "risks.txt") {
		if line == "" || strings.HasPrefix(line, "//") {
			continue
		}
		w := strings.Split(line, "|")
		v := field(w, 1)
		switch w[0] {
		case "start_message":
			r.StartMessage = v
		case "start_url":
			r.StartURL = v
		case "start_url_bg":
			r.StartBG = v
		case "normal":
			r.Accept = strings.TrimSpace(v)
		case "risk":
			r.Risk = strings.TrimSpace(v)
		case "fail_message":
			r.FailMessage = v
		case "fail_url":
			r.FailURL = v
		case "fail_url_bg":
			r.FailBG = v
		case "success_message":
			r.SuccessMessage = v
		case "success_url":
			r.SuccessURL = v
		case "success_url_bg":
			r.SuccessBG = v
		case "normal_message":
			r.AcceptMessage = v
		case "normal_url":
			r.AcceptURL = v
		case "normal_url_bg":
			r.AcceptBG = v
		case "add_risk":
			out = append(out, r)
		}
	}
	return out
}

func loadSell(dir, name string) []SellItem {
	var out []SellItem
	var it SellItem
	for _, line := range readLines(dir, name) {
		if line == "" || strings.HasPrefix(line, "//") {
			continue
		}
		w := strings.Split(line, "|")
		switch w[0] {
		case "reference":
			it.A = strings.TrimSpace(field(w, 1))
		case "name":
			it.Name = strings.TrimSpace(field(w, 1))
		case "price":
			it.Price = atoi(field(w, 1))
		case "add_item":
			out = append(out, it)
		}
	}
	return out
}

func loadEvents(dir, name string) []eventRange {
	var out []eventRange
	var cur *eventRange
	var e *Event
	for _, line := range readLines(dir, name) {
		if line == "" || strings.HasPrefix(line, "//") {
			continue
		}
		w := strings.Split(line, "|")
		key := strings.TrimSpace(w[0])
		switch {
		case key == "range":
			out = append(out, eventRange{Low: atoi(field(w, 1)), High: atoi(field(w, 2))})
			cur = &out[len(out)-1]
			e = nil
		case key == "start_entry":
			if cur != nil {
				e = &Event{}
				cur.Entries = append(cur.Entries, e)
			}
		case e != nil:
			pair := [2]int{atoi(field(w, 1)), atoi(field(w, 2))}
			switch key {
			case "message":
				e.Message = field(w, 1)
			case "title":
				e.Title = field(w, 1)
			case "give_random":
				e.GiveRandom = field(w, 1)
			case "add_log":
				e.AddLog = field(w, 1)
			case "set_pic":
				e.Pic = field(w, 1)
			case "mod_bp":
				e.BP, e.HasBP = pair, true
			case "mod_luck":
				e.Luck, e.HasLuck = pair, true
			case "mod_turns":
				e.Turns, e.HasTurns = pair, true
			}
		}
	}
	// keep only ranges with entries
	return out
}

func loadNumbered(dir, name string) []string {
	out := make([]string, 100)
	for _, line := range readLines(dir, name) {
		w := strings.Split(line, "|")
		n := atoi(w[0])
		if n >= 1 && n <= 100 {
			out[n-1] = field(w, 1)
		}
	}
	return out
}

func loadSwears(dir string) [][2]string {
	var out [][2]string
	for _, line := range readLines(dir, "swear_words.txt") {
		if line == "" || strings.HasPrefix(line, ";") {
			continue
		}
		w := strings.Split(line, "|")
		if w[0] == "addword" && field(w, 1) != "" {
			out = append(out, [2]string{strings.ToLower(w[1]), field(w, 2)})
		}
	}
	return out
}

// LoadData reads every data file from dir.
func LoadData(dir string) *Data {
	return &Data{
		Risks:       loadRisks(dir),
		Options:     loadSell(dir, "soft_sell.txt"),
		Upgrades:    loadSell(dir, "hard_sell.txt"),
		Events:      loadEvents(dir, "events.txt"),
		Yangs:       loadEvents(dir, "yangs.txt"),
		YangsNice:   loadEvents(dir, "yangs_nice.txt"),
		NoCustomers: loadEvents(dir, "no_customers.txt"),
		NewsBlurbs:  loadEvents(dir, "news_blurbs.txt"),
		Karma:       loadNumbered(dir, "karma.txt"),
		Ratings:     loadNumbered(dir, "ratings.txt"),
		Swears:      loadSwears(dir),
		Transport: []Transport{
			{"Bicycle", 4, 0, "(you start with this, you can trade it in for 2)", ""},
			{"Budget Hearse", 12, 2, "The ever humble Budget Hearse can fulfill all your transportation needs.  Children may laugh and point somewhat, but it sure beats a bike.", "hearse/hearse1"},
			{"Medalist", 30, 4, "The new Medalist very simply is the greatest value available today in the funeral profession. Flowing body lines and a graceful roof make this coach a winner.", "hearse/hearse2"},
			{"Statesman", 50, 7, "The paradigm of contemporary elegance and styling, the Statesman funeral coach gracefully integrates form and function with dramatic design.", "hearse/hearse3"},
			{"Crown Sovereign", 80, 10, "Beautifully proportioned, this new funeral coach reflects the prestige and styling of lasting beauty, an investment in your business future that is as distinguished and distinctive as the service you provide.", "hearse/hearse4"},
		},
	}
}

// computeEvent picks a random entry of the first range containing value (CEvent::compute_event).
func computeEvent(ranges []eventRange, value int) *Event {
	for _, r := range ranges {
		if value >= r.Low && value <= r.High && len(r.Entries) > 0 {
			return r.Entries[rand.IntN(len(r.Entries))]
		}
	}
	return nil
}

var picClean = regexp.MustCompile(`[^a-z0-9/_-]`)

// PicKey turns an original Flash URL ("flash\people\m_adult.swf") into an art key ("people/m_adult").
func PicKey(url string) string {
	k := strings.ToLower(strings.TrimSpace(strings.ReplaceAll(url, "\\", "/")))
	k = strings.TrimLeft(k, "/")
	k = strings.TrimPrefix(k, "flash/")
	k = strings.TrimSuffix(k, ".swf")
	for strings.Contains(k, "//") {
		k = strings.ReplaceAll(k, "//", "/")
	}
	k = picClean.ReplaceAllString(k, "_")
	if k == "blank" {
		return ""
	}
	return k
}

package engine

import (
	"archive/zip"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestUpgradeFromOldData(t *testing.T) {
	g := newTestGame(t)
	a, _ := g.CreatePlayer(NewPlayer{Name: "Oldtimer", Parlor: "Old Rest", Logon: "old", Password: "x"})
	b, _ := g.CreatePlayer(NewPlayer{Name: "Newbie", Parlor: "New Rest", Logon: "new", Password: "x"})
	// make it look like a 1.7 world: no schema, no levels, a veteran with a huge score
	g.Store.Tx(func(w *World) error {
		w.Schema = 0
		w.Config.AIPlayers = 0
		for _, p := range w.Players {
			p.Level, p.XP = 0, 0
		}
		w.Player(a.ID).Exp = 5_000_000
		w.Player(b.ID).Exp = 300
		return nil
	})
	g.Store.Tx(func(w *World) error { g.MaintCheck(w, false); return nil })
	g.View(func(w *World) {
		if w.Schema != CurrentSchema {
			t.Fatalf("schema %d", w.Schema)
		}
		old, nw := w.Player(a.ID), w.Player(b.ID)
		if old.Level != 40 || old.Exp != 5_000_000 {
			t.Errorf("veteran: level %d exp %d (want level 40, score untouched)", old.Level, old.Exp)
		}
		if nw.Level < 2 || nw.Level > 10 {
			t.Errorf("newer player level %d", nw.Level)
		}
		if nw.XPBoost == 0 {
			t.Error("player far below the average should catch up faster")
		}
	})
	pre, _ := filepath.Glob(filepath.Join(g.Store.Dir, "backups", "fq-before-upgrade-*.zip"))
	if len(pre) != 1 {
		t.Fatalf("backups: %v", g.Backups())
	}
	zr, err := zip.OpenReader(pre[0])
	if err != nil {
		t.Fatal(err)
	}
	found := false
	for _, f := range zr.File {
		found = found || f.Name == "world.json"
		if strings.HasPrefix(f.Name, "backups/") || strings.HasSuffix(f.Name, ".lock") {
			t.Errorf("backup holds %s", f.Name)
		}
	}
	zr.Close()
	if !found {
		t.Fatal("backup has no world.json")
	}
	// a second start doesn't upgrade (or back up) again
	g.Store.Tx(func(w *World) error { g.MaintCheck(w, false); return nil })
	if pre, _ = filepath.Glob(filepath.Join(g.Store.Dir, "backups", "fq-before-upgrade-*.zip")); len(pre) != 1 {
		t.Fatalf("%d upgrade backups after restart", len(pre))
	}
}

func TestWeeklyBackups(t *testing.T) {
	g := newTestGame(t)
	g.CreatePlayer(NewPlayer{Name: "Keeper", Parlor: "Keep Rest", Logon: "keeper", Password: "x"})
	g.Store.Tx(func(w *World) error { w.Config.BackupKeep = 2; return nil })
	for i := 0; i < 4; i++ {
		g.Store.Tx(func(w *World) error {
			w.Glo.LastBackup = "2000-01-01" // long ago: due
			g.MaintCheck(w, true)
			return nil
		})
	}
	m, _ := filepath.Glob(filepath.Join(g.Store.Dir, "backups", "fq-backup-*.zip"))
	if len(m) == 0 || len(m) > 2 {
		t.Fatalf("automatic backups kept: %d", len(m))
	}
	// not due again the same day
	n := len(m)
	g.Store.Tx(func(w *World) error { g.MaintCheck(w, true); return nil })
	m, _ = filepath.Glob(filepath.Join(g.Store.Dir, "backups", "fq-backup-*.zip"))
	if len(m) != n {
		t.Fatalf("backed up again before it was due")
	}
	if _, err := g.BackupNow(); err != nil {
		t.Fatal(err)
	}
	if st, _ := os.Stat(g.Backups()[0]); st == nil || st.Size() == 0 {
		t.Fatal("manual backup is empty")
	}
}

func TestLevelsRetireChallenges(t *testing.T) {
	g := newTestGame(t)
	p, _ := g.CreatePlayer(NewPlayer{Name: "Earl Hatch", Parlor: "Hatch Home", Male: true, Logon: "earl", Password: "x"})
	small, _ := g.CreatePlayer(NewPlayer{Name: "Tiny", Parlor: "Tiny Rest", Logon: "tiny", Password: "x"})
	g.Store.Tx(func(w *World) error {
		w.Config.AIPlayers = 0
		w.Player(small.ID).Exp = 100
		return nil
	})
	s := g.NewSession(p.ID, "web")
	s.Act(Action{Cmd: "main"})
	s.Act(Action{Cmd: "main"})

	// level up: enough experience for level 10 pays tags and says so on the next screen
	g.Store.Tx(func(w *World) error { w.Player(p.ID).XP = levelXP(10, 100); return nil })
	sc := s.Act(Action{Cmd: "stats"})
	sc = s.Act(Action{Cmd: "main"})
	if !strings.Contains(sc.Text, "LEVEL UP") || sc.Stats.Level != 10 || sc.Stats.Title != "Undertaker" {
		t.Fatalf("level up: %d %q %q", sc.Stats.Level, sc.Stats.Title, sc.Text)
	}

	// raid gap: level 30 can't raid level 1
	g.Store.Tx(func(w *World) error { w.Player(p.ID).XP = levelXP(30, 100); return nil })
	s.Act(Action{Cmd: "main"})
	s.Act(Action{Cmd: "comp"})
	sc = s.Act(Action{Cmd: "comp", Sub: "gotname", HisID: &small.ID})
	if !strings.Contains(sc.Text, "beginner") {
		t.Fatalf("raid gap: %s", sc.Text)
	}

	// challenges: three this week; finishing one pays experience and leaves a letter
	sc = s.Act(Action{Cmd: "challenges"})
	if strings.Count(sc.Text, "[ ]") != 3 {
		t.Fatalf("challenges: %s", sc.Text)
	}
	var kind string
	g.View(func(w *World) { kind = w.Player(p.ID).Week.Ch[0].Kind })
	var xp0 int
	g.View(func(w *World) { xp0 = w.Player(p.ID).XP })
	g.Store.Tx(func(w *World) error {
		s.w = w
		defer func() { s.w = nil }()
		for _, ch := range w.Player(p.ID).Week.Ch {
			s.progress(ch.Kind, ch.Need)
		}
		return nil
	})
	g.View(func(w *World) {
		me := w.Player(p.ID)
		if !me.Week.Bonus || me.XP <= xp0 {
			t.Fatalf("challenges not paid: %+v xp %d -> %d (%s)", me.Week, xp0, me.XP, kind)
		}
		if w.MailCount(me.ID) < 4 {
			t.Fatalf("challenge letters: %d", w.MailCount(me.ID))
		}
	})

	// retire at 60 with an heirloom
	g.Store.Tx(func(w *World) error {
		me := w.Player(p.ID)
		me.XP, me.Transport, me.Exp, me.Plots = levelXP(60, 100), 2, 99999, 500
		w.Mail = nil
		return nil
	})
	sc = s.Act(Action{Cmd: "main"})
	hasRetire := false
	for _, b := range sc.Buttons {
		hasRetire = hasRetire || b.Cmd == "retire"
	}
	if !hasRetire {
		t.Fatalf("no Retire button at level 60: %+v", sc.Buttons)
	}
	s.Act(Action{Cmd: "retire"})
	s.Act(Action{Cmd: "retire", Sub: "pick_hearse"})
	sc = s.Act(Action{Cmd: "retire", Sub: "do_hearse"})
	g.View(func(w *World) {
		me := w.Player(p.ID)
		if me.Name != "Earl Hatch Jr." || me.Level != 1 || me.XP != 0 || me.Exp != 0 || me.Transport != 2 || me.Generation != 2 || me.Logon != "earl" {
			t.Fatalf("heir: %+v", me)
		}
		if len(w.Legends) != 1 || w.Legends[0].Name != "Earl Hatch" {
			t.Fatalf("legends: %+v", w.Legends)
		}
	})
	// the heir can log in with the same logon
	if _, err := g.Login("earl", "x"); err != nil {
		t.Fatal(err)
	}
	// a second retirement names the next generation III
	g.Store.Tx(func(w *World) error { w.Player(p.ID).XP = levelXP(60, 100); return nil })
	s.Act(Action{Cmd: "main"})
	s.Act(Action{Cmd: "retire", Sub: "do_turns"})
	g.View(func(w *World) {
		me := w.Player(p.ID)
		if me.Name != "Earl Hatch III" || me.Heirlooms["turns"] != 1 || me.Heirlooms["hearse"] != 1 {
			t.Fatalf("third generation: %s %+v", me.Name, me.Heirlooms)
		}
	})
}

func TestRestedTurns(t *testing.T) {
	g := newTestGame(t)
	p, _ := g.CreatePlayer(NewPlayer{Name: "Sleepy", Parlor: "Nap Rest", Logon: "nap", Password: "x"})
	s := g.NewSession(p.ID, "web")
	s.Act(Action{Cmd: "main"})
	// played day 1 with 5 turns left, then missed two days
	g.Store.Tx(func(w *World) error {
		me := w.Player(p.ID)
		me.Turns, me.DayLast = 5, w.Glo.GameAge
		w.Glo.GameAge += 3
		return nil
	})
	s.greeted = false
	sc := s.Act(Action{Cmd: "main"})
	if sc.Stats.Turns != 15+min(5+2*15, 45) || !strings.Contains(sc.Text, "well rested") {
		t.Fatalf("rested turns: %d %q", sc.Stats.Turns, sc.Text)
	}
}

func TestSeasons(t *testing.T) {
	g := newTestGame(t)
	a, _ := g.CreatePlayer(NewPlayer{Name: "Winner", Parlor: "Win Rest", Logon: "winner", Password: "x"})
	b, _ := g.CreatePlayer(NewPlayer{Name: "Second", Parlor: "Two Rest", Logon: "second", Password: "x"})
	g.Store.Tx(func(w *World) error {
		w.Config.SeasonDays, w.Config.AIPlayers = 3, 0
		g.MaintCheck(w, true) // starts season 1
		w.Player(a.ID).SeasonBP, w.Player(b.ID).SeasonBP = 900, 400
		w.Player(a.ID).Exp = 12345
		return nil
	})
	for i := 0; i < 3; i++ {
		g.Store.Tx(func(w *World) error { g.MaintCheck(w, true); return nil })
	}
	g.View(func(w *World) {
		win := w.Player(a.ID)
		if win.Trophies != 1 || win.SeasonBP != 0 || win.Exp != 12345 || win.XP == 0 || w.Glo.Season != 2 {
			t.Fatalf("season end: trophies %d seasonBP %d exp %d xp %d season %d", win.Trophies, win.SeasonBP, win.Exp, win.XP, w.Glo.Season)
		}
		if !strings.Contains(strings.Join(w.Deeds, "\n"), "Winner won season 1") {
			t.Fatalf("deeds: %v", w.Deeds)
		}
	})
}

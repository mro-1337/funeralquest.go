package engine

import (
	"archive/zip"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

// CurrentSchema is the layout of world.json this version writes. upgrade brings older data
// files up to it, once, after making a backup.
//
//	1 (or missing): 1.0.0 - 1.7.x
//	2: 1.8.0 levels, dynasties, weekly challenges, seasons
const CurrentSchema = 2

// upgrade converts an older world.json. Called with the world lock held, from MaintCheck,
// so it runs before anyone plays on the new version. New settings get their defaults in
// Config.fillNew; this handles player records.
func (g *Game) upgrade(w *World) {
	if w.Schema >= CurrentSchema {
		return
	}
	if len(w.Players) > 0 {
		name, err := Backup(w.dir, "before-upgrade-"+Version)
		if err != nil {
			g.Log.Printf("upgrade: backup failed (%v); upgrading anyway, your old world.json is unchanged until the next save", err)
		} else {
			g.Log.Printf("upgrade: saved a backup of the old data in %s", name)
		}
	}
	if w.Schema < 2 {
		// levels: existing parlors start at the level their Bury Points would have earned,
		// up to level 40, so veterans get a head start but still have to earn the top titles
		pace := w.Config.LevelPace
		for _, p := range w.Players {
			if p.Level == 0 {
				p.XP = min(max(0, p.Exp), levelXP(40, pace))
				p.Level = levelFor(p.XP, pace)
			}
		}
		catchUp(w)
		if len(w.Players) > 0 {
			g.Log.Printf("upgrade: gave %d parlors their levels", len(w.Players))
		}
	}
	w.Schema = CurrentSchema
}

// Backup zips the data folder (everything but older backups, locks and temporary files)
// into data/backups and returns the file's path. Backups named fq-backup-* are automatic
// ones and are thinned to keep; others (before an upgrade, or made by hand) are kept.
func Backup(dataDir, label string) (string, error) {
	dir := filepath.Join(dataDir, "backups")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return "", err
	}
	name := filepath.Join(dir, fmt.Sprintf("fq-%s-%s.zip", label, time.Now().Format("2006-01-02-150405")))
	f, err := os.Create(name + ".part")
	if err != nil {
		return "", err
	}
	zw := zip.NewWriter(f)
	err = filepath.Walk(dataDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return nil // skip what can't be read
		}
		rel, _ := filepath.Rel(dataDir, path)
		if info.IsDir() {
			if rel == "backups" {
				return filepath.SkipDir
			}
			return nil
		}
		low := strings.ToLower(info.Name())
		if strings.HasSuffix(low, ".lock") || strings.HasSuffix(low, ".tmp") || strings.HasSuffix(low, ".part") {
			return nil
		}
		h, err := zip.FileInfoHeader(info)
		if err != nil {
			return nil
		}
		h.Name, h.Method = filepath.ToSlash(rel), zip.Deflate
		out, err := zw.CreateHeader(h)
		if err != nil {
			return err
		}
		in, err := os.Open(path)
		if err != nil {
			return nil
		}
		defer in.Close()
		_, err = io.Copy(out, in)
		return err
	})
	if cerr := zw.Close(); err == nil {
		err = cerr
	}
	if cerr := f.Close(); err == nil {
		err = cerr
	}
	if err != nil {
		os.Remove(name + ".part")
		return "", err
	}
	if err := os.Rename(name+".part", name); err != nil {
		return "", err
	}
	return name, nil
}

// pruneBackups deletes the oldest automatic backups beyond keep.
func pruneBackups(dataDir string, keep int) {
	m, _ := filepath.Glob(filepath.Join(dataDir, "backups", "fq-backup-*.zip"))
	sort.Strings(m) // names carry the date and time, so this is oldest first
	for len(m) > max(1, keep) {
		os.Remove(m[0])
		m = m[1:]
	}
}

// autoBackup makes the regular backup when it's due (from the nightly maintenance).
func (g *Game) autoBackup(w *World) {
	c := w.Config
	if c.BackupDays <= 0 || len(w.Players) == 0 {
		return
	}
	if last, err := time.Parse("2006-01-02", w.Glo.LastBackup); err == nil && time.Since(last) < time.Duration(c.BackupDays)*24*time.Hour-time.Hour {
		return
	}
	name, err := Backup(w.dir, "backup")
	if err != nil {
		g.Log.Printf("backup failed: %v", err)
		return
	}
	w.Glo.LastBackup = today()
	pruneBackups(w.dir, c.BackupKeep)
	g.Log.Printf("backup saved: %s", name)
}

// BackupNow makes a backup on request (fq admin backup, the web admin), under the lock so
// the copy is consistent.
func (g *Game) BackupNow() (string, error) {
	var name string
	err := g.Store.Tx(func(w *World) error {
		var err error
		name, err = Backup(w.dir, "manual")
		return err
	})
	return name, err
}

// Backups lists the backup files, newest first.
func (g *Game) Backups() []string {
	m, _ := filepath.Glob(filepath.Join(g.Store.Dir, "backups", "fq-*.zip"))
	at := map[string]time.Time{}
	for _, f := range m {
		if st, err := os.Stat(f); err == nil {
			at[f] = st.ModTime()
		}
	}
	sort.Slice(m, func(i, j int) bool { return at[m[i]].After(at[m[j]]) })
	return m
}

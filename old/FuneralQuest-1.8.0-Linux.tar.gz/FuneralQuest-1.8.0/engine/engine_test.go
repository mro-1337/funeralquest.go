package engine

import (
	"encoding/json"
	"log"
	"math/rand/v2"
	"os"
	"strings"
	"testing"
)

func newTestGame(t *testing.T) *Game {
	g, err := NewGame(t.TempDir(), "../gamedata", log.New(os.Stderr, "", 0))
	if err != nil {
		t.Fatal(err)
	}
	return g
}

// TestFuzz: bots press random buttons and answer prompts across the whole game.
func TestFuzz(t *testing.T) {
	g := newTestGame(t)
	names := []string{"Skelly", "Morticia", "Digger", "Bones"}
	var ss []*Session
	for i, n := range names {
		p, err := g.CreatePlayer(NewPlayer{Name: n, Parlor: n + " Rest", Male: i%2 == 0, Logon: strings.ToLower(n), Password: "pw"})
		if err != nil {
			t.Fatal(err)
		}
		ss = append(ss, g.NewSession(p.ID, map[bool]string{true: "web", false: "bbs"}[i < 2]))
	}
	g.Store.Tx(func(w *World) error {
		for _, p := range w.Players {
			p.Coffins = [3]int{50, 50, 80}
			p.Custom.Lockpick = 3
		}
		return nil
	})
	scr := make([]Screen, len(ss))
	for i, s := range ss {
		scr[i] = s.Act(Action{Cmd: "main"})
	}
	seen := map[string]bool{}
	for step := 0; step < 6000; step++ {
		i := step % len(ss)
		s, sc := ss[i], scr[i]
		if sc.View == "quit" || sc.View == "gone" {
			s.greeted = false
			scr[i] = s.Act(Action{Cmd: "main"})
			continue
		}
		var a Action
		switch {
		case sc.Input != nil:
			v := "hello there"
			switch sc.Input.Kind {
			case "name":
				v = names[rand.IntN(len(names))][:3]
			case "number":
				v = string(rune('0' + rand.IntN(6)))
			}
			a = Action{Cmd: "input", Value: &v}
			if rand.IntN(10) == 0 {
				a.Value = nil
			}
		case sc.View == "chat" && rand.IntN(10) < 6:
			s.ChatUpdate([]string{"hi", "/?", "/info", "/give mor gold", "/tv off", "/me waves", "/all", "/who", "/yell yo"}[rand.IntN(9)])
			continue
		default:
			if len(sc.Buttons) == 0 {
				t.Fatalf("no buttons on view %s: %+v", sc.View, sc)
			}
			b := sc.Buttons[rand.IntN(len(sc.Buttons))]
			for _, x := range sc.Buttons {
				if x.Cmd == "wait" && rand.IntN(10) < 4 {
					b = x
				}
			}
			if b.Cmd == "quit" && rand.IntN(10) < 9 {
				b = sc.Buttons[0]
			}
			a = b.Action
		}
		seen[a.Cmd+":"+a.Sub] = true
		scr[i] = s.Act(a)
		js, _ := json.Marshal(scr[i])
		if strings.Contains(string(js), "%!") || strings.Contains(string(js), "<nil>") {
			t.Fatalf("bad format in %s", js)
		}
		if step == 3000 {
			g.Store.Tx(func(w *World) error { g.MaintCheck(w, true); return nil })
		}
	}
	if len(seen) < 55 {
		t.Errorf("only %d actions exercised", len(seen))
	}
	t.Logf("%d different actions exercised", len(seen))
}

// TestPvP covers raids, battles, letters, arson and cafe chat between players.
func TestPvP(t *testing.T) {
	g := newTestGame(t)
	a, _ := g.CreatePlayer(NewPlayer{Name: "Attacker", Parlor: "Grim Inc", Male: true, Logon: "att", Password: "x"})
	v, _ := g.CreatePlayer(NewPlayer{Name: "Victim", Parlor: "Soft Rest", Logon: "vic", Password: "x"})
	g.Store.Tx(func(w *World) error {
		p := w.Player(a.ID)
		p.Strength, p.HPMax, p.Plots, p.Coffins = 30, 60, 5, [3]int{0, 0, 20}
		q := w.Player(v.ID)
		q.Exp, q.Coffins = 1000, [3]int{9, 9, 9}
		return nil
	})
	str := func(s string) *string { return &s }
	s := g.NewSession(a.ID, "web")
	s.Act(Action{Cmd: "main"})
	s.Act(Action{Cmd: "main"})
	s.Act(Action{Cmd: "comp"})
	sc := s.Act(Action{Cmd: "comp", Sub: "getname"})
	if sc.Input == nil || sc.Input.Kind != "name" {
		t.Fatal("expected name prompt")
	}
	sc = s.Act(Action{Cmd: "input", Value: str("vic")})
	if !strings.Contains(sc.Text, "Victim") {
		t.Fatal("name lookup failed: " + sc.Text)
	}
	sc = s.Act(Action{Cmd: "namepick", Sub: "yes"})
	if !strings.Contains(sc.Text, "lights are off") {
		t.Fatal("front door: " + sc.Text)
	}
	s.Act(Action{Cmd: "comp", Sub: "try_door"})
	sc = s.Act(Action{Cmd: "comp", Sub: "attack"})
	for n := 0; sc.View == "battle" && len(sc.Buttons) > 0 && sc.Buttons[0].Sub == "attack" && n < 50; n++ {
		sc = s.Act(Action{Cmd: "battle", Sub: "attack"})
	}
	if !strings.Contains(sc.Text, "won the battle") {
		t.Fatal("battle: " + sc.Text)
	}
	sc = s.Act(Action{Cmd: "battle", Sub: sc.Buttons[0].Sub})
	s.Act(Action{Cmd: "input", Value: str("Discount this!")})
	g.View(func(w *World) {
		if !strings.Contains(w.News(w.Glo.GameAge, "crime"), "Discount this!") {
			t.Error("crime news missing")
		}
		if !w.Player(v.ID).Police {
			t.Error("victim should be police protected")
		}
	})
	s2 := g.NewSession(v.ID, "bbs")
	s2.Act(Action{Cmd: "main"})
	m := s2.Act(Action{Cmd: "main"})
	if !strings.Contains(m.Text, "attacked in your sleep") {
		t.Error("victim letter: " + m.Text)
	}
	s2.Disconnect()
	// arson
	g.Store.Tx(func(w *World) error { w.Player(v.ID).Plots = 40; return nil })
	s.Act(Action{Cmd: "arson"})
	s.Act(Action{Cmd: "arson", Sub: "hire"})
	s.Act(Action{Cmd: "input", Value: str("Victim")})
	sc = s.Act(Action{Cmd: "namepick", Sub: "yes"})
	if !strings.Contains(sc.Text, "fire") {
		t.Error("arson: " + sc.Text)
	}
	// letter with reply button
	s.Act(Action{Cmd: "mail_write"})
	s.Act(Action{Cmd: "input", Value: str("Vict")})
	s.Act(Action{Cmd: "namepick", Sub: "yes"})
	s.Act(Action{Cmd: "input", Value: str("Nice fire, huh?")})
	s3 := g.NewSession(v.ID, "web")
	m = s3.Act(Action{Cmd: "main"})
	reply := false
	for i := 0; i < 8 && !reply; i++ {
		for _, b := range m.Buttons {
			reply = reply || b.Label == "Reply"
		}
		if !reply {
			m = s3.Act(Action{Cmd: "main"})
		}
	}
	if !reply {
		t.Error("no reply button on letter")
	}
	// cafe
	s.Act(Action{Cmd: "cafe"})
	s3.Act(Action{Cmd: "cafe"})
	s.ChatUpdate("hello victim")
	s.ChatUpdate("/give vic gold")
	lines := strings.Join(s3.ChatUpdate(""), " / ")
	if !strings.Contains(lines, "hello victim") || !strings.Contains(lines, "gives `wVictim") {
		t.Error("chat: " + lines)
	}
}

package fqnet

// Linking without the web server.
//
// A town doesn't need the web game to be linked. Whichever Funeral Quest program runs the
// network (fq web, fq telnet or fq net) syncs with the linked towns. A town can also link
// without accepting any incoming connections at all ("outbound only", e.g. behind a firewall
// with no port forwarded): every sync answer brings back the other town's players, letters
// for our players, settings votes and its version and settings, and real-time chat comes
// through the listen requests we make. The one thing that needs an open port is being
// raided by players from other towns, since their server has to reach ours.

import (
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"encoding/hex"
	"errors"
	"fmt"
	"math"
	"net"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"funeralquest/engine"
	"funeralquest/guard"
)

// parsePlayers cleans a town's player list.
func parsePlayers(peerID, town string, in []wirePlayer) []engine.RemotePlayer {
	var players []engine.RemotePlayer
	for i, wp := range in {
		if i >= maxPlayers {
			break
		}
		name := engine.CleanRemote(wp.Name, 20, false)
		if name == "" {
			continue
		}
		stt := ""
		if wp.Status == "on now" || wp.Status == "in cafe" {
			stt = wp.Status
		}
		players = append(players, engine.RemotePlayer{Peer: peerID, Town: town, Name: name,
			Parlor: engine.CleanRemote(wp.Parlor, 30, false), Male: wp.Male, Exp: max(0, min(wp.Exp, 2_000_000_000)), Status: stt, Level: max(0, min(wp.Level, engine.MaxLevel))})
	}
	return players
}

// deliverMail puts letters from a linked town into our players' mailboxes. Letters already
// delivered (they can arrive twice, by push and by pull) are acknowledged again but not
// delivered again.
func (n *Net) deliverMail(peerID, town string, mails []wireMail) []mailResult {
	if len(mails) == 0 {
		return nil
	}
	seen := n.load().SeenMail
	cfg := n.cfg()
	var results []mailResult
	newSeen := map[string]int64{}
	err := n.G.Store.Tx(func(w *engine.World) error {
		for i, ml := range mails {
			if i >= maxMail || ml.ID == "" || len(ml.ID) > 64 {
				continue
			}
			key := peerID + "/" + ml.ID
			if _, dup := seen[key]; dup {
				results = append(results, mailResult{ID: ml.ID, OK: true})
				continue
			}
			if cfg.NetMailOff {
				results = append(results, mailResult{ID: ml.ID, Error: cfg.ServerName + " isn't taking letters from other towns"})
				continue
			}
			to := w.ByName(engine.CleanRemote(ml.To, 20, false))
			if to == nil || !to.Active {
				results = append(results, mailResult{ID: ml.ID, Error: "nobody by that name lives in " + cfg.ServerName + " any more"})
				continue
			}
			if w.MailCount(to.ID) > 100 {
				results = append(results, mailResult{ID: ml.ID, Error: to.Name + "'s mailbox is full"})
				continue
			}
			from := engine.CleanRemote(ml.FromName, 20, false)
			parlor := engine.CleanRemote(ml.FromParlor, 30, false)
			text := engine.CleanRemote(ml.Text, maxMailText, true)
			if from == "" || text == "" {
				results = append(results, mailResult{ID: ml.ID, Error: "empty letter"})
				continue
			}
			w.AddMail(engine.Letter{To: to.ID, Pic: "note", NetFrom: engine.NetRef(peerID, from, town),
				Text: fmt.Sprintf("`$You have received a letter from `w%s`$ of %s, in the town of `w%s`$:\n\n%s", from, parlor, town, text)})
			w.AddChat("`5You have mail from out of town waiting at your parlor.", to.ID)
			newSeen[key] = time.Now().Unix()
			results = append(results, mailResult{ID: ml.ID, OK: true})
		}
		return nil
	})
	if err != nil {
		return nil // try again next time
	}
	if len(newSeen) > 0 {
		n.tx(func(st *state) error {
			for k, v := range newSeen {
				st.SeenMail[k] = v
			}
			return nil
		})
	}
	return results
}

// settleMail removes answered letters from the outbox (inside a tx) and returns the ones to
// send back to their writers.
func settleMail(st *state, peerID string, results []mailResult) (bounces []*OutMail) {
	res := map[string]mailResult{}
	for _, r := range results {
		res[r.ID] = r
	}
	var keep []*OutMail
	for _, o := range st.Out {
		r, answered := res[o.ID]
		switch {
		case o.Peer != peerID || !answered:
			if o.Peer == peerID && time.Since(o.Created) > 7*24*time.Hour {
				o.Text = "it could not be delivered for a week"
				bounces = append(bounces, o)
				continue
			}
			keep = append(keep, o)
		case !r.OK:
			o.Text = r.Error
			bounces = append(bounces, o)
		}
	}
	st.Out = keep
	return
}

func (n *Net) sendBounces(town string, bounces []*OutMail) {
	if len(bounces) == 0 {
		return
	}
	n.G.Store.Tx(func(w *engine.World) error {
		for _, b := range bounces {
			if pl := w.Player(b.FromID); pl != nil && pl.Active {
				w.AddMail(engine.Letter{To: pl.ID, Pic: "note", Text: fmt.Sprintf("`$The post office returned your letter to `w%s`$ in %s: %s",
					b.To, town, engine.CleanRemote(b.Text, 200, false))})
			}
		}
		return nil
	})
}

// pullAnswer fills in what a sync answer carries for a town that may not be reachable:
// our players and the letters waiting for its players.
func (n *Net) pullAnswer(peerID string, ans *syncAns) {
	snap, _ := n.snapshot(Peer{ChatSent: math.MaxInt}, nil)
	ans.Players, ans.ChatTop = snap.Players, snap.ChatTop
	if n.cfg().NetMailOff {
		return
	}
	for _, o := range n.load().Out {
		if o.Peer == peerID && len(ans.Deliver) < maxMail {
			ans.Deliver = append(ans.Deliver, wireMail{o.ID, o.To, o.FromName, o.FromParlor, o.Text})
		}
	}
}

// ------------------------------------------------------------------ one network runner

// runLock makes sure only one process (web, telnet or net) runs the sync loop for a town.
// The holder touches the lock file every 10 seconds; a lock not touched for 40 seconds is
// taken over, so the network keeps going if that program stops.
func (n *Net) runLock() bool {
	p := filepath.Join(n.Dir, "runner.lock")
	me := n.runnerID()
	if b, err := os.ReadFile(p); err == nil {
		st, _ := os.Stat(p)
		if strings.TrimSpace(string(b)) != me && st != nil && time.Since(st.ModTime()) < 40*time.Second {
			return false
		}
		if strings.TrimSpace(string(b)) == me {
			now := time.Now()
			os.Chtimes(p, now, now)
			return true
		}
		os.Remove(p)
	}
	f, err := os.OpenFile(p, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0o600)
	if err != nil {
		return false
	}
	f.WriteString(me)
	f.Close()
	return true
}

// runnerID names this program (and this Net, in case one program opens two) in runner.lock.
func (n *Net) runnerID() string {
	n.runOnce.Do(func() {
		b := make([]byte, 4)
		rand.Read(b)
		n.runID = strconv.Itoa(os.Getpid()) + "-" + hex.EncodeToString(b)
	})
	return n.runID
}

func (n *Net) releaseRunLock() {
	p := filepath.Join(n.Dir, "runner.lock")
	if b, err := os.ReadFile(p); err == nil && strings.TrimSpace(string(b)) == n.runnerID() {
		os.Remove(p)
	}
}

// ------------------------------------------------------------------ network-only port

// ServeNetwork answers other Funeral Quest servers on addr: a port just for the network,
// with no web game on it. certFile/keyFile ("" = plain HTTP; messages are signed either way).
func (n *Net) ServeNetwork(addr string, gd *guard.Guard, certFile, keyFile string) error {
	fed := n.Handler(gd)
	h := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		ip, _, _ := net.SplitHostPort(r.RemoteAddr)
		if ok, _ := gd.Check(ip); !ok {
			http.Error(w, "Access denied.", http.StatusForbidden)
			return
		}
		if !strings.HasPrefix(r.URL.Path, "/fed/") {
			http.Error(w, "This is a Funeral Quest network port.", http.StatusNotFound)
			return
		}
		w.Header().Set("X-Content-Type-Options", "nosniff")
		r.Body = http.MaxBytesReader(w, r.Body, maxBody+1024)
		fed.ServeHTTP(w, r)
	})
	hs := &http.Server{Addr: addr, Handler: h, ReadHeaderTimeout: 10 * time.Second, ReadTimeout: 30 * time.Second,
		WriteTimeout: 60 * time.Second, IdleTimeout: 120 * time.Second, MaxHeaderBytes: 16 << 10}
	if certFile != "" && keyFile != "" {
		hs.TLSConfig = &tls.Config{MinVersion: tls.VersionTLS12}
		return hs.ListenAndServeTLS(certFile, keyFile)
	}
	return hs.ListenAndServe()
}

// ------------------------------------------------------------------ HTTPS between towns

// httpsClient connects to a town over HTTPS. A certificate from a known authority is
// accepted as usual. A self-signed one is trusted the first time (its fingerprint is then
// pinned on that town) and must stay the same after that. Messages are signed anyway, so
// this is about keeping letters private on the way, not about who's talking.
func (n *Net) httpsClient(base string, timeout time.Duration, learned *string) *http.Client {
	pin := ""
	for _, p := range n.load().Peers {
		if p.URL == base {
			pin = p.CertPin
		}
	}
	tr := &http.Transport{
		Proxy:             http.ProxyFromEnvironment,
		DisableKeepAlives: true,
		TLSClientConfig: &tls.Config{MinVersion: tls.VersionTLS12, InsecureSkipVerify: true,
			VerifyConnection: func(cs tls.ConnectionState) error {
				if len(cs.PeerCertificates) == 0 {
					return errors.New("no certificate")
				}
				leaf := cs.PeerCertificates[0]
				inter := x509.NewCertPool()
				for _, c := range cs.PeerCertificates[1:] {
					inter.AddCert(c)
				}
				if _, err := leaf.Verify(x509.VerifyOptions{DNSName: cs.ServerName, Intermediates: inter}); err == nil {
					return nil // from a known authority
				}
				sum := sha256.Sum256(leaf.Raw)
				fp := hex.EncodeToString(sum[:])
				switch {
				case pin == "":
					*learned = fp
					return nil
				case fp == pin:
					return nil
				}
				return errors.New("its HTTPS certificate has changed since we linked. If its sysop made a new one, remove the link and link again; otherwise someone may be in between")
			}},
	}
	return &http.Client{Timeout: timeout, Transport: tr,
		CheckRedirect: func(*http.Request, []*http.Request) error { return errors.New("redirects not allowed") }}
}

// rememberPin stores a self-signed certificate's fingerprint on the town that answered.
func (n *Net) rememberPin(id, fp string) {
	if fp == "" || id == "" {
		return
	}
	n.pinMu.Lock()
	n.pins[id] = fp
	n.pinMu.Unlock()
	n.tx(func(st *state) error {
		if p := st.peer(id); p != nil && p.CertPin == "" {
			p.CertPin = fp
		}
		return nil
	})
}

func (n *Net) pendingPin(id string) string {
	n.pinMu.Lock()
	defer n.pinMu.Unlock()
	return n.pins[id]
}

// announce tells linked towns our address when it changes (e.g. after switching to https).
// They accept a new address only if the host name stays the same.
func (n *Net) announce() {
	c := n.cfg()
	pub := n.PublicURL()
	if pub == "" || n.load().Announced == pub {
		return
	}
	for _, p := range n.Peers() {
		if p.State == Linked && p.URL != "" {
			env := newEnvelope(n.ID, p.ID)
			n.post(p.URL, "/fed/hello", p.ID, helloMsg{envelope: env, URL: pub, Name: c.ServerName, rules: n.ourRules()}, env)
		}
	}
	n.tx(func(st *state) error { st.Announced = pub; return nil })
}

func sameHost(a, b string) bool {
	ua, err1 := url.Parse(a)
	ub, err2 := url.Parse(b)
	return err1 == nil && err2 == nil && ua.Hostname() != "" && strings.EqualFold(ua.Hostname(), ub.Hostname())
}

// PublicURL is the address other towns should use for this one: "This server's web
// address", or, with "network port only", the same host on the network port.
func (n *Net) PublicURL() string { return AdvertisedURL(n.cfg()) }

// AdvertisedURL works out PublicURL from the settings.
func AdvertisedURL(c engine.Config) string {
	u := strings.TrimSpace(c.NetPublicURL)
	if !c.NetPortOnly || c.NetPort == 0 || u == "" {
		return u
	}
	pu, err := url.Parse(u)
	if err != nil || pu.Hostname() == "" {
		return u
	}
	scheme := "http"
	if c.NetPortHTTPS && c.WebCert != "" && c.WebKey != "" {
		scheme = "https"
	}
	return scheme + "://" + net.JoinHostPort(pu.Hostname(), strconv.Itoa(c.NetPort))
}

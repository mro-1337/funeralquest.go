package fqnet

import (
	"sort"
	"strings"

	"funeralquest/engine"
)

const maxNews = 50 // stories per sync

// newsFor builds the news part of a sync: our stories newer than since (what the other town
// says it has printed), plus how far we've printed theirs.
func (n *Net) newsFor(since, recv int) newsWire {
	nw := newsWire{NewsRecv: recv}
	n.G.View(func(w *engine.World) {
		nw.NewsTop = w.NextNewsID
		if w.Config.NetNewsOff {
			return
		}
		if since > w.NextNewsID {
			since = 0 // they're ahead of us: our paper started over
		}
		for _, it := range w.NewsLog {
			if it.ID > since && len(nw.News) < maxNews {
				nw.News = append(nw.News, wireNews{it.ID, it.Section, it.Text})
			}
		}
	})
	return nw
}

// deliverNews prints a linked town's stories in our paper, marked with the town's name, and
// returns the newest of their stories we have now. Stories carry numbers, so a story that
// arrives twice (both towns syncing at once) is printed once.
func (n *Net) deliverNews(peerID, town string, nw newsWire) int {
	n.newsMu.Lock()
	defer n.newsMu.Unlock()
	p := n.load().peer(peerID)
	if p == nil || p.State != Linked {
		return 0
	}
	recv := p.NewsRecv
	if nw.NewsTop < recv {
		recv = 0 // their paper started over (game reset)
	}
	if town == "" {
		town = p.Name
	}
	sort.Slice(nw.News, func(i, j int) bool { return nw.News[i].ID < nw.News[j].ID })
	type story struct{ sec, text string }
	var add []story
	for i, it := range nw.News {
		if i >= maxNews || it.ID <= recv {
			continue
		}
		recv = it.ID
		sec := "front"
		if it.Section == "crime" {
			sec = "crime"
		}
		t := engine.CleanRemote(strings.ReplaceAll(it.Text, "\r", ""), 1200, true)
		if strings.TrimSpace(engine.StripCodes(t)) == "" {
			continue
		}
		t = strings.TrimRight(t, "\n")
		add = append(add, story{sec, "`3[" + town + "] " + strings.ReplaceAll(t, "\n", "\r\n") + "\r\n\r\n"})
	}
	if len(add) > 0 && !n.cfg().NetNewsOff {
		n.G.Store.Tx(func(w *engine.World) error {
			for _, s := range add {
				w.AddLocalNews(s.sec, s.text) // not passed on again: every town hears from the source
			}
			return nil
		})
	}
	if recv != p.NewsRecv {
		n.tx(func(st *state) error {
			if pp := st.peer(peerID); pp != nil {
				pp.NewsRecv = recv
			}
			return nil
		})
	}
	return recv
}

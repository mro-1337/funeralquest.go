package fqnet

// Settings votes. A sysop proposes their game settings to every town they're linked to.
// Each of those towns' sysops is asked whether to accept the settings from that town. When
// more than half of all the towns in the vote say yes (the proposing town counts as a yes),
// the vote passes and every town in it switches to those settings - unless its sysop has
// turned off "Apply settings votes that pass".
//
// Every vote is signed with the voting town's own key, and a town only applies a passed vote
// after checking those signatures itself, so the proposing town can't fake the result.
// Proposals, votes and results ride along on the normal syncs, so they retry by themselves.

import (
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"errors"
	"fmt"
	"sort"
	"strings"
	"time"

	"funeralquest/engine"
)

const voteLength = 7 * 24 * time.Hour

// Proposal is a settings vote, as the proposing town or a voting town sees it.
type Proposal struct {
	ID       string            `json:"id"`
	From     string            `json:"from"`      // proposing town's ID
	FromName string            `json:"from_name"` //
	Rules    map[string]string `json:"rules"`
	Voters   []string          `json:"voters"` // town IDs asked to vote (not the proposer)
	Created  time.Time         `json:"created"`
	Expires  time.Time         `json:"expires"`
	Status   string            `json:"status"` // open, passed, failed, expired
	Votes    []Vote            `json:"votes,omitempty"`
	MyVote   string            `json:"my_vote,omitempty"` // on a town that was asked: yes / no
	Applied  bool              `json:"applied,omitempty"`
	Note     string            `json:"note,omitempty"`
}

// Vote is one town's signed answer.
type Vote struct {
	Prop  string `json:"prop"`
	Voter string `json:"voter"`
	Yes   bool   `json:"yes"`
	Sig   string `json:"sig"`
}

func rulesHash(from string, rules map[string]string) string {
	keys := make([]string, 0, len(rules))
	for k := range rules {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	h := sha256.New()
	h.Write([]byte(from + "\n"))
	for _, k := range keys {
		fmt.Fprintf(h, "%s=%s\n", k, rules[k])
	}
	return hex.EncodeToString(h.Sum(nil))
}

func voteBytes(p *Proposal, yes bool) []byte {
	return []byte(fmt.Sprintf("FQVOTE1\n%s\n%s\n%v", p.ID, rulesHash(p.From, p.Rules), yes))
}

func (v Vote) valid(p *Proposal) bool {
	pub, ok := pubFromID(v.Voter)
	if !ok || v.Prop != p.ID {
		return false
	}
	sig, err := base64.StdEncoding.DecodeString(v.Sig)
	if err != nil {
		return false
	}
	return ed25519.Verify(pub, voteBytes(p, v.Yes), sig)
}

// tally counts the valid votes. The proposing town is a yes.
func tally(p *Proposal) (yes, no, total int) {
	total = len(p.Voters) + 1
	yes = 1
	seen := map[string]bool{}
	asked := map[string]bool{}
	for _, v := range p.Voters {
		asked[v] = true
	}
	for _, v := range p.Votes {
		if !asked[v.Voter] || seen[v.Voter] || !v.valid(p) {
			continue
		}
		seen[v.Voter] = true
		if v.Yes {
			yes++
		} else {
			no++
		}
	}
	return
}

func passes(yes, total int) bool { return yes*2 > total }

// ------------------------------------------------------------------ sysop actions

// Propose asks every linked town to accept this town's current game settings.
func (n *Net) Propose() (*Proposal, error) {
	c := n.cfg()
	var voters []string
	for _, p := range n.Peers() {
		if p.State == Linked && p.TheyOK {
			voters = append(voters, p.ID)
		}
	}
	if len(voters) == 0 {
		return nil, errors.New("no linked towns to vote")
	}
	b := make([]byte, 9)
	rand.Read(b)
	now := time.Now()
	prop := &Proposal{ID: hex.EncodeToString(b), From: n.ID, FromName: c.ServerName, Rules: c.Rules(), Voters: voters,
		Created: now, Expires: now.Add(voteLength), Status: "open"}
	err := n.tx(func(st *state) error {
		for _, x := range st.Props {
			if x.From == n.ID && x.Status == "open" {
				x.Status, x.Note = "expired", "replaced by a newer proposal"
			}
		}
		st.Props = append(st.Props, prop)
		return nil
	})
	if err != nil {
		return nil, err
	}
	n.Log("network: proposed this town's game settings to %d linked town(s)", len(voters))
	n.Kick()
	return prop, nil
}

// CastVote answers a proposal from another town.
func (n *Net) CastVote(id string, yes bool) error {
	err := n.tx(func(st *state) error {
		p := st.prop(id)
		if p == nil || p.From == n.ID {
			return errors.New("no such vote")
		}
		if p.Status != "open" {
			return errors.New("that vote is over (" + p.Status + ")")
		}
		v := Vote{Prop: p.ID, Voter: n.ID, Yes: yes, Sig: base64.StdEncoding.EncodeToString(ed25519.Sign(n.key, voteBytes(p, yes)))}
		p.MyVote = map[bool]string{true: "yes", false: "no"}[yes]
		p.Votes = []Vote{v}
		return nil
	})
	if err == nil {
		n.Kick()
	}
	return err
}

// Proposals lists votes, newest first.
func (n *Net) Proposals() []Proposal {
	var out []Proposal
	for _, p := range n.load().Props {
		out = append(out, *p)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Created.After(out[j].Created) })
	return out
}

// Tally reports a proposal's count of yes, no and towns in the vote.
func Tally(p Proposal) (yes, no, total int) { return tally(&p) }

// OpenVotes counts proposals from other towns still waiting for this sysop's answer.
func (n *Net) OpenVotes() int {
	c := 0
	for _, p := range n.view().Props {
		if p.From != n.ID && p.Status == "open" && p.MyVote == "" {
			c++
		}
	}
	return c
}

func (st *state) prop(id string) *Proposal {
	for _, p := range st.Props {
		if p.ID == id {
			return p
		}
	}
	return nil
}

// ------------------------------------------------------------------ over the wire

// voteWire is what one town sends another about votes during a sync.
type voteWire struct {
	Props []Proposal `json:"props,omitempty"` // proposals the sender made that the receiver votes on
	Votes []Vote     `json:"votes,omitempty"` // the sender's votes on proposals the receiver made
}

// outgoingVotes is what we tell peer about votes.
func (n *Net) outgoingVotes(peer string) voteWire {
	var w voteWire
	for _, p := range n.load().Props {
		if p.From == n.ID {
			for _, v := range p.Voters {
				if v == peer && time.Since(p.Expires) < 14*24*time.Hour {
					w.Props = append(w.Props, *p)
				}
			}
		} else if p.From == peer && p.MyVote != "" && p.Status == "open" {
			w.Votes = append(w.Votes, p.Votes...)
		}
	}
	return w
}

// incomingVotes handles what a peer told us about votes.
func (n *Net) incomingVotes(peer, peerName string, in voteWire) {
	var apply map[string]string
	var applyFrom string
	n.tx(func(st *state) error {
		// their proposals to us
		for i, wp := range in.Props {
			if i >= 10 || wp.From != peer || len(wp.ID) > 40 || wp.ID == "" {
				continue
			}
			asked := false
			for _, v := range wp.Voters {
				asked = asked || v == n.ID
			}
			if !asked || len(wp.Voters) > 200 {
				continue
			}
			rules := cleanRules(wp.Rules)
			p := st.prop(wp.ID)
			if p == nil {
				if wp.Status != "open" {
					continue
				}
				p = &Proposal{ID: wp.ID, From: peer, FromName: peerName, Rules: rules, Voters: wp.Voters,
					Created: time.Now(), Expires: time.Now().Add(voteLength), Status: "open"}
				// a newer proposal from the same town replaces an open older one
				for _, x := range st.Props {
					if x.From == peer && x.Status == "open" {
						x.Status, x.Note = "expired", "replaced by a newer proposal"
					}
				}
				st.Props = append(st.Props, p)
				n.Log("network: %s asks this town to accept its game settings (vote %s). Answer in fqedit, /sysop or  fq admin votes", peerName, p.ID)
			}
			if rulesHash(peer, rules) != rulesHash(p.From, p.Rules) {
				continue // the proposal can't change after it was made
			}
			switch wp.Status {
			case "passed":
				if p.Status != "open" {
					continue
				}
				// check the signed votes ourselves
				check := *p
				check.Votes = wp.Votes
				yes, _, total := tally(&check)
				if !passes(yes, total) {
					p.Note = "the proposing town said the vote passed, but the signed votes don't add up"
					continue
				}
				p.Status, p.Votes = "passed", append(p.Votes[:0:0], wp.Votes...)
				if !n.cfg().NetVoteApplyOff {
					p.Applied = true
					apply, applyFrom = p.Rules, peerName
				} else {
					p.Note = "passed, but this town doesn't apply settings votes (setting turned off)"
				}
			case "failed", "expired":
				if p.Status == "open" {
					p.Status = wp.Status
				}
			}
		}
		// votes on our proposals
		for i, v := range in.Votes {
			if i >= 20 || v.Voter != peer {
				continue
			}
			p := st.prop(v.Prop)
			if p == nil || p.From != n.ID || p.Status != "open" || !v.valid(p) {
				continue
			}
			kept := p.Votes[:0]
			for _, x := range p.Votes {
				if x.Voter != v.Voter {
					kept = append(kept, x)
				}
			}
			p.Votes = append(kept, v)
			yes, no, total := tally(p)
			n.Log("network: %s voted %s on your settings (%d yes, %d no of %d towns)", peerName, map[bool]string{true: "yes", false: "no"}[v.Yes], yes, no, total)
			if passes(yes, total) {
				p.Status = "passed"
				p.Applied = true
				apply, applyFrom = p.Rules, "your own proposal"
				n.Log("network: your settings vote passed; linked towns will switch to them")
			} else if !passes(total-no, total) {
				p.Status = "failed"
				n.Log("network: your settings vote failed")
			}
		}
		// time limits
		for _, p := range st.Props {
			if p.Status == "open" && time.Now().After(p.Expires) {
				p.Status = "expired"
			}
		}
		return nil
	})
	if apply != nil {
		kv := map[string]string{}
		for k, v := range apply {
			kv[k] = v
		}
		if err := n.applyRules(kv); err != nil {
			n.Log("network: couldn't apply the settings vote from %s: %v", applyFrom, err)
		} else {
			n.Log("network: applied game settings from the vote (%s)", applyFrom)
		}
	}
}

// applyRules changes our shared game settings (only those).
func (n *Net) applyRules(kv map[string]string) error {
	return n.G.Store.Tx(func(w *engine.World) error {
		c := w.Config
		for _, k := range engine.SharedSettings {
			if v, ok := kv[k]; ok {
				if err := c.Set(k, v); err != nil {
					return err
				}
			}
		}
		w.Config = c
		return nil
	})
}

// VoteSummary is a one-line description of a proposal for lists.
func VoteSummary(me string, p Proposal) string {
	yes, no, total := tally(&p)
	who := p.FromName
	if p.From == me {
		who = "you"
	}
	s := fmt.Sprintf("from %s, %s", who, p.Status)
	if p.From == me {
		s += fmt.Sprintf(" (%d yes, %d no of %d towns)", yes, no, total)
	} else if p.MyVote != "" {
		s += ", you voted " + p.MyVote
	} else if p.Status == "open" {
		s += ", WAITING FOR YOUR VOTE"
	}
	if p.Status == "open" {
		s += ", ends " + p.Expires.Local().Format("Jan 2")
	}
	return strings.TrimSpace(s)
}

package fqnet

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"strconv"
	"strings"
	"time"

	"funeralquest/engine"
	"funeralquest/guard"
)

// Handler answers other Funeral Quest servers at /fed/id, /fed/hello and /fed/sync.
func (n *Net) Handler(gd *guard.Guard) http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /fed/id", func(w http.ResponseWriter, r *http.Request) {
		c := n.cfg()
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]any{"v": Version, "id": n.ID, "name": c.ServerName, "fingerprint": Fingerprint(n.ID)})
	})
	mux.HandleFunc("POST /fed/hello", func(w http.ResponseWriter, r *http.Request) { n.serve(w, r, gd, n.hello) })
	mux.HandleFunc("POST /fed/sync", func(w http.ResponseWriter, r *http.Request) { n.serve(w, r, gd, n.syncIn) })
	mux.HandleFunc("POST /fed/raid", func(w http.ResponseWriter, r *http.Request) { n.serve(w, r, gd, n.raidIn) })
	mux.HandleFunc("POST /fed/jobs", func(w http.ResponseWriter, r *http.Request) {
		n.serve(w, r, gd, func(env envelope, body []byte, ip string) (any, error) { return n.jobsIn(r.Context(), env) })
	})
	mux.HandleFunc("POST /fed/jobdone", func(w http.ResponseWriter, r *http.Request) {
		n.serve(w, r, gd, func(env envelope, body []byte, ip string) (any, error) { return n.jobDoneIn(env, body) })
	})
	mux.HandleFunc("POST /fed/listen", func(w http.ResponseWriter, r *http.Request) {
		n.serve(w, r, gd, func(env envelope, body []byte, ip string) (any, error) { return n.listenIn(r.Context(), env, body) })
	})
	return mux
}

type handlerFn func(env envelope, body []byte, ip string) (any, error)

func (n *Net) serve(w http.ResponseWriter, r *http.Request, gd *guard.Guard, fn handlerFn) {
	ip, _, _ := net.SplitHostPort(r.RemoteAddr)
	body, err := io.ReadAll(io.LimitReader(r.Body, maxBody+1))
	if err != nil || len(body) > maxBody {
		http.Error(w, "too big", http.StatusRequestEntityTooLarge)
		return
	}
	var env envelope
	if json.Unmarshal(body, &env) != nil || env.V != Version {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	path := r.URL.Path
	if !verify(env.From, r.Header.Get("X-FQ-Sig"), []byte("FQNET1"), []byte(path), body) {
		if gd != nil {
			gd.Strike(ip, "bad network signature", 2)
		}
		http.Error(w, "bad signature", http.StatusForbidden)
		return
	}
	if env.From == n.ID {
		http.Error(w, "that's me", http.StatusBadRequest)
		return
	}
	if env.To != n.ID && !(env.To == "" && strings.HasSuffix(path, "/hello")) {
		http.Error(w, "not for this server", http.StatusMisdirectedRequest)
		return
	}
	if err := n.freshNonce(env); err != nil {
		if gd != nil && strings.Contains(err.Error(), "replay") {
			gd.Strike(ip, "replayed network message", 1)
		}
		n.answer(w, path, env, map[string]any{}, err)
		return
	}
	out, err := fn(env, body, ip)
	if out == nil {
		out = map[string]any{}
	}
	n.answer(w, path, env, out, err)
}

// answer sends a signed reply bound to the request's nonce.
func (n *Net) answer(w http.ResponseWriter, path string, req envelope, v any, err error) {
	b, _ := json.Marshal(v)
	var m map[string]any
	json.Unmarshal(b, &m)
	if m == nil {
		m = map[string]any{}
	}
	ae := newEnvelope(n.ID, req.From)
	m["v"], m["from"], m["to"], m["ts"], m["nonce"] = ae.V, ae.From, ae.To, ae.TS, ae.Nonce
	if err != nil {
		m["error"] = err.Error()
	}
	body, _ := json.Marshal(m)
	w.Header().Set("Content-Type", "application/json")
	// an exact length instead of chunked encoding: some proxies, firewalls and antivirus
	// web filters cut chunked answers short
	w.Header().Set("Content-Length", strconv.Itoa(len(body)))
	w.Header().Set("Cache-Control", "no-store, no-transform")
	w.Header().Set("X-FQ-Sig", n.sign([]byte("FQNET1-ANSWER"), []byte(path), []byte(req.Nonce), body))
	w.Write(body)
}

func (n *Net) hello(env envelope, body []byte, ip string) (any, error) {
	var m helloMsg
	if json.Unmarshal(body, &m) != nil {
		return nil, errors.New("bad hello")
	}
	claimed := ""
	if m.URL != "" {
		if u, err := normURL(m.URL); err == nil {
			claimed = u
		}
	}
	name := engine.CleanRemote(m.Name, 30, false)
	if name == "" {
		name = "Unnamed town"
	}
	c := n.cfg()
	var peerState string
	err := n.tx(func(st *state) error {
		p := st.peer(env.From)
		if p != nil && p.State == Blocked {
			return errors.New("not accepted")
		}
		if p == nil {
			pending := 0
			for _, x := range st.Peers {
				if x.State == Pending || x.State == KeyChange {
					pending++
				}
			}
			if pending >= 50 {
				return errors.New("too many link requests waiting here; try again later")
			}
			p = &Peer{ID: env.From, Added: time.Now(), URL: claimed, State: Pending}
			for _, x := range st.Peers {
				if claimed != "" && x.URL == claimed && x.ID != env.From {
					p.State = KeyChange
					p.Note = "A server at this address used to have a different key (" + Fingerprint(x.ID) + "). Check with its sysop before accepting."
				}
			}
			if p.State == Pending && c.NetAutoAccept {
				p.State = Linked
			}
			if by := vouchedBy(st, env.From); by != "" && p.State != KeyChange {
				p.Note = strings.TrimSpace(p.Note + " Introduced by " + by + ".")
				if p.State == Pending && c.NetAcceptIntroduced {
					p.State = Linked
				}
			} else if m.Via != "" {
				if v := st.peer(m.Via); v != nil && v.State == Linked {
					p.Note = strings.TrimSpace(p.Note + " Says it was introduced by " + v.Name + ".")
				}
			}
			if _, gone := st.Forgot[env.From]; gone && p.State == Linked && !c.NetAutoAccept {
				p.State = Pending // you removed this town before: it has to be accepted again by hand
			}
			if p.State != Linked {
				p.Note = strings.TrimSpace(p.Note + " Request came from " + ip + ".")
			}
			st.Peers = append(st.Peers, p)
		}
		p.Name = name
		p.OutOnly = claimed == ""
		switch {
		case p.State != Linked && claimed != "":
			p.URL = claimed // a pending request may correct its address
		case p.State == Linked && claimed != "" && claimed != p.URL && sameHost(claimed, p.URL):
			// a linked town may change scheme or port (say, to https) but not move to another host
			p.URL, p.CertPin = claimed, ""
			n.Log("network: %s's address is now %s", p.Name, claimed)
		}
		if p.State == Linked {
			p.TheyOK = true
		}
		n.noteRules(p, m.GameVer, m.Rules)
		peerState = p.State
		return nil
	})
	if err != nil {
		return nil, err
	}
	if peerState == Linked {
		n.Kick()
	}
	return helloAns{Name: c.ServerName, State: peerState, rules: n.ourRules()}, nil
}

func (n *Net) syncIn(env envelope, body []byte, ip string) (any, error) {
	var m syncMsg
	if json.Unmarshal(body, &m) != nil {
		return nil, errors.New("bad sync")
	}
	n.once.Lock()
	defer n.once.Unlock()
	st := n.load()
	p := st.peer(env.From)
	if p == nil || p.State != Linked {
		return nil, fmt.Errorf("not accepted by %s yet", n.cfg().ServerName)
	}
	town := engine.CleanRemote(m.Town, 30, false)
	if town == "" {
		town = p.Name
	}

	players := parsePlayers(p.ID, town, m.Players)
	// chat and mail go into our world; peers can only add lines and letters, nothing else
	chatAck := n.deliverChatLocked(p.ID, town, m.Chat, m.ChatTop)
	newsRecv := n.deliverNews(p.ID, town, m.newsWire)
	results := n.deliverMail(p.ID, town, m.Mail)
	// their answers for letters we handed them in earlier sync answers
	var bounces []*OutMail
	if len(m.MailAcks) > 0 {
		n.tx(func(st *state) error { bounces = settleMail(st, p.ID, m.MailAcks); return nil })
	}
	n.sendBounces(town, bounces)
	n.tx(func(st *state) error {
		pp := st.peer(env.From)
		if pp == nil {
			return nil
		}
		pp.Name, pp.Day, pp.Players, pp.Online = town, max(0, m.Day), max(0, m.Total), max(0, m.Online)
		pp.LastIn, pp.TheyOK = time.Now(), true
		pp.OutOnly = strings.TrimSpace(m.URL) == ""
		n.noteRules(pp, m.GameVer, m.Rules)
		st.Remote[pp.ID] = players
		n.noteKnown(st, pp.ID, m.Known, n.cfg().NetAcceptIntroduced)
		return nil
	})
	n.incomingVotes(env.From, town, m.Vote)
	ans := syncAns{ChatAck: chatAck, Mail: results, rules: n.ourRules(), Vote: n.outgoingVotes(env.From), Known: n.knownFor(env.From)}
	n.pullAnswer(env.From, &ans)
	ans.newsWire = n.newsFor(m.NewsRecv, newsRecv)
	n.G.View(func(w *engine.World) {
		ans.Town, ans.Day, ans.Total = w.Config.ServerName, w.Glo.GameAge, len(w.Active())
		on := map[int]bool{}
		for _, s := range w.Online() {
			on[s.PlayerID] = true
		}
		ans.Online = len(on)
	})
	return ans, nil
}

// raidIn referees one raid step by a visitor from a linked town. Only our own player is
// changed, by our own rules; the visitor's claimed stats are checked against what their
// town last told us and capped.
func (n *Net) raidIn(env envelope, body []byte, ip string) (any, error) {
	var m raidMsg
	if json.Unmarshal(body, &m) != nil {
		return nil, errors.New("bad raid")
	}
	return n.refereeRaid(env.From, m.Req)
}

// refereeRaid runs one raid step from a linked town (sent to us directly, or fetched by us
// from that town when we can't be reached).
func (n *Net) refereeRaid(from string, req engine.RaidReq) (any, error) {
	st := n.view()
	p := st.peer(from)
	if p == nil || p.State != Linked {
		return nil, fmt.Errorf("not accepted by %s yet", n.cfg().ServerName)
	}
	// the attacker has to be one of their players as of their last sync, and can't claim
	// more BP than that (BP is what a defender who wins gets a share of)
	known := false
	for _, rp := range st.Remote[p.ID] {
		if strings.EqualFold(rp.Name, req.Att.Name) {
			known = true
			req.Att.Exp = min(req.Att.Exp, rp.Exp+rp.Exp/20+500)
			req.Att.Name = rp.Name
		}
	}
	if !known {
		return raidAns{Ans: engine.RaidAns{Refused: "unknown"}}, nil
	}

	n.raidMu.Lock()
	defer n.raidMu.Unlock()
	now := time.Now()
	active := 0
	for id, r := range n.raids {
		if now.Sub(r.Created) > 20*time.Minute {
			delete(n.raids, id)
		} else if r.Peer == p.ID {
			active++
		}
	}
	var rs *engine.RaidState
	busy := false
	switch req.Op {
	case "look", "arson":
		if active >= 30 {
			return raidAns{Ans: engine.RaidAns{Refused: "busy"}}, nil
		}
		b := make([]byte, 12)
		rand.Read(b)
		rs = &engine.RaidState{ID: hex.EncodeToString(b), Peer: p.ID, Town: p.Name, Created: now}
	default:
		rs = n.raids[req.Raid]
		if rs == nil || rs.Peer != p.ID || !strings.EqualFold(rs.Att.Name, req.Att.Name) {
			return raidAns{Ans: engine.RaidAns{Refused: "over"}}, nil
		}
	}
	var ans engine.RaidAns
	err := n.G.Store.Tx(func(w *engine.World) error {
		n.G.MaintCheck(w, false)
		if req.Op == "look" {
			if t := w.ByName(req.Target); t != nil {
				for _, r := range n.raids {
					if r.DefID == t.ID && r.Active() {
						busy = true
					}
				}
			}
		}
		ans = n.G.DefendRaid(w, rs, req, busy)
		return nil
	})
	if err != nil {
		return nil, errors.New("busy, try again")
	}
	if req.Op == "look" && ans.Refused == "" {
		ans.Raid = rs.ID
		n.raids[rs.ID] = rs
		n.Log("network: %s of %s is raiding %s", rs.Att.Name, rs.Town, ans.Name)
	}
	if rs.Done && (rs.Outcome == "" || rs.Yelled) {
		delete(n.raids, rs.ID)
	}
	return raidAns{Ans: ans}, nil
}

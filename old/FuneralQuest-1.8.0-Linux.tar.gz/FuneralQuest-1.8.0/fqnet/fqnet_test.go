package fqnet_test

import (
	"bytes"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"funeralquest/admin"
	"funeralquest/engine"
	"funeralquest/fqnet"
	"funeralquest/web"
)

type town struct {
	a   *admin.Admin
	srv *httptest.Server
}

func copyDir(t *testing.T, src, dst string) {
	os.MkdirAll(dst, 0o755)
	ents, _ := os.ReadDir(src)
	for _, e := range ents {
		b, err := os.ReadFile(filepath.Join(src, e.Name()))
		if err != nil {
			t.Fatal(err)
		}
		os.WriteFile(filepath.Join(dst, e.Name()), b, 0o644)
	}
}

func newTown(t *testing.T, name string) *town {
	home := t.TempDir()
	copyDir(t, "../gamedata", filepath.Join(home, "gamedata"))
	a, err := admin.Open(home, nil)
	if err != nil {
		t.Fatal(err)
	}
	s := web.New(a, filepath.Join(home, "web"), filepath.Join(home, "art"), web.Options{})
	ts := httptest.NewServer(s.Handler())
	t.Cleanup(ts.Close)
	if err := a.SetSettings(map[string]string{"server_name": name, "net_public_url": ts.URL, "ai_players": "0"}); err != nil {
		t.Fatal(err)
	}
	return &town{a, ts}
}

func (tw *town) player(t *testing.T, name string) int {
	p, err := tw.a.G.CreatePlayer(engine.NewPlayer{Name: name, Parlor: name + "'s Parlor", Male: true, Logon: strings.ToLower(name), Password: "secret1"})
	if err != nil {
		t.Fatal(err)
	}
	return p.ID
}

func TestLinkChatMail(t *testing.T) {
	A := newTown(t, "Deathville")
	B := newTown(t, "Gravesend")
	alice := A.player(t, "Alice")
	bob := B.player(t, "Bobby")

	// A links to B; B hasn't accepted, so syncing must be refused
	p, err := A.a.Net.AddPeer(B.srv.URL)
	if err != nil {
		t.Fatal(err)
	}
	if p.Name != "Gravesend" || p.TheyOK {
		t.Fatalf("unexpected peer %+v", p)
	}
	if err := A.a.Net.SyncPeer(p.ID); err == nil || !strings.Contains(err.Error(), "not accepted") {
		t.Fatalf("sync before accept should fail, got %v", err)
	}
	bp := B.a.Net.Peers()
	if len(bp) != 1 || bp[0].State != fqnet.Pending || bp[0].URL != A.srv.URL {
		t.Fatalf("B should have a pending request: %+v", bp)
	}
	if err := B.a.Net.Accept(bp[0].ID); err != nil {
		t.Fatal(err)
	}

	// chat both ways
	A.a.G.Store.Tx(func(w *engine.World) error { w.AddSharedChat("`$Alice: `whello from Deathville"); return nil })
	A.a.G.Store.Tx(func(w *engine.World) error { w.AddChat("private to alice", alice); return nil })
	if err := A.a.Net.SyncPeer(p.ID); err != nil {
		t.Fatal(err)
	}
	B.a.G.Store.Tx(func(w *engine.World) error { w.AddSharedChat("`$Bobby: `whi back \x1b[2J"); return nil })
	if err := B.a.Net.SyncPeer(bp[0].ID); err != nil {
		t.Fatal(err)
	}
	var bChat, aChat []string
	B.a.G.View(func(w *engine.World) {
		for _, l := range w.Chat {
			bChat = append(bChat, l.Text)
		}
	})
	A.a.G.View(func(w *engine.World) {
		for _, l := range w.Chat {
			aChat = append(aChat, l.Text)
		}
	})
	if !contains(bChat, "[Deathville] `$Alice: `whello from Deathville") || contains(bChat, "private") {
		t.Fatalf("B chat wrong: %q", bChat)
	}
	if !contains(aChat, "[Gravesend] `$Bobby: `whi back [2J") || contains(aChat, "\x1b") {
		t.Fatalf("A chat wrong (escape must be stripped): %q", aChat)
	}
	// no echo loop: A's line that came back must not be re-sent
	A.a.Net.SyncPeer(p.ID)
	n := 0
	B.a.G.View(func(w *engine.World) {
		for _, l := range w.Chat {
			if strings.Contains(l.Text, "hello from Deathville") {
				n++
			}
		}
	})
	if n != 1 {
		t.Fatalf("line delivered %d times", n)
	}

	// remote players visible both ways
	if rp := A.a.Net.RemotePlayers(); len(rp) != 1 || rp[0].Name != "Bobby" || rp[0].Town != "Gravesend" {
		t.Fatalf("A remote players: %+v", rp)
	}

	// mail A -> B, then a reply B -> A, and one to nobody (bounces)
	if err := A.a.Net.QueueMail(p.ID, "Bobby", alice, "Alice", "Alice's Parlor", "Got any coffins?"); err != nil {
		t.Fatal(err)
	}
	A.a.Net.QueueMail(p.ID, "Nobody", alice, "Alice", "Alice's Parlor", "hello?")
	if err := A.a.Net.SyncPeer(p.ID); err != nil {
		t.Fatal(err)
	}
	var got *engine.Letter
	B.a.G.Store.Tx(func(w *engine.World) error { got = w.TakeMail(bob); return nil })
	if got == nil || !strings.Contains(got.Text, "Got any coffins?") || !strings.Contains(got.Text, "Deathville") || got.NetFrom == "" {
		t.Fatalf("B didn't get the letter: %+v", got)
	}
	var bounce *engine.Letter
	A.a.G.Store.Tx(func(w *engine.World) error { bounce = w.TakeMail(alice); return nil })
	if bounce == nil || !strings.Contains(bounce.Text, "returned") {
		t.Fatalf("no bounce: %+v", bounce)
	}
	if q := A.a.Net.QueuedMail(); q[p.ID] != 0 {
		t.Fatalf("outbox not emptied: %v", q)
	}
	// the reply address in the letter works
	ref := strings.Split(got.NetFrom, "\t")
	if err := B.a.Net.QueueMail(ref[0], ref[1], bob, "Bobby", "Bobby's Parlor", "Plenty."); err != nil {
		t.Fatal(err)
	}
	B.a.Net.SyncPeer(ref[0])
	var reply *engine.Letter
	A.a.G.Store.Tx(func(w *engine.World) error { reply = w.TakeMail(alice); return nil })
	if reply == nil || !strings.Contains(reply.Text, "Plenty.") {
		t.Fatalf("reply not delivered: %+v", reply)
	}

	// the remote server can't change local players: their data is untouched
	A.a.G.View(func(w *engine.World) {
		pl := w.Player(alice)
		if pl.Name != "Alice" || pl.Money != w.Config.StartingMoney {
			t.Fatalf("local player changed: %+v", pl)
		}
	})
}

func TestForgedAndReplayed(t *testing.T) {
	A := newTown(t, "Deathville")
	B := newTown(t, "Gravesend")
	p, _ := A.a.Net.AddPeer(B.srv.URL)
	B.a.Net.Accept(B.a.Net.Peers()[0].ID)

	// capture a real signed request by proxying one sync through a recorder
	var body []byte
	var sig string
	rec := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		body, _ = io.ReadAll(r.Body)
		sig = r.Header.Get("X-FQ-Sig")
		// pass it on so A is happy
		req, _ := http.NewRequest("POST", B.srv.URL+r.URL.Path, bytes.NewReader(body))
		req.Header = r.Header.Clone()
		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			w.WriteHeader(502)
			return
		}
		for k, v := range resp.Header {
			w.Header()[k] = v
		}
		io.Copy(w, resp.Body)
	}))
	defer rec.Close()
	// point A at the recorder (same server behind it)
	setURL(t, A, p.ID, rec.URL)
	if err := A.a.Net.SyncPeer(p.ID); err != nil {
		t.Fatal(err)
	}
	post := func(b []byte, s string) int {
		req, _ := http.NewRequest("POST", B.srv.URL+"/fed/sync", bytes.NewReader(b))
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("X-FQ-Sig", s)
		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatal(err)
		}
		resp.Body.Close()
		if resp.StatusCode == 200 {
			var m map[string]any
			_ = m
		}
		return resp.StatusCode
	}
	// replay: same signed body again -> refused (signed error answer, but no data accepted)
	var before int
	B.a.G.View(func(w *engine.World) { before = len(w.Chat) })
	code := post(body, sig)
	var after int
	B.a.G.View(func(w *engine.World) { after = len(w.Chat) })
	if after != before {
		t.Fatalf("replay changed data (code %d)", code)
	}
	// tampered: change a byte -> bad signature
	var m map[string]any
	json.Unmarshal(body, &m)
	m["town"] = "Evilville"
	tb, _ := json.Marshal(m)
	if code := post(tb, sig); code != 403 {
		t.Fatalf("tampered body accepted: %d", code)
	}
	// a stranger's hello creates only a pending request
	C := newTown(t, "Strangeburg")
	if _, err := C.a.Net.AddPeer(B.srv.URL); err != nil {
		t.Fatal(err)
	}
	for _, pp := range B.a.Net.Peers() {
		if pp.Name == "Strangeburg" && pp.State != fqnet.Pending {
			t.Fatalf("stranger auto-linked: %+v", pp)
		}
	}
	cp := C.a.Net.Peers()[0]
	if err := C.a.Net.SyncPeer(cp.ID); err == nil {
		t.Fatal("unaccepted stranger could sync")
	}
	_ = time.Second
}

func setURL(t *testing.T, tw *town, id, url string) {
	// test helper: rewrite the stored address directly
	p := filepath.Join(tw.a.Home, "data", "net", "network.json")
	b, _ := os.ReadFile(p)
	var st map[string]any
	json.Unmarshal(b, &st)
	for _, x := range st["peers"].([]any) {
		m := x.(map[string]any)
		if m["id"] == id {
			m["url"] = url
		}
	}
	b, _ = json.Marshal(st)
	os.WriteFile(p, b, 0o600)
	time.Sleep(2100 * time.Millisecond) // view cache
}

func contains(list []string, s string) bool {
	for _, x := range list {
		if strings.Contains(x, s) {
			return true
		}
	}
	return false
}

func sleepMs(ms int) { time.Sleep(time.Duration(ms) * time.Millisecond) }

// setField edits one field of one entry in data/net/network.json (test helper).
func setField(t *testing.T, tw *town, list, id, field string, val any) {
	p := filepath.Join(tw.a.Home, "data", "net", "network.json")
	b, _ := os.ReadFile(p)
	var st map[string]any
	json.Unmarshal(b, &st)
	for _, x := range st[list].([]any) {
		m := x.(map[string]any)
		if m["id"] == id {
			m[field] = val
		}
	}
	b, _ = json.Marshal(st)
	os.WriteFile(p, b, 0o600)
}

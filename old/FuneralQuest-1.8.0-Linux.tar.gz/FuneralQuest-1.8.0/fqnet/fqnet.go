// Package fqnet links Funeral Quest servers together.
//
// Each server has its own Ed25519 key (data/net/identity.json). Its ID is the public key,
// so nobody can pretend to be another server. A sysop links to another server by typing in
// its web address; the other sysop accepts the request (or adds this server too). From then
// on the two servers' web processes swap, every few seconds:
//
//   - a public list of their players (name, parlor, BP, online status) for network rankings
//     and for addressing letters,
//   - public Cafe chat lines,
//   - letters written to a player on the other server.
//
// That is all. A linked server can't read or change anything else: it never gets passwords,
// logons, money, tags or any file, and everything it sends is checked, cleaned and size
// limited before it is stored. Players on each server belong to that server alone.
//
// Every request and every answer is signed and carries a time stamp, a one-time nonce and the
// receiving server's ID, so messages can't be forged, replayed, or replayed to another server.
package fqnet

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"

	"funeralquest/engine"
)

const (
	Version     = 1
	maxBody     = 1 << 20
	maxPlayers  = 500
	maxChat     = 100
	maxMail     = 50
	maxMailText = 2000
	clockSkew   = 5 * time.Minute
)

// Peer states.
const (
	Linked    = "linked"    // we trust this server
	Pending   = "pending"   // it asked to link; waiting for our sysop
	Blocked   = "blocked"   // ignore it
	KeyChange = "keychange" // a server at a known address showed up with a different key
)

type Peer struct {
	ID       string            `json:"id"`
	URL      string            `json:"url"`
	Name     string            `json:"name"`
	State    string            `json:"state"`
	Added    time.Time         `json:"added"`
	LastTry  time.Time         `json:"last_try"`
	LastOK   time.Time         `json:"last_ok"`  // our last successful sync with them
	LastIn   time.Time         `json:"last_in"`  // their last successful sync with us
	LastErr  string            `json:"last_err"` //
	TheyOK   bool              `json:"they_ok"`  // they have accepted us
	ChatSent int               `json:"chat_sent"`
	ChatRecv int               `json:"chat_recv"`
	NewsSent int               `json:"news_sent,omitempty"` // newest of our stories they've confirmed
	NewsRecv int               `json:"news_recv,omitempty"` // newest of their stories we've printed
	Day      int               `json:"day"`
	Players  int               `json:"players"`
	Online   int               `json:"online"`
	Note     string            `json:"note,omitempty"`
	GameVer  string            `json:"game_version,omitempty"` // their game version
	Rules    map[string]string `json:"rules,omitempty"`        // their game settings
	OutOnly  bool              `json:"out_only,omitempty"`     // it says it can't be reached: it connects out only
	CertPin  string            `json:"cert_pin,omitempty"`     // fingerprint of its self-signed HTTPS certificate
	RelayAt  time.Time         `json:"relay_at,omitempty"`     // an outbound-only town last fetched its raid steps from us
}

// Fingerprint is a short, readable form of a server ID that sysops can compare by phone or email.
func Fingerprint(id string) string {
	sum := sha256.Sum256([]byte(id))
	h := strings.ToUpper(hex.EncodeToString(sum[:8]))
	return h[0:4] + "-" + h[4:8] + "-" + h[8:12] + "-" + h[12:16]
}

type OutMail struct {
	ID         string    `json:"id"`
	Peer       string    `json:"peer"`
	To         string    `json:"to"`
	FromID     int       `json:"from_id"`
	FromName   string    `json:"from_name"`
	FromParlor string    `json:"from_parlor"`
	Text       string    `json:"text"`
	Created    time.Time `json:"created"`
	Tries      int       `json:"tries"`
}

type state struct {
	Peers     []*Peer                          `json:"peers"`
	Remote    map[string][]engine.RemotePlayer `json:"remote"`
	Out       []*OutMail                       `json:"out"`
	SeenMail  map[string]int64                 `json:"seen_mail"`           // delivered mail IDs (no double delivery)
	Props     []*Proposal                      `json:"proposals,omitempty"` // settings votes
	Acks      map[string][]mailResult          `json:"acks,omitempty"`      // answers for letters linked towns handed us in their sync answers
	Announced string                           `json:"announced,omitempty"` // our address as last told to linked towns
	KnownBy   map[string][]string              `json:"known_by,omitempty"`  // which towns each linked town says it's linked to
	Intros    map[string]*Intro                `json:"intros,omitempty"`    // introduced towns we haven't linked to yet
	Forgot    map[string]int64                 `json:"forgot,omitempty"`    // towns the sysop removed: introductions don't bring them back
}

type identity struct {
	Seed    string    `json:"seed"`
	Created time.Time `json:"created"`
}

// Net is the network link. Every process (door, telnet, web, fqedit) can open it: they share
// the files in data/net. Only the web server runs the sync loop and answers other servers.
type Net struct {
	G   *engine.Game
	Dir string
	Log func(format string, a ...any)

	key  ed25519.PrivateKey
	ID   string
	mu   sync.Mutex
	once sync.Mutex

	nonceMu sync.Mutex
	nonces  map[string]time.Time

	cacheMu sync.Mutex
	cacheAt time.Time
	cache   *state

	kick   chan struct{}
	client *http.Client

	newsMu sync.Mutex // one batch of stories from a linked town at a time

	raidMu sync.Mutex
	raids  map[string]*engine.RaidState // raids by visitors from linked towns, in progress here

	long  *http.Client // for listen requests, which are held open
	sigMu sync.Mutex
	sig   chan struct{} // closed and replaced whenever a new chat line appears

	watchOnce sync.Once
	runOnce   sync.Once
	runID     string
	pinMu     sync.Mutex
	pins      map[string]string // certificate fingerprints learned this run, by town ID
}

func Open(g *engine.Game, dataDir string) (*Net, error) {
	dir := filepath.Join(dataDir, "net")
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return nil, err
	}
	n := &Net{G: g, Dir: dir, Log: func(string, ...any) {}, nonces: map[string]time.Time{}, kick: make(chan struct{}, 1),
		raids: map[string]*engine.RaidState{}, sig: make(chan struct{}), pins: map[string]string{}}
	n.client = &http.Client{Timeout: 15 * time.Second,
		CheckRedirect: func(*http.Request, []*http.Request) error { return errors.New("redirects not allowed") }}
	n.long = &http.Client{Timeout: listenHold + 15*time.Second,
		CheckRedirect: func(*http.Request, []*http.Request) error { return errors.New("redirects not allowed") }}
	idPath := filepath.Join(dir, "identity.json")
	var id identity
	if b, err := os.ReadFile(idPath); err == nil {
		if json.Unmarshal(b, &id) != nil {
			return nil, errors.New("data/net/identity.json is damaged")
		}
	} else {
		seed := make([]byte, ed25519.SeedSize)
		rand.Read(seed)
		id = identity{Seed: base64.StdEncoding.EncodeToString(seed), Created: time.Now()}
		b, _ := json.MarshalIndent(id, "", " ")
		// O_EXCL: if two processes start at once, only one key is made
		f, err := os.OpenFile(idPath, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0o600)
		if err == nil {
			f.Write(b)
			f.Close()
		} else if b2, err2 := os.ReadFile(idPath); err2 == nil {
			json.Unmarshal(b2, &id)
		}
	}
	seed, err := base64.StdEncoding.DecodeString(id.Seed)
	if err != nil || len(seed) != ed25519.SeedSize {
		return nil, errors.New("data/net/identity.json is damaged")
	}
	n.key = ed25519.NewKeyFromSeed(seed)
	n.ID = base64.RawURLEncoding.EncodeToString(n.key.Public().(ed25519.PublicKey))
	return n, nil
}

func pubFromID(id string) (ed25519.PublicKey, bool) {
	b, err := base64.RawURLEncoding.DecodeString(id)
	if err != nil || len(b) != ed25519.PublicKeySize {
		return nil, false
	}
	return ed25519.PublicKey(b), true
}

// ------------------------------------------------------------------ state file

func (n *Net) lock() (func(), error) {
	p := filepath.Join(n.Dir, "network.lock")
	deadline := time.Now().Add(20 * time.Second)
	for {
		f, err := os.OpenFile(p, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0o600)
		if err == nil {
			f.Close()
			return func() { os.Remove(p) }, nil
		}
		if st, e := os.Stat(p); e == nil && time.Since(st.ModTime()) > 15*time.Second {
			os.Remove(p)
			continue
		}
		if time.Now().After(deadline) {
			return nil, errors.New("network data is locked (data/net/network.lock)")
		}
		time.Sleep(5 * time.Millisecond)
	}
}

func (n *Net) load() *state {
	st := &state{}
	if b, err := os.ReadFile(filepath.Join(n.Dir, "network.json")); err == nil {
		json.Unmarshal(b, st)
	}
	if st.Remote == nil {
		st.Remote = map[string][]engine.RemotePlayer{}
	}
	if st.SeenMail == nil {
		st.SeenMail = map[string]int64{}
	}
	return st
}

func (n *Net) tx(fn func(st *state) error) error {
	n.mu.Lock()
	defer n.mu.Unlock()
	unlock, err := n.lock()
	if err != nil {
		return err
	}
	defer unlock()
	st := n.load()
	if err := fn(st); err != nil {
		return err
	}
	var keepProps []*Proposal
	for _, p := range st.Props {
		if time.Since(p.Expires) < 60*24*time.Hour {
			keepProps = append(keepProps, p)
		}
	}
	st.Props = keepProps
	cut := time.Now().Add(-30 * 24 * time.Hour).Unix()
	for k, t := range st.SeenMail {
		if t < cut {
			delete(st.SeenMail, k)
		}
	}
	b, _ := json.MarshalIndent(st, "", " ")
	tmp := filepath.Join(n.Dir, fmt.Sprintf("network.%d.tmp", os.Getpid()))
	if err := os.WriteFile(tmp, b, 0o600); err != nil {
		return err
	}
	n.cacheMu.Lock()
	n.cache = nil
	n.cacheMu.Unlock()
	return os.Rename(tmp, filepath.Join(n.Dir, "network.json"))
}

// view returns a recent read-only copy (re-read at most every 2 seconds).
func (n *Net) view() *state {
	n.cacheMu.Lock()
	defer n.cacheMu.Unlock()
	if n.cache == nil || time.Since(n.cacheAt) > 2*time.Second {
		n.cache, n.cacheAt = n.load(), time.Now()
	}
	return n.cache
}

func (st *state) peer(id string) *Peer {
	for _, p := range st.Peers {
		if p.ID == id {
			return p
		}
	}
	return nil
}

// ------------------------------------------------------------------ engine.Network

func (n *Net) RemotePlayers() []engine.RemotePlayer {
	st := n.view()
	var out []engine.RemotePlayer
	for _, p := range st.Peers {
		if p.State == Linked {
			out = append(out, st.Remote[p.ID]...)
		}
	}
	return out
}

// Reach describes how well we can connect to a linked town: "" when both sides can reach
// each other, otherwise a short note. A town that connects out only can still chat, write
// letters, vote and raid other towns, but nobody can connect to it, so its players can't be
// visited or raided.
func Reach(p Peer) string {
	reachedLately := !p.LastOK.IsZero() && time.Since(p.LastOK) < 5*time.Minute
	switch {
	case p.State != Linked:
		return ""
	case RelayActive(p):
		return "" // it fetches visits from us, so everything works
	case p.URL == "":
		return "outbound only and not online right now: its players can't be visited until its server fetches again"
	case reachedLately:
		return "" // we got through to it, whatever it says about itself
	case p.OutOnly:
		return "outbound only and not online right now: its players can't be visited until its server fetches again"
	case p.LastErr != "" && !p.LastIn.IsZero() && time.Since(p.LastIn) < 5*time.Minute && p.LastOK.Before(p.LastIn.Add(-2*time.Minute)):
		return "its address doesn't work from here (" + p.URL + "). It still connects to us, but its players can't be visited until it fetches again; its sysop should check This server's web address and the port forwarding"
	}
	return ""
}

func (n *Net) Towns() []engine.Town {
	st := n.view()
	var out []engine.Town
	for _, p := range st.Peers {
		if p.State == Linked && p.TheyOK {
			last := p.LastOK
			if p.LastIn.After(last) {
				last = p.LastIn
			}
			out = append(out, engine.Town{ID: p.ID, Name: p.Name, Day: p.Day, Players: p.Players, Online: p.Online, LastOK: last, OutOnly: Reach(*p) != ""})
		}
	}
	return out
}

func (n *Net) QueueMail(peer, toName string, fromID int, fromName, fromParlor, text string) error {
	if len(text) > maxMailText {
		text = text[:maxMailText]
	}
	b := make([]byte, 12)
	rand.Read(b)
	err := n.tx(func(st *state) error {
		p := st.peer(peer)
		if p == nil || p.State != Linked {
			return errors.New("that town isn't linked any more")
		}
		count := 0
		for _, m := range st.Out {
			if m.Peer == peer {
				count++
			}
		}
		if count > 500 {
			return errors.New("too much mail is waiting for that town already")
		}
		st.Out = append(st.Out, &OutMail{ID: n.ID[:8] + hex.EncodeToString(b), Peer: peer, To: toName, FromID: fromID,
			FromName: fromName, FromParlor: fromParlor, Text: text, Created: time.Now()})
		return nil
	})
	if err == nil {
		n.Kick()
	}
	return err
}

// Kick asks the sync loop to run soon (used when there's mail or chat to send).
func (n *Net) Kick() {
	select {
	case n.kick <- struct{}{}:
	default:
	}
}

// ------------------------------------------------------------------ signing

func (n *Net) sign(parts ...[]byte) string {
	return base64.StdEncoding.EncodeToString(ed25519.Sign(n.key, bytes.Join(parts, []byte("\n"))))
}

func verify(id, sig string, parts ...[]byte) bool {
	pub, ok := pubFromID(id)
	if !ok {
		return false
	}
	s, err := base64.StdEncoding.DecodeString(sig)
	if err != nil {
		return false
	}
	return ed25519.Verify(pub, bytes.Join(parts, []byte("\n")), s)
}

// envelope is the outer part of every request.
type envelope struct {
	V     int    `json:"v"`
	From  string `json:"from"`
	To    string `json:"to"` // receiver's ID ("" only for hello to an unknown server)
	TS    int64  `json:"ts"`
	Nonce string `json:"nonce"`
}

func newEnvelope(from, to string) envelope {
	b := make([]byte, 16)
	rand.Read(b)
	return envelope{V: Version, From: from, To: to, TS: time.Now().Unix(), Nonce: hex.EncodeToString(b)}
}

func (n *Net) freshNonce(e envelope) error {
	t := time.Unix(e.TS, 0)
	if d := time.Since(t); d > clockSkew || d < -clockSkew {
		return errors.New("clock difference too big (check the date and time on both servers)")
	}
	if len(e.Nonce) < 16 || len(e.Nonce) > 64 {
		return errors.New("bad nonce")
	}
	n.nonceMu.Lock()
	defer n.nonceMu.Unlock()
	for k, at := range n.nonces {
		if time.Since(at) > 2*clockSkew {
			delete(n.nonces, k)
		}
	}
	key := e.From + "/" + e.Nonce
	if _, seen := n.nonces[key]; seen {
		return errors.New("replayed message")
	}
	n.nonces[key] = time.Now()
	return nil
}

// ------------------------------------------------------------------ client side

func normURL(raw string) (string, error) {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return "", errors.New("no address given")
	}
	if !strings.Contains(raw, "://") {
		raw = "http://" + raw
	}
	u, err := url.Parse(raw)
	if err != nil || u.Host == "" || (u.Scheme != "http" && u.Scheme != "https") || u.User != nil {
		return "", errors.New("give an address like bbs.example.com:8080 or https://bbs.example.com")
	}
	u.Path = strings.TrimRight(u.Path, "/")
	u.RawQuery, u.Fragment = "", ""
	return u.String(), nil
}

// post sends a signed request and checks the signed answer. Pass expect="" only for hello to
// a server we don't know yet (the answer then tells us its ID).
func (n *Net) post(base, path, expect string, req any, reqEnv envelope) (json.RawMessage, string, error) {
	return n.postWith(n.client, base, path, expect, req, reqEnv)
}

func (n *Net) postWith(client *http.Client, base, path, expect string, req any, reqEnv envelope) (json.RawMessage, string, error) {
	var learned string
	if strings.HasPrefix(base, "https://") {
		client = n.httpsClient(base, client.Timeout, &learned)
	}
	body, _ := json.Marshal(req)
	hr, err := http.NewRequest("POST", base+path, bytes.NewReader(body))
	if err != nil {
		return nil, "", err
	}
	hr.Header.Set("Content-Type", "application/json")
	hr.Header.Set("Cache-Control", "no-transform")
	hr.Header.Set("User-Agent", "FuneralQuest/"+engine.Version)
	hr.Header.Set("X-FQ-Sig", n.sign([]byte("FQNET1"), []byte(path), body))
	resp, err := client.Do(hr)
	if err != nil {
		return nil, "", fmt.Errorf("can't reach %s: %w", base, err)
	}
	defer resp.Body.Close()
	rb, err := io.ReadAll(io.LimitReader(resp.Body, maxBody+1))
	if err != nil && (len(rb) == 0 || !json.Valid(rb)) {
		return nil, "", fmt.Errorf("the answer from %s was cut off after %d bytes (%v). Something between the two servers (a proxy, firewall or antivirus web filter) may be interfering; try  fq admin test-link %s", base, len(rb), err, base)
	}
	// (if the connection dropped right after a complete answer, carry on: the signature
	// check below proves nothing is missing or changed)
	if len(rb) > maxBody {
		return nil, "", fmt.Errorf("%s sent back a big page that isn't a Funeral Quest answer (HTTP %d). Check the address and port: %s/fed/id should show the town's name in a browser", base, resp.StatusCode, base)
	}
	var ans struct {
		envelope
		Error string `json:"error"`
	}
	if json.Unmarshal(rb, &ans) != nil {
		if resp.StatusCode == http.StatusMisdirectedRequest {
			return nil, "", errors.New("that server has a new key (its data was reset or moved). Remove it and link again, after checking with its sysop")
		}
		return nil, "", fmt.Errorf("%s isn't a Funeral Quest server (HTTP %d%s). Check the address and port: %s/fed/id should show the town's name in a browser", base, resp.StatusCode, snippet(rb), base)
	}
	if expect != "" && ans.From != expect {
		return nil, "", errors.New("the other server answered with a different ID than expected")
	}
	if !verify(ans.From, resp.Header.Get("X-FQ-Sig"), []byte("FQNET1-ANSWER"), []byte(path), []byte(reqEnv.Nonce), rb) {
		if ans.Error != "" {
			return nil, ans.From, errors.New(ans.Error)
		}
		return nil, "", errors.New("the other server's answer had a bad signature")
	}
	if ans.To != n.ID {
		return nil, "", errors.New("answer wasn't meant for this server")
	}
	n.rememberPin(ans.From, learned)
	if ans.Error != "" {
		return rb, ans.From, errors.New(ans.Error)
	}
	return rb, ans.From, nil
}

// rules travel with every hello and sync (signed like everything else), so each town knows
// the other's game version and settings and can tell its sysop what differs
type rules struct {
	GameVer string            `json:"game_version"`
	Rules   map[string]string `json:"rules"`
}

func (n *Net) ourRules() rules {
	c := n.cfg()
	return rules{engine.Version, c.Rules()}
}

type helloMsg struct {
	envelope
	URL  string `json:"url"`
	Name string `json:"name"`
	rules
	Via string `json:"via,omitempty"` // the linked town that introduced us (its ID)
}

type helloAns struct {
	envelope
	Name  string `json:"name"`
	State string `json:"state"`
	rules
}

func (n *Net) cfg() engine.Config {
	var c engine.Config
	n.G.View(func(w *engine.World) { c = w.Config })
	return c
}

// snippet shows the start of an unexpected answer, to help tell what answered instead.
func snippet(b []byte) string {
	s := strings.Join(strings.Fields(engine.CleanRemote(string(b[:min(len(b), 400)]), 80, false)), " ")
	if s == "" {
		return ""
	}
	return `: "` + s + `"`
}

// findAddress turns what the sysop typed into the other town's address and checks it's a
// Funeral Quest server. Without http:// or https:// it tries both, since a town may use
// HTTPS (for example with a self-signed certificate).
func (n *Net) findAddress(addr string) (string, error) {
	base, err := normURL(addr)
	if err != nil {
		return "", err
	}
	if strings.Contains(strings.TrimSpace(addr), "://") {
		return base, n.checkAddress(base)
	}
	errHTTP := n.checkAddress(base)
	if errHTTP == nil {
		return base, nil
	}
	secure := "https://" + strings.TrimPrefix(base, "http://")
	if n.checkAddress(secure) == nil {
		return secure, nil
	}
	return "", errHTTP
}

// checkAddress asks addr/fed/id first, so a wrong address gets a clear message.
func (n *Net) checkAddress(base string) error {
	var learned string
	client := n.client
	if strings.HasPrefix(base, "https://") {
		client = n.httpsClient(base, n.client.Timeout, &learned)
	}
	resp, err := client.Get(base + "/fed/id")
	if err != nil {
		return fmt.Errorf("can't reach %s: %w", base, err)
	}
	defer resp.Body.Close()
	b, err := io.ReadAll(io.LimitReader(resp.Body, 64<<10))
	if err != nil {
		return fmt.Errorf("the answer from %s was cut off (%v). Something between the two servers (a proxy, firewall or antivirus web filter) may be interfering", base, err)
	}
	var id struct {
		ID   string `json:"id"`
		Name string `json:"name"`
	}
	if json.Unmarshal(b, &id) != nil || id.ID == "" {
		return fmt.Errorf("%s isn't a Funeral Quest server (HTTP %d%s). Check the address and the port: it's the other town's web port (or network port), e.g. bbs.example.com:8080", base, resp.StatusCode, snippet(b))
	}
	if id.ID == n.ID {
		return errors.New("that address is this server")
	}
	return nil
}

// AddPeer links to the server at addr. It contacts it, learns and pins its ID, and sends our
// link request. The other sysop has to accept it (unless they turned on auto-accept).
func (n *Net) AddPeer(addr string) (*Peer, error) {
	base, err := n.findAddress(addr)
	if err != nil {
		return nil, err
	}
	c := n.cfg()
	env := newEnvelope(n.ID, "")
	rb, from, err := n.post(base, "/fed/hello", "", helloMsg{envelope: env, URL: n.PublicURL(), Name: c.ServerName, rules: n.ourRules()}, env)
	if err != nil {
		return nil, err
	}
	if from == n.ID {
		return nil, errors.New("that address is this server")
	}
	var ans helloAns
	json.Unmarshal(rb, &ans)
	var out Peer
	err = n.tx(func(st *state) error {
		for _, p := range st.Peers {
			if p.URL == base && p.ID != from {
				return fmt.Errorf("%s already belongs to a linked server with a different key (%s). Remove that one first if the other sysop really changed keys", base, Fingerprint(p.ID))
			}
		}
		p := st.peer(from)
		if p == nil {
			p = &Peer{ID: from, Added: time.Now()}
			st.Peers = append(st.Peers, p)
		}
		delete(st.Forgot, from)
		delete(st.Intros, from)
		p.URL, p.Name, p.State, p.Note = base, engine.CleanRemote(ans.Name, 30, false), Linked, ""
		if p.CertPin == "" {
			p.CertPin = n.pendingPin(from)
		}
		p.TheyOK = ans.State == Linked
		n.noteRules(p, ans.GameVer, ans.Rules)
		out = *p
		return nil
	})
	if err != nil {
		return nil, err
	}
	n.Kick()
	return &out, nil
}

// Accept approves a pending link request (or re-trusts a server).
func (n *Net) Accept(id string) error {
	err := n.tx(func(st *state) error {
		p := st.peer(id)
		if p == nil {
			return errors.New("no such server")
		}
		// a town without an address connects out only; it learns it was accepted on its next sync
		p.State, p.Note = Linked, ""
		return nil
	})
	if err == nil {
		// tell them right away
		var p *Peer
		for _, x := range n.Peers() {
			if x.ID == id {
				p = &x
			}
		}
		if p != nil && p.URL != "" {
			c := n.cfg()
			env := newEnvelope(n.ID, id)
			n.post(p.URL, "/fed/hello", id, helloMsg{envelope: env, URL: n.PublicURL(), Name: c.ServerName, rules: n.ourRules()}, env)
		}
		n.Kick()
	}
	return err
}

// Remove forgets a server and everything it sent.
func (n *Net) Remove(id string) error {
	return n.tx(func(st *state) error {
		var keep []*Peer
		for _, p := range st.Peers {
			if p.ID != id {
				keep = append(keep, p)
			}
		}
		st.Peers = keep
		delete(st.Remote, id)
		delete(st.KnownBy, id)
		delete(st.Intros, id)
		if st.Forgot == nil {
			st.Forgot = map[string]int64{}
		}
		st.Forgot[id] = time.Now().Unix()
		var out []*OutMail
		for _, m := range st.Out {
			if m.Peer != id {
				out = append(out, m)
			}
		}
		st.Out = out
		return nil
	})
}

// Block ignores a server from now on.
func (n *Net) Block(id string) error {
	return n.tx(func(st *state) error {
		p := st.peer(id)
		if p == nil {
			return errors.New("no such server")
		}
		p.State = Blocked
		delete(st.Remote, id)
		return nil
	})
}

func (n *Net) Peers() []Peer {
	st := n.load()
	var out []Peer
	for _, p := range st.Peers {
		out = append(out, *p)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Name < out[j].Name })
	return out
}

// QueuedMail counts letters waiting to go out, per server.
func (n *Net) QueuedMail() map[string]int {
	m := map[string]int{}
	for _, o := range n.load().Out {
		m[o.Peer]++
	}
	return m
}

// ------------------------------------------------------------------ sync

type wirePlayer struct {
	Name   string `json:"name"`
	Parlor string `json:"parlor"`
	Male   bool   `json:"male"`
	Exp    int    `json:"exp"`
	Status string `json:"status,omitempty"`
	Level  int    `json:"level,omitempty"`
}

type wireChat struct {
	ID   int    `json:"id"`
	Text string `json:"text"`
}

type wireNews struct {
	ID      int    `json:"id"`
	Section string `json:"section"`
	Text    string `json:"text"`
}

type wireMail struct {
	ID         string `json:"id"`
	To         string `json:"to"`
	FromName   string `json:"from_name"`
	FromParlor string `json:"from_parlor"`
	Text       string `json:"text"`
}

type syncMsg struct {
	envelope
	Town    string       `json:"town"`
	URL     string       `json:"url"`
	Day     int          `json:"day"`
	Total   int          `json:"total"`
	Online  int          `json:"online"`
	ChatTop int          `json:"chat_top"` // our newest chat ID (tells the peer if our chat numbering restarted)
	Players []wirePlayer `json:"players"`
	Chat    []wireChat   `json:"chat"`
	Mail    []wireMail   `json:"mail"`
	rules
	Vote     voteWire     `json:"vote"`
	MailAcks []mailResult `json:"mail_acks,omitempty"` // answers for letters they handed us last time
	Known    []knownTown  `json:"known,omitempty"`     // the other towns we're linked to (introductions)
	newsWire
}

// newsWire carries newspaper stories both ways in every sync: each side sends its own
// stories newer than what the other says it has printed, so towns that can only connect
// out get the news too.
type newsWire struct {
	News     []wireNews `json:"news,omitempty"`
	NewsTop  int        `json:"news_top,omitempty"`  // our newest story ID (a smaller one means our paper started over)
	NewsRecv int        `json:"news_recv,omitempty"` // the newest of your stories we have printed
}

type mailResult struct {
	ID    string `json:"id"`
	OK    bool   `json:"ok"`
	Error string `json:"error,omitempty"`
}

type syncAns struct {
	envelope
	Town    string       `json:"town"`
	Day     int          `json:"day"`
	Total   int          `json:"total"`
	Online  int          `json:"online"`
	ChatAck int          `json:"chat_ack"`
	Mail    []mailResult `json:"mail"`
	rules
	Vote voteWire `json:"vote"`
	// so a town that can't be reached still gets everything by asking
	Players []wirePlayer `json:"players,omitempty"`
	ChatTop int          `json:"chat_top,omitempty"`
	Deliver []wireMail   `json:"deliver,omitempty"` // letters for the asking town's players
	Known   []knownTown  `json:"known,omitempty"`
	newsWire
}

// snapshot builds what we tell a peer about our town.
func (n *Net) snapshot(p Peer, out []*OutMail) (syncMsg, int) {
	var m syncMsg
	lastChat := p.ChatSent
	n.G.View(func(w *engine.World) {
		c := w.Config
		m.Town, m.URL, m.Day, m.ChatTop = c.ServerName, AdvertisedURL(c), w.Glo.GameAge, w.NextChatID
		status := map[int]string{}
		for _, s := range w.Online() {
			status[s.PlayerID] = map[bool]string{true: "in cafe", false: "on now"}[s.Status == "chat"]
		}
		m.Online = len(status)
		ranked := w.Ranked()
		m.Total = len(ranked)
		for i, pl := range ranked {
			if i >= maxPlayers {
				break
			}
			m.Players = append(m.Players, wirePlayer{pl.Name, pl.Parlor, pl.Male, pl.Exp, status[pl.ID], max(1, pl.Level)})
		}
		if !c.NetChatOff {
			for _, l := range w.Chat {
				if l.ID > p.ChatSent && l.Share && l.Net == "" && l.To == 0 && len(m.Chat) < maxChat {
					m.Chat = append(m.Chat, wireChat{l.ID, l.Text})
					lastChat = l.ID
				}
			}
			// nothing new: still move the cursor so old lines are never sent later
			if len(m.Chat) == 0 && w.NextChatID > lastChat {
				lastChat = w.NextChatID
			}
		} else {
			lastChat = w.NextChatID
		}
	})
	for _, o := range out {
		if len(m.Mail) >= maxMail {
			break
		}
		m.Mail = append(m.Mail, wireMail{o.ID, o.To, o.FromName, o.FromParlor, o.Text})
	}
	return m, lastChat
}

// SyncPeer exchanges data with one linked server.
func (n *Net) SyncPeer(id string) error {
	st := n.load()
	pp := st.peer(id)
	if pp == nil || pp.State != Linked || pp.URL == "" {
		return nil
	}
	p := *pp
	var out []*OutMail
	if !n.cfg().NetMailOff {
		for _, o := range st.Out {
			if o.Peer == id {
				out = append(out, o)
			}
		}
	}
	msg, lastChat := n.snapshot(p, out)
	msg.envelope = newEnvelope(n.ID, id)
	msg.rules = n.ourRules()
	msg.Vote = n.outgoingVotes(id)
	msg.MailAcks = st.Acks[id]
	msg.Known = n.knownFor(id)
	msg.newsWire = n.newsFor(p.NewsSent, p.NewsRecv)
	rb, _, err := n.post(p.URL, "/fed/sync", id, msg, msg.envelope)
	var ans syncAns
	if err == nil {
		err = json.Unmarshal(rb, &ans)
	}
	var bounces []*OutMail
	n.tx(func(st *state) error {
		pp := st.peer(id)
		if pp == nil {
			return nil
		}
		pp.LastTry = time.Now()
		if err != nil {
			pp.LastErr = err.Error()
			if strings.Contains(err.Error(), "not accepted") {
				pp.TheyOK = false
			}
			return nil
		}
		pp.LastOK, pp.LastErr, pp.TheyOK = time.Now(), "", true
		if strings.HasPrefix(pp.Note, "Request came from") {
			pp.Note = "" // only useful while the request waited
		}
		if t := engine.CleanRemote(ans.Town, 30, false); t != "" {
			pp.Name = t
		}
		pp.Day, pp.Players, pp.Online = max(0, ans.Day), max(0, ans.Total), max(0, ans.Online)
		n.noteRules(pp, ans.GameVer, ans.Rules)
		pp.ChatSent = lastChat
		bounces = settleMail(st, id, ans.Mail)
		if st.Acks != nil {
			delete(st.Acks, id) // they have our answers now
		}
		if ans.Players != nil || ans.Total == 0 {
			st.Remote[id] = parsePlayers(id, pp.Name, ans.Players)
		}
		n.noteKnown(st, id, ans.Known, n.cfg().NetAcceptIntroduced)
		pp.NewsSent = ans.NewsRecv
		return nil
	})
	if err == nil {
		n.incomingVotes(id, p.Name, ans.Vote)
		n.deliverNews(id, p.Name, ans.newsWire)
		// letters they were holding for our players (works even if they can't reach us)
		if res := n.deliverMail(id, p.Name, ans.Deliver); len(res) > 0 {
			n.tx(func(st *state) error {
				if st.Acks == nil {
					st.Acks = map[string][]mailResult{}
				}
				st.Acks[id] = append(st.Acks[id], res...)
				return nil
			})
			n.Kick()
		}
	}
	n.sendBounces(p.Name, bounces)
	return err
}

// Run is the web server's sync loop: every linked server every 30 seconds, or within a few
// seconds when there's new chat or mail to send.
func (n *Net) Run() {
	// only one program per town does this (web, telnet or net); the others wait in case it stops
	told := false
	for !n.runLock() {
		if !told {
			n.Log("network: another Funeral Quest program on this machine is handling the network; standing by")
			told = true
		}
		time.Sleep(15 * time.Second)
	}
	if told {
		n.Log("network: taking over the network")
	}
	defer n.releaseRunLock()
	n.startWatch()
	n.announce()
	listeners := map[string]context.CancelFunc{}
	fetchers := map[string]context.CancelFunc{}
	last := map[string]time.Time{}
	chatSeen := n.G.Store.ChatSeq()
	tick := time.NewTicker(3 * time.Second)
	defer tick.Stop()
	beat := time.Now()
	for {
		select {
		case <-tick.C:
		case <-n.kick:
		}
		if time.Since(beat) > 10*time.Second {
			n.runLock() // heartbeat
			n.announce()
			n.FollowIntros()
			beat = time.Now()
		}
		// new chat since we last looked? (cheap: chat.seq)
		seq := n.G.Store.ChatSeq()
		newChat := seq != chatSeen
		chatSeen = seq
		mail := n.QueuedMail()
		for id, a := range n.load().Acks {
			mail[id] += len(a)
		}
		// one open listen request per linked town (real-time chat)
		want := map[string]bool{}
		for _, p := range n.Peers() {
			if p.State == Linked && p.TheyOK && p.URL != "" {
				want[p.ID] = true
				if listeners[p.ID] == nil {
					ctx, cancel := context.WithCancel(context.Background())
					listeners[p.ID] = cancel
					go n.listenLoop(ctx, p.ID)
				}
			}
		}
		for id, cancel := range listeners {
			if !want[id] {
				cancel()
				delete(listeners, id)
			}
		}
		// every town fetches its raid steps from the towns it links to, so raids still get in
		// when its address doesn't work from there (or it has none)
		for _, p := range n.Peers() {
			on := p.State == Linked && p.TheyOK && p.URL != ""
			if on && fetchers[p.ID] == nil {
				ctx, cancel := context.WithCancel(context.Background())
				fetchers[p.ID] = cancel
				go n.jobsLoop(ctx, p.ID)
			} else if !on && fetchers[p.ID] != nil {
				fetchers[p.ID]()
				delete(fetchers, p.ID)
			}
		}
		for _, p := range n.Peers() {
			if p.State != Linked || p.URL == "" {
				continue
			}
			due := time.Since(last[p.ID]) > 30*time.Second
			// back off servers that keep failing
			if p.LastErr != "" && time.Since(p.LastTry) < 2*time.Minute {
				due = false
			} else if (newChat || mail[p.ID] > 0) && time.Since(last[p.ID]) > 300*time.Millisecond {
				due = true
			}
			if !due {
				continue
			}
			last[p.ID] = time.Now()
			if err := n.SyncPeer(p.ID); err != nil {
				n.Log("network: %s (%s): %v", p.Name, p.URL, err)
			}
		}
	}
}

// ------------------------------------------------------------------ raids (client side)

type raidMsg struct {
	envelope
	Req engine.RaidReq `json:"req"`
}

type raidAns struct {
	envelope
	Ans engine.RaidAns `json:"ans"`
}

// Raid sends one raid step to a linked town (engine.Network). Raids are short, so they use
// a shorter timeout than syncing.
func (n *Net) Raid(peer string, req engine.RaidReq) (engine.RaidAns, error) {
	st := n.view()
	p := st.peer(peer)
	if p == nil || p.State != Linked {
		return engine.RaidAns{}, errors.New("that town isn't linked any more")
	}
	if !p.TheyOK {
		return engine.RaidAns{}, errors.New(p.Name + " hasn't accepted the link yet")
	}
	if p.URL == "" {
		// we can't reach it, but it fetches its raid steps from us
		if RelayActive(*p) {
			return n.relayRaid(p, req)
		}
		return engine.RaidAns{}, errors.New(p.Name + " doesn't take visitors right now: its server connects out only and isn't online")
	}
	for try := 0; ; try++ {
		msg := raidMsg{newEnvelope(n.ID, peer), req}
		rb, _, err := n.post(p.URL, "/fed/raid", peer, msg, msg.envelope)
		if err != nil {
			if strings.HasPrefix(err.Error(), "can't reach") && RelayActive(*p) {
				return n.relayRaid(p, req) // its address doesn't work from here, but it fetches from us
			}
			return engine.RaidAns{}, err
		}
		var ans raidAns
		if err := json.Unmarshal(rb, &ans); err != nil {
			return engine.RaidAns{}, errors.New("bad answer")
		}
		// they don't know this player yet (new since the last sync): sync now and try again
		if ans.Ans.Refused == "unknown" && try == 0 {
			if n.SyncPeer(peer) == nil {
				continue
			}
		}
		return ans.Ans, nil
	}
}

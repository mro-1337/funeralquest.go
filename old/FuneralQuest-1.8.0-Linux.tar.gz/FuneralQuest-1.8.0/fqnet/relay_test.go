package fqnet_test

import (
	"strings"
	"testing"
	"time"

	"funeralquest/engine"
	"funeralquest/fqnet"
)

// Gravesend can't be reached. It fetches its raid steps from Deathville, so Deathville's
// players can still break in, steal and fight there.
func TestRaidIntoOutboundOnlyTown(t *testing.T) {
	A := newTown(t, "Deathville")
	B := newTown(t, "Gravesend")
	B.a.SetSettings(map[string]string{"net_public_url": ""})
	alice := A.player(t, "Alice")
	bobby := B.player(t, "Bobby")
	A.a.UpdatePlayer(alice, map[string]string{"strength": "40", "exp": "5000"})
	B.a.UpdatePlayer(bobby, map[string]string{"wood": "10", "silver": "10", "gold": "10", "exp": "8000"})

	pa, err := B.a.Net.AddPeer(A.srv.URL)
	if err != nil {
		t.Fatal(err)
	}
	bID := B.a.Net.ID
	A.a.Net.Accept(bID)
	B.a.Net.SyncPeer(pa.ID)
	B.a.Net.SyncPeer(pa.ID)
	go B.a.Net.Run() // fetches raid steps (and chat) from Deathville
	deadline := time.Now().Add(10 * time.Second)
	for !fqnet.RelayActive(peerOf(A, bID)) && time.Now().Before(deadline) {
		time.Sleep(200 * time.Millisecond)
	}
	if !fqnet.RelayActive(peerOf(A, bID)) {
		t.Fatal("Gravesend never started fetching")
	}
	waitView()
	if r := fqnet.Reach(peerOf(A, bID)); r != "" {
		t.Fatalf("a fetching town should be fully usable, got %q", r)
	}

	// break in and steal
	p := visit(t, A, alice)
	if !strings.Contains(p.scr.Text, "lights are off") {
		t.Fatalf("couldn't visit the outbound-only town: %q", p.scr.Text)
	}
	start := time.Now()
	p.press("Try Door")
	p.press("Steal")
	t.Logf("relayed raid step took %v", time.Since(start).Round(time.Millisecond))
	var bb engine.Player
	B.a.G.View(func(w *engine.World) { bb = *w.Player(bobby) })
	taken := 30 - (bb.Coffins[0] + bb.Coffins[1] + bb.Coffins[2])
	var aa engine.Player
	A.a.G.View(func(w *engine.World) { aa = *w.Player(alice) })
	if got := aa.Coffins[0] + aa.Coffins[1] + aa.Coffins[2]; got != taken || taken < 0 || taken > 3 {
		t.Fatalf("tags didn't move consistently: taken %d got %d (%q)", taken, got, p.scr.Text)
	}

	// and a fight to the finish
	A.a.SetSettings(map[string]string{"visits_per_day": "5"})
	p = visit(t, A, alice)
	p.press("Try Door")
	p.press("Attack")
	for i := 0; i < 200 && p.scr.View == "battle" && len(p.scr.Buttons) == 2; i++ {
		p.press("Attack")
	}
	if !strings.Contains(p.scr.Text, "won the battle") && !strings.Contains(p.scr.Text, "unable to get up") {
		t.Fatalf("relayed fight didn't finish: %q", p.scr.Text)
	}
}

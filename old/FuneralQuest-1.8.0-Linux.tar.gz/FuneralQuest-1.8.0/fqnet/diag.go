package fqnet

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"strings"
	"time"
)

// TestLink checks the way to another town step by step and describes what happens, for
// "fq admin test-link". It changes nothing.
func (n *Net) TestLink(addr string, say func(format string, a ...any)) {
	base, err := normURL(addr)
	if err != nil {
		say("Address: %v", err)
		return
	}
	if !strings.Contains(addr, "://") {
		if found, err := n.findAddress(addr); err == nil && found != base {
			say("It answers on HTTPS, so testing %s", found)
			base = found
		}
	}
	u, _ := url.Parse(base)
	port := u.Port()
	if port == "" {
		port = map[string]string{"http": "80", "https": "443"}[u.Scheme]
		say("No port given, so this uses port %s (%s). If their game runs on another port, add it: %s:8080", port, u.Scheme, u.Hostname())
	}
	say("Testing %s", base)

	// 1. name lookup
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	ips, err := net.DefaultResolver.LookupHost(ctx, u.Hostname())
	cancel()
	if err != nil {
		say("1. Name lookup: FAILED: %v", err)
		return
	}
	say("1. Name lookup: %s -> %s", u.Hostname(), strings.Join(ips, ", "))

	// 2. TCP connection
	start := time.Now()
	c, err := net.DialTimeout("tcp", net.JoinHostPort(u.Hostname(), port), 8*time.Second)
	if err != nil {
		say("2. Connect to port %s: FAILED: %v", port, err)
		say("   The port is closed or blocked. Check the port number, that  fq web  is running there, and the firewall / router port forwarding on their side.")
		return
	}
	c.Close()
	say("2. Connect to port %s: OK (%v)", port, time.Since(start).Round(time.Millisecond))

	// 3. GET /fed/id
	var learned string
	client := n.client
	if u.Scheme == "https" {
		client = n.httpsClient(base, n.client.Timeout, &learned)
	}
	resp, err := client.Get(base + "/fed/id")
	if err != nil {
		say("3. Ask for its Funeral Quest ID: FAILED: %v", err)
		if strings.Contains(err.Error(), "HTTP response to HTTPS") {
			say("   It speaks plain HTTP: use http:// instead of https://")
		} else if strings.Contains(err.Error(), "malformed HTTP") {
			say("   Something other than a web server answered (a telnet or RLogin port?). Use their WEB port.")
		}
		return
	}
	b, rerr := io.ReadAll(io.LimitReader(resp.Body, 64<<10))
	resp.Body.Close()
	say("3. Ask for its Funeral Quest ID: HTTP %d, %d bytes, server %q, via %q", resp.StatusCode, len(b), resp.Header.Get("Server"), resp.Header.Get("Via"))
	if rerr != nil {
		say("   The answer was CUT OFF: %v", rerr)
	}
	var id struct {
		ID, Name, Fingerprint string
		V                     int
	}
	if json.Unmarshal(b, &id) != nil || id.ID == "" {
		say("   That's not a Funeral Quest answer%s", snippet(b))
		say("   So something else is answering on that address and port: another website, a router page, or a proxy. Check the port.")
		return
	}
	say("   It's Funeral Quest town %q, fingerprint %s", id.Name, Fingerprint(id.ID))
	if id.ID == n.ID {
		say("   ...and that's THIS server.")
		return
	}

	// 4. a signed POST, as linking does (a hello that its server ignores as unsigned)
	req, _ := http.NewRequest("POST", base+"/fed/hello", strings.NewReader(`{"v":1}`))
	req.Header.Set("Content-Type", "application/json")
	resp, err = client.Do(req)
	if err != nil {
		say("4. Send a network message: FAILED: %v", err)
		say("   Reading works but sending doesn't: something between (proxy, firewall, antivirus web filter) blocks POST requests.")
		return
	}
	b, rerr = io.ReadAll(io.LimitReader(resp.Body, 64<<10))
	resp.Body.Close()
	switch {
	case rerr != nil:
		say("4. Send a network message: the answer was CUT OFF after %d bytes: %v", len(b), rerr)
		say("   Something between the two servers is interfering with the answers (antivirus web shield, proxy, firewall). Try turning off HTTP scanning for fq.exe, or use https:// (Security tab: make a certificate) so nothing in between can read the traffic.")
	case resp.StatusCode == 403 && strings.Contains(string(b), "signature"):
		say("4. Send a network message: OK (it answered, refusing the unsigned test as it should)")
		say("Everything looks fine. If linking still fails, check that the clocks on both computers are right (within 5 minutes) and that both run Funeral Quest 1.3 or later.")
	default:
		say("4. Send a network message: HTTP %d%s", resp.StatusCode, snippet(b))
		say("   Something between changed the answer, or it isn't the Funeral Quest web port.")
	}
}

var _ = fmt.Sprintf

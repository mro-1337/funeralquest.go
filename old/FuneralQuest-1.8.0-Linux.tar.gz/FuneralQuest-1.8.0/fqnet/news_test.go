package fqnet_test

import (
	"strings"
	"testing"

	"funeralquest/engine"
	"funeralquest/fqnet"
)

func TestNetworkNews(t *testing.T) {
	A := newTown(t, "Deathville")
	B := newTown(t, "Gravesend")
	p, err := A.a.Net.AddPeer(B.srv.URL)
	if err != nil {
		t.Fatal(err)
	}
	bp := B.a.Net.Peers()
	if err := B.a.Net.Accept(bp[0].ID); err != nil {
		t.Fatal(err)
	}
	day := func(tw *town) (s string) {
		tw.a.G.View(func(w *engine.World) { s = w.News(w.Glo.GameAge, "front") + w.News(w.Glo.GameAge, "crime") })
		return
	}
	A.a.G.Store.Tx(func(w *engine.World) error {
		w.AddNews("front", "`8Alice of Alice's Parlor makes an announcement:`6\r\nCoffins half off!\r\n\r\n")
		w.AddNews("crime", "`8Alice brutally assaulted Carl!\r\n\r\n")
		w.AddLocalNews("front", "`7LOCAL WEATHER\r\n`^Rain.\r\n\r\n")
		return nil
	})
	B.a.G.Store.Tx(func(w *engine.World) error {
		w.AddNews("front", "`7Bobby makes a perfect sale, the industry is in awe.\r\n\r\n")
		return nil
	})
	// one sync from A carries A's news to B and brings B's back in the answer
	for i := 0; i < 3; i++ {
		if err := A.a.Net.SyncPeer(p.ID); err != nil {
			t.Fatal(err)
		}
	}
	b, a := day(B), day(A)
	if !strings.Contains(b, "`3[Deathville] `8Alice of Alice's Parlor makes an announcement:`6\r\nCoffins half off!") ||
		!strings.Contains(b, "[Deathville] `8Alice brutally assaulted Carl!") {
		t.Fatalf("B's paper: %q", b)
	}
	if strings.Contains(b, "WEATHER") {
		t.Fatalf("local flavor news was shared: %q", b)
	}
	if strings.Count(b, "Coffins half off") != 1 || strings.Count(a, "perfect sale") != 1 {
		t.Fatalf("stories printed more than once:\nA %q\nB %q", a, b)
	}
	if !strings.Contains(a, "[Gravesend] `7Bobby makes a perfect sale") {
		t.Fatalf("A's paper: %q", a)
	}
	// B syncing too doesn't print anything twice, and stories aren't passed back to their town
	B.a.Net.SyncPeer(bp[0].ID)
	if strings.Count(day(B), "Coffins half off") != 1 || strings.Contains(day(A), "[Gravesend] `3[Deathville]") {
		t.Fatalf("echo or duplicate:\nA %q\nB %q", day(A), day(B))
	}
	// news off: nothing more goes out
	if err := A.a.SetSettings(map[string]string{"net_news_off": "true"}); err != nil {
		t.Fatal(err)
	}
	A.a.G.Store.Tx(func(w *engine.World) error { w.AddNews("front", "`7SECRET STORY\r\n\r\n"); return nil })
	A.a.Net.SyncPeer(p.ID)
	if strings.Contains(day(B), "SECRET") {
		t.Fatal("news went out with network news off")
	}
	_ = fqnet.Linked
}

func TestRivalParlorsShowLinkedTowns(t *testing.T) {
	A := newTown(t, "Deathville")
	B := newTown(t, "Gravesend")
	alice := A.player(t, "Alice")
	B.player(t, "Bobby")
	p, err := A.a.Net.AddPeer(B.srv.URL)
	if err != nil {
		t.Fatal(err)
	}
	if err := B.a.Net.Accept(B.a.Net.Peers()[0].ID); err != nil {
		t.Fatal(err)
	}
	if err := A.a.Net.SyncPeer(p.ID); err != nil {
		t.Fatal(err)
	}
	s := A.a.G.NewSession(alice, "web")
	s.Act(engine.Action{Cmd: "main"})
	s.Act(engine.Action{Cmd: "comp"})
	sc := s.Act(engine.Action{Cmd: "comp", Sub: "look"})
	var bob, me bool
	for _, r := range sc.Rows.([]engine.RankRow) {
		bob = bob || (r.Name == "Bobby" && strings.HasPrefix(r.Status, "Gravesend"))
		me = me || (r.Name == "Alice" && strings.HasPrefix(r.Status, "Deathville"))
	}
	if !bob || !me {
		t.Fatalf("rival parlors list: %+v", sc.Rows)
	}
}

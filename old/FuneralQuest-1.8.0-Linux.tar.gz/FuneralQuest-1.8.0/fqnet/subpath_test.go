package fqnet_test

import (
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"funeralquest/engine"
	"funeralquest/fqnet"
	"funeralquest/web"
)

// Like Caddy's  handle_path /funeralquest/*  in front of fq web: the town lives at
// https://example/funeralquest/ and the proxy strips the folder before passing requests on.
func TestTownBehindProxyFolder(t *testing.T) {
	A := newTown(t, "Deathville")
	B := newTown(t, "Tie Studio")
	pub := filepath.Join(B.a.Home, "public")
	os.MkdirAll(filepath.Join(pub, "sysop"), 0o755)
	os.WriteFile(filepath.Join(pub, "index.html"), []byte(`<a href="sysop/">Admin</a>`), 0o644)
	os.WriteFile(filepath.Join(pub, "sysop", "index.html"), []byte("admin"), 0o644)
	h := web.New(B.a, pub, filepath.Join(B.a.Home, "art"), web.Options{}).Handler()
	mux := http.NewServeMux()
	mux.Handle("/funeralquest/", http.StripPrefix("/funeralquest", h))
	proxy := httptest.NewServer(mux)
	defer proxy.Close()
	addr := proxy.URL + "/funeralquest"
	B.a.SetSettings(map[string]string{"net_public_url": addr})

	// the game and admin pages load under the folder
	for _, path := range []string{"/funeralquest/", "/funeralquest/sysop/", "/funeralquest/api/info"} {
		resp, err := http.Get(proxy.URL + path)
		if err != nil || resp.StatusCode != 200 {
			t.Fatalf("%s: %v %v", path, err, resp)
		}
		resp.Body.Close()
	}

	// link by the folder address (with a trailing slash, as people type it)
	p, err := A.a.Net.AddPeer(addr + "/")
	if err != nil {
		t.Fatalf("linking to a town in a folder: %v", err)
	}
	if p.URL != addr {
		t.Fatalf("stored address %q, want %q", p.URL, addr)
	}
	B.a.Net.Accept(A.a.Net.ID)
	if err := A.a.Net.SyncPeer(p.ID); err != nil {
		t.Fatalf("sync through the folder: %v", err)
	}
	// real-time chat through the folder
	go A.a.Net.Run()
	time.Sleep(4 * time.Second)
	B.a.G.Store.Tx(func(w *engine.World) error { w.AddSharedChat("`$Tie: `whello through Caddy"); return nil })
	deadline := time.Now().Add(3 * time.Second)
	for {
		heard := false
		A.a.G.Store.Read(func(w *engine.World) {
			for _, l := range w.Chat {
				heard = heard || strings.Contains(l.Text, "through Caddy")
			}
		})
		if heard {
			break
		}
		if time.Now().After(deadline) {
			t.Fatal("chat didn't come through the folder")
		}
		time.Sleep(30 * time.Millisecond)
	}
	resp, _ := http.Get(addr + "/fed/id")
	b, _ := io.ReadAll(resp.Body)
	if !strings.Contains(string(b), "Tie Studio") {
		t.Fatalf("/fed/id through the folder: %s", b)
	}
}

func TestAdvertisedURL(t *testing.T) {
	c := engine.DefaultConfig()
	c.NetPublicURL = "https://tiestudio.ca/funeralquest"
	if got := fqnet.AdvertisedURL(c); got != c.NetPublicURL {
		t.Fatalf("without port-only: %q", got)
	}
	c.NetPort, c.NetPortOnly = 8090, true
	if got := fqnet.AdvertisedURL(c); got != "http://tiestudio.ca:8090" {
		t.Fatalf("port-only, plain: %q", got)
	}
	c.NetPortHTTPS, c.WebCert, c.WebKey = true, "x.crt", "x.key"
	if got := fqnet.AdvertisedURL(c); got != "https://tiestudio.ca:8090" {
		t.Fatalf("port-only, https: %q", got)
	}
	c.WebCert = ""
	if got := fqnet.AdvertisedURL(c); got != "http://tiestudio.ca:8090" {
		t.Fatalf("https asked but no certificate: %q", got)
	}
}

package fqnet_test

import (
	"strings"
	"testing"
	"time"

	"funeralquest/engine"
	"funeralquest/fqnet"
)

func link(t *testing.T, a, b *town) string {
	p, err := a.a.Net.AddPeer(b.srv.URL)
	if err != nil {
		t.Fatal(err)
	}
	for _, x := range b.a.Net.Peers() {
		if x.ID == a.a.Net.ID {
			b.a.Net.Accept(x.ID)
		}
	}
	a.a.Net.SyncPeer(p.ID)
	return p.ID
}

func peerOf(tw *town, id string) fqnet.Peer {
	for _, p := range tw.a.Net.Peers() {
		if p.ID == id {
			return p
		}
	}
	return fqnet.Peer{}
}

func TestSettingsDiffsAndVersion(t *testing.T) {
	A := newTown(t, "Deathville")
	B := newTown(t, "Gravesend")
	B.a.SetSettings(map[string]string{"turns_per_day": "40", "risk": "70"})
	id := link(t, A, B)
	d := fqnet.RuleDiffs(A.a.Config(), peerOf(A, id))
	if len(d) != 2 {
		t.Fatalf("expected 2 differences, got %+v", d)
	}
	if peerOf(A, id).GameVer != engine.Version || fqnet.VersionNote(peerOf(A, id)) != "" {
		t.Fatalf("version not exchanged: %q", peerOf(A, id).GameVer)
	}
	// B sees the same differences the other way round
	B.a.Net.SyncPeer(A.a.Net.ID)
	if d := fqnet.RuleDiffs(B.a.Config(), peerOf(B, A.a.Net.ID)); len(d) != 2 || d[0].Ours == d[0].Theirs {
		t.Fatalf("B's view: %+v", d)
	}
	// who should update
	p := peerOf(A, id)
	p.GameVer = "1.2.9"
	if !strings.Contains(fqnet.VersionNote(p), "Gravesend's sysop needs to update") {
		t.Fatal(fqnet.VersionNote(p))
	}
	p.GameVer = "1.10.0"
	if !strings.Contains(fqnet.VersionNote(p), "You need to update") {
		t.Fatal(fqnet.VersionNote(p))
	}
	// copy theirs
	if err := A.a.Net.UseTheirs(A.a, id, nil); err != nil {
		t.Fatal(err)
	}
	if c := A.a.Config(); c.TurnsPerDay != 40 || c.Risk != 70 {
		t.Fatalf("use theirs didn't copy: %d %d", c.TurnsPerDay, c.Risk)
	}
}

func TestVoteMajorityAppliesEverywhere(t *testing.T) {
	A := newTown(t, "Deathville")
	B := newTown(t, "Gravesend")
	C := newTown(t, "Boneyard")
	ab := link(t, A, B)
	ac := link(t, A, C)
	A.a.SetSettings(map[string]string{"turns_per_day": "33", "visits_per_day": "4"})
	prop, err := A.a.Net.Propose()
	if err != nil {
		t.Fatal(err)
	}
	A.a.Net.SyncPeer(ab)
	A.a.Net.SyncPeer(ac)
	if B.a.Net.OpenVotes() != 1 || C.a.Net.OpenVotes() != 1 {
		t.Fatalf("towns weren't asked: %d %d", B.a.Net.OpenVotes(), C.a.Net.OpenVotes())
	}
	if err := C.a.Net.CastVote(prop.ID, false); err != nil {
		t.Fatal(err)
	}
	C.a.Net.SyncPeer(A.a.Net.ID)
	if ps := A.a.Net.Proposals(); ps[0].Status != "open" {
		t.Fatalf("one no shouldn't decide it: %s", ps[0].Status)
	}
	B.a.Net.CastVote(prop.ID, true)
	B.a.Net.SyncPeer(A.a.Net.ID)
	if ps := A.a.Net.Proposals(); ps[0].Status != "passed" {
		t.Fatalf("2 of 3 should pass: %s", ps[0].Status)
	}
	// the result reaches both towns on the next sync; C applies it even though it voted no
	A.a.Net.SyncPeer(ab)
	A.a.Net.SyncPeer(ac)
	for _, tw := range []*town{B, C} {
		c := tw.a.Config()
		if c.TurnsPerDay != 33 || c.VisitsPerDay != 4 {
			t.Fatalf("%s didn't switch: turns %d visits %d", c.ServerName, c.TurnsPerDay, c.VisitsPerDay)
		}
	}
}

func TestVoteFailsAndForgery(t *testing.T) {
	A := newTown(t, "Deathville")
	B := newTown(t, "Gravesend")
	ab := link(t, A, B)
	A.a.SetSettings(map[string]string{"turns_per_day": "99"})
	prop, _ := A.a.Net.Propose()
	A.a.Net.SyncPeer(ab)
	B.a.Net.CastVote(prop.ID, false)
	B.a.Net.SyncPeer(A.a.Net.ID)
	if ps := A.a.Net.Proposals(); ps[0].Status != "failed" {
		t.Fatalf("1 of 2 must fail: %s", ps[0].Status)
	}
	A.a.Net.SyncPeer(ab)
	if B.a.Config().TurnsPerDay == 99 {
		t.Fatal("failed vote applied")
	}

	// a town that lies: claims its new proposal passed with no votes. Simulate by writing
	// "passed" straight into A's network file.
	prop2, _ := A.a.Net.Propose()
	A.a.Net.SyncPeer(ab)
	forcePassed(t, A, prop2.ID)
	A.a.Net.SyncPeer(ab)
	if B.a.Config().TurnsPerDay == 99 {
		t.Fatal("forged result applied")
	}
	for _, p := range B.a.Net.Proposals() {
		if p.ID == prop2.ID && !strings.Contains(p.Note, "don't add up") {
			t.Fatalf("forgery not noticed: %+v", p)
		}
	}
}

func forcePassed(t *testing.T, tw *town, id string) {
	setField(t, tw, "proposals", id, "status", "passed")
}

func TestRealtimeChat(t *testing.T) {
	A := newTown(t, "Deathville")
	B := newTown(t, "Gravesend")
	link(t, A, B)
	B.a.Net.SyncPeer(A.a.Net.ID)
	go A.a.Net.Run()
	go B.a.Net.Run()
	time.Sleep(4 * time.Second) // listeners start
	for i := 0; i < 3; i++ {
		start := time.Now()
		A.a.G.Store.Tx(func(w *engine.World) error { w.AddSharedChat("`$Alice: `wping " + string(rune('a'+i))); return nil })
		for {
			got := false
			B.a.G.Store.Read(func(w *engine.World) {
				for _, l := range w.Chat {
					if strings.Contains(l.Text, "ping "+string(rune('a'+i))) {
						got = true
					}
				}
			})
			if got {
				break
			}
			if time.Since(start) > 3*time.Second {
				t.Fatalf("line %d took more than 3 seconds", i)
			}
			time.Sleep(20 * time.Millisecond)
		}
		t.Logf("line %d arrived in %v", i, time.Since(start).Round(time.Millisecond))
		if time.Since(start) > 1500*time.Millisecond {
			t.Fatalf("too slow for real-time chat: %v", time.Since(start))
		}
		time.Sleep(300 * time.Millisecond)
	}
}

package fqnet_test

import (
	"strings"
	"testing"

	"funeralquest/engine"
)

// play drives a player's session like a front end would.
type play struct {
	t   *testing.T
	s   *engine.Session
	scr engine.Screen
}

func (p *play) act(a engine.Action) engine.Screen {
	p.scr = p.s.Act(a)
	return p.scr
}
func (p *play) input(v string) engine.Screen { return p.act(engine.Action{Cmd: "input", Value: &v}) }
func (p *play) press(label string) engine.Screen {
	for _, b := range p.scr.Buttons {
		if strings.EqualFold(b.Label, label) {
			return p.act(b.Action)
		}
	}
	p.t.Fatalf("no %q button; screen: %q buttons %v", label, p.scr.Text, labels(p.scr))
	return p.scr
}
func labels(s engine.Screen) []string {
	var out []string
	for _, b := range s.Buttons {
		out = append(out, b.Label)
	}
	return out
}

func linkedTowns(t *testing.T) (A, B *town, alice, bobby int) {
	A = newTown(t, "Deathville")
	B = newTown(t, "Gravesend")
	alice = A.player(t, "Alice")
	bobby = B.player(t, "Bobby")
	p, err := A.a.Net.AddPeer(B.srv.URL)
	if err != nil {
		t.Fatal(err)
	}
	B.a.Net.Accept(B.a.Net.Peers()[0].ID)
	A.a.Net.SyncPeer(p.ID)
	B.a.Net.SyncPeer(B.a.Net.Peers()[0].ID)
	A.a.Net.SyncPeer(p.ID)
	waitView()
	return
}

func waitView() { sleepMs(2100) }

func get(tw *town, id int) engine.Player {
	var out engine.Player
	tw.a.G.View(func(w *engine.World) { out = *w.Player(id) })
	return out
}

func visit(t *testing.T, A *town, alice int) *play {
	p := &play{t: t, s: A.a.G.NewSession(alice, "web")}
	p.act(engine.Action{Cmd: "comp"})
	p.press("Visit")
	p.input("bob")
	if !strings.Contains(p.scr.Text, "Gravesend") {
		t.Fatalf("remote parlor not offered: %q", p.scr.Text)
	}
	p.press("Yes")
	return p
}

func TestRaidStealAndFight(t *testing.T) {
	A, B, alice, bobby := linkedTowns(t)
	B.a.UpdatePlayer(bobby, map[string]string{"wood": "10", "silver": "10", "gold": "10", "exp": "100000", "plots": "50"})
	A.a.UpdatePlayer(alice, map[string]string{"exp": "50000", "strength": "40", "plots": "0"})
	B.a.Net.SyncPeer(B.a.Net.Peers()[0].ID) // Deathville learns Bobby's new BP
	waitView()

	// 1. break in and steal
	p := visit(t, A, alice)
	if !strings.Contains(p.scr.Text, "lights are off") {
		t.Fatalf("not at the door: %q", p.scr.Text)
	}
	p.press("Try Door")
	p.press("Steal")
	bb, aa := get(B, bobby), get(A, alice)
	taken := 30 - (bb.Coffins[0] + bb.Coffins[1] + bb.Coffins[2])
	got := aa.Coffins[0] + aa.Coffins[1] + aa.Coffins[2]
	if taken != got || taken < 0 || taken > 3 {
		t.Fatalf("tags didn't move consistently: taken %d got %d (%q)", taken, got, p.scr.Text)
	}
	if aa.Fights != 1 {
		t.Fatalf("visit not counted: %d", aa.Fights)
	}
	var letter *engine.Letter
	B.a.G.Store.Tx(func(w *engine.World) error { letter = w.TakeMail(bobby); return nil })
	if letter == nil || !strings.Contains(letter.Text, "Alice of Deathville") {
		t.Fatalf("Bobby wasn't told: %+v", letter)
	}

	// 2. come back and fight to the end
	p = visit(t, A, alice)
	p.press("Try Door")
	p.press("Attack")
	for i := 0; i < 200 && p.scr.View == "battle" && len(p.scr.Buttons) == 2; i++ {
		p.press("Attack")
	}
	if !strings.Contains(p.scr.Text, "won the battle") && !strings.Contains(p.scr.Text, "unable to get up") {
		t.Fatalf("fight didn't finish: %q", p.scr.Text)
	}
	won := strings.Contains(p.scr.Text, "won the battle")
	aa2, bb2 := get(A, alice), get(B, bobby)
	if won {
		if !bb2.Police || bb2.Exp >= bb.Exp || aa2.Exp <= aa.Exp || aa2.Exp-aa.Exp > 2001 {
			t.Fatalf("win not settled right: alice %d->%d bobby %d->%d police %v", aa.Exp, aa2.Exp, bb.Exp, bb2.Exp, bb2.Police)
		}
		p.press("Continue")
		p.input("See you in Deathville!")
	} else {
		if aa2.HP != 0 || aa2.Exp >= aa.Exp || bb2.Exp <= bb.Exp {
			t.Fatalf("loss not settled right")
		}
		p.press("Continue")
		p.input("ow")
	}
	var news string
	B.a.G.View(func(w *engine.World) { news = w.News(w.Glo.GameAge, "crime") })
	if !strings.Contains(news, "Deathville") {
		t.Fatalf("no crime news in Gravesend: %q", news)
	}
	A.a.G.View(func(w *engine.World) { news = w.News(w.Glo.GameAge, "crime") })
	if !strings.Contains(news, "Gravesend") {
		t.Fatalf("no crime news in Deathville: %q", news)
	}
}

func TestRaidLimitsArsonAndCheating(t *testing.T) {
	A, B, alice, bobby := linkedTowns(t)
	A.a.SetSettings(map[string]string{"visits_per_day": "10"})
	B.a.SetSettings(map[string]string{"net_raids_per_day": "2"})
	B.a.UpdatePlayer(bobby, map[string]string{"wood": "7", "plots": "100"})
	A.a.UpdatePlayer(alice, map[string]string{"gold": "20"})

	// arson counts toward Bobby's daily limit
	p := &play{t: t, s: A.a.G.NewSession(alice, "web")}
	p.act(engine.Action{Cmd: "arson"})
	p.press("Hire Twins")
	p.input("bob")
	p.press("Yes")
	if !strings.Contains(p.scr.Text, "fire") && !strings.Contains(p.scr.Text, "smoke") {
		t.Fatalf("arson: %q", p.scr.Text)
	}
	if g := get(A, alice).Coffins[2]; g != 14 {
		t.Fatalf("arson cost not paid: %d gold left", g)
	}
	if bb := get(B, bobby); bb.Plots != 95 || bb.Coffins[0] != 0 {
		t.Fatalf("fire didn't burn: plots %d wood %d", bb.Plots, bb.Coffins[0])
	}
	// second visit allowed, third refused (limit 2)
	p = visit(t, A, alice)
	p.press("Leave")
	p = visit(t, A, alice)
	if !strings.Contains(p.scr.Text, "come back tomorrow") {
		t.Fatalf("daily limit not enforced: %q", p.scr.Text)
	}

	// a cheating town: claims a giant attacker and a name that isn't theirs
	rs := &engine.RaidState{}
	B.a.G.Store.Tx(func(w *engine.World) error {
		w.Player(bobby).NetRaids = 0
		B.a.G.DefendRaid(w, rs, engine.RaidReq{Op: "look", Target: "Bobby", Att: engine.RaidFighter{Name: "Alice", Strength: 1e9, HPMax: 1e9}}, false)
		return nil
	})
	if rs.Att.Strength > 100 || rs.Att.HPMax > 200 {
		t.Fatalf("claimed stats not capped: %+v", rs.Att)
	}
	if _, err := A.a.Net.Raid(A.a.Net.Peers()[0].ID, engine.RaidReq{Op: "look", Target: "Bobby", Att: engine.RaidFighter{Name: "Mallory"}}); err != nil {
		t.Fatal(err)
	} else if a, _ := A.a.Net.Raid(A.a.Net.Peers()[0].ID, engine.RaidReq{Op: "look", Target: "Bobby", Att: engine.RaidFighter{Name: "Mallory"}}); a.Refused != "unknown" {
		t.Fatalf("made-up attacker accepted: %+v", a)
	}
	// a raid step for a raid that doesn't exist
	if a, _ := A.a.Net.Raid(A.a.Net.Peers()[0].ID, engine.RaidReq{Op: "steal", Raid: "nope", Att: engine.RaidFighter{Name: "Alice"}}); a.Refused != "over" {
		t.Fatalf("steal without a raid: %+v", a)
	}
	// sysop switch
	B.a.SetSettings(map[string]string{"net_raids_off": "yes"})
	if a, _ := A.a.Net.Raid(A.a.Net.Peers()[0].ID, engine.RaidReq{Op: "look", Target: "Bobby", Att: engine.RaidFighter{Name: "Alice"}}); a.Refused != "off" {
		t.Fatalf("raids not switched off: %+v", a)
	}
}

func TestRaidLose(t *testing.T) {
	A, B, alice, bobby := linkedTowns(t)
	B.a.UpdatePlayer(bobby, map[string]string{"strength": "30", "hp_max": "40", "plots": "5", "exp": "1000"})
	A.a.UpdatePlayer(alice, map[string]string{"strength": "0", "exp": "20000", "plots": "0"})
	A.a.Net.SyncPeer(A.a.Net.Peers()[0].ID) // Gravesend learns Alice's BP
	waitView()
	before := get(B, bobby).Exp
	p := visit(t, A, alice)
	p.press("Try Door")
	p.press("Attack")
	for i := 0; i < 200 && p.scr.View == "battle" && len(p.scr.Buttons) == 2; i++ {
		p.press("Attack")
	}
	if !strings.Contains(p.scr.Text, "unable to get up") {
		t.Fatalf("expected Alice to lose: %q", p.scr.Text)
	}
	aa, bb := get(A, alice), get(B, bobby)
	if aa.HP != 0 || aa.Exp != 20000-100 {
		t.Fatalf("Alice's loss: hp %d exp %d", aa.HP, aa.Exp)
	}
	if bb.Exp != before+200 {
		t.Fatalf("Bobby should win 1%% of Alice's BP: %d -> %d", before, bb.Exp)
	}
	p.press("Continue")
	p.input("I'll be back")
	if p.scr.View == "battle" {
		t.Fatalf("should be in the hospital: %q", p.scr.Text)
	}
}

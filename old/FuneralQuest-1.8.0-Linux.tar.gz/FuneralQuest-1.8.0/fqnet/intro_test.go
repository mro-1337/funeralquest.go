package fqnet_test

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"

	"funeralquest/fqnet"
)

func linkedBoth(a, b *town) bool {
	pa, pb := peerOf(a, b.a.Net.ID), peerOf(b, a.a.Net.ID)
	return pa.State == fqnet.Linked && pb.State == fqnet.Linked
}

// Deathville–Gravesend and Gravesend–Boneyard are linked. Introductions should link
// Deathville and Boneyard by themselves.
func TestIntroductionsFillTheMesh(t *testing.T) {
	A := newTown(t, "Deathville")
	B := newTown(t, "Gravesend")
	C := newTown(t, "Boneyard")
	link(t, A, B)
	link(t, B, C)
	round := func() {
		for _, tw := range []*town{A, B, C} {
			for _, p := range tw.a.Net.Peers() {
				tw.a.Net.SyncPeer(p.ID)
			}
		}
		for _, tw := range []*town{A, B, C} {
			tw.a.Net.FollowIntros()
		}
	}
	for i := 0; i < 3 && !linkedBoth(A, C); i++ {
		round()
	}
	if !linkedBoth(A, C) {
		t.Fatalf("Deathville and Boneyard didn't link: A sees %+v, C sees %+v", peerOf(A, C.a.Net.ID), peerOf(C, A.a.Net.ID))
	}
	round()
	if err := A.a.Net.SyncPeer(C.a.Net.ID); err != nil {
		t.Fatalf("new link doesn't sync: %v", err)
	}
	if p := peerOf(A, C.a.Net.ID); !p.TheyOK {
		t.Fatal("Boneyard hasn't accepted Deathville")
	}

	// a town removed by hand isn't brought back by introductions
	A.a.Net.Remove(C.a.Net.ID)
	round()
	round()
	if p := peerOf(A, C.a.Net.ID); p.State == fqnet.Linked {
		t.Fatal("introductions brought back a town the sysop removed")
	}
}

// A town that doesn't follow introductions isn't linked behind its sysop's back.
func TestIntroductionsOff(t *testing.T) {
	A := newTown(t, "Deathville")
	B := newTown(t, "Gravesend")
	C := newTown(t, "Boneyard")
	A.a.SetSettings(map[string]string{"net_intro_off": "yes"})
	C.a.SetSettings(map[string]string{"net_intro_off": "yes"})
	link(t, A, B)
	link(t, B, C)
	for i := 0; i < 3; i++ {
		for _, tw := range []*town{A, B, C} {
			for _, p := range tw.a.Net.Peers() {
				tw.a.Net.SyncPeer(p.ID)
			}
			tw.a.Net.FollowIntros()
		}
	}
	if peerOf(A, C.a.Net.ID).ID != "" || peerOf(C, A.a.Net.ID).ID != "" {
		t.Fatal("towns that don't follow introductions got linked")
	}
}

// An introduction pairing Boneyard's ID with Mallory's address must not link to Mallory.
func TestForgedIntroduction(t *testing.T) {
	A := newTown(t, "Deathville")
	C := newTown(t, "Boneyard")
	M := newTown(t, "Mallory")
	p := filepath.Join(A.a.Home, "data", "net", "network.json")
	b, _ := os.ReadFile(p)
	st := map[string]any{}
	json.Unmarshal(b, &st)
	st["intros"] = map[string]any{C.a.Net.ID: map[string]any{"url": M.srv.URL, "name": "Boneyard", "by": "x"}}
	b, _ = json.Marshal(st)
	os.WriteFile(p, b, 0o600)
	A.a.Net.FollowIntros()
	for _, x := range A.a.Net.Peers() {
		if x.URL == M.srv.URL || x.ID == M.a.Net.ID {
			t.Fatalf("linked to an impostor: %+v", x)
		}
	}
}

// Package guard keeps unwanted callers out: block list files for IP addresses and host
// names, an allow list that is never blocked, and temporary bans for addresses that keep
// attacking (failed logons, connection floods, bot user names, bad network signatures).
//
// Files, all in the data folder (created with instructions the first time):
//
//	blocklist_ip.txt     one IP or CIDR range per line (1.2.3.4, 10.0.0.0/8, 2001:db8::/32)
//	blocklist_hosts.txt  one host name per line, * wildcards allowed (*.badisp.net)
//	allowlist_ip.txt     IPs/ranges that are never blocked or banned (put your own here)
//	tempbans.json        temporary bans (shared by the door, telnet and web processes)
//
// The text files are re-read automatically when they change; no restart needed.
package guard

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"net/netip"
	"os"
	"path"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"
)

// Settings controls temporary bans.
type Settings struct {
	StrikeLimit   int           // strikes inside StrikeWindow that cause a ban
	StrikeWindow  time.Duration //
	BanTime       time.Duration // first ban; doubles for each repeat ban, up to MaxBan
	MaxBan        time.Duration //
	ConnPerMinute int           // more new connections than this per minute from one address = ban
	MaxPerIP      int           // simultaneous connections allowed from one address
}

func DefaultSettings() Settings {
	return Settings{StrikeLimit: 5, StrikeWindow: 10 * time.Minute, BanTime: 30 * time.Minute,
		MaxBan: 7 * 24 * time.Hour, ConnPerMinute: 8, MaxPerIP: 3}
}

// Ban is one temporary ban.
type Ban struct {
	IP      string    `json:"ip"`
	Until   time.Time `json:"until"`
	Reason  string    `json:"reason"`
	Count   int       `json:"count"` // how many times this address has been banned
	Created time.Time `json:"created"`
}

type listFile struct {
	path    string
	mod     time.Time
	size    int64
	checked time.Time
}

type Guard struct {
	Dir string
	S   Settings
	Log func(format string, a ...any)

	mu       sync.Mutex
	blockF   listFile
	hostF    listFile
	allowF   listFile
	banF     listFile
	blockIPs []netip.Prefix
	allowIPs []netip.Prefix
	hostPats []string     // wildcard patterns, matched against reverse DNS
	hostIPs  []netip.Addr // exact host names resolved to addresses
	hostsAt  time.Time
	bans     map[string]*Ban
	strikes  map[string][]time.Time
	conns    map[string][]time.Time
	open     map[string]int
	ptr      map[string]ptrEntry
}

type ptrEntry struct {
	names []string
	at    time.Time
}

func New(dataDir string) *Guard {
	g := &Guard{Dir: dataDir, S: DefaultSettings(), Log: func(string, ...any) {},
		bans: map[string]*Ban{}, strikes: map[string][]time.Time{}, conns: map[string][]time.Time{},
		open: map[string]int{}, ptr: map[string]ptrEntry{}}
	g.blockF.path = filepath.Join(dataDir, "blocklist_ip.txt")
	g.hostF.path = filepath.Join(dataDir, "blocklist_hosts.txt")
	g.allowF.path = filepath.Join(dataDir, "allowlist_ip.txt")
	g.banF.path = filepath.Join(dataDir, "tempbans.json")
	os.MkdirAll(dataDir, 0o755)
	writeIfMissing(g.blockF.path, ipTemplate)
	writeIfMissing(g.hostF.path, hostTemplate)
	writeIfMissing(g.allowF.path, allowTemplate)
	return g
}

const ipTemplate = `# Funeral Quest IP block list.
# One address or range per line. Lines starting with # are comments.
# Blocked addresses can't use the telnet server, the web game, the sysop pages
# or link their Funeral Quest server to yours. Changes take effect within seconds.
#
# 203.0.113.7
# 198.51.100.0/24
# 2001:db8::/32
`

const hostTemplate = `# Funeral Quest host name block list.
# One host name per line; * matches anything. Lines starting with # are comments.
# A caller is blocked if the reverse DNS name of their address matches a pattern,
# or if their address is one that a plain host name (no *) resolves to.
#
# *.badisp.example
# scanner.example.net
`

const allowTemplate = `# Funeral Quest allow list.
# Addresses and ranges here are never blocked or temporarily banned.
# Put your own address and your LAN here so you can't lock yourself out.
127.0.0.1
::1
`

func writeIfMissing(p, s string) {
	if _, err := os.Stat(p); os.IsNotExist(err) {
		os.WriteFile(p, []byte(strings.ReplaceAll(s, "\n", "\r\n")), 0o644)
	}
}

// changed reports whether a watched file is new or modified (checked at most every 3 seconds).
func (f *listFile) changed() bool {
	if time.Since(f.checked) < 3*time.Second {
		return false
	}
	f.checked = time.Now()
	st, err := os.Stat(f.path)
	if err != nil {
		if f.size != -1 {
			f.size, f.mod = -1, time.Time{}
			return true
		}
		return false
	}
	if st.ModTime().Equal(f.mod) && st.Size() == f.size {
		return false
	}
	f.mod, f.size = st.ModTime(), st.Size()
	return true
}

// ParsePrefixes reads IPs and CIDR ranges, one per line; bad lines are reported.
func ParsePrefixes(text string) (out []netip.Prefix, bad []string) {
	for _, line := range strings.Split(text, "\n") {
		line = strings.TrimSpace(line)
		if i := strings.IndexAny(line, "#;"); i >= 0 {
			line = strings.TrimSpace(line[:i])
		}
		if line == "" {
			continue
		}
		if p, err := netip.ParsePrefix(line); err == nil {
			out = append(out, p.Masked())
		} else if a, err := netip.ParseAddr(line); err == nil {
			a = a.Unmap()
			out = append(out, netip.PrefixFrom(a, a.BitLen()))
		} else {
			bad = append(bad, line)
		}
	}
	return
}

func readLines(p string) []string {
	b, _ := os.ReadFile(p)
	var out []string
	for _, line := range strings.Split(string(b), "\n") {
		line = strings.TrimSpace(line)
		if i := strings.Index(line, "#"); i >= 0 {
			line = strings.TrimSpace(line[:i])
		}
		if line != "" {
			out = append(out, strings.ToLower(line))
		}
	}
	return out
}

func (g *Guard) refresh() {
	if g.blockF.changed() {
		b, _ := os.ReadFile(g.blockF.path)
		var bad []string
		g.blockIPs, bad = ParsePrefixes(string(b))
		for _, l := range bad {
			g.Log("blocklist_ip.txt: can't understand %q", l)
		}
	}
	if g.allowF.changed() {
		b, _ := os.ReadFile(g.allowF.path)
		g.allowIPs, _ = ParsePrefixes(string(b))
	}
	if g.hostF.changed() || time.Since(g.hostsAt) > 10*time.Minute {
		g.hostsAt = time.Now()
		g.hostPats = readLines(g.hostF.path)
		var exact []string
		for _, h := range g.hostPats {
			if !strings.ContainsAny(h, "*?[") {
				exact = append(exact, h)
			}
		}
		go g.resolveHosts(exact)
	}
	if g.banF.changed() {
		g.loadBans()
	}
}

func (g *Guard) resolveHosts(names []string) {
	var ips []netip.Addr
	for _, n := range names {
		ctx, cancel := context.WithTimeout(context.Background(), 4*time.Second)
		addrs, err := net.DefaultResolver.LookupNetIP(ctx, "ip", n)
		cancel()
		if err == nil {
			for _, a := range addrs {
				ips = append(ips, a.Unmap())
			}
		}
	}
	g.mu.Lock()
	g.hostIPs = ips
	g.mu.Unlock()
}

func inList(a netip.Addr, list []netip.Prefix) bool {
	for _, p := range list {
		if p.Contains(a) {
			return true
		}
	}
	return false
}

// ParseIP accepts "1.2.3.4", "1.2.3.4:5678" or "[::1]:80".
func ParseIP(s string) (netip.Addr, error) {
	if ap, err := netip.ParseAddrPort(s); err == nil {
		return ap.Addr().Unmap(), nil
	}
	a, err := netip.ParseAddr(strings.Trim(s, "[]"))
	return a.Unmap(), err
}

// Allowed reports whether ip is on the allow list.
func (g *Guard) Allowed(ip string) bool {
	a, err := ParseIP(ip)
	if err != nil {
		return false
	}
	g.mu.Lock()
	defer g.mu.Unlock()
	g.refresh()
	return inList(a, g.allowIPs)
}

// Check says whether an address may connect. It looks at the allow list, the IP block list,
// temporary bans and (with a short DNS lookup) the host name block list.
func (g *Guard) Check(ip string) (ok bool, why string) {
	a, err := ParseIP(ip)
	if err != nil {
		return false, "bad address"
	}
	key := a.String()
	g.mu.Lock()
	g.refresh()
	if inList(a, g.allowIPs) {
		g.mu.Unlock()
		return true, ""
	}
	if inList(a, g.blockIPs) {
		g.mu.Unlock()
		return false, "address is on the block list"
	}
	if b := g.bans[key]; b != nil && time.Now().Before(b.Until) {
		g.mu.Unlock()
		return false, "temporarily banned until " + b.Until.Local().Format("Jan 2 15:04") + " (" + b.Reason + ")"
	}
	for _, h := range g.hostIPs {
		if h == a {
			g.mu.Unlock()
			return false, "host is on the block list"
		}
	}
	var pats []string
	for _, p := range g.hostPats {
		if strings.ContainsAny(p, "*?[") {
			pats = append(pats, p)
		}
	}
	g.mu.Unlock()
	if len(pats) > 0 {
		for _, n := range g.reverse(key) {
			for _, p := range pats {
				if m, _ := path.Match(p, n); m {
					return false, "host " + n + " is on the block list"
				}
			}
		}
	}
	return true, ""
}

func (g *Guard) reverse(ip string) []string {
	g.mu.Lock()
	if e, ok := g.ptr[ip]; ok && time.Since(e.at) < 30*time.Minute {
		g.mu.Unlock()
		return e.names
	}
	g.mu.Unlock()
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	names, _ := net.DefaultResolver.LookupAddr(ctx, ip)
	cancel()
	for i := range names {
		names[i] = strings.ToLower(strings.TrimSuffix(names[i], "."))
	}
	g.mu.Lock()
	if len(g.ptr) > 5000 {
		g.ptr = map[string]ptrEntry{}
	}
	g.ptr[ip] = ptrEntry{names, time.Now()}
	g.mu.Unlock()
	return names
}

// Connect records a new connection. It returns a release func to call when the connection
// ends, or ok=false (and bans the address) if it is flooding.
func (g *Guard) Connect(ip string) (release func(), ok bool, why string) {
	if ok, why := g.Check(ip); !ok {
		return nil, false, why
	}
	a, _ := ParseIP(ip)
	key := a.String()
	g.mu.Lock()
	allowed := inList(a, g.allowIPs)
	now := time.Now()
	var keep []time.Time
	for _, t := range g.conns[key] {
		if now.Sub(t) < time.Minute {
			keep = append(keep, t)
		}
	}
	keep = append(keep, now)
	g.conns[key] = keep
	flood := len(keep) > g.S.ConnPerMinute
	tooMany := g.open[key] >= g.S.MaxPerIP
	if !allowed && (flood || tooMany) {
		g.mu.Unlock()
		if flood {
			g.Ban(key, "connection flood", 0)
			return nil, false, "too many connections"
		}
		return nil, false, "too many connections at once from your address"
	}
	g.open[key]++
	g.mu.Unlock()
	var once sync.Once
	return func() {
		once.Do(func() {
			g.mu.Lock()
			if g.open[key]--; g.open[key] <= 0 {
				delete(g.open, key)
			}
			g.mu.Unlock()
		})
	}, true, ""
}

// Strike counts one offence (weight 1 normally). Reaching StrikeLimit inside StrikeWindow
// bans the address. It returns true if the address is now banned.
func (g *Guard) Strike(ip, reason string, weight int) bool {
	a, err := ParseIP(ip)
	if err != nil {
		return false
	}
	key := a.String()
	g.mu.Lock()
	if inList(a, g.allowIPs) {
		g.mu.Unlock()
		return false
	}
	now := time.Now()
	var keep []time.Time
	for _, t := range g.strikes[key] {
		if now.Sub(t) < g.S.StrikeWindow {
			keep = append(keep, t)
		}
	}
	for i := 0; i < min(max(1, weight), g.S.StrikeLimit); i++ {
		keep = append(keep, now)
	}
	g.strikes[key] = keep
	hit := len(keep) >= g.S.StrikeLimit
	if hit {
		delete(g.strikes, key)
	}
	g.mu.Unlock()
	if hit {
		g.Ban(key, reason, 0)
	}
	return hit
}

// Ban bans an address. dur 0 means the automatic length (doubling on repeats).
func (g *Guard) Ban(ip, reason string, dur time.Duration) {
	a, err := ParseIP(ip)
	if err != nil {
		return
	}
	key := a.String()
	var until time.Time
	g.updateBans(func(m map[string]*Ban) {
		b := m[key]
		if b == nil {
			b = &Ban{IP: key}
			m[key] = b
		}
		b.Count++
		d := dur
		if d == 0 {
			d = g.S.BanTime
			for i := 1; i < b.Count && d < g.S.MaxBan; i++ {
				d *= 2
			}
			d = min(d, g.S.MaxBan)
		}
		b.Until, b.Reason, b.Created = time.Now().Add(d), reason, time.Now()
		until = b.Until
	})
	g.Log("banned %s for %s (%s)", key, reason, time.Until(until).Round(time.Minute))
}

// Unban lifts a temporary ban and forgets the address's history.
func (g *Guard) Unban(ip string) bool {
	a, err := ParseIP(ip)
	if err != nil {
		return false
	}
	found := false
	g.updateBans(func(m map[string]*Ban) {
		_, found = m[a.String()]
		delete(m, a.String())
	})
	g.mu.Lock()
	delete(g.strikes, a.String())
	g.mu.Unlock()
	return found
}

// Bans lists the bans in force, newest first.
func (g *Guard) Bans() []Ban {
	g.mu.Lock()
	g.banF.checked = time.Time{}
	g.refresh()
	var out []Ban
	for _, b := range g.bans {
		if time.Now().Before(b.Until) {
			out = append(out, *b)
		}
	}
	g.mu.Unlock()
	sort.Slice(out, func(i, j int) bool { return out[i].Created.After(out[j].Created) })
	return out
}

func (g *Guard) loadBans() {
	b, err := os.ReadFile(g.banF.path)
	m := map[string]*Ban{}
	if err == nil {
		var list []*Ban
		if json.Unmarshal(b, &list) == nil {
			for _, x := range list {
				m[x.IP] = x
			}
		}
	}
	g.bans = m
}

// updateBans edits tempbans.json under a lock file, since several processes share it.
func (g *Guard) updateBans(fn func(map[string]*Ban)) error {
	unlock, err := lockFile(g.banF.path + ".lock")
	if err != nil {
		return err
	}
	defer unlock()
	g.mu.Lock()
	defer g.mu.Unlock()
	g.loadBans()
	fn(g.bans)
	var list []*Ban
	for _, b := range g.bans {
		// forget expired bans after a month so repeat offenders still get longer bans
		if time.Since(b.Until) < 30*24*time.Hour {
			list = append(list, b)
		}
	}
	data, _ := json.MarshalIndent(list, "", " ")
	tmp := fmt.Sprintf("%s.%d.tmp", g.banF.path, os.Getpid())
	if err := os.WriteFile(tmp, data, 0o644); err != nil {
		return err
	}
	g.banF.checked = time.Time{}
	return os.Rename(tmp, g.banF.path)
}

func lockFile(p string) (func(), error) {
	deadline := time.Now().Add(10 * time.Second)
	for {
		f, err := os.OpenFile(p, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0o644)
		if err == nil {
			f.Close()
			return func() { os.Remove(p) }, nil
		}
		if st, e := os.Stat(p); e == nil && time.Since(st.ModTime()) > 10*time.Second {
			os.Remove(p)
			continue
		}
		if time.Now().After(deadline) {
			return nil, errors.New("tempbans.json is locked")
		}
		time.Sleep(5 * time.Millisecond)
	}
}

// BotNames are logon names that only attack scripts use on telnet ports.
var BotNames = map[string]bool{"root": true, "admin": true, "administrator": true,
	"support": true, "ubnt": true, "shell": true, "sh": true, "enable": true,
	"system": true, "default": true, "telnet": true, "pi": true, "oracle": true,
	"ftp": true, "mother": true, "supervisor": true, "daemon": true, "nobody": true}

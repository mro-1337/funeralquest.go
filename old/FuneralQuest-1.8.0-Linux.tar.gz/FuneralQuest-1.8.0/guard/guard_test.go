package guard

import (
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestStrikesAndEscalation(t *testing.T) {
	g := New(t.TempDir())
	os.WriteFile(filepath.Join(g.Dir, "allowlist_ip.txt"), []byte("192.168.1.5\n"), 0o644)
	g.allowF.checked = time.Time{}
	for i := 0; i < 4; i++ {
		if g.Strike("203.0.113.9", "bad logon", 1) {
			t.Fatal("banned too early")
		}
	}
	if !g.Strike("203.0.113.9", "bad logon", 1) {
		t.Fatal("not banned after 5 strikes")
	}
	if ok, _ := g.Check("203.0.113.9"); ok {
		t.Fatal("banned address allowed")
	}
	first := g.Bans()[0].Until
	// a second ban lasts about twice as long
	g.Ban("203.0.113.9", "again", 0)
	if second := g.Bans()[0].Until; second.Sub(time.Now()) < first.Sub(time.Now())+20*time.Minute {
		t.Fatalf("ban didn't escalate: %v vs %v", first, second)
	}
	// allow-listed addresses are never banned
	if g.Strike("192.168.1.5", "x", 100) {
		t.Fatal("allow-listed address banned")
	}
	// a second process sees the ban (shared file)
	g2 := New(g.Dir)
	if ok, _ := g2.Check("203.0.113.9"); ok {
		t.Fatal("ban not shared between processes")
	}
	if !g.Unban("203.0.113.9") {
		t.Fatal("unban failed")
	}
	g2.banF.checked = time.Time{}
	if ok, _ := g2.Check("203.0.113.9"); !ok {
		t.Fatal("unban not shared")
	}
}

func TestFloodAndLists(t *testing.T) {
	g := New(t.TempDir())
	g.S.ConnPerMinute = 3
	var rel []func()
	for i := 0; i < 3; i++ {
		r, ok, why := g.Connect("198.51.100.7")
		if !ok {
			t.Fatalf("connection %d refused: %s", i, why)
		}
		rel = append(rel, r)
	}
	if _, ok, _ := g.Connect("198.51.100.7"); ok {
		t.Fatal("4th connection inside a minute allowed")
	}
	if ok, _ := g.Check("198.51.100.7"); ok {
		t.Fatal("flooder not banned")
	}
	for _, r := range rel {
		r()
	}
	os.WriteFile(filepath.Join(g.Dir, "blocklist_ip.txt"), []byte("# test\n10.0.0.0/8 ; office\n2001:db8::/32\n"), 0o644)
	g.blockF.checked = time.Time{}
	for _, ip := range []string{"10.1.2.3", "[2001:db8::1]:23", "::ffff:10.0.0.1"} {
		if ok, _ := g.Check(ip); ok {
			t.Errorf("%s not blocked", ip)
		}
	}
	if ok, _ := g.Check("11.0.0.1"); !ok {
		t.Error("11.0.0.1 blocked")
	}
	if _, bad := ParsePrefixes("1.2.3.4\nnonsense\n"); len(bad) != 1 {
		t.Error("bad line not reported")
	}
}

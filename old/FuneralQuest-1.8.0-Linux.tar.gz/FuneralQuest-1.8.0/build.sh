#!/bin/sh
# Builds Funeral Quest (fq) and the sysop editor (fqedit) for every supported system.
# Needs Go 1.24+. Only Go's standard library is used, so no downloads are needed.
set -e
build() { # GOOS GOARCH suffix
	CGO_ENABLED=0 GOOS=$1 GOARCH=$2 GOARM=7 go build -trimpath -ldflags "-s -w" -o "fq$3" .
	CGO_ENABLED=0 GOOS=$1 GOARCH=$2 GOARM=7 go build -trimpath -ldflags "-s -w" -o "fqedit$3" ./cmd/fqedit
	echo "built fq$3 and fqedit$3"
}
build windows amd64 .exe
build windows 386   32.exe
build windows arm64 -arm64.exe
build linux   amd64 -linux
build linux   386   -linux32
build linux   arm64 -linux-arm64
build linux   arm   -linux-arm
build darwin  arm64 -macos-arm
build darwin  amd64 -macos-intel
build freebsd amd64 -freebsd
build freebsd arm64 -freebsd-arm64
build openbsd amd64 -openbsd
build netbsd  amd64 -netbsd

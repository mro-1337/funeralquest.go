package rlogin

import (
	"bufio"
	"io"
	"net"
	"strings"
	"testing"
	"time"
)

func TestReadHandshake(t *testing.T) {
	r := bufio.NewReader(strings.NewReader("\x00pw\x00Bob\x00ansi-bbs/38400\x00typed"))
	req, err := ReadHandshake(r)
	if err != nil || req.ClientUser != "pw" || req.ServerUser != "Bob" || req.Terminal != "ansi-bbs/38400" {
		t.Fatalf("got %+v, %v", req, err)
	}
	rest, _ := io.ReadAll(r)
	if string(rest) != "typed" {
		t.Fatalf("bytes after the handshake lost: %q", rest)
	}
	if _, err := ReadHandshake(bufio.NewReader(strings.NewReader("x\x00a\x00b\x00"))); err == nil {
		t.Fatal("missing leading zero accepted")
	}
}

func TestGatewayName(t *testing.T) {
	cases := []struct{ secret, first, second, want string }{
		{"s3cret", "Bob", "s3cret", "Bob"}, // name first (SyncTERM "RLogin")
		{"s3cret", "s3cret", "Bob", "Bob"}, // password first (Synchronet, SyncTERM "RLogin Reversed")
		{"s3cret", "Bob", "nope", ""},      // no secret
		{"s3cret", "s3cret", "", ""},       // secret but no name
		{"s3cret", "s3cret", "s3cret", ""}, // both the secret
		{"", "Bob", "Bob", ""},             // gateway disabled
	}
	for _, c := range cases {
		got, ok := GatewayName(c.secret, c.first, c.second)
		if got != c.want || ok != (c.want != "") {
			t.Errorf("GatewayName(%q,%q,%q) = %q,%v; want %q", c.secret, c.first, c.second, got, ok, c.want)
		}
	}
}

func TestTrusted(t *testing.T) {
	a := &net.TCPAddr{IP: net.ParseIP("10.1.2.3"), Port: 999}
	for list, want := range map[string]bool{"*": true, "10.1.2.3": true, "10.0.0.0/8": true, "127.0.0.1": false, "": false, "192.168.0.0/16": false} {
		if got := Trusted(a, strings.Split(list, ",")); got != want {
			t.Errorf("Trusted(%q) = %v", list, got)
		}
	}
}

// end-to-end over a real listener
func TestServer(t *testing.T) {
	accounts := map[string]string{"alice": "alicepw1"}
	auth := func(name, pw string) (string, bool) {
		if p, ok := accounts[strings.ToLower(name)]; ok && p != "" && p == pw {
			return "Alice", true
		}
		return "", false
	}
	got := make(chan *Session, 1)
	srv := New(Config{Trusted: []string{"127.0.0.1", "::1"}, Secret: "s3cret", FailLimit: 3}, auth, func(s *Session) {
		got <- s
		s.Write([]byte("hello " + s.Name + "\r\n"))
	})
	srv.Log = func(string, ...any) {}
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer ln.Close()
	go srv.Serve(ln)

	dial := func(first, second string) (*Session, string) {
		t.Helper()
		c, err := net.Dial("tcp", ln.Addr().String())
		if err != nil {
			t.Fatal(err)
		}
		defer c.Close()
		c.Write([]byte("\x00" + first + "\x00" + second + "\x00ansi-bbs/38400\x00"))
		c.SetReadDeadline(time.Now().Add(3 * time.Second))
		out, _ := io.ReadAll(c)
		select {
		case s := <-got:
			return s, string(out)
		case <-time.After(3 * time.Second):
			return nil, string(out)
		}
	}
	check := func(first, second, wantName string, wantMethod Method) {
		t.Helper()
		s, out := dial(first, second)
		if s == nil {
			t.Fatalf("(%q,%q): no session, output %q", first, second, out)
		}
		if s.Name != wantName || s.Method != wantMethod {
			t.Errorf("(%q,%q): got %q/%v, want %q/%v", first, second, s.Name, s.Method, wantName, wantMethod)
		}
		if !strings.HasPrefix(out, "\x00") {
			t.Errorf("(%q,%q): server must answer with a zero byte, got %q", first, second, out)
		}
	}
	check("s3cret", "Bob", "Bob", Gateway)        // BBS gateway, password first
	check("Bob", "s3cret", "Bob", Gateway)        // BBS gateway, name first
	check("alice", "alicepw1", "Alice", Password) // own password
	check("alicepw1", "alice", "Alice", Password) // own password, reversed
	check("", "", "", Prompt)                     // nothing sent
	check("alice", "alice", "", Prompt)           // name only: NOT trusted (fail 1)
	check("alice", "guess", "", Prompt)           // wrong password (fail 2)
	check("alice", "guess2", "", Prompt)          // (fail 3) -> now blocked
	if s, out := dial("alice", "alicepw1"); s != nil || !strings.Contains(out, "Too many failed logins") {
		t.Errorf("after 3 failures the address should be refused, got session %v, output %q", s, out)
	}
	if s, _ := dial("s3cret", "Bob"); s == nil || s.Method != Gateway {
		t.Error("the BBS gateway must keep working while an address is blocked")
	}
}

func TestUntrusted(t *testing.T) {
	srv := New(Config{Trusted: []string{"10.9.9.9"}}, nil, func(s *Session) { t.Error("handler ran for an untrusted host") })
	srv.Log = func(string, ...any) {}
	ln, _ := net.Listen("tcp", "127.0.0.1:0")
	defer ln.Close()
	go srv.Serve(ln)
	c, _ := net.Dial("tcp", ln.Addr().String())
	defer c.Close()
	c.Write([]byte("\x00a\x00b\x00ansi/9600\x00"))
	c.SetReadDeadline(time.Now().Add(2 * time.Second))
	out, _ := io.ReadAll(c)
	if !strings.HasPrefix(string(out), "\x01") {
		t.Fatalf("untrusted host should get a 0x01 error byte, got %q", out)
	}
}

// the game's block lists/bans and its strike counting are wired in through Check and OnFail
func TestCheckAndOnFail(t *testing.T) {
	var fails []string
	srv := New(Config{Trusted: []string{"*"}, Secret: "s3cret",
		Check:  func(ip string) (bool, string) { return false, "address is on the block list" },
		OnFail: func(ip string) { fails = append(fails, ip) }}, nil, func(s *Session) { t.Error("handler ran for a blocked address") })
	srv.Log = func(string, ...any) {}
	ln, _ := net.Listen("tcp", "127.0.0.1:0")
	defer ln.Close()
	go srv.Serve(ln)
	c, _ := net.Dial("tcp", ln.Addr().String())
	c.Write([]byte("\x00s3cret\x00Bob\x00ansi/9600\x00"))
	c.SetReadDeadline(time.Now().Add(2 * time.Second))
	out, _ := io.ReadAll(c)
	c.Close()
	if !strings.HasPrefix(string(out), "\x01") || !strings.Contains(string(out), "block list") {
		t.Fatalf("blocked address should be refused even with the secret, got %q", out)
	}
	srv.SetConfig(Config{Trusted: []string{"*"}, OnFail: func(ip string) { fails = append(fails, ip) }})
	got := make(chan bool, 1)
	srv.handler = func(s *Session) { got <- true }
	c, _ = net.Dial("tcp", ln.Addr().String())
	c.Write([]byte("\x00someone\x00wrongpw\x00ansi/9600\x00"))
	<-got
	c.Close()
	if len(fails) != 1 {
		t.Fatalf("failed login not reported to the game: %v", fails)
	}
}

// Package rlogin is the RLogin (RFC 1282) server for Funeral Quest, built on the methods of
// the rlogin kit: it does the handshake, decides who the caller is, and hands the game a
// ready connection.
//
// RLogin sends two user fields with no password field of its own, and BBS software disagrees
// about which field carries the name and which the password (Synchronet sends the password
// first, SyncTERM has "RLogin" and "RLogin Reversed", Mystic decides for itself). So the
// order is never trusted; the values decide:
//
//  1. Trusted host check: the caller's IP must be in Config.Trusted (IPs, CIDRs or "*"),
//     and must pass the game's block lists and bans (Config.Check).
//  2. BBS gateway: if Config.Secret is set and exactly one field is the secret, the other
//     field is the user name, trusted because the BBS already checked the caller.
//  3. The caller's own password: otherwise both orders are tried as name+password against
//     the game's accounts.
//  4. Fallback: nothing matched (or nothing was sent) and the game shows its normal log-on
//     screen. A name alone is never trusted.
//
// Failed logins are counted per IP; after FailLimit failures in FailWindow that IP is refused.
// Passwords never reach the log or the screen: the raw fields are dropped as soon as the
// decision is made.
package rlogin

import (
	"bufio"
	"errors"
	"io"
	"log"
	"net"
	"strings"
	"sync"
	"time"
)

// Method says how a session was identified.
type Method int

const (
	Gateway  Method = iota + 1 // the BBS vouched for the name with the shared secret
	Password                   // the caller sent their own account name and password
	Prompt                     // not identified: the game must ask for a log-on
)

func (m Method) String() string {
	switch m {
	case Gateway:
		return "gateway"
	case Password:
		return "password"
	case Prompt:
		return "prompt"
	}
	return "?"
}

// Session is one accepted RLogin connection.
type Session struct {
	Conn     net.Conn
	Reader   io.Reader // the caller's input (holds bytes already buffered by the handshake)
	Name     string    // user name (empty when Method == Prompt)
	Method   Method
	Reason   string // for Prompt: "none sent" or "no match"
	Terminal string // e.g. "ansi-bbs/38400"
	IP       string

	srv *Server
}

func (s *Session) Read(p []byte) (int, error)  { return s.Reader.Read(p) }
func (s *Session) Write(p []byte) (int, error) { return s.Conn.Write(p) }

// LoginFailed records a failed log-on typed at the game's own prompt.
func (s *Session) LoginFailed() { s.srv.fail(s.IP) }

// LoginOK clears the failure count after a good log-on at the prompt.
func (s *Session) LoginOK() { s.srv.fails.clear(s.IP) }

// Blocked reports whether this caller's address is refused right now.
func (s *Session) Blocked() bool { return s.srv.fails.blocked(s.IP) }

// Config controls the server; change it while running with SetConfig.
type Config struct {
	Trusted          []string // IPs / CIDRs allowed to connect; "*" = any; empty = nobody
	Secret           string   // shared with BBS gateways ("" = no gateway logins)
	FailLimit        int      // failed logins per IP within FailWindow before refusing (5)
	FailWindow       time.Duration
	HandshakeTimeout time.Duration // for the client to send its fields (15 s)
	// Check, if set, also vets the caller's IP (block lists, bans). Return ok=false to refuse.
	Check func(ip string) (ok bool, why string)
	// OnFail, if set, is told about every failed login (for the game's own ban counting).
	OnFail func(ip string)
}

// Auth checks a name and password against the game's accounts. It returns the account's
// proper name and true only if they match; false for an account without a password.
type Auth func(name, password string) (canonical string, ok bool)

// Handler runs the game for one session; the connection closes when it returns.
type Handler func(s *Session)

type Server struct {
	mu      sync.RWMutex
	cfg     Config
	auth    Auth
	handler Handler
	fails   *failCounter
	Log     func(format string, args ...any) // never gets passwords
}

func New(cfg Config, auth Auth, handler Handler) *Server {
	return &Server{cfg: cfg, auth: auth, handler: handler, fails: &failCounter{m: map[string][]time.Time{}}, Log: log.Printf}
}

func (srv *Server) SetConfig(c Config) {
	srv.mu.Lock()
	srv.cfg = c
	srv.mu.Unlock()
}

func (srv *Server) config() Config {
	srv.mu.RLock()
	defer srv.mu.RUnlock()
	c := srv.cfg
	if c.FailLimit <= 0 {
		c.FailLimit = 5
	}
	if c.FailWindow <= 0 {
		c.FailWindow = 15 * time.Minute
	}
	if c.HandshakeTimeout <= 0 {
		c.HandshakeTimeout = 15 * time.Second
	}
	return c
}

func (srv *Server) fail(ip string) {
	srv.fails.add(ip)
	if f := srv.config().OnFail; f != nil {
		f(ip)
	}
}

func (srv *Server) ListenAndServe(addr string) error {
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		return err
	}
	return srv.Serve(ln)
}

func (srv *Server) Serve(ln net.Listener) error {
	for {
		c, err := ln.Accept()
		if err != nil {
			var ne net.Error
			if errors.As(err, &ne) && ne.Timeout() {
				continue
			}
			return err
		}
		go srv.Handle(c)
	}
}

// Request is the handshake as received.
type Request struct {
	ClientUser string // 1st field (RFC: local user name; BBSes: often the password)
	ServerUser string // 2nd field (RFC: account to log in as)
	Terminal   string // "type/speed"
}

// ReadHandshake reads "\0client\0server\0term/speed\0".
func ReadHandshake(r *bufio.Reader) (Request, error) {
	var req Request
	if b, err := r.ReadByte(); err != nil {
		return req, err
	} else if b != 0 {
		return req, errors.New("rlogin: handshake must start with a zero byte")
	}
	field := func() (string, error) {
		var b []byte
		for {
			c, err := r.ReadByte()
			if err != nil {
				return "", err
			}
			if c == 0 {
				return string(b), nil
			}
			if len(b) >= 256 {
				return "", errors.New("rlogin: field too long")
			}
			b = append(b, c)
		}
	}
	var err error
	if req.ClientUser, err = field(); err != nil {
		return req, err
	}
	if req.ServerUser, err = field(); err != nil {
		return req, err
	}
	if req.Terminal, err = field(); err != nil {
		return req, err
	}
	return req, nil
}

func refuse(c net.Conn, msg string) {
	c.SetWriteDeadline(time.Now().Add(3 * time.Second))
	c.Write(append([]byte{1}, []byte(msg+"\r\n")...)) // RFC: non-zero first byte = refused
}

// Handle runs one connection (exported so tests and other listeners can use it).
func (srv *Server) Handle(c net.Conn) {
	defer c.Close()
	cfg := srv.config()
	srv.fails.setLimits(cfg.FailLimit, cfg.FailWindow)
	ip := HostOf(c.RemoteAddr())
	if !Trusted(c.RemoteAddr(), cfg.Trusted) {
		srv.Log("rlogin: refused %s: host not trusted", ip)
		refuse(c, "Host not trusted for rlogin.")
		return
	}
	if cfg.Check != nil {
		if ok, why := cfg.Check(ip); !ok {
			srv.Log("rlogin: refused %s: %s", ip, why)
			refuse(c, "Access denied: "+why)
			return
		}
	}
	c.SetReadDeadline(time.Now().Add(cfg.HandshakeTimeout))
	br := bufio.NewReader(c)
	req, err := ReadHandshake(br)
	if err != nil {
		return
	}
	c.SetReadDeadline(time.Time{})
	c.Write([]byte{0}) // RFC: zero byte = accepted

	first, second := strings.TrimSpace(req.ClientUser), strings.TrimSpace(req.ServerUser)
	req.ClientUser, req.ServerUser = "", "" // never keep the password around
	sess := &Session{Conn: c, Reader: io.MultiReader(br, c), Terminal: req.Terminal, IP: ip, srv: srv}

	switch name, ok := GatewayName(cfg.Secret, first, second); {
	case ok:
		sess.Name, sess.Method = name, Gateway
	case srv.fails.blocked(ip):
		srv.Log("rlogin: refused %s: too many failed logins", ip)
		c.Write([]byte("\r\nToo many failed logins from your address. Try again later.\r\n"))
		time.Sleep(time.Second)
		return
	default:
		if n, ok := srv.tryAuth(first, second); ok {
			sess.Name, sess.Method = n, Password
		} else if n, ok := srv.tryAuth(second, first); ok {
			sess.Name, sess.Method = n, Password
		} else {
			sess.Method, sess.Reason = Prompt, "none sent"
			if first != "" || second != "" {
				sess.Reason = "no match"
				srv.fail(ip)
			}
		}
	}
	first, second = "", ""
	if sess.Method == Password {
		srv.fails.clear(ip)
	}
	if sess.Name != "" {
		srv.Log("rlogin: %s as %q (%s, terminal %q)", ip, sess.Name, sess.Method, sess.Terminal)
	} else {
		srv.Log("rlogin: %s needs to log on (%s)", ip, sess.Reason)
	}
	srv.handler(sess)
}

func (srv *Server) tryAuth(name, pw string) (string, bool) {
	if name == "" || pw == "" || srv.auth == nil {
		return "", false
	}
	return srv.auth(name, pw)
}

// GatewayName returns the field that isn't the shared secret, if exactly one field is the
// secret and the other isn't empty.
func GatewayName(secret, first, second string) (string, bool) {
	if secret == "" {
		return "", false
	}
	switch {
	case first == secret && second != secret && second != "":
		return second, true
	case second == secret && first != secret && first != "":
		return first, true
	}
	return "", false
}

// Trusted reports whether remote is allowed by list (IPs, CIDRs, "*").
func Trusted(remote net.Addr, list []string) bool {
	ip := net.ParseIP(HostOf(remote))
	for _, t := range list {
		t = strings.TrimSpace(t)
		switch {
		case t == "*":
			return true
		case strings.Contains(t, "/"):
			if _, n, err := net.ParseCIDR(t); err == nil && ip != nil && n.Contains(ip) {
				return true
			}
		default:
			if tip := net.ParseIP(t); tip != nil && ip != nil && tip.Equal(ip) {
				return true
			}
		}
	}
	return false
}

func HostOf(a net.Addr) string {
	h, _, err := net.SplitHostPort(a.String())
	if err != nil {
		return a.String()
	}
	return h
}

type failCounter struct {
	mu     sync.Mutex
	m      map[string][]time.Time
	limit  int
	window time.Duration
}

func (f *failCounter) setLimits(limit int, window time.Duration) {
	f.mu.Lock()
	f.limit, f.window = limit, window
	f.mu.Unlock()
}

func (f *failCounter) settings() (int, time.Duration) {
	if f.limit > 0 {
		return f.limit, f.window
	}
	return 5, 15 * time.Minute
}

func (f *failCounter) recent(ip string) []time.Time {
	_, win := f.settings()
	var keep []time.Time
	for _, t := range f.m[ip] {
		if time.Since(t) < win {
			keep = append(keep, t)
		}
	}
	if len(keep) == 0 {
		delete(f.m, ip)
	} else {
		f.m[ip] = keep
	}
	return keep
}

func (f *failCounter) blocked(ip string) bool {
	f.mu.Lock()
	defer f.mu.Unlock()
	lim, _ := f.settings()
	return len(f.recent(ip)) >= lim
}

func (f *failCounter) add(ip string) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.m[ip] = append(f.recent(ip), time.Now())
}

func (f *failCounter) clear(ip string) {
	f.mu.Lock()
	defer f.mu.Unlock()
	delete(f.m, ip)
}

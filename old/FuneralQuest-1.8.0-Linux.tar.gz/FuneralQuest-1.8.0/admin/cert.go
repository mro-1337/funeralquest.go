package admin

import (
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/sha256"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/hex"
	"encoding/pem"
	"errors"
	"fmt"
	"math/big"
	"net"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"time"
)

// CertInfo describes the HTTPS certificate the web server is set to use.
type CertInfo struct {
	File        string    `json:"file"`
	Subject     string    `json:"subject"`
	Names       []string  `json:"names"`
	Expires     time.Time `json:"expires"`
	SelfSigned  bool      `json:"self_signed"`
	Fingerprint string    `json:"fingerprint"`
	Error       string    `json:"error,omitempty"`
}

// CertFingerprint is the SHA-256 of a certificate, the way browsers show it.
func CertFingerprint(der []byte) string {
	sum := sha256.Sum256(der)
	h := strings.ToUpper(hex.EncodeToString(sum[:]))
	var parts []string
	for i := 0; i < len(h); i += 2 {
		parts = append(parts, h[i:i+2])
	}
	return strings.Join(parts, ":")
}

// Cert reports on the configured certificate (nil when HTTPS isn't set up).
func (a *Admin) Cert() *CertInfo {
	c := a.Config()
	if c.WebCert == "" {
		return nil
	}
	info := &CertInfo{File: c.WebCert}
	b, err := os.ReadFile(c.WebCert)
	if err != nil {
		info.Error = err.Error()
		return info
	}
	blk, _ := pem.Decode(b)
	if blk == nil {
		info.Error = "not a PEM certificate file"
		return info
	}
	crt, err := x509.ParseCertificate(blk.Bytes)
	if err != nil {
		info.Error = err.Error()
		return info
	}
	info.Subject, info.Expires = crt.Subject.CommonName, crt.NotAfter
	info.Names = append(info.Names, crt.DNSNames...)
	for _, ip := range crt.IPAddresses {
		info.Names = append(info.Names, ip.String())
	}
	info.SelfSigned = crt.Issuer.String() == crt.Subject.String()
	info.Fingerprint = CertFingerprint(crt.Raw)
	return info
}

// CertHosts suggests the names a new certificate should cover: this server's web address,
// the computer's name, and localhost.
func (a *Admin) CertHosts() []string {
	var hosts []string
	add := func(h string) {
		h = strings.TrimSpace(strings.Trim(h, "[]"))
		if h == "" {
			return
		}
		for _, x := range hosts {
			if strings.EqualFold(x, h) {
				return
			}
		}
		hosts = append(hosts, h)
	}
	if u, err := url.Parse(a.Config().NetPublicURL); err == nil {
		add(u.Hostname())
	}
	if h, err := os.Hostname(); err == nil {
		add(h)
	}
	add("localhost")
	add("127.0.0.1")
	add("::1")
	return hosts
}

// MakeSelfSignedCert makes a certificate and key for HTTPS in data/tls, points the web
// server at them, and switches this server's web address to https. Browsers will warn that
// it isn't from a known authority; linked Funeral Quest servers trust it the first time and
// then remember (pin) it.
func (a *Admin) MakeSelfSignedCert(hosts []string) (*CertInfo, error) {
	if len(hosts) == 0 {
		hosts = a.CertHosts()
	}
	var dns []string
	var ips []net.IP
	for _, h := range hosts {
		h = strings.TrimSpace(strings.Trim(h, "[]"))
		if h == "" {
			continue
		}
		if ip := net.ParseIP(h); ip != nil {
			ips = append(ips, ip)
		} else if strings.ContainsAny(h, " /\\:") || len(h) > 253 {
			return nil, fmt.Errorf("%q isn't a host name", h)
		} else {
			dns = append(dns, h)
		}
	}
	if len(dns)+len(ips) == 0 {
		return nil, errors.New("give at least one host name or IP address")
	}
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return nil, err
	}
	serial, _ := rand.Int(rand.Reader, new(big.Int).Lsh(big.NewInt(1), 120))
	cn := "Funeral Quest"
	if len(dns) > 0 {
		cn = dns[0]
	}
	tmpl := &x509.Certificate{
		SerialNumber:          serial,
		Subject:               pkix.Name{CommonName: cn, Organization: []string{"Funeral Quest - " + a.Config().ServerName}},
		NotBefore:             time.Now().Add(-time.Hour),
		NotAfter:              time.Now().Add(825 * 24 * time.Hour), // the longest browsers accept
		KeyUsage:              x509.KeyUsageDigitalSignature,
		ExtKeyUsage:           []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		BasicConstraintsValid: true,
		DNSNames:              dns,
		IPAddresses:           ips,
	}
	der, err := x509.CreateCertificate(rand.Reader, tmpl, tmpl, &key.PublicKey, key)
	if err != nil {
		return nil, err
	}
	kb, err := x509.MarshalECPrivateKey(key)
	if err != nil {
		return nil, err
	}
	dir := filepath.Join(a.Home, "data", "tls")
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return nil, err
	}
	certPath, keyPath := filepath.Join(dir, "fq-selfsigned.crt"), filepath.Join(dir, "fq-selfsigned.key")
	if err := os.WriteFile(keyPath, pem.EncodeToMemory(&pem.Block{Type: "EC PRIVATE KEY", Bytes: kb}), 0o600); err != nil {
		return nil, err
	}
	if err := os.WriteFile(certPath, pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der}), 0o644); err != nil {
		return nil, err
	}
	kv := map[string]string{"web_cert": certPath, "web_key": keyPath}
	if u := a.Config().NetPublicURL; strings.HasPrefix(u, "http://") {
		kv["net_public_url"] = "https://" + strings.TrimPrefix(u, "http://")
	}
	if err := a.SetSettings(kv); err != nil {
		return nil, err
	}
	return a.Cert(), nil
}

// TurnOffHTTPS clears the certificate settings (plain HTTP again after a restart).
func (a *Admin) TurnOffHTTPS() error {
	kv := map[string]string{"web_cert": "", "web_key": ""}
	if u := a.Config().NetPublicURL; strings.HasPrefix(u, "https://") {
		kv["net_public_url"] = "http://" + strings.TrimPrefix(u, "https://")
	}
	return a.SetSettings(kv)
}

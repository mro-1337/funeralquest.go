module funeralquest

go 1.24

Funeral Quest over RLogin - BBS and terminal setup
==================================================

Turn RLogin on in Funeral Quest first (fqedit > Game settings > RLogin, the web
admin Settings tab, or  fq admin config rlogin_port=1513 rlogin_secret=...),
then run  fq telnet  or  fq rlogin.

Synchronet
----------
Use synchronet_fq_rlogin.js from this folder (instructions inside). Put
Funeral Quest's gateway secret in it. Callers arrive logged in under their
Synchronet alias, as the same player they'd be through the door (if the
door's --bbs-id and the "BBS ID for gateway callers" setting match; both
default to "bbs").

Mystic BBS
----------
Menu Editor > pick a menu > insert an item:
  Hotkey / Text : F  /  (F) Funeral Quest
  Command       : IR   (Outbound RLOGIN Connection)
  Data          : /addr=127.0.0.1 /port=1513 /user=@USER@ /pass=YOUR-GATEWAY-SECRET

Mystic picks which RLogin field gets /user and which /pass. Funeral Quest
accepts either order.

Other BBSes
-----------
Any BBS that can make an outbound RLogin connection works the same way: the
caller's name in one field and the gateway secret in the other, either order.

SyncTERM (or NetRunner etc.) connecting straight to the game
------------------------------------------------------------
Dialing directory > new entry:
  Connection Type : RLogin  (or RLogin Reversed - both work)
  Address / Port  : the game's host and RLogin port
  Username        : the player's Funeral Quest logon
  Password        : the player's own Funeral Quest password (NOT the gateway secret)
If they don't match an account (or Username is empty), the normal log-on
screen appears, where new players can open a parlor.

Testing
-------
Each of these should give the result shown:
  1st field      2nd field      result
  SECRET         Bob            logged in as Bob (gateway, Synchronet order)
  Bob            SECRET         logged in as Bob (gateway, other order)
  alice          her-password   logged in as alice
  her-password   alice          logged in as alice
  alice          alice          log-on screen (a name alone is never trusted)
  alice          wrong          log-on screen (counts as a failed log-on)
  (empty)        (empty)        log-on screen
  too many wrong passwords from one address: refused, and the address is
  temporarily banned like any other failed log-ons
  from an address not in "Hosts allowed to connect": refused (reply 0x01)
Passwords and the secret never appear on screen or in the logs.

If it works on the same machine but not from outside, the port is being
blocked: check the computer's firewall and your router or host's firewall.

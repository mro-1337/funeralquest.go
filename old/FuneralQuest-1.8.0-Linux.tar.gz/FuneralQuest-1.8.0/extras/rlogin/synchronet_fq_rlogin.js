// Synchronet: send the caller to Funeral Quest over RLogin, already logged in.
// (Optional: Synchronet can also run Funeral Quest as a DOOR32.SYS door; see README.md.)
//
// Install: copy this file to sbbs/mods, then in SCFG:
//   External Programs > Online Programs (Doors) > [section] > add a program
//     Command Line:              ?synchronet_fq_rlogin.js
//     Native Executable/Script:  No
//     BBS Drop File Type:        None
//
// ADDRESS = "host:port" of Funeral Quest's RLogin server (the rlogin_port setting).
// SECRET  = Funeral Quest's "BBS gateway secret" (rlogin_secret). Keep it private:
//           whoever has it can enter under any name.
//
// bbs.rlogin_gate(address, client_user_name, server_user_name): Synchronet sends the
// password first and the name second. Funeral Quest accepts either order.
"use strict";
var ADDRESS = "127.0.0.1:1513";
var SECRET  = "change-me-to-your-gateway-secret";

bbs.rlogin_gate(ADDRESS, SECRET, user.alias);

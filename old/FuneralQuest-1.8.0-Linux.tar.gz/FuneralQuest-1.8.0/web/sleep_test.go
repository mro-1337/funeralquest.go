package web_test

import "time"

func sleep() { time.Sleep(100 * time.Millisecond) }

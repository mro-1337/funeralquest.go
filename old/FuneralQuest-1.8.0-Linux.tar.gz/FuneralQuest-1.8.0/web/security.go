package web

import (
	"errors"
	"io/fs"
	"net"
	"net/http"
	"net/netip"
	"os"
	"strings"
	"sync"
	"time"
)

// Options for the web server.
type Options struct {
	TLS        bool // serving HTTPS (adds HSTS)
	TrustProxy bool // take the caller's address from X-Forwarded-For (only behind your own proxy)
}

const csp = "default-src 'self'; script-src 'self' 'wasm-unsafe-eval'; style-src 'self' 'unsafe-inline'; " +
	"img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self'; worker-src 'self' blob:; " +
	"object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'"

// clientIP is the caller's address. X-Forwarded-For is only believed with --trust-proxy, and
// then only from a proxy on this machine or the LAN.
func (srv *Server) clientIP(r *http.Request) string {
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		host = r.RemoteAddr
	}
	if srv.Opt.TrustProxy {
		if a, err := netip.ParseAddr(host); err == nil && (a.IsLoopback() || a.IsPrivate()) {
			if xff := r.Header.Get("X-Forwarded-For"); xff != "" {
				parts := strings.Split(xff, ",")
				if c, err := netip.ParseAddr(strings.TrimSpace(parts[len(parts)-1])); err == nil {
					return c.Unmap().String()
				}
			}
		}
	}
	return host
}

// limiter is a per-address sliding window counter.
type limiter struct {
	mu   sync.Mutex
	hits map[string][]time.Time
	n    int
	win  time.Duration
	gc   time.Time
}

func newLimiter(n int, win time.Duration) *limiter {
	return &limiter{hits: map[string][]time.Time{}, n: n, win: win}
}

// allow records a hit and reports whether the address is still under the limit.
func (l *limiter) allow(key string) bool {
	l.mu.Lock()
	defer l.mu.Unlock()
	now := time.Now()
	if now.Sub(l.gc) > time.Minute {
		for k, v := range l.hits {
			if len(v) == 0 || now.Sub(v[len(v)-1]) > l.win {
				delete(l.hits, k)
			}
		}
		l.gc = now
	}
	keep := l.hits[key][:0]
	for _, t := range l.hits[key] {
		if now.Sub(t) < l.win {
			keep = append(keep, t)
		}
	}
	if len(keep) >= l.n {
		l.hits[key] = keep
		return false
	}
	l.hits[key] = append(keep, now)
	return true
}

// protect wraps every request: block lists and bans, a request rate limit, and security headers.
func (srv *Server) protect(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		ip := srv.clientIP(r)
		h := w.Header()
		h.Set("X-Content-Type-Options", "nosniff")
		h.Set("X-Frame-Options", "DENY")
		h.Set("Referrer-Policy", "no-referrer")
		h.Set("Content-Security-Policy", csp)
		h.Set("Cross-Origin-Opener-Policy", "same-origin")
		h.Set("Cross-Origin-Resource-Policy", "same-origin")
		h.Set("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=(), usb=()")
		if srv.Opt.TLS {
			h.Set("Strict-Transport-Security", "max-age=31536000")
		}
		if ok, why := srv.A.Guard.Check(ip); !ok {
			srv.secLog("refused %s %s: %s", ip, r.URL.Path, why)
			http.Error(w, "Access denied.", http.StatusForbidden)
			return
		}
		if !srv.general.allow(ip) {
			if srv.A.Guard.Strike(ip, "web request flood", 1) {
				srv.secLog("banned %s: web request flood", ip)
			}
			w.Header().Set("Retry-After", "10")
			http.Error(w, "Slow down.", http.StatusTooManyRequests)
			return
		}
		switch r.Method {
		case http.MethodGet, http.MethodHead, http.MethodPost:
		default:
			http.Error(w, "Method not allowed.", http.StatusMethodNotAllowed)
			return
		}
		// keep absurd URLs and bodies out
		if len(r.URL.RawQuery) > 2048 || len(r.URL.Path) > 512 {
			http.Error(w, "Bad request.", http.StatusBadRequest)
			return
		}
		if r.Method == http.MethodPost {
			r.Body = http.MaxBytesReader(w, r.Body, 2<<20)
		}
		next.ServeHTTP(w, r)
	})
}

// staticFS serves files only: no directory listings, no hidden files, no backup files.
type staticFS struct{ fs http.FileSystem }

var errNotFound = errors.New("not found")

func (s staticFS) Open(name string) (http.File, error) {
	for _, part := range strings.Split(name, "/") {
		if strings.HasPrefix(part, ".") || strings.HasSuffix(part, "~") || strings.HasSuffix(part, ".bak") {
			return nil, fs.ErrNotExist
		}
	}
	f, err := s.fs.Open(name)
	if err != nil {
		return nil, err
	}
	st, err := f.Stat()
	if err != nil {
		f.Close()
		return nil, err
	}
	if st.IsDir() {
		// a folder is only served if it has an index.html (which FileServer then shows)
		idx, err := s.fs.Open(strings.TrimSuffix(name, "/") + "/index.html")
		if err != nil {
			f.Close()
			return nil, fs.ErrNotExist
		}
		idx.Close()
	}
	return f, nil
}

func ensureDir(p string) { os.MkdirAll(p, 0o755) }

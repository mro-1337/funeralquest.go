package web_test

import (
	"bytes"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"funeralquest/admin"
	"funeralquest/web"
)

func setup(t *testing.T) (*admin.Admin, *httptest.Server, string) {
	home := t.TempDir()
	os.MkdirAll(filepath.Join(home, "gamedata"), 0o755)
	ents, _ := os.ReadDir("../gamedata")
	for _, e := range ents {
		b, _ := os.ReadFile(filepath.Join("../gamedata", e.Name()))
		os.WriteFile(filepath.Join(home, "gamedata", e.Name()), b, 0o644)
	}
	pub := filepath.Join(home, "public")
	os.MkdirAll(filepath.Join(pub, "sysop"), 0o755)
	os.MkdirAll(filepath.Join(pub, "secret"), 0o755)
	os.WriteFile(filepath.Join(pub, "index.html"), []byte("<html>game</html>"), 0o644)
	os.WriteFile(filepath.Join(pub, "sysop", "index.html"), []byte("<html>sysop</html>"), 0o644)
	os.WriteFile(filepath.Join(pub, "secret", "x.txt"), []byte("x"), 0o644)
	os.WriteFile(filepath.Join(pub, ".env"), []byte("pw"), 0o644)
	a, err := admin.Open(home, nil)
	if err != nil {
		t.Fatal(err)
	}
	// the test client comes from 127.0.0.1, which the default allow list never bans; take it off
	os.WriteFile(filepath.Join(home, "data", "allowlist_ip.txt"), []byte("# none\n"), 0o644)
	s := web.New(a, pub, filepath.Join(home, "art"), web.Options{})
	ts := httptest.NewServer(s.Handler())
	t.Cleanup(ts.Close)
	return a, ts, home
}

func get(t *testing.T, url string, hdr map[string]string) (int, string, http.Header) {
	req, _ := http.NewRequest("GET", url, nil)
	for k, v := range hdr {
		req.Header.Set(k, v)
	}
	r, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer r.Body.Close()
	b, _ := io.ReadAll(r.Body)
	return r.StatusCode, string(b), r.Header
}

func post(t *testing.T, url string, body any, hdr map[string]string) (int, map[string]any) {
	b, _ := json.Marshal(body)
	req, _ := http.NewRequest("POST", url, bytes.NewReader(b))
	req.Header.Set("Content-Type", "application/json")
	for k, v := range hdr {
		req.Header.Set(k, v)
	}
	r, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer r.Body.Close()
	var m map[string]any
	json.NewDecoder(r.Body).Decode(&m)
	return r.StatusCode, m
}

func TestStaticAndHeaders(t *testing.T) {
	_, ts, _ := setup(t)
	code, body, h := get(t, ts.URL+"/", nil)
	if code != 200 || !strings.Contains(body, "game") {
		t.Fatalf("index: %d %q", code, body)
	}
	for _, k := range []string{"Content-Security-Policy", "X-Frame-Options", "X-Content-Type-Options", "Referrer-Policy"} {
		if h.Get(k) == "" {
			t.Errorf("missing header %s", k)
		}
	}
	if code, _, _ := get(t, ts.URL+"/secret/", nil); code != 404 {
		t.Errorf("directory listing served: %d", code)
	}
	if code, _, _ := get(t, ts.URL+"/.env", nil); code != 404 {
		t.Errorf("dotfile served: %d", code)
	}
	if code, _, _ := get(t, ts.URL+"/../data/world.json", nil); code == 200 {
		t.Errorf("path traversal")
	}
	req, _ := http.NewRequest("PUT", ts.URL+"/", nil)
	if r, _ := http.DefaultClient.Do(req); r.StatusCode != 405 {
		t.Errorf("PUT allowed: %d", r.StatusCode)
	}
}

func TestSysopAuth(t *testing.T) {
	a, ts, _ := setup(t)
	// off until a password is set
	if code, _ := post(t, ts.URL+"/api/sysop/login", map[string]any{"password": "x"}, nil); code != 503 {
		t.Fatalf("sysop pages should be off: %d", code)
	}
	if err := a.SetSysopPassword("short"); err == nil {
		t.Fatal("short password accepted")
	}
	a.SetSysopPassword("correct horse battery")
	if code, _, _ := get(t, ts.URL+"/api/sysop/status", nil); code != 401 {
		t.Fatalf("status without token: %d", code)
	}
	if code, _, _ := get(t, ts.URL+"/api/sysop/status", map[string]string{"Authorization": "Bearer " + strings.Repeat("a", 64)}); code != 401 {
		t.Fatalf("status with made-up token: %d", code)
	}
	_, m := post(t, ts.URL+"/api/sysop/login", map[string]any{"password": "correct horse battery"}, nil)
	tok, _ := m["token"].(string)
	if len(tok) != 64 {
		t.Fatalf("no token: %v", m)
	}
	auth := map[string]string{"Authorization": "Bearer " + tok}
	if code, body, _ := get(t, ts.URL+"/api/sysop/status", auth); code != 200 || !strings.Contains(body, "fingerprint") {
		t.Fatalf("status: %d %s", code, body)
	}
	// change a setting, bad value refused
	if _, m := post(t, ts.URL+"/api/sysop/settings", map[string]any{"values": map[string]any{"turns_per_day": "abc"}}, auth); m["error"] == nil {
		t.Fatal("bad setting accepted")
	}
	if _, m := post(t, ts.URL+"/api/sysop/settings", map[string]any{"values": map[string]any{"turns_per_day": "25"}}, auth); m["error"] != nil {
		t.Fatal(m["error"])
	}
	if a.Config().TurnsPerDay != 25 {
		t.Fatal("setting not saved")
	}
	// form posts (no JSON content type) are refused: no cross-site form tricks
	req, _ := http.NewRequest("POST", ts.URL+"/api/sysop/settings", strings.NewReader("values=1"))
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	req.Header.Set("Authorization", "Bearer "+tok)
	if r, _ := http.DefaultClient.Do(req); r.StatusCode != 415 {
		t.Fatalf("form post: %d", r.StatusCode)
	}
	// brute force: wrong passwords get the address banned
	for i := 0; i < 5; i++ {
		post(t, ts.URL+"/api/sysop/login", map[string]any{"password": "nope"}, nil)
	}
	if code, _, _ := get(t, ts.URL+"/", nil); code != 403 {
		t.Fatalf("brute forcer not banned: %d", code)
	}
	if len(a.Guard.Bans()) != 1 {
		t.Fatal("ban not recorded")
	}
	a.Guard.Unban("127.0.0.1")
	if code, _, _ := get(t, ts.URL+"/", nil); code != 200 {
		t.Fatalf("unban didn't work: %d", code)
	}
	// sysop_allow keeps everyone else out (404, the pages don't exist for them)
	a.SetSettings(map[string]string{"sysop_allow": "10.9.9.0/24"})
	if code, _, _ := get(t, ts.URL+"/sysop/", nil); code != 404 {
		t.Fatalf("sysop page from a disallowed address: %d", code)
	}
}

func TestBlockLists(t *testing.T) {
	a, ts, home := setup(t)
	os.WriteFile(filepath.Join(home, "data", "blocklist_ip.txt"), []byte("127.0.0.0/8\n"), 0o644)
	a.Guard.Check("1.1.1.1") // a check can be up to 3s stale; force a fresh read below
	for i := 0; i < 40; i++ {
		if ok, _ := a.Guard.Check("127.0.0.1"); !ok {
			break
		}
		sleep()
	}
	if code, _, _ := get(t, ts.URL+"/", nil); code != 403 {
		t.Fatalf("blocked IP got in: %d", code)
	}
	// the allow list beats the block list
	os.WriteFile(filepath.Join(home, "data", "allowlist_ip.txt"), []byte("127.0.0.1\n"), 0o644)
	for i := 0; i < 40; i++ {
		if ok, _ := a.Guard.Check("127.0.0.1"); ok {
			break
		}
		sleep()
	}
	if code, _, _ := get(t, ts.URL+"/", nil); code != 200 {
		t.Fatalf("allow list ignored: %d", code)
	}
}

func TestFirstTimeSetup(t *testing.T) {
	a, ts, home := setup(t)
	_, m := post(t, ts.URL+"/api/sysop/setup", map[string]any{"code": "WRONG", "password": "a good long password"}, nil)
	if m["error"] == nil || a.SysopPasswordSet() {
		t.Fatal("wrong setup code accepted")
	}
	b, err := os.ReadFile(filepath.Join(home, "data", "sysop-setup-code.txt"))
	if err != nil {
		t.Fatal("setup code file not written")
	}
	code := strings.TrimSpace(strings.Split(strings.Split(string(b), ": ")[1], "\r\n")[0])
	_, m = post(t, ts.URL+"/api/sysop/setup", map[string]any{"code": strings.ToLower(code), "password": "a good long password"}, nil)
	tok, _ := m["token"].(string)
	if len(tok) != 64 || !a.SysopPasswordSet() {
		t.Fatalf("setup failed: %v", m)
	}
	if code, _, _ := get(t, ts.URL+"/api/sysop/status", map[string]string{"Authorization": "Bearer " + tok}); code != 200 {
		t.Fatalf("setup session doesn't work: %d", code)
	}
	if _, err := os.Stat(filepath.Join(home, "data", "sysop-setup-code.txt")); err == nil {
		t.Fatal("setup code file left behind")
	}
	// can't be used again
	_, m = post(t, ts.URL+"/api/sysop/setup", map[string]any{"code": code, "password": "another password here"}, nil)
	if m["error"] == nil {
		t.Fatal("setup reused")
	}
}

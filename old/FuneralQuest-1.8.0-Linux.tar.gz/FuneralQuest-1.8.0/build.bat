@echo off
rem Builds Funeral Quest (fq) and the sysop editor (fqedit) for every supported system.
rem Needs Go 1.24+. Only Go's standard library is used, so no downloads are needed.
set GOARM=7
set CGO_ENABLED=0
call :build windows amd64 .exe
call :build windows 386   32.exe
call :build windows arm64 -arm64.exe
call :build linux   amd64 -linux
call :build linux   386   -linux32
call :build linux   arm64 -linux-arm64
call :build linux   arm   -linux-arm
call :build darwin  arm64 -macos-arm
call :build darwin  amd64 -macos-intel
call :build freebsd amd64 -freebsd
call :build freebsd arm64 -freebsd-arm64
call :build openbsd amd64 -openbsd
call :build netbsd  amd64 -netbsd
set GOOS=
set GOARCH=
set GOARM=
set CGO_ENABLED=
goto :eof

:build
set GOOS=%1
set GOARCH=%2
go build -trimpath -ldflags "-s -w" -o fq%3 . || exit /b 1
go build -trimpath -ldflags "-s -w" -o fqedit%3 ./cmd/fqedit || exit /b 1
echo built fq%3 and fqedit%3
goto :eof

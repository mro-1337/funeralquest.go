'use strict';
// Funeral Quest sysop pages. The log-on token lives only in this tab (sessionStorage).
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let token = sessionStorage.getItem('fq_sysop') || '';

async function api(path, body) {
  const opt = { headers: { Authorization: 'Bearer ' + token } };
  if (body !== undefined) {
    opt.method = 'POST';
    opt.headers['Content-Type'] = 'application/json';
    opt.body = JSON.stringify(body);
  }
  const r = await fetch('../api/sysop/' + path, opt);
  let j;
  try { j = await r.json(); } catch { j = { error: 'The server said ' + r.status }; }
  if (j.auth) { showLogin('Your session ended. Please log on again.'); throw new Error('auth'); }
  return j;
}

function say(el, text, err) { el.textContent = text || ''; el.classList.toggle('err', !!err); }
async function act(msgEl, fn) {
  say(msgEl, 'Working...');
  try {
    const r = await fn();
    if (r && r.error) { say(msgEl, r.error, true); return null; }
    say(msgEl, 'Done.');
    return r;
  } catch (e) { if (e.message !== 'auth') say(msgEl, e.message, true); return null; }
}

// ---------------------------------------------------------------- log-on & tabs

function showLogin(msg) {
  token = ''; sessionStorage.removeItem('fq_sysop');
  document.querySelectorAll('.tab').forEach((t) => { t.hidden = true; });
  $('tabs').hidden = true; $('login').hidden = false; $('setup').hidden = true;
  say($('loginMsg'), msg || '', !!msg);
  // no admin password yet? show the first-time setup instead
  fetch('../api/sysop/setup').then((r) => r.json()).then((j) => {
    if (j.needed) { $('login').hidden = true; $('setup').hidden = false; }
    $('sysCap').hidden = !j.captcha;
    $('sysCapIn').required = !!j.captcha;
    if (j.captcha) newSysStone();
  }).catch(() => {});
}
async function newSysStone() {
  try {
    const j = await (await fetch('../api/sysop/captcha', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })).json();
    $('sysCapImg').src = '../api/captcha/' + j.id + '.png';
    $('sysCapImg').dataset.id = j.id;
    $('sysCapIn').value = '';
  } catch { /* offline */ }
}
$('sysCapNew').addEventListener('click', (e) => { e.preventDefault(); newSysStone(); });

$('setupForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  if ($('setupPw').value !== $('setupPw2').value) { say($('setupMsg'), "The passwords don't match.", true); return; }
  say($('setupMsg'), 'Setting up...');
  const r = await fetch('../api/sysop/setup', { method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ code: $('setupCode').value, password: $('setupPw').value }) });
  const j = await r.json().catch(() => ({ error: 'No answer from the server.' }));
  if (j.error) { say($('setupMsg'), j.error, true); return; }
  $('setupPw').value = $('setupPw2').value = '';
  token = j.token; sessionStorage.setItem('fq_sysop', token);
  $('setup').hidden = true;
  start();
});

$('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  say($('loginMsg'), 'Checking...');
  const r = await fetch('../api/sysop/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password: $('pw').value, captcha_id: $('sysCapImg').dataset.id || '', captcha: $('sysCapIn').value }) });
  const j = await r.json().catch(() => ({ error: 'No answer from the server.' }));
  $('pw').value = '';
  if (j.error) { say($('loginMsg'), j.error, true); if (!$('sysCap').hidden) newSysStone(); return; }
  token = j.token; sessionStorage.setItem('fq_sysop', token);
  start();
});

$('logout').addEventListener('click', async () => { try { await api('logout', {}); } catch { /* ignore */ } showLogin(); });

const loaders = {};
function openTab(name) {
  document.querySelectorAll('.tab').forEach((t) => { t.hidden = t.id !== name; });
  document.querySelectorAll('#tabs button[data-tab]').forEach((b) => b.classList.toggle('on', b.dataset.tab === name));
  location.hash = name;
  if (loaders[name]) loaders[name]().catch(() => {});
}
document.querySelectorAll('#tabs button[data-tab]').forEach((b) => b.addEventListener('click', () => openTab(b.dataset.tab)));

function start() {
  $('login').hidden = true; $('tabs').hidden = false;
  const want = location.hash.slice(1);
  openTab(loaders[want] ? want : 'status');
}

// ---------------------------------------------------------------- status

loaders.status = async () => {
  const s = await api('status');
  const card = (n, label) => `<div class="stat"><b>${esc(n)}</b><span>${esc(label)}</span></div>`;
  const warn = s.warnings || [];
  $('statusWarn').hidden = !warn.length;
  $('statusWarn').innerHTML = warn.length ? `<h2>Linked towns need attention</h2><ul>${warn.map((w) => `<li>${esc(w)}</li>`).join('')}</ul><p class="help">See the Network tab to compare settings and copy theirs.</p>` : '';
  $('onNow').textContent = (s.on_now || []).length ? s.on_now.join(', ') : 'Nobody right now.';
  api('notes').then((n) => drawNotesBadge(n)).catch(() => {});
  api('update').then((u) => {
    const st = u.status || {};
    const show = st.available && st.latest;
    $('updateNote').hidden = !show;
    $('updateNote').innerHTML = show ? `<h2>Funeral Quest ${esc(st.latest.version)} is out</h2><p class="help">You have ${esc(st.current)}. <a href="#updates" id="goUpdates">See what's new and install it</a>.</p>` : '';
    if (show) $('goUpdates').addEventListener('click', (e) => { e.preventDefault(); openTab('updates'); });
  }).catch(() => {});
  $('statusCards').innerHTML = card(s.version, 'game version') + card(s.town, 'town') + card(s.day, 'game day') + card(s.players, 'open parlors') + card(s.online, 'playing now')
    + card(s.mail, 'letters waiting') + card(s.bans, 'addresses banned') + card(s.links, 'linked towns') + card(s.pending, 'link requests waiting');
};

// ---------------------------------------------------------------- settings

let settings = [];
function settingRow(s) {
  let input;
  if (s.kind === 'bool') {
    input = `<select data-key="${esc(s.key)}"><option value="no">No</option><option value="yes"${s.value === 'true' ? ' selected' : ''}>Yes</option></select>`;
  } else {
    const wide = s.kind === 'text' && s.max > 40;
    input = `<input data-key="${esc(s.key)}" value="${esc(s.value)}"${wide ? ' style="width:100%"' : ''}>`;
  }
  return `<div class="setting${s.kind === 'text' && s.max > 40 ? ' wide' : ''}"><div class="k">${esc(s.label)}</div>${input}<div class="h">${esc(s.help)}</div></div>`;
}
loaders.settings = async () => {
  const r = await api('settings');
  settings = r.settings;
  let html = '', group = '';
  for (const s of settings) {
    if (s.group === 'Updates') continue; // these live on the Updates tab
    if (s.group !== group) {
      if (group) html += '</fieldset>';
      group = s.group; html += `<fieldset><legend>${esc(group)}</legend>`;
      if (group.startsWith('Server')) html += '<p class="help">These take effect when fq web / fq telnet / the door next start. Command-line switches (--port, --cert...) override them.</p>';
    }
    let input;
    if (s.kind === 'bool') {
      input = `<select data-key="${esc(s.key)}"><option value="no">No</option><option value="yes"${s.value === 'true' ? ' selected' : ''}>Yes</option></select>`;
    } else {
      const wide = s.kind === 'text' && s.max > 40;
      input = `<input data-key="${esc(s.key)}" value="${esc(s.value)}"${wide ? ' style="width:100%"' : ''}>`;
    }
    html += `<div class="setting${s.kind === 'text' && s.max > 40 ? ' wide' : ''}"><div class="k">${esc(s.label)}</div>${input}<div class="h">${esc(s.help)}</div></div>`;
  }
  $('settingsForm').innerHTML = html + '</fieldset>';
};
$('saveSettings').addEventListener('click', () => act($('settingsMsg'), async () => {
  const values = {};
  document.querySelectorAll('#settingsForm [data-key]').forEach((el) => { values[el.dataset.key] = el.value; });
  const r = await api('settings', { values });
  if (!r.error) await loaders.settings();
  return r;
}));

// ---------------------------------------------------------------- players

let players = [], fields = [], editing = 0;
function drawPlayers() {
  const q = $('playerFilter').value.toLowerCase(), closed = $('showClosed').checked;
  $('playerRows').innerHTML = players.filter((p) => (closed || p.active) && (!q || (p.name + ' ' + p.parlor + ' ' + p.logon).toLowerCase().includes(q)))
    .map((p) => `<tr class="${p.active ? '' : 'closed'}"><td>${p.id}</td><td>${esc(p.name)}${p.online ? ' <span class="state linked">on</span>' : ''}</td>`
      + `<td>${esc(p.parlor)}</td><td>${p.level}</td><td>${p.exp.toLocaleString()}</td><td>$${p.money.toLocaleString()}</td><td>${p.turns}</td><td>${p.day_last}</td>`
      + `<td>${esc(p.logon || p.bbs_key)}</td><td><button class="small plain" data-edit="${p.id}">Edit</button></td></tr>`).join('');
}
loaders.players = async () => {
  const r = await api('players');
  players = r.players || []; fields = r.fields || [];
  drawPlayers();
};
$('playerFilter').addEventListener('input', drawPlayers);
$('showClosed').addEventListener('change', drawPlayers);
$('playerRows').addEventListener('click', async (e) => {
  const id = e.target.dataset.edit;
  if (!id) return;
  const r = await api('player?id=' + encodeURIComponent(id));
  if (r.error) return;
  editing = +id;
  const p = r.player;
  $('peTitle').textContent = `${p.name} of ${p.parlor}` + (p.bbs_key ? ` (BBS: ${p.bbs_key})` : '');
  $('peForm').innerHTML = fields.map((f) => f.kind === 'bool'
    ? `<label>${esc(f.label)}<select data-f="${esc(f.key)}"><option value="no">No</option><option value="yes"${p[f.key] === 'yes' ? ' selected' : ''}>Yes</option></select></label>`
    : `<label>${esc(f.label)}<input data-f="${esc(f.key)}" value="${esc(p[f.key])}"></label>`).join('');
  $('playerEdit').hidden = false; say($('peMsg'), '');
  $('playerEdit').scrollIntoView({ behavior: 'smooth' });
});
$('peSave').addEventListener('click', () => act($('peMsg'), async () => {
  const values = {};
  document.querySelectorAll('#peForm [data-f]').forEach((el) => { values[el.dataset.f] = el.value; });
  const r = await api('player', { id: editing, values });
  if (!r.error) await loaders.players();
  return r;
}));
$('pePw').addEventListener('click', () => {
  const pw = prompt('New password for this player (4+ characters):');
  if (pw) act($('peMsg'), () => api('player/password', { id: editing, password: pw }));
});
$('peDelete').addEventListener('click', () => {
  if (!confirm('Delete this player for good? Their parlor and letters are removed. (To just close the parlor, set "Open" to No.)')) return;
  act($('peMsg'), async () => {
    const r = await api('player/delete', { id: editing });
    if (!r.error) { $('playerEdit').hidden = true; await loaders.players(); }
    return r;
  });
});
$('peClose').addEventListener('click', () => { $('playerEdit').hidden = true; });

// ---------------------------------------------------------------- texts

let texts = [], textKey = '';
loaders.texts = async () => {
  if (!texts.length) texts = (await api('texts')).texts;
  $('textList').innerHTML = texts.map((t) => `<li data-key="${esc(t.key)}" class="${t.key === textKey ? 'on' : ''}">${esc(t.title)}<small>${esc(t.file)}</small></li>`).join('');
};
async function openText(key) {
  const t = texts.find((x) => x.key === key);
  if (!t) return;
  const r = await api('text?key=' + encodeURIComponent(key));
  if (r.error) { say($('textMsg'), r.error, true); return; }
  textKey = key;
  $('textTitle').textContent = t.title + ' (' + t.file + ')';
  $('textHelp').textContent = t.help;
  $('textBody').value = r.content; $('textBody').disabled = false; $('saveText').disabled = false;
  say($('textMsg'), '');
  loaders.texts();
}
$('textList').addEventListener('click', (e) => { const li = e.target.closest('li'); if (li) openText(li.dataset.key); });
$('saveText').addEventListener('click', () => act($('textMsg'), () => api('text', { key: textKey, content: $('textBody').value })));
document.querySelectorAll('[data-text]').forEach((b) => b.addEventListener('click', async () => {
  openTab('texts');
  if (!texts.length) await loaders.texts();
  openText(b.dataset.text);
}));

// ---------------------------------------------------------------- game

$('postNews').addEventListener('click', () => act($('newsMsg'), async () => {
  const r = await api('news', { text: $('newsText').value });
  if (!r.error) $('newsText').value = '';
  return r;
}));
function drawBackups(list) {
  $('backupRows').innerHTML = (list || []).map((b) => `<tr><td>${esc(b.file)}</td><td>${(b.size / 1048576).toFixed(1)} MB</td><td>${esc(b.when)}</td></tr>`).join('')
    || '<tr><td colspan="3">No backups yet.</td></tr>';
}
$('runBackup').addEventListener('click', () => act($('backupMsg'), async () => {
  const r = await api('backup', {});
  if (!r.error) { drawBackups(r.backups); setTimeout(() => say($('backupMsg'), 'Saved ' + r.file), 0); }
  return r;
}));
$('runMaint').addEventListener('click', () => act($('maintMsg'), async () => {
  const r = await api('maint', {});
  if (!r.error) setTimeout(() => say($('maintMsg'), 'Done. It is now day ' + r.day + '.'), 0);
  return r;
}));
$('runReset').addEventListener('click', () => {
  if (!confirm('Really reset the game?')) return;
  act($('resetMsg'), () => api('reset', { confirm: $('resetConfirm').value, wipe: $('resetWipe').checked }));
});

// ---------------------------------------------------------------- security

async function loadCert() {
  const c = await api('cert');
  if (!$('certHosts').value) $('certHosts').value = c.hosts || '';
  const x = c.cert;
  $('certNow').textContent = !x ? 'HTTPS is off: the web server uses plain HTTP.'
    : x.error ? `Certificate file ${x.file}: ${x.error}`
      : `Using ${x.self_signed ? 'a self-signed' : 'a'} certificate for ${(x.names || []).join(', ')}, valid until ${new Date(x.expires).toLocaleDateString()}. SHA-256 fingerprint: ${x.fingerprint}.`
        + (c.serving_https ? '' : ' (The web server is still on plain HTTP: restart it to use this.)');
}
$('makeCert').addEventListener('click', () => {
  if (!confirm('Make a new self-signed certificate? Visitors will see a browser warning until they accept it.')) return;
  act($('certMsg'), async () => { const r = await api('cert', { action: 'make', hosts: $('certHosts').value }); await loadCert(); if (!r.error) setTimeout(() => say($('certMsg'), 'Made. Restart fq web to start using HTTPS.'), 0); return r; });
});
$('certOff').addEventListener('click', () => act($('certMsg'), async () => { const r = await api('cert', { action: 'off' }); await loadCert(); return r; }));

loaders.security = async () => {
  loadCert().catch(() => {});
  const r = await api('bans');
  $('myIP').textContent = r.me;
  const bans = r.bans || [];
  $('banRows').innerHTML = bans.length ? bans.map((b) => `<tr><td class="mono">${esc(b.ip)}</td><td>${esc(new Date(b.until).toLocaleString())}</td>`
    + `<td>${esc(b.reason)}</td><td>${b.count}</td><td><button class="small plain" data-unban="${esc(b.ip)}">Unban</button></td></tr>`).join('')
    : '<tr><td colspan="5" class="help">Nobody is banned right now.</td></tr>';
};
$('banRows').addEventListener('click', (e) => {
  const ip = e.target.dataset.unban;
  if (ip) act($('banMsg'), async () => { const r = await api('unban', { ip }); await loaders.security(); return r; });
});
$('banForm').addEventListener('submit', (e) => {
  e.preventDefault();
  act($('banMsg'), async () => {
    const r = await api('ban', { ip: $('banIP').value, minutes: $('banMins').value, reason: $('banReason').value });
    if (!r.error) { $('banIP').value = ''; $('banReason').value = ''; await loaders.security(); }
    return r;
  });
});

// ---------------------------------------------------------------- network

function ago(t) {
  const d = new Date(t);
  if (d.getFullYear() < 2000) return 'never';
  const s = Math.round((Date.now() - d) / 1000);
  if (s < 90) return s + 's ago';
  if (s < 5400) return Math.round(s / 60) + 'm ago';
  if (s < 172800) return Math.round(s / 3600) + 'h ago';
  return d.toLocaleDateString();
}
loaders.network = async () => {
  const r = await api('network');
  $('myFinger').textContent = r.fingerprint;
  $('myURL').textContent = r.public_url || '(not set: this town is outbound only. It connects out to linked towns, but they can\'t connect to it, so your players can\'t be visited or raided from other towns.)';
  $('myVer').textContent = r.version;
  $('autoAccept').checked = !!r.auto_accept;
  $('portOnly').checked = !!r.port_only;
  $('portOnly').disabled = !r.net_port && !r.port_only;
  $('portOnlyHelp').textContent = r.net_port
    ? `(network port ${r.net_port}, ${r.port_https ? 'HTTPS' : 'plain HTTP'}: other servers then connect there instead of the web port; the address above switches by itself)`
    : '(set a Network port under Settings → Server first, then restart fq web)';
  const peers = r.peers || [];
  const byId = Object.fromEntries(peers.map((p) => [p.id, p.name]));
  $('peerRows').innerHTML = peers.length ? peers.map((p) => {
    let st = p.state, label = p.state;
    if (p.state === 'linked' && !p.they_ok) { st = 'waiting'; label = 'waiting for them'; }
    if (p.state === 'pending') label = 'wants to link';
    if (p.state === 'keychange') label = 'KEY CHANGED';
    if (p.state === 'linked' && p.they_ok && p.reach) { st = 'waiting'; label = p.url ? 'not reachable' : 'outbound only'; }
    const last = [p.last_ok, p.last_in].sort().pop();
    let btns = '';
    if (p.state === 'pending' || p.state === 'keychange' || p.state === 'blocked') btns += `<button class="small" data-net="accept" data-id="${esc(p.id)}">Accept</button> `;
    if (p.state === 'linked') btns += `<button class="small plain" data-net="sync" data-id="${esc(p.id)}">Sync now</button> `;
    if (p.state !== 'blocked') btns += `<button class="small plain" data-net="block" data-id="${esc(p.id)}">Block</button> `;
    btns += `<button class="small danger" data-net="remove" data-id="${esc(p.id)}">Remove</button>`;
    const q = (r.queued || {})[p.id];
    const warn = (p.version_note ? 1 : 0) + (p.diffs || []).length;
    return `<tr><td><b>${esc(p.name)}</b>${p.state === 'linked' && p.they_ok ? `<br><small class="help">day ${p.day}, ${p.players} parlors, ${p.online} on, version ${esc(p.game_version || '?')}</small>` : ''}`
      + `${warn ? '<br><span class="state pending">needs attention (see below)</span>' : ''}</td>`
      + `<td><span class="state ${st}">${esc(label)}</span>${q ? `<br><small class="help">${q} letters waiting</small>` : ''}`
      + `${p.reach ? `<br><small class="help">${esc(p.reach)}</small>` : ''}</td>`
      + `<td class="mono">${esc(p.url || (p.via && byId[p.via] ? 'through ' + byId[p.via] : '(none: connects out only)'))}</td><td class="mono">${esc(p.fingerprint)}</td>`
      + `<td>${esc(ago(last))}${p.last_err ? `<br><small class="msg err">${esc(p.last_err)}</small>` : ''}${p.note ? `<br><small class="help">${esc(p.note)}</small>` : ''}</td>`
      + `<td>${btns}</td></tr>`;
  }).join('') : '<tr><td colspan="6" class="help">No linked servers yet.</td></tr>';
  const intros = r.intros || [];
  $('introList').innerHTML = intros.length ? '<div class="card"><h2>Introduced towns</h2>'
    + `<p class="help">${r.intro_off ? 'This town doesn\'t follow introductions (Settings → Network), so these wait for you: link to them by address if you want them.' : 'Your linked towns introduced these. This town sends each a link request by itself (retrying if it can\'t reach them yet).'}</p>`
    + '<table class="grid"><thead><tr><th>Town</th><th>Address</th><th>Fingerprint</th><th>Introduced by</th><th>Status</th></tr></thead><tbody>'
    + intros.map((i) => `<tr><td>${esc(i.name)}</td><td class="mono">${esc(i.url || 'through ' + i.by_name)}</td><td class="mono">${esc(i.fingerprint)}</td><td>${esc(i.by_name)}</td>`
      + `<td>${i.last_err ? `<small class="msg err">${esc(i.last_err)}</small><br><small class="help">tried ${i.tries} time(s)</small>` : '<small class="help">linking soon</small>'}</td></tr>`).join('')
    + '</tbody></table></div>' : '';
  $('voteTown').textContent = (await api('status')).town;
  drawVotes(r);
  // version and game-settings differences, per town
  $('peerProblems').innerHTML = peers.filter((p) => p.version_note || (p.diffs || []).length).map((p) => {
    let h = `<div class="card warn"><h2>${esc(p.name)}</h2>`;
    if (p.version_note) h += `<p><b>Version:</b> ${esc(p.version_note)}</p>`;
    const d = p.diffs || [];
    if (d.length) {
      h += `<p>These game settings are different. Both towns should play by the same rules: agree with ${esc(p.name)}'s sysop which values to use. Either of you can copy the other's.</p>`
        + '<table class="grid diff"><thead><tr><th>Setting</th><th>Here</th><th>There</th><th></th></tr></thead><tbody>'
        + d.map((x) => `<tr><td>${esc(x.label)}</td><td>${esc(x.ours)}</td><td>${esc(x.theirs)}</td>`
          + `<td><button class="small plain" data-use="${esc(x.key)}" data-id="${esc(p.id)}">Use theirs</button></td></tr>`).join('')
        + `</tbody></table><div class="bar"><button class="small" data-use="" data-id="${esc(p.id)}">Use all of ${esc(p.name)}'s settings</button></div>`;
    }
    return h + '</div>';
  }).join('');
};
function drawVotes(r) {
  $('voteApplyNote').textContent = r.vote_apply ? 'This town applies votes that pass.' : 'This town does NOT apply votes that pass (Settings → Network → Don\'t apply settings votes).';
  const votes = r.votes || [];
  $('voteList').innerHTML = votes.length ? votes.map((v) => {
    let h = `<div class="card${v.status === 'open' && !v.mine && !v.my_vote ? ' warn' : ''}"><b>${v.mine ? 'Your proposal' : esc(v.from_name) + ' asks you to accept its settings'}</b> <span class="help">${esc(v.summary)}</span>`;
    if (v.mine) h += `<p class="help">${v.yes} yes, ${v.no} no, ${v.total - v.yes - v.no} not voted yet, of ${v.total} towns. Needs more than ${Math.floor(v.total / 2)} yes.</p>`;
    const d = v.diffs || [];
    if (!v.mine) {
      h += d.length ? '<table class="grid diff"><thead><tr><th>Setting</th><th>Yours now</th><th>Proposed</th></tr></thead><tbody>'
        + d.map((x) => `<tr><td>${esc(x.label)}</td><td>${esc(x.ours)}</td><td>${esc(x.theirs)}</td></tr>`).join('') + '</tbody></table>'
        : '<p class="help">The proposed settings are the same as yours.</p>';
    }
    if (v.note) h += `<p class="help">${esc(v.note)}</p>`;
    if (!v.mine && v.status === 'open') {
      h += `<div class="bar"><button class="small" data-vote="true" data-id="${esc(v.id)}">Accept</button> <button class="small danger" data-vote="false" data-id="${esc(v.id)}">Decline</button>${v.my_vote ? ` <span class="help">you voted ${esc(v.my_vote)}; you can change it until the vote ends</span>` : ''}</div>`;
    }
    return h + '</div>';
  }).join('') : '<p class="help">No votes yet.</p>';
}
$('voteList').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-vote]');
  if (!b) return;
  act($('voteMsg'), async () => { const r = await api('network', { action: 'vote', id: b.dataset.id, yes: b.dataset.vote }); await loaders.network(); return r; });
});
$('proposeBtn').addEventListener('click', () => {
  if (!confirm('Ask every linked town to switch to this town\'s game settings?')) return;
  act($('voteMsg'), async () => {
    const r = await api('network', { action: 'propose' });
    if (!r.error) { await loaders.network(); setTimeout(() => say($('voteMsg'), `Sent to ${r.voters} town(s). Their sysops will be asked to accept.`), 0); }
    return r;
  });
});
$('peerProblems').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-use]');
  if (!b) return;
  if (!b.dataset.use && !confirm('Change all the differing settings to the other town\'s values?')) return;
  act($('linkMsg'), async () => { const r = await api('network', { action: 'use_theirs', id: b.dataset.id, key: b.dataset.use }); await loaders.network(); return r; });
});
$('portOnly').addEventListener('change', () => act($('autoMsg'), async () => {
  const r = await api('network', { action: 'port_only', on: $('portOnly').checked ? 'yes' : 'no' });
  await loaders.network();
  return r;
}));
$('autoAccept').addEventListener('change', () => act($('autoMsg'), () => api('network', { action: 'auto_accept', on: $('autoAccept').checked ? 'yes' : 'no' })));
$('linkForm').addEventListener('submit', (e) => {
  e.preventDefault();
  act($('linkMsg'), async () => {
    const r = await api('network', { action: 'add', url: $('linkURL').value });
    if (!r.error) {
      $('linkURL').value = '';
      await loaders.network();
      setTimeout(() => say($('linkMsg'), `Linked to ${r.peer.name}. Check its fingerprint with the other sysop: ${r.fingerprint}`), 0);
    }
    return r;
  });
});
$('peerRows').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-net]');
  if (!b) return;
  if (b.dataset.net === 'remove' && !confirm('Remove this server? Its players disappear from your rankings and waiting letters are dropped.')) return;
  act($('linkMsg'), async () => { const r = await api('network', { action: b.dataset.net, id: b.dataset.id }); await loaders.network(); return r; });
});

// ---------------------------------------------------------------- logs

loaders.logs = async () => {
  const name = $('logName').value || 'server.log';
  const r = await api('log?name=' + encodeURIComponent(name));
  if (!$('logName').options.length) $('logName').innerHTML = (r.logs || []).map((l) => `<option>${esc(l)}</option>`).join('');
  $('logText').textContent = r.error || r.text;
  $('logText').scrollTop = $('logText').scrollHeight;
};
$('logName').addEventListener('change', () => loaders.logs());
$('refreshLog').addEventListener('click', () => loaders.logs());

// ---------------------------------------------------------------- password

$('pwForm').addEventListener('submit', (e) => {
  e.preventDefault();
  if ($('pwNew').value !== $('pwNew2').value) { say($('pwMsg'), "The new passwords don't match.", true); return; }
  act($('pwMsg'), async () => {
    const r = await api('password', { old: $('pwOld').value, new: $('pwNew').value });
    if (r.relogin) showLogin('Password changed. Log on with the new one.');
    return r;
  });
});

$('offForm').addEventListener('submit', (e) => {
  e.preventDefault();
  if (!confirm('Turn off the admin pages? You will be logged off.')) return;
  act($('offMsg'), async () => {
    const r = await api('disable', { password: $('offPw').value });
    if (!r.error) showLogin('The admin pages are off.');
    return r;
  });
});

if (token) start(); else showLogin();
loaders.game = async () => { const r = await api('backups'); if (!r.error) drawBackups(r.backups); };

// ---------------------------------------------------------------- updates

let updTimer = 0;
let updRestarting = false;
function drawUpdate(u) {
  const st = u.status || {};
  const repo = u.repo || '';
  $('updRepo').textContent = 'github.com/' + repo;
  $('updRepo').href = 'https://github.com/' + repo + '/releases';
  const when = (t) => (t && !t.startsWith('0001') ? new Date(t).toLocaleString() : '');
  const lines = [`<p>Installed: <b>${esc(st.current)}</b></p>`];
  if (st.latest) {
    lines.push(`<p>Newest release: <b>${esc(st.latest.version)}</b>${st.latest.published ? ' (' + esc(when(st.latest.published)) + ')' : ''}${st.available ? ' <b class="msg">: newer than yours</b>' : ': you have it'}</p>`);
  }
  if (st.checked && when(st.checked)) lines.push(`<p class="help">Last checked ${esc(when(st.checked))}.</p>`);
  if (!st.supported) lines.push('<p class="help">There are no ready-made programs for this kind of computer; update by building from the source package.</p>');
  if (st.last && st.last.to) {
    lines.push(`<p class="help">Last update: ${esc(st.last.from)} to ${esc(st.last.to)} on ${esc(when(st.last.when))}${st.last.undone_at && !st.last.undone_at.startsWith('0001') ? ' (undone)' : ''}. Data backup: ${esc(st.last.backup)}.${(st.last.kept || []).length ? ' Edited texts kept: ' + esc(st.last.kept.join(', ')) + ' (new versions saved beside them as .new).' : ''}</p>`);
  }
  $('updAuto').checked = !!u.auto;
  if (u.exit_only) lines.push('<p class="help">After installing, fq exits and your service manager starts the new version (see Update settings below).</p>');
  $('updState').innerHTML = lines.join('');
  const busy = !!st.busy;
  $('updInstall').hidden = !(st.available && st.supported && st.latest && st.latest.asset && st.latest.asset.url);
  $('updInstall').textContent = st.latest ? 'Install ' + st.latest.version : 'Install update';
  $('updUndo').hidden = !st.can_undo;
  if (st.can_undo && st.last) $('updUndo').textContent = 'Go back to ' + st.last.from;
  ['updCheck', 'updInstall', 'updUndo'].forEach((id) => { $(id).disabled = busy; });
  if (busy) say($('updMsg'), 'Working: ' + st.busy + '...');
  else if (st.error) say($('updMsg'), st.error, true);
  else if (st.message) say($('updMsg'), st.message);
  const notes = st.latest && st.latest.notes;
  $('updNotesCard').hidden = !notes;
  if (notes) { $('updNotesTitle').textContent = "What's new in " + st.latest.version; $('updNotes').textContent = notes; }
  clearTimeout(updTimer);
  // keep watching while it works, and through the restart
  updRestarting = /Restarting/.test(st.message || '');
  if (busy || updRestarting) updTimer = setTimeout(pollUpdate, 1500);
}
async function pollUpdate() {
  try {
    const u = await api('update');
    if (!u.error) drawUpdate(u);
  } catch (e) {
    if (e.message === 'auth') {
      if (updRestarting) showLogin('The game has restarted. Log on again to see the version it is running.');
    } else { say($('updMsg'), 'Restarting... (this page reconnects by itself)'); updTimer = setTimeout(pollUpdate, 2000); }
  }
}
loaders.updates = async () => {
  const u = await api('update');
  if (!u.error) drawUpdate(u);
  // the other update settings (the automatic switch is at the top)
  const r = await api('settings');
  const rows = (r.settings || []).filter((x) => x.group === 'Updates' && x.key !== 'update_auto');
  $('updSettings').innerHTML = rows.map(settingRow).join('');
};
$('updSave').addEventListener('click', async () => {
  const values = {};
  document.querySelectorAll('#updSettings [data-key]').forEach((el) => { values[el.dataset.key] = el.value; });
  const r = await api('settings', { values });
  if (r.error) { say($('updSetMsg'), r.error, true); return; }
  say($('updSetMsg'), 'Saved.');
  loaders.updates();
});
$('updCheck').addEventListener('click', async () => {
  say($('updMsg'), 'Asking GitHub...');
  const u = await api('update/check', {});
  if (u.error) say($('updMsg'), u.error, true); else { say($('updMsg'), ''); drawUpdate(u); }
});
$('updInstall').addEventListener('click', async () => {
  if (!confirm('Install the update now? The data folder is backed up first, and the game restarts when it is done (web players have to log on again).')) return;
  const u = await api('update/install', {});
  if (u.error) say($('updMsg'), u.error, true);
  pollUpdate();
});
$('updUndo').addEventListener('click', async () => {
  if (!confirm('Put the previous version back? The data folder is not changed. The game restarts when it is done.')) return;
  const u = await api('update/undo', {});
  if (u.error) say($('updMsg'), u.error, true);
  pollUpdate();
});

// ---------------------------------------------------------------- notes for the operator

function drawNotesBadge(n) {
  const k = (n && n.unread) || 0;
  $('notesBadge').hidden = !k;
  $('notesBadge').textContent = k;
  $('notesNote').hidden = !k;
  $('notesNote').innerHTML = k ? `<h2>${k} new message${k === 1 ? '' : 's'} in your mailbox</h2><p class="help">Forgotten passwords, Contact messages, player edits and notes from other sysops. <a href="#notes" id="goNotes">Read ${k === 1 ? 'it' : 'them'}</a>.</p>` : '';
  if (k) $('goNotes').addEventListener('click', (e) => { e.preventDefault(); openTab('notes'); });
}
loaders.notes = async () => {
  const n = await api('notes');
  if (n.error) return;
  const notes = n.notes || [];
  const towns = n.towns || [];
  const keep = $('writeTo').value;
  $('writeTo').innerHTML = (towns.length ? `<option value="">Every linked town (${towns.length})</option>` : '<option value="">(no linked towns)</option>')
    + towns.map((t) => `<option value="${esc(t.id)}">${esc(t.name)}</option>`).join('');
  if (keep) $('writeTo').value = keep;
  $('notesList').innerHTML = notes.length ? notes.map((m) => {
    const pid = /player #(\d+)/.exec(m.account || '');
    const subject = m.kind === 'Forgotten password' ? 'Your Funeral Quest password' : 'Re: your note to the Funeral Quest sysop';
    const mail = /@/.test(m.email || '') ? `mailto:${encodeURIComponent(m.email)}?subject=${encodeURIComponent(subject)}` : '';
    const row = (k, v) => v ? `<dt>${k}</dt><dd>${esc(v)}</dd>` : '';
    return `<div class="note ${m.read ? '' : 'unread'}" data-file="${esc(m.file)}">
      <h3>${esc(m.kind)}${m.read ? '' : ' <span class="badge">new</span>'} <small class="help">${esc(new Date(m.date).toLocaleString())}</small></h3>
      <dl>${row('Logon name', m.logon)}${row('Account', m.account)}${row('E-mail on file', m.on_file)}${row(m.peer ? 'Town' : 'Name', m.name)}${row('Reach them at', m.email)}${row('From', m.from)}</dl>
      ${m.text ? `<pre>${esc(m.text)}</pre>` : ''}
      <div class="bar">
        ${pid ? `<input type="text" class="newpw" placeholder="new password" autocomplete="off"> <button class="small" data-note="setpw" data-pid="${pid[1]}">Set new password</button> ` : ''}
        ${mail ? `<a class="mail" href="${mail}">E-mail them</a> ` : ''}
        ${m.peer ? `<button class="small plain" data-note="reply" data-peer="${esc(m.peer)}">Reply</button> ` : ''}
        ${m.read ? '' : '<button class="small plain" data-note="read">Mark read</button> '}
        <button class="small danger" data-note="delete">Delete</button>
        <span class="msg"></span>
      </div>
      <p class="help">File: data/operator/${esc(m.file)}</p>
    </div>`;
  }).join('') : '<p class="help">Your desk is clear: no notes.</p>';
  drawNotesBadge(n);
};
$('notesList').addEventListener('click', async (e) => {
  const b = e.target.closest('button[data-note]');
  if (!b) return;
  const card = b.closest('.note');
  const file = card.dataset.file;
  const msg = card.querySelector('.msg');
  if (b.dataset.note === 'setpw') {
    const pw = card.querySelector('.newpw').value.trim();
    if (pw.length < 4) { say(msg, 'Use at least 4 characters.', true); return; }
    const r = await api('player/password', { id: Number(b.dataset.pid), password: pw });
    if (r.error) { say(msg, r.error, true); return; }
    await api('notes/read', { file });
    const a = card.querySelector('a.mail');
    if (a) a.href += '&body=' + encodeURIComponent(`Hello,\n\nYour Funeral Quest password has been reset. Log on with your usual logon name and this password:\n\n    ${pw}\n\nSee you in Deathville.`);
    say(msg, `Done. Now e-mail the new password (${pw}) to the player${a ? ': the E-mail them button has it written out' : ''}.`);
    return;
  }
  if (b.dataset.note === 'reply') {
    $('writeTo').value = b.dataset.peer;
    const subj = /^Subject: (.*)$/m.exec(card.querySelector('pre')?.textContent || '');
    $('writeSubj').value = subj ? (subj[1].startsWith('Re: ') ? subj[1] : 'Re: ' + subj[1]) : 'Re: your note';
    $('writeText').focus();
    $('writeForm').scrollIntoView({ behavior: 'smooth' });
    if (!card.classList.contains('unread')) return;
    await api('notes/read', { file });
    return;
  }
  if (b.dataset.note === 'delete' && !confirm('Delete this note?')) return;
  const r = await api('notes/' + b.dataset.note, { file });
  if (r.error) { say(msg, r.error, true); return; }
  loaders.notes();
});

$('writeForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const r = await api('notes/write', { town: $('writeTo').value, subject: $('writeSubj').value, text: $('writeText').value });
  if (r.error) { say($('writeMsg'), r.error, true); return; }
  say($('writeMsg'), `Sent to ${r.sent} town${r.sent === 1 ? '' : 's'}: it goes out with the next sync.`);
  $('writeSubj').value = ''; $('writeText').value = '';
  loaders.notes();
});

$('updAuto').addEventListener('change', async () => {
  const on = $('updAuto').checked;
  const r = await api('settings', { values: { update_auto: on ? '1' : '0' } });
  if (r && r.error) { $('updAuto').checked = !on; say($('updMsg'), r.error, true); return; }
  say($('updMsg'), on ? 'Automatic updates are on. New versions will install by themselves once nobody is playing.' : 'Automatic updates are off. New versions wait for you to click Install.');
});

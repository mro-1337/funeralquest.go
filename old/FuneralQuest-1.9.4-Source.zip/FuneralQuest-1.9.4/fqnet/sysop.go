package fqnet

// Notes between the sysops of linked towns. They land on the receiving sysop's desk (the Notes
// tab of the web admin pages, and the console). Two kinds:
//   - "Player edited": sent to every linked town when a sysop changes a player by hand (who,
//     what changed, when, on which town and with what), so nobody quietly boosts their own
//     parlor in the shared rankings.
//   - "Message from a sysop": written on the web admin pages to one linked town or to all.
// They ride along on the regular sync, both ways (so towns that connect out only get them
// too), and are sent again until the other side says it has them.

import (
	"path/filepath"
	"strings"
	"time"

	"funeralquest/opmsg"
)

type sysopNote struct {
	ID   string    `json:"id"`
	Kind string    `json:"kind"`
	At   time.Time `json:"at"`
	Town string    `json:"town"`           // the town that sent it
	Who  string    `json:"who,omitempty"`  // the player edited
	Subj string    `json:"subj,omitempty"` // message subject
	Text string    `json:"text"`
	Via  string    `json:"via,omitempty"` // what made the edit (web admin pages, fqedit, fq admin)
}

type sysopWire struct {
	SysopNotes []sysopNote `json:"sysop_notes,omitempty"`
	SysopSeen  []string    `json:"sysop_seen,omitempty"` // your notes we have, so you can stop sending them
}

const (
	SysopKindEdit = "Player edited"
	SysopKindMsg  = "Message from a sysop"
)

// QueueSysopNote sends a note to one linked town (to = its ID) or to all of them (to = "").
func (n *Net) QueueSysopNote(to, kind, who, subj, text, via string) (int, error) {
	note := sysopNote{ID: newJobID(), Kind: kind, At: time.Now(), Town: n.cfg().ServerName, Who: who, Subj: subj, Text: text, Via: via}
	if len(note.Text) > 4000 {
		note.Text = note.Text[:4000]
	}
	sent := 0
	err := n.tx(func(st *state) error {
		if st.SysopOut == nil {
			st.SysopOut = map[string][]sysopNote{}
		}
		for _, p := range st.Peers {
			if p.State != Linked || (to != "" && p.ID != to) {
				continue
			}
			q := append(st.SysopOut[p.ID], note)
			if len(q) > 200 {
				q = q[len(q)-200:]
			}
			st.SysopOut[p.ID] = q
			sent++
		}
		return nil
	})
	n.Kick()
	return sent, err
}

// sysopFor is what goes to a peer in a sync: our notes for it, and which of its notes we have.
func (n *Net) sysopFor(peer string) sysopWire {
	st := n.view()
	return sysopWire{SysopNotes: st.SysopOut[peer], SysopSeen: st.SysopIn[peer]}
}

// sysopIn takes a peer's notes (onto our sysop's desk) and drops ours it says it has.
func (n *Net) sysopIn(peer, town string, w sysopWire) {
	if len(w.SysopNotes) == 0 && len(w.SysopSeen) == 0 {
		return
	}
	var fresh []sysopNote
	n.tx(func(st *state) error {
		if len(w.SysopSeen) > 0 && len(st.SysopOut[peer]) > 0 {
			have := map[string]bool{}
			for _, id := range w.SysopSeen {
				have[id] = true
			}
			var keep []sysopNote
			for _, x := range st.SysopOut[peer] {
				if !have[x.ID] {
					keep = append(keep, x)
				}
			}
			st.SysopOut[peer] = keep
		}
		if st.SysopIn == nil {
			st.SysopIn = map[string][]string{}
		}
		seen := map[string]bool{}
		for _, id := range st.SysopIn[peer] {
			seen[id] = true
		}
		for _, x := range w.SysopNotes {
			if x.ID == "" || seen[x.ID] || len(fresh) >= 50 {
				continue
			}
			seen[x.ID] = true
			fresh = append(fresh, x)
			st.SysopIn[peer] = append(st.SysopIn[peer], x.ID)
		}
		if l := st.SysopIn[peer]; len(l) > 300 {
			st.SysopIn[peer] = l[len(l)-300:]
		}
		return nil
	})
	box := opmsg.Open(filepath.Dir(n.Dir))
	for _, x := range fresh {
		m := opmsg.Msg{Kind: x.Kind, From: "the sysop of " + oneLine(town) + " (linked town)", Name: oneLine(x.Town), Text: x.Text, Account: oneLine(x.Who), Logon: "", Email: "", OnFile: ""}
		if x.Kind == SysopKindMsg && x.Subj != "" {
			m.Text = "Subject: " + oneLine(x.Subj) + "\n\n" + x.Text
		}
		m.Peer = peer
		box.Put(m)
		n.Log("network: a note from the sysop of %s is on your desk (%s)", town, x.Kind)
	}
}

func oneLine(s string) string {
	s = strings.Map(func(r rune) rune {
		if r < 32 {
			return ' '
		}
		return r
	}, s)
	if len(s) > 100 {
		s = s[:100]
	}
	return strings.TrimSpace(s)
}

// LinkedTowns lists the linked towns (ID and name), for writing to their sysops.
func (n *Net) LinkedTowns() []map[string]string {
	var out []map[string]string
	for _, p := range n.Peers() {
		if p.State == Linked {
			out = append(out, map[string]string{"id": p.ID, "name": p.Name})
		}
	}
	return out
}

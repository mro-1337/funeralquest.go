package engine

import (
	"strings"
	"testing"
)

func TestChurchAndGraveyard(t *testing.T) {
	g := newTestGame(t)
	p, _ := g.CreatePlayer(NewPlayer{Name: "Digger", Parlor: "Dig Inc", Male: true, Logon: "dig", Password: "x"})
	g.Store.Tx(func(w *World) error {
		q := w.Player(p.ID)
		q.Coffins, q.Karma, q.Luck = [3]int{20, 5, 5}, 40, 50
		w.Config.ChallengesOff = true // a finished challenge would level the player up and pay tags
		return nil
	})
	s := g.NewSession(p.ID, "web")
	s.Act(Action{Cmd: "main"})
	s.Act(Action{Cmd: "main"})
	get := func() Player {
		var out Player
		g.View(func(w *World) { out = *w.Player(p.ID) })
		return out
	}

	// Confession: below 50 karma, costs wood tags, once a day, never above 50.
	s.Act(Action{Cmd: "church"})
	sc := s.Act(Action{Cmd: "church", Sub: "confess"})
	if me := get(); me.Karma != 50 || me.Coffins[Wood] != 18 {
		t.Fatalf("confess: karma %d wood %d: %s", me.Karma, me.Coffins[Wood], sc.Text)
	}
	sc = s.Act(Action{Cmd: "church", Sub: "confess"})
	if !strings.Contains(sc.Text, "nothing worth") && !strings.Contains(sc.Text, "Once a day") {
		t.Fatal("second confession: " + sc.Text)
	}

	// Donations: gold is 4 karma, capped at 8 a day.
	gold0 := get().Coffins[Gold] // (a morning event or level-up may have handed out tags)
	s.Act(Action{Cmd: "church", Sub: "give_g"})
	s.Act(Action{Cmd: "church", Sub: "give_g"})
	sc = s.Act(Action{Cmd: "church", Sub: "give_g"})
	if me := get(); me.Karma != 58 || me.Coffins[Gold] != gold0-2 {
		t.Fatalf("donate: karma %d gold %d (was %d) level %d xp %d: %s", me.Karma, me.Coffins[Gold], gold0, me.Level, me.XP, sc.Text)
	}

	// Blessing needs 70 karma.
	sc = s.Act(Action{Cmd: "church", Sub: "bless"})
	if !strings.Contains(sc.Text, "cleaner") {
		t.Fatal("bless with low karma: " + sc.Text)
	}
	g.Store.Tx(func(w *World) error { w.Player(p.ID).Karma = 80; return nil })
	s.Act(Action{Cmd: "church", Sub: "bless"})
	if me := get(); me.Luck != 53 {
		t.Fatalf("bless: luck %d", me.Luck)
	}

	// Graveyard: quests don't cost turns (they work with none left), stop at the daily
	// limit, digging costs karma.
	g.Store.Tx(func(w *World) error { w.Player(p.ID).Turns = 0; return nil })
	before := get()
	s.Act(Action{Cmd: "graveyard"})
	sc = s.Act(Action{Cmd: "graveyard", Sub: "dig"})
	after := get()
	if after.Turns != before.Turns || after.Karma != before.Karma-2 || strings.Contains(sc.Text, "too tired") {
		t.Fatalf("dig: turns %d->%d karma %d->%d: %s", before.Turns, after.Turns, before.Karma, after.Karma, sc.Text)
	}
	// Riddle: the right answer is wherever the session put it.
	sc = s.Act(Action{Cmd: "graveyard", Sub: "crypt"})
	if len(sc.Buttons) != 3 {
		t.Fatalf("crypt buttons: %+v", sc.Buttons)
	}
	exp := get().Exp
	sc = s.Act(Action{Cmd: "graveyard", Sub: sc.Buttons[s.riddleAns].Sub})
	if !strings.Contains(sc.Text, "Correct") || get().Exp <= exp {
		t.Fatal("riddle: " + sc.Text)
	}
	s.Act(Action{Cmd: "graveyard", Sub: "work"})
	s.Act(Action{Cmd: "graveyard", Sub: "ghoul"})
	sc = s.Act(Action{Cmd: "graveyard", Sub: "dig"})
	if !strings.Contains(sc.Text, "Closing time") {
		t.Fatal("quest limit: " + sc.Text)
	}
	if me := get(); me.HP < 1 {
		t.Fatal("graveyard killed the player")
	}
	sc = s.Act(Action{Cmd: "graveyard", Sub: "top"})
	if !strings.Contains(sc.Text, "plot(s) are filled") {
		t.Fatal("top: " + sc.Text)
	}
}

package engine

import (
	"strings"
	"testing"
)

func TestBar(t *testing.T) {
	g := newTestGame(t)
	p, err := g.CreatePlayer(NewPlayer{Name: "Barfly", Parlor: "Barfly's", Logon: "barfly", Password: "secret", Email: "b@example.com"})
	if err != nil {
		t.Fatal(err)
	}
	s := g.NewSession(p.ID, "web")
	g.Store.Tx(func(w *World) error { me := w.Player(p.ID); me.Money, me.Coffins[Gold] = 1000, 0; return nil })
	sc := s.Act(Action{Cmd: "cafe"})
	if sc.View != "chat" || len(sc.Buttons) != 3 {
		t.Fatalf("cafe: %+v", sc.Buttons)
	}
	sc = s.Act(Action{Cmd: "bar", Sub: "talk"})
	if !strings.Contains(sc.Text, "Bertram") || len(sc.Buttons) != 5 {
		t.Fatalf("bar: %q %+v", sc.Text, sc.Buttons)
	}
	get := func() Player {
		var me Player
		g.View(func(w *World) { me = *w.Player(p.ID) })
		return me
	}
	// the gold drink needs gold
	sc = s.Act(Action{Cmd: "bar", Sub: "drink_departed"})
	if !strings.Contains(sc.Text, "paid in gold") {
		t.Fatalf("gold drink without gold: %q", sc.Text)
	}
	before := get().Money
	sc = s.Act(Action{Cmd: "bar", Sub: "drink_elbow"})
	after := get()
	if !strings.Contains(sc.Text, "Embalmer's Elbow") || after.Church.Drinks != 1 {
		t.Fatalf("drink: %q", sc.Text)
	}
	// $150, plus or minus what the drink did to the wallet
	if d := before - after.Money; d != 150 && !strings.Contains(sc.Text, "$") {
		t.Fatalf("paid %d: %q", d, sc.Text)
	}
	s.Act(Action{Cmd: "bar", Sub: "drink_elbow"})
	s.Act(Action{Cmd: "bar", Sub: "drink_elbow"})
	sc = s.Act(Action{Cmd: "bar", Sub: "drink_elbow"})
	if !strings.Contains(sc.Text, "enough for today") {
		t.Fatalf("no daily limit: %q", sc.Text)
	}
	if me := get(); me.HP < 1 || me.Luck < 1 || me.Money < 0 {
		t.Fatalf("drinks broke something: %+v", me)
	}
	// every effect, good and bad, at every strength, leaves a sane player
	for pow := 1; pow <= 3; pow++ {
		for i := 0; i < 40; i++ {
			g.Store.Tx(func(w *World) error {
				s.w = w
				if i%2 == 0 {
					s.drinkGood(pow)
				} else {
					s.drinkBad(pow)
				}
				return nil
			})
		}
	}
	if me := get(); me.HP < 1 || me.Luck < 1 || me.Money < 0 || me.Turns < 0 || me.Karma < 1 {
		t.Fatalf("effects broke something: %+v", me)
	}
	if sc = s.Act(Action{Cmd: "cafe", Sub: "back"}); sc.View != "chat" {
		t.Fatal("back to the tables")
	}
}

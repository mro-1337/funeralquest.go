package engine

import (
	"fmt"
	"strings"
)

// The bar in the Pale Horse Cafe: Bertram the bartender tells stories, and sells three drinks
// with random effects, good or bad. A few drinks a day at most.

const barInfo = "Bertram has polished the same glass since 1974.  He knows everyone's secrets, and tells most of them."

var bartenderStories = []string{
	"\"Fella came in last week, ordered a glass of water and a straw.  Said he was practicing for his embalming.  Tipped in teeth.  I didn't ask whose.\"",
	"\"You know why I never play cards with undertakers?  They always know when somebody's about to fold.\"",
	"\"Old Mrs. Pennywhistle pre-paid her funeral in 1962.  In nickels.  Every Tuesday she comes in to check they're still in the jar.\"",
	"\"Had a ghost in here once.  Ordered the boos-iest thing on the menu.  Walked right through the bill, too.\"",
	"\"That big bottle on the roof?  Previous owner said it was for 'emergencies.'  Nobody's been brave enough to ask what kind.\"",
	"\"A parlor owner tried to pay his tab with a coupon for '10% off your next burial.'  I said, 'Pal, I'm not planning on needing it.'  He winked.  I've been looking over my shoulder ever since.\"",
	"\"The gravedigger and the florist had a fight in here over who has the deadlier job.  Gravedigger won.  Florist wilted.\"",
	"\"Guy once told me his hearse was so old it had a rumble seat.  For the deceased's in-laws.\"",
	"\"I asked the coroner what his favorite drink was.  He said, 'Anything on the rocks.  Like my last three clients.'\"",
	"\"The mayor came in, said City Hall was running on a skeleton crew.  I said I know, Doris has been dead since spring.  Nobody's told her.\"",
	"\"You want a tip?  Never let a funeral director pick the karaoke song.  Eleven minutes of 'Another One Bites the Dust,' with a slideshow.\"",
	"\"Somebody left a casket out front with a sign that said FREE TO GOOD HOME.  By morning it had a waiting list.  By noon it had a tenant.\"",
	"\"A fortune teller drank here every Friday.  Always knew what she'd order.  Never knew when to leave.\"",
	"\"I once served a vampire, a werewolf and a tax collector.  Only one of 'em scared me.  He's still sending letters.\"",
	"\"My grandpa ran this bar.  His last words were 'Don't put that bottle on the roof.'  Well.  Anyway.  What can I get you?\"",
}

// a few useful tips mixed in
var bartenderTips = []string{
	"\"Free advice: families pay more when your parlor looks nice.  Spend a little at Yang's and watch 'em open their wallets.\"",
	"\"If your luck's in the dirt, the church will bless you.  For a donation.  The Lord accepts all major tags.\"",
	"\"The groundskeeper hides something under one of those headstones.  Read 'em sometime.  One of 'em's chatty.\"",
	"\"A padlock on your parlor won't stop a pro, but it slows 'em down.  And slow thieves are caught thieves.\"",
}

type drink struct {
	key, name, short, desc string
	cash, gold             int     // price: cash, or gold tags
	good                   float64 // chance the effect is a good one
	power                  int     // how strong the effects are (1-3)
}

var drinks = []drink{
	{"elbow", "The Embalmer's Elbow", "Embalmer's Elbow", "Gin, formaldehyde-flavored bitters and a pickled onion.  Gentle.  Mostly.", 150, 0, 0.6, 1},
	{"fizz", "Grave Digger's Fizz", "Digger's Fizz", "Root beer, black coffee and a raw egg, served in a little shovel.", 600, 0, 0.55, 2},
	{"departed", "The Dearly Departed", "Dearly Departed", "Nobody knows what's in it.  Bertram pours it with oven mitts.  Paid in gold.", 0, 1, 0.5, 3},
}

const drinksPerDay = 3

func (s *Session) barScr(text string) Screen {
	me := s.me()
	bs := []Button{B("Another story", "bar", "talk").K("s")}
	for i, d := range drinks {
		price := fmt.Sprintf("$%d", d.cash)
		if d.gold > 0 {
			price = fmt.Sprintf("%d gold", d.gold)
		}
		bs = append(bs, B(d.short+" "+price, "bar", "drink_"+d.key).K(fmt.Sprint(i+1)))
	}
	bs = append(bs, B("Back to the tables", "cafe", "back").K("b").D())
	left := drinksPerDay - s.drinksToday()
	info := barInfo + fmt.Sprintf("\n\nHe'll pour you %d more today.\nCash: $%s.  Gold tags: %d.", max(0, left), Cash(me.Money), me.Coffins[Gold])
	return Screen{View: "generic", BG: "bar", Info: info, Text: text, Buttons: bs}
}

func (s *Session) drinksToday() int {
	me := s.me()
	if me.Church.DrinkDay != s.age() {
		return 0
	}
	return me.Church.Drinks
}

func (s *Session) cmdBar(a Action) Screen {
	if s.chatting {
		s.w.AddSharedChat("`5" + s.me().Name + " wanders over to the bar.")
	}
	s.setLocation("at the bar")
	switch {
	case a.Sub == "" || a.Sub == "talk":
		story := pick(bartenderStories)
		if random(4) == 0 {
			story = pick(bartenderTips)
		}
		return s.barScr("`$Bertram leans on the bar.\n\n`w" + story)
	case strings.HasPrefix(a.Sub, "drink_"):
		for _, d := range drinks {
			if "drink_"+d.key == a.Sub {
				return s.buyDrink(d)
			}
		}
	}
	menu := "`$Bertram slaps a sticky menu on the bar.  \"Three drinks.  Three ways to regret it.  Pick one.\"\n"
	for _, d := range drinks {
		price := fmt.Sprintf("$%d", d.cash)
		if d.gold > 0 {
			price = fmt.Sprintf("%d gold tag", d.gold)
		}
		menu += "\n`w" + d.name + " `$(" + price + ")`7: " + d.desc
	}
	return s.barScr(menu)
}

func (s *Session) buyDrink(d drink) Screen {
	me := s.me()
	if s.drinksToday() >= drinksPerDay {
		return s.barScr("`yBertram takes the glass out of your hand.  \"That's enough for today, friend.  I've seen how you park.\"")
	}
	switch {
	case d.gold > 0 && me.Coffins[Gold] < d.gold:
		return s.barScr(fmt.Sprintf("`y\"%s is paid in gold, pal.  You've got %d gold tag(s).\"", d.name, me.Coffins[Gold]))
	case d.cash > 0 && me.Money < d.cash:
		return s.barScr(fmt.Sprintf("`y\"That's $%d.  Come back when your pockets are less empty than my jokes.\"", d.cash))
	}
	if me.Church.DrinkDay != s.age() {
		me.Church.DrinkDay, me.Church.Drinks = s.age(), 0
	}
	me.Church.Drinks++
	me.Money -= d.cash
	me.Coffins[Gold] -= d.gold
	text := fmt.Sprintf("`$Bertram slides you %s.  You drink it in one go.\n\n", "`w"+d.name+"`$")
	if frandom(1) < d.good {
		text += s.drinkGood(d.power)
	} else {
		text += s.drinkBad(d.power)
	}
	return s.barScr(text)
}

// drinkGood: something nice happens. power 1-3 makes it bigger.
func (s *Session) drinkGood(power int) string {
	me := s.me()
	switch random(6) {
	case 0:
		n := 3 * power
		luckMod(me, n)
		return fmt.Sprintf("`0A warm glow spreads from your toes to your ears.  You feel lucky!  `w(luck +%d)", n)
	case 1:
		turnsMod(me, power)
		return fmt.Sprintf("`0You feel like you could bury the whole town before supper.  `w(+%d turn%s)", power, ifs(power == 1, "", "s"))
	case 2:
		if me.HP < me.HPMax {
			me.HP = me.HPMax
			return "`0Every ache in your body packs its bags and leaves.  `w(hit points full)"
		}
		n := 2 * power
		me.Karma = clamp(me.Karma+n, 1, 100)
		return fmt.Sprintf("`0You buy the whole bar a round.  Well, you mean to.  Everyone loves you anyway.  `w(karma +%d)", n)
	case 3:
		n := 100 * power * power
		me.Money += n
		return fmt.Sprintf("`0There's something at the bottom of the glass.  A folded-up bill!  Bertram swears it isn't his.  `w(+$%d)", n)
	case 4:
		n := 5 * power
		expMod(me, n)
		return fmt.Sprintf("`0A grieving family at the next table asks for your card.  Word gets around.  `w(+%d bury points)", n)
	default:
		n := 4 * power
		me.Strength += n
		return fmt.Sprintf("`0You arm-wrestle the gravedigger.  You win.  Somehow.  `w(strength +%d)", n)
	}
}

// drinkBad: something unfortunate happens (never deadly).
func (s *Session) drinkBad(power int) string {
	me := s.me()
	switch random(6) {
	case 0:
		n := 3 * power
		luckMod(me, -n)
		return fmt.Sprintf("`4You hiccup so hard you crack a mirror.  Seven years of bad luck, or at least a few points.  `w(luck -%d)", n)
	case 1:
		n := min(power, me.Turns)
		turnsMod(me, -n)
		if n == 0 {
			return "`4You nod off on the bar stool.  Luckily you had nothing better to do."
		}
		return fmt.Sprintf("`4You wake up under the pool table with a mustache drawn on your face.  `w(-%d turn%s)", n, ifs(n == 1, "", "s"))
	case 2:
		n := 2 * power
		me.HP = max(1, me.HP-n)
		return fmt.Sprintf("`4It goes down like a lit match.  You spend a while lying very still.  `w(-%d hit points)", n)
	case 3:
		n := min(me.Money, 75*power*power)
		me.Money -= n
		return fmt.Sprintf("`4You insist on paying for everyone's drinks.  Loudly.  Twice.  `w(-$%d)", n)
	case 4:
		n := 2 * power
		me.Karma = clamp(me.Karma-n, 1, 100)
		return fmt.Sprintf("`4You tell the church lady a joke about what's really in the communion wine.  She heard.  `w(karma -%d)", n)
	default:
		return "`4You start singing.  Bertram turns up the jukebox.  Then he unplugs it and hands you a glass of water.  Nothing else happens, thankfully, except the memories."
	}
}

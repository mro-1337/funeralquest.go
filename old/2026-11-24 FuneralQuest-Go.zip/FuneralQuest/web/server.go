// Package web serves the browser version of Funeral Quest and its JSON API.
package web

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"net"
	"net/http"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"funeralquest/engine"
)

type Server struct {
	G         *engine.Game
	PublicDir string // web/public
	ArtDir    string // assets/web
	Idle      time.Duration

	mu       sync.Mutex
	sessions map[string]*websess
	tries    map[string][]time.Time
}

type websess struct {
	s    *engine.Session
	seen time.Time
}

func New(g *engine.Game, publicDir, artDir string) *Server {
	srv := &Server{G: g, PublicDir: publicDir, ArtDir: artDir, Idle: 20 * time.Minute, sessions: map[string]*websess{}, tries: map[string][]time.Time{}}
	go srv.reaper()
	return srv
}

func (srv *Server) reaper() {
	for range time.Tick(time.Minute) {
		srv.mu.Lock()
		for tok, ws := range srv.sessions {
			if time.Since(ws.seen) > srv.Idle {
				go ws.s.Disconnect()
				delete(srv.sessions, tok)
			}
		}
		srv.mu.Unlock()
		srv.G.Store.Tx(func(w *engine.World) error { srv.G.MaintCheck(w, false); return nil })
	}
}

func (srv *Server) start(p *engine.Player) (string, engine.Screen) {
	srv.mu.Lock()
	for tok, ws := range srv.sessions { // one browser session per player
		if ws.s.PID == p.ID {
			go ws.s.Disconnect()
			delete(srv.sessions, tok)
		}
	}
	b := make([]byte, 24)
	rand.Read(b)
	tok := hex.EncodeToString(b)
	s := srv.G.NewSession(p.ID, "web")
	srv.sessions[tok] = &websess{s: s, seen: time.Now()}
	srv.mu.Unlock()
	return tok, s.Act(engine.Action{Cmd: "main"})
}

func (srv *Server) get(tok string) *engine.Session {
	srv.mu.Lock()
	defer srv.mu.Unlock()
	ws := srv.sessions[tok]
	if ws == nil {
		return nil
	}
	ws.seen = time.Now()
	return ws.s
}

func (srv *Server) tooMany(ip string) bool {
	srv.mu.Lock()
	defer srv.mu.Unlock()
	var keep []time.Time
	for _, t := range srv.tries[ip] {
		if time.Since(t) < time.Minute {
			keep = append(keep, t)
		}
	}
	keep = append(keep, time.Now())
	srv.tries[ip] = keep
	return len(keep) > 20
}

func send(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	json.NewEncoder(w).Encode(v)
}
func errJSON(err error) map[string]any { return map[string]any{"error": err.Error()} }

func (srv *Server) Handler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /api/info", func(w http.ResponseWriter, r *http.Request) {
		var out map[string]any
		srv.G.View(func(wd *engine.World) {
			on := map[int]bool{}
			for _, s := range wd.Online() {
				on[s.PlayerID] = true
			}
			out = map[string]any{"day": wd.Glo.GameAge, "players": len(wd.Active()), "online": len(on), "name": wd.Config.ServerName}
		})
		send(w, out)
	})
	mux.HandleFunc("GET /api/rankings", func(w http.ResponseWriter, r *http.Request) {
		rows := []engine.RankRow{}
		srv.G.View(func(wd *engine.World) {
			on := map[int]bool{}
			for _, s := range wd.Online() {
				on[s.PlayerID] = true
			}
			for _, p := range wd.Ranked() {
				st := ""
				if on[p.ID] {
					st = "on now"
				}
				rows = append(rows, engine.RankRow{Name: p.Name, Male: p.Male, Parlor: p.Parlor, Exp: p.Exp, Status: st})
			}
		})
		send(w, map[string]any{"rows": rows})
	})
	mux.HandleFunc("POST /api/{call}", func(w http.ResponseWriter, r *http.Request) {
		r.Body = http.MaxBytesReader(w, r.Body, 65536)
		var b struct {
			Token, Logon, Password, Password2, Name, Parlor string
			Male                                            bool
			Action                                          *engine.Action
			Say                                             *string
		}
		if err := json.NewDecoder(r.Body).Decode(&b); err != nil {
			w.WriteHeader(400)
			send(w, errJSON(errors.New("bad request")))
			return
		}
		ip, _, _ := net.SplitHostPort(r.RemoteAddr)
		switch r.PathValue("call") {
		case "login":
			if srv.tooMany(ip) {
				send(w, errJSON(errors.New("Too many tries.  Wait a minute.")))
				return
			}
			p, err := srv.G.Login(strings.TrimSpace(b.Logon), b.Password)
			if err != nil {
				send(w, errJSON(err))
				return
			}
			tok, scr := srv.start(p)
			send(w, map[string]any{"token": tok, "screen": scr})
		case "register":
			if srv.tooMany(ip) {
				send(w, errJSON(errors.New("Too many tries.  Wait a minute.")))
				return
			}
			if b.Password != b.Password2 {
				send(w, errJSON(errors.New("Your passwords don't match!  Try again, genius.")))
				return
			}
			p, err := srv.G.CreatePlayer(engine.NewPlayer{Logon: b.Logon, Password: b.Password, Name: b.Name, Parlor: b.Parlor, Male: b.Male})
			if err != nil {
				send(w, errJSON(err))
				return
			}
			tok, _ := srv.start(p)
			// the original showed brand new players the newspaper first
			scr := srv.get(tok).Act(engine.Action{Cmd: "news"})
			send(w, map[string]any{"token": tok, "screen": scr})
		case "act":
			s := srv.get(b.Token)
			if s == nil {
				send(w, map[string]any{"error": "Your session expired.  Please log on again.", "expired": true})
				return
			}
			a := engine.Action{Cmd: "main"}
			if b.Action != nil {
				a = *b.Action
			}
			scr := s.Act(a)
			if scr.View == "quit" {
				srv.mu.Lock()
				delete(srv.sessions, b.Token)
				srv.mu.Unlock()
			}
			send(w, map[string]any{"screen": scr})
		case "chat":
			s := srv.get(b.Token)
			if s == nil {
				send(w, map[string]any{"error": "Your session expired.", "expired": true})
				return
			}
			say := ""
			if b.Say != nil {
				say = *b.Say
				if len(say) > 300 {
					say = say[:300]
				}
			}
			lines := s.ChatUpdate(say)
			if lines == nil {
				lines = []string{}
			}
			send(w, map[string]any{"lines": lines})
		default:
			w.WriteHeader(404)
			send(w, errJSON(errors.New("no such call")))
		}
	})
	art := http.StripPrefix("/art/", http.FileServer(http.Dir(srv.ArtDir)))
	mux.Handle("GET /art/", http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if strings.HasSuffix(r.URL.Path, ".jxl") {
			w.Header().Set("Content-Type", "image/jxl")
		}
		w.Header().Set("Cache-Control", "public, max-age=86400")
		art.ServeHTTP(w, r)
	}))
	snd := http.StripPrefix("/sound/", http.FileServer(http.Dir(filepath.Join(filepath.Dir(srv.ArtDir), "sound"))))
	mux.Handle("GET /sound/", http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if strings.HasSuffix(r.URL.Path, ".ogg") {
			w.Header().Set("Content-Type", "audio/ogg")
		}
		w.Header().Set("Cache-Control", "public, max-age=86400")
		snd.ServeHTTP(w, r)
	}))
	pub := http.FileServer(http.Dir(srv.PublicDir))
	mux.Handle("GET /", http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch filepath.Ext(r.URL.Path) {
		case ".wasm":
			w.Header().Set("Content-Type", "application/wasm")
		case ".js":
			w.Header().Set("Content-Type", "text/javascript; charset=utf-8")
		}
		w.Header().Set("X-Content-Type-Options", "nosniff")
		pub.ServeHTTP(w, r)
	}))
	return mux
}

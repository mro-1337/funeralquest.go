#!/bin/sh
# Builds fq.exe (64-bit), fq32.exe (32-bit) and fq-linux with Go 1.24+
set -e
GOOS=windows GOARCH=amd64 go build -trimpath -ldflags "-s -w" -o fq.exe .
GOOS=windows GOARCH=386   go build -trimpath -ldflags "-s -w" -o fq32.exe .
GOOS=linux   GOARCH=amd64 go build -trimpath -ldflags "-s -w" -o fq-linux .

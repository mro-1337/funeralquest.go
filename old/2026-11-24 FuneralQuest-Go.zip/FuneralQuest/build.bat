@echo off
rem Builds fq.exe (64-bit), fq32.exe (32-bit) and fq-linux with Go 1.24+
set GOOS=windows
set GOARCH=amd64
go build -trimpath -ldflags "-s -w" -o fq.exe .
set GOARCH=386
go build -trimpath -ldflags "-s -w" -o fq32.exe .
set GOOS=linux
set GOARCH=amd64
go build -trimpath -ldflags "-s -w" -o fq-linux .
set GOOS=
set GOARCH=

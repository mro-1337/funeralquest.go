// Package door is the BBS door front end: ANSI screens, plus pictures drawn by the
// caller's terminal as JPEG XL (SyncTERM) or, failing that, Sixel.
package door

import (
	"crypto/md5"
	"encoding/base64"
	"encoding/hex"
	"io"
	"strconv"
	"strings"
	"sync"
	"time"
)

const esc = "\x1b"
const csi = "\x1b["
const st = "\x1b\\"

var cp437 = map[rune]byte{
	'░': 0xb0, '▒': 0xb1, '▓': 0xb2, '│': 0xb3, '┤': 0xb4, '║': 0xba, '╗': 0xbb, '╝': 0xbc, '┐': 0xbf, '└': 0xc0,
	'┴': 0xc1, '┬': 0xc2, '├': 0xc3, '─': 0xc4, '┼': 0xc5, '╚': 0xc8, '╔': 0xc9, '╩': 0xca, '╦': 0xcb, '╠': 0xcc,
	'═': 0xcd, '╬': 0xce, '┘': 0xd9, '┌': 0xda, '█': 0xdb, '▄': 0xdc, '▌': 0xdd, '▐': 0xde, '▀': 0xdf, '■': 0xfe,
	'·': 0xfa, '∙': 0xf9, '»': 0xaf, '«': 0xae, 'é': 0x82,
}

type resp struct {
	apc   bool
	final byte
	body  string
}

// Term is one caller's connection.
type Term struct {
	r      io.Reader
	w      io.Writer
	telnet bool
	UTF8   bool

	mu     sync.Mutex
	buf    []byte
	keys   []string
	resps  []resp
	notify chan struct{}
	closed bool
	iac    int
	wmu    sync.Mutex

	Cols, Rows   int
	CTerm, JXL   bool
	Sixel        bool
	Audio        bool
	CellW, CellH int
	cache        map[string]string
}

func NewTerm(r io.Reader, w io.Writer, telnet bool) *Term {
	t := &Term{r: r, w: w, telnet: telnet, notify: make(chan struct{}, 1), Cols: 80, Rows: 24, CellW: 8, CellH: 16, cache: map[string]string{}}
	go t.readLoop()
	return t
}

func (t *Term) Closed() bool { t.mu.Lock(); defer t.mu.Unlock(); return t.closed }

func (t *Term) wake() {
	select {
	case t.notify <- struct{}{}:
	default:
	}
}

func (t *Term) readLoop() {
	b := make([]byte, 4096)
	for {
		n, err := t.r.Read(b)
		if n > 0 {
			t.mu.Lock()
			for _, c := range b[:n] {
				if t.telnet {
					// strip telnet IAC sequences: 1=IAC seen, 2=option byte, 3=subneg, 4=subneg IAC
					switch t.iac {
					case 1:
						switch {
						case c == 0xff:
							t.iac = 0
							t.buf = append(t.buf, 0xff)
						case c >= 0xfb && c <= 0xfe:
							t.iac = 2
						case c == 0xfa:
							t.iac = 3
						default:
							t.iac = 0
						}
						continue
					case 2:
						t.iac = 0
						continue
					case 3:
						if c == 0xff {
							t.iac = 4
						}
						continue
					case 4:
						if c == 0xf0 {
							t.iac = 0
						} else {
							t.iac = 3
						}
						continue
					}
					if c == 0xff {
						t.iac = 1
						continue
					}
				}
				t.buf = append(t.buf, c)
			}
			t.parse()
			t.mu.Unlock()
			t.wake()
		}
		if err != nil {
			t.mu.Lock()
			t.closed = true
			t.mu.Unlock()
			t.wake()
			return
		}
	}
}

// parse turns buffered bytes into keys and terminal responses. Caller holds mu.
func (t *Term) parse() {
	B := t.buf
	for len(B) > 0 {
		c := B[0]
		if c == 0x1b {
			if len(B) == 1 {
				// lone ESC: decide after a short pause whether it is the Escape key
				go func() {
					time.Sleep(80 * time.Millisecond)
					t.mu.Lock()
					if len(t.buf) == 1 && t.buf[0] == 0x1b {
						t.buf = t.buf[:0]
						t.keys = append(t.keys, "esc")
					}
					t.mu.Unlock()
					t.wake()
				}()
				break
			}
			if B[1] == '[' {
				j := 2
				for j < len(B) && !(B[j] >= 0x40 && B[j] <= 0x7e) {
					j++
				}
				if j >= len(B) {
					break
				}
				t.onCSI(string(B[2:j]), B[j])
				B = B[j+1:]
				continue
			}
			if B[1] == '_' || B[1] == 'P' || B[1] == ']' {
				end := -1
				for j := 2; j < len(B); j++ {
					if B[j] == 0x07 {
						end = j + 1
						break
					}
					if B[j] == 0x1b && j+1 < len(B) && B[j+1] == '\\' {
						end = j + 2
						break
					}
				}
				if end < 0 {
					break
				}
				body := strings.TrimSuffix(strings.TrimSuffix(string(B[2:end]), "\x1b\\"), "\x07")
				t.resps = append(t.resps, resp{apc: true, body: body})
				B = B[end:]
				continue
			}
			if B[1] == 'O' && len(B) >= 3 {
				m := map[byte]string{'A': "up", 'B': "down", 'C': "right", 'D': "left", 'H': "home", 'F': "end"}
				k := m[B[2]]
				if k == "" {
					k = "esc"
				}
				t.keys = append(t.keys, k)
				B = B[3:]
				continue
			}
			t.keys = append(t.keys, "esc")
			B = B[1:]
			continue
		}
		B = B[1:]
		switch {
		case c == '\r':
			if len(B) > 0 && (B[0] == '\n' || B[0] == 0) {
				B = B[1:]
			}
			t.keys = append(t.keys, "enter")
		case c == '\n':
			t.keys = append(t.keys, "enter")
		case c == 8 || c == 0x7f:
			t.keys = append(t.keys, "backspace")
		case c == 9:
			t.keys = append(t.keys, "tab")
		case c == 0:
		case c < 0x20:
			t.keys = append(t.keys, "ctrl-"+string(rune(c+0x60)))
		case c < 0x80:
			t.keys = append(t.keys, string(rune(c)))
		default:
			t.keys = append(t.keys, "?")
		}
	}
	t.buf = append(t.buf[:0], B...)
}

func (t *Term) onCSI(body string, final byte) {
	switch {
	case final == 'R' || final == 'c' || final == 'S' || final == 't' || (final == 'n' && strings.HasPrefix(body, "=")):
		t.resps = append(t.resps, resp{final: final, body: body})
		return
	}
	m := map[byte]string{'A': "up", 'B': "down", 'C': "right", 'D': "left", 'H': "home", 'F': "end"}
	if k, ok := m[final]; ok {
		t.keys = append(t.keys, k)
		return
	}
	if final == '~' {
		k := map[string]string{"1": "home", "2": "insert", "3": "delete", "4": "end", "5": "pgup", "6": "pgdn"}[body]
		if k == "" {
			k = "unknown"
		}
		t.keys = append(t.keys, k)
	}
}

// Key waits for the next key. ok=false on timeout; key=="" with ok=true means disconnected.
func (t *Term) Key(timeout time.Duration) (key string, ok bool) {
	var deadline <-chan time.Time
	if timeout > 0 {
		tm := time.NewTimer(timeout)
		defer tm.Stop()
		deadline = tm.C
	}
	for {
		t.mu.Lock()
		if len(t.keys) > 0 {
			k := t.keys[0]
			t.keys = t.keys[1:]
			t.mu.Unlock()
			return k, true
		}
		closed := t.closed
		t.mu.Unlock()
		if closed {
			return "", true
		}
		select {
		case <-t.notify:
		case <-deadline:
			return "", false
		}
	}
}

func (t *Term) response(match func(resp) bool, timeout time.Duration) (resp, bool) {
	deadline := time.After(timeout)
	for {
		t.mu.Lock()
		for i, r := range t.resps {
			if match(r) {
				t.resps = append(t.resps[:i], t.resps[i+1:]...)
				t.mu.Unlock()
				return r, true
			}
		}
		closed := t.closed
		t.mu.Unlock()
		if closed {
			return resp{}, false
		}
		select {
		case <-t.notify:
		case <-deadline:
			return resp{}, false
		}
	}
}

// Write sends text, converting it to CP437 (or UTF-8 when asked).
func (t *Term) Write(s string) {
	var out []byte
	if t.UTF8 {
		out = []byte(s)
	} else {
		out = make([]byte, 0, len(s))
		for _, r := range s {
			switch {
			case r < 0x80:
				out = append(out, byte(r))
			case cp437[r] != 0:
				out = append(out, cp437[r])
			default:
				out = append(out, '?')
			}
		}
	}
	t.Raw(out)
}

// Raw sends bytes unchanged (escaping telnet IAC).
func (t *Term) Raw(b []byte) {
	if t.telnet && strings.IndexByte(string(b), 0xff) >= 0 {
		var o []byte
		for _, c := range b {
			o = append(o, c)
			if c == 0xff {
				o = append(o, 0xff)
			}
		}
		b = o
	}
	t.wmu.Lock()
	defer t.wmu.Unlock()
	if _, err := t.w.Write(b); err != nil {
		t.mu.Lock()
		t.closed = true
		t.mu.Unlock()
	}
}
func (t *Term) RawS(s string) { t.Raw([]byte(s)) }

// Detect asks the terminal about its size, whether it's SyncTERM (CTerm), whether it can draw
// JPEG XL (APC SyncTERM:Q;JXL) and, if not, whether it can do Sixel.
func (t *Term) Detect() {
	t.RawS(csi + "s" + csi + "255;255H" + csi + "6n" + csi + "u")
	if r, ok := t.response(func(r resp) bool { return r.final == 'R' }, 1500*time.Millisecond); ok {
		p := strings.Split(r.body, ";")
		if len(p) == 2 {
			if v, _ := strconv.Atoi(p[0]); v > 10 {
				t.Rows = v
			}
			if v, _ := strconv.Atoi(p[1]); v > 40 {
				t.Cols = v
			}
		}
	}
	t.RawS(csi + "c")
	da, haveDA := t.response(func(r resp) bool { return r.final == 'c' && !strings.HasPrefix(r.body, "<") }, 1200*time.Millisecond)
	t.CTerm = haveDA && strings.HasPrefix(da.body, "=67;84;101;114;109")

	// --- the JPEG XL check: SyncTERM answers CSI = 1 ; 1 - n when it can decode JPEG XL
	t.RawS(esc + "_SyncTERM:Q;JXL" + st)
	wait := 900 * time.Millisecond
	if t.CTerm {
		wait = 2000 * time.Millisecond
	}
	if r, ok := t.response(func(r resp) bool { return r.final == 'n' && strings.HasPrefix(r.body, "=1;") }, wait); ok {
		t.JXL = strings.HasPrefix(strings.TrimPrefix(r.body, "=1;"), "1")
	}
	if t.CTerm || t.JXL {
		t.RawS(csi + "=3n")
		if r, ok := t.response(func(r resp) bool { return r.final == 'n' && strings.HasPrefix(r.body, "=3;") }, 1200*time.Millisecond); ok {
			p := strings.Split(r.body, ";")
			if len(p) == 3 {
				h, _ := strconv.Atoi(p[1])
				w, _ := strconv.Atoi(p[2])
				if h > 0 && w > 0 {
					t.CellW, t.CellH = w, h
				}
			}
		}
	}
	// --- sound: can the terminal play audio files (SyncTERM's libsndfile, feature 100), and Ogg Vorbis?
	t.RawS(esc + "_SyncTERM:Q;libsndfile" + st)
	if r, ok := t.response(func(r resp) bool { return r.final == 'n' && strings.HasPrefix(r.body, "=7;100;") }, wait); ok && strings.HasSuffix(r.body, ";1") {
		t.RawS(esc + "_SyncTERM:Q;libsndfileFormat;32;96" + st) // SF_FORMAT_OGG / SF_FORMAT_VORBIS
		r2, ok2 := t.response(func(r resp) bool { return r.final == 'n' && strings.HasPrefix(r.body, "=7;101;") }, 1500*time.Millisecond)
		t.Audio = !ok2 || strings.HasSuffix(r2.body, ";1")
	}
	if t.JXL || t.Audio {
		t.listCache()
	}
	if t.JXL {
		return
	}
	// --- no JPEG XL: Sixel? (CTerm feature 4 via CSI < c, or DA1 attribute 4)
	if t.CTerm {
		t.RawS(csi + "<c")
		if r, ok := t.response(func(r resp) bool { return r.final == 'c' && strings.HasPrefix(r.body, "<") }, 1200*time.Millisecond); ok {
			t.Sixel = hasParam(strings.TrimPrefix(r.body, "<"), "4")
		}
	} else if haveDA && strings.HasPrefix(da.body, "?") {
		t.Sixel = hasParam(strings.TrimPrefix(da.body, "?"), "4")
		if t.Sixel {
			t.RawS(csi + "16t")
			if r, ok := t.response(func(r resp) bool { return r.final == 't' && strings.HasPrefix(r.body, "6;") }, 1200*time.Millisecond); ok {
				p := strings.Split(r.body, ";")
				if len(p) == 3 {
					h, _ := strconv.Atoi(p[1])
					w, _ := strconv.Atoi(p[2])
					if h > 0 && w > 0 {
						t.CellW, t.CellH = w, h
					}
				}
			}
		}
	}
}

func hasParam(list, p string) bool {
	for _, x := range strings.Split(list, ";") {
		if x == p {
			return true
		}
	}
	return false
}

// listCache asks SyncTERM which of our files it already has (APC SyncTERM:C;L).
func (t *Term) listCache() {
	t.RawS(esc + "_SyncTERM:C;L;fq_*" + st)
	r, ok := t.response(func(r resp) bool { return r.apc && strings.HasPrefix(r.body, "SyncTERM:C;L") }, 3*time.Second)
	if !ok {
		return
	}
	for _, line := range strings.Split(r.body, "\n")[1:] {
		f := strings.Split(line, "\t")
		if len(f) == 2 {
			t.cache[strings.TrimSpace(f[0])] = strings.ToLower(strings.TrimSpace(f[1]))
		}
	}
}

// EnsureCached uploads a file into SyncTERM's cache unless it's already there unchanged.
func (t *Term) EnsureCached(name string, data []byte) {
	sum := md5.Sum(data)
	h := hex.EncodeToString(sum[:])
	if t.cache[name] == h {
		return
	}
	t.RawS(esc + "_SyncTERM:C;S;" + name + ";" + base64.StdEncoding.EncodeToString(data) + st)
	t.cache[name] = h
}

// DrawJXL draws a cached JPEG XL at pixel position dx,dy, optionally through a PBM mask.
func (t *Term) DrawJXL(name string, dx, dy int, mask string) {
	o := "DX=" + strconv.Itoa(dx) + ";DY=" + strconv.Itoa(dy)
	if mask != "" {
		o += ";MFILE=" + mask
	}
	t.RawS(esc + "_SyncTERM:C;DrawJXL;" + o + ";" + name + st)
}

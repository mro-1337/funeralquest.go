package door

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"funeralquest/engine"
)

// Audio for SyncTERM (and terminals that answer its audio query), using the CTerm audio APCs:
//
//	APC SyncTERM:C;S;<name>;<base64>       upload the .ogg into the terminal's cache (once)
//	APC SyncTERM:A;Load;S=<slot>;<name>    decode it into a "master" slot (once per call)
//	APC SyncTERM:A;Copy;S=<m>;D=<tmp>      Queue empties a slot, so we always queue a copy
//	APC SyncTERM:A;Queue;C=<ch>;S=<tmp>[;L] play on a channel, L = loop
//	APC SyncTERM:A;Flush;C=<ch>;O=<ms>     stop a channel with a fade-out
//
// Channels 2 and 3 carry looping ambience/music, 4-7 one-shot effects (0-1 belong to SyncTERM).

type audio struct {
	t       *Term
	dir     string
	loops   map[string]bool // sound key -> loops in the original
	master  map[string]int
	next    int
	tmp     int
	shot    int
	channel map[int]string // loop channel -> key playing
}

func newAudio(t *Term, dir string) *audio {
	a := &audio{t: t, dir: dir, loops: map[string]bool{}, master: map[string]int{}, tmp: 200, shot: 4, channel: map[int]string{}}
	if b, err := os.ReadFile(filepath.Join(dir, "sounds.json")); err == nil {
		var m map[string]struct{ Loop bool }
		if json.Unmarshal(b, &m) == nil {
			for k, v := range m {
				a.loops[k] = v.Loop
			}
		}
	}
	return a
}

func (a *audio) has(key string) bool { _, ok := a.loops[key]; return key != "" && ok }

func (a *audio) load(key string) (int, bool) {
	if s, ok := a.master[key]; ok {
		return s, true
	}
	data, err := os.ReadFile(filepath.Join(a.dir, key+".ogg"))
	if err != nil || a.next >= 200 {
		return 0, false
	}
	name := "fq_snd_" + strings.ReplaceAll(key, "/", "_") + ".ogg"
	a.t.EnsureCached(name, data)
	slot := a.next
	a.next++
	a.t.RawS(fmt.Sprintf("%s_SyncTERM:A;Load;S=%d;%s%s", esc, slot, name, st))
	a.master[key] = slot
	return slot, true
}

func (a *audio) queue(key string, ch int, loop bool) {
	m, ok := a.load(key)
	if !ok {
		return
	}
	tmp := a.tmp
	a.tmp++
	if a.tmp > 255 {
		a.tmp = 200
	}
	l := ""
	if loop {
		l = ";L"
	}
	a.t.RawS(fmt.Sprintf("%s_SyncTERM:A;Copy;S=%d;D=%d%s%s_SyncTERM:A;Queue;C=%d;S=%d%s%s", esc, m, tmp, st, esc, ch, tmp, l, st))
}

func (a *audio) flush(ch int) {
	a.t.RawS(fmt.Sprintf("%s_SyncTERM:A;Flush;C=%d;O=400%s", esc, ch, st))
	delete(a.channel, ch)
}

func (a *audio) once(key string) {
	a.queue(key, a.shot, false)
	a.shot++
	if a.shot > 7 {
		a.shot = 4
	}
}

// setLoops keeps wanted loops playing, fades out the rest and starts new ones (max two).
func (a *audio) setLoops(want []string) {
	keep := map[string]bool{}
	for _, k := range want {
		keep[k] = true
	}
	for ch, k := range a.channel {
		if !keep[k] {
			a.flush(ch)
		}
	}
	playing := map[string]bool{}
	for _, k := range a.channel {
		playing[k] = true
	}
	for _, k := range want {
		if playing[k] {
			continue
		}
		for _, ch := range []int{2, 3} {
			if _, busy := a.channel[ch]; !busy {
				a.channel[ch] = k
				a.queue(k, ch, true)
				break
			}
		}
	}
}

func (a *audio) stopAll() {
	for ch := range a.channel {
		a.flush(ch)
	}
}

// scene plays what the Flash client would have played for this screen: every scene movie had its
// own sound (looping ambience or a one-shot), plus music for battles, sneaking and the map.
func (a *audio) scene(s *engine.Screen, lastBG, lastPic string) {
	var loops []string
	add := func(key string, changed bool) {
		if !a.has(key) {
			return
		}
		if a.loops[key] {
			loops = append(loops, key)
		} else if changed {
			a.once(key)
		}
	}
	add(s.BG, s.BG != lastBG)
	add(s.Pic, s.Pic != lastPic)
	if a.has(s.Music) {
		loops = append(loops, s.Music)
	}
	if a.has(s.Sound) && (s.BG != lastBG || s.Pic != lastPic || s.View == "news") {
		a.once(s.Sound)
	}
	if len(loops) > 2 {
		loops = loops[len(loops)-2:]
	}
	a.setLoops(loops)
}

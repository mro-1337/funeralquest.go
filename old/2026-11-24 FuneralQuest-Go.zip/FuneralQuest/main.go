// Funeral Quest — BBS door + web server in one program.
//
//	fq door <DOOR32.SYS | node dir> [--stdio] [--bbs-id NAME]   run as a BBS door
//	fq web [--port 8080] [--host 0.0.0.0]                       run the web version
//	fq telnet [--port 2323]                                     stand-alone telnet server
//	fq admin players | config [k=v ...] | maint | reset [--wipe] | delete NAME | news TEXT
//
// Global option: --home DIR  folder holding assets/, gamedata/, web/ and data/ (default: next to the exe)
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"time"

	"funeralquest/door"
	"funeralquest/engine"
	"funeralquest/web"
)

func usage() {
	fmt.Fprint(os.Stderr, `Funeral Quest

  fq door <DOOR32.SYS or node dir> [--stdio] [--bbs-id NAME] [--nosound]
  fq web [--port 8080] [--host 0.0.0.0]
  fq telnet [--port 2323]
  fq admin players | config [key=value ...] | maint | reset [--wipe] | delete <name> | news <text>

  --home DIR   folder with assets/, gamedata/, web/ and data/ (default: the exe's folder)
`)
	os.Exit(2)
}

func homeDir(flagVal string) string {
	if flagVal != "" {
		return flagVal
	}
	if exe, err := os.Executable(); err == nil {
		dir := filepath.Dir(exe)
		if _, err := os.Stat(filepath.Join(dir, "gamedata")); err == nil {
			return dir
		}
	}
	wd, _ := os.Getwd()
	return wd
}

func openGame(home string, logw io.Writer) *engine.Game {
	g, err := engine.NewGame(filepath.Join(home, "data"), filepath.Join(home, "gamedata"), log.New(logw, "", log.LstdFlags))
	if err != nil {
		fmt.Fprintln(os.Stderr, "fq:", err)
		os.Exit(1)
	}
	return g
}

func main() {
	if len(os.Args) < 2 {
		usage()
	}
	cmd := os.Args[1]
	fs := flag.NewFlagSet(cmd, flag.ExitOnError)
	home := fs.String("home", "", "install folder")
	port := fs.Int("port", 0, "port")
	host := fs.String("host", "0.0.0.0", "listen address")
	stdio := fs.Bool("stdio", false, "door: use standard input/output instead of the DOOR32.SYS socket")
	bbsID := fs.String("bbs-id", "", "door: prefix for player keys when several BBSes share one game")
	wipe := fs.Bool("wipe", false, "admin reset: delete accounts too")
	noSound := fs.Bool("nosound", false, "door/telnet: never send sound to callers")
	// allow flags after positional arguments
	var pos []string
	args := os.Args[2:]
	for len(args) > 0 {
		fs.Parse(args)
		args = fs.Args()
		if len(args) > 0 {
			pos = append(pos, args[0])
			args = args[1:]
		}
	}
	h := homeDir(*home)

	switch cmd {
	case "door":
		if len(pos) < 1 {
			usage()
		}
		runDoor(h, pos[0], *stdio, *bbsID, *noSound)
	case "web":
		if *port == 0 {
			*port = 8080
		}
		g := openGame(h, os.Stdout)
		srv := web.New(g, filepath.Join(h, "web", "public"), filepath.Join(h, "assets", "web"))
		addr := net.JoinHostPort(*host, strconv.Itoa(*port))
		log.Printf("Funeral Quest web server on http://%s/  (data in %s)", addr, filepath.Join(h, "data"))
		log.Fatal(http.ListenAndServe(addr, srv.Handler()))
	case "telnet":
		if *port == 0 {
			*port = 2323
		}
		runTelnet(h, *host, *port, *noSound)
	case "admin":
		runAdmin(h, pos, *wipe)
	default:
		usage()
	}
}

func doorLog(home string) *os.File {
	os.MkdirAll(filepath.Join(home, "data"), 0o755)
	f, err := os.OpenFile(filepath.Join(home, "data", "door.log"), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644)
	if err != nil {
		return os.Stderr
	}
	return f
}

func runDoor(home, dropPath string, useStdio bool, bbsID string, noSound bool) {
	lf := doorLog(home)
	logger := log.New(lf, "", log.LstdFlags)
	defer func() {
		if r := recover(); r != nil {
			logger.Printf("door crashed: %v", r)
		}
	}()
	d, err := door.ReadDropfile(dropPath)
	if err != nil {
		logger.Printf("drop file: %v", err)
		fmt.Fprintln(os.Stderr, "fq:", err)
		os.Exit(1)
	}
	g := openGame(home, lf)
	var rw io.ReadWriter = struct {
		io.Reader
		io.Writer
	}{os.Stdin, os.Stdout}
	telnet := false
	if !useStdio && d.Handle > 0 && d.Comm != 0 {
		s, err := door.OpenSocket(d.Handle)
		if err != nil {
			logger.Printf("socket %d: %v", d.Handle, err)
			os.Exit(1)
		}
		rw, telnet = s, true
	}
	t := door.NewTerm(rw, rw, telnet)
	dr := door.New(t, g, filepath.Join(home, "assets", "door"), time.Duration(d.TimeLeft)*time.Minute)
	dr.NoSound = noSound
	if bbsID == "" {
		bbsID = "bbs"
	}
	dr.BBSKey = bbsID + ":" + strings.ToLower(d.Alias)

	// make sure the "online" mark is cleared if the BBS kills us
	sig := make(chan os.Signal, 1)
	signal.Notify(sig, os.Interrupt, syscall.SIGTERM)
	go func() { <-sig; os.Exit(0) }()

	t.Write(csiClear + "\x1b[1;33mFuneral Quest\x1b[0m  - checking your terminal...")
	t.Detect()
	logger.Printf("caller %q node %d: cols=%d rows=%d syncterm=%v jpegxl=%v sixel=%v audio=%v cell=%dx%d",
		d.Alias, d.Node, t.Cols, t.Rows, t.CTerm, t.JXL, t.Sixel, t.Audio && !noSound, t.CellW, t.CellH)
	p := g.FindBBSPlayer(dr.BBSKey)
	if p == nil {
		p = dr.NewPlayer(d.Alias)
	}
	if p != nil {
		dr.Play(p.ID, "bbs")
	}
	t.Write("\x1b[0m\r\n")
	time.Sleep(300 * time.Millisecond)
}

const csiClear = "\x1b[0m\x1b[2J\x1b[H"

func runTelnet(home, host string, port int, noSound bool) {
	g := openGame(home, os.Stdout)
	ln, err := net.Listen("tcp", net.JoinHostPort(host, strconv.Itoa(port)))
	if err != nil {
		log.Fatal(err)
	}
	log.Printf("Funeral Quest telnet server on port %d", port)
	for {
		c, err := ln.Accept()
		if err != nil {
			continue
		}
		go func(c net.Conn) {
			defer c.Close()
			defer func() {
				if r := recover(); r != nil {
					log.Printf("session crashed: %v", r)
				}
			}()
			c.Write([]byte{255, 251, 1, 255, 251, 3, 255, 253, 3}) // WILL ECHO, WILL SGA, DO SGA
			t := door.NewTerm(c, c, true)
			dr := door.New(t, g, filepath.Join(home, "assets", "door"), 2*time.Hour)
			dr.NoSound = noSound
			t.Write(csiClear + "\x1b[1;33mFuneral Quest\x1b[0m  - checking your terminal...")
			t.Detect()
			if p := dr.TelnetLogin(); p != nil {
				dr.Play(p.ID, "bbs")
			}
		}(c)
	}
}

func runAdmin(home string, pos []string, wipe bool) {
	g := openGame(home, io.Discard)
	if len(pos) == 0 {
		usage()
	}
	switch pos[0] {
	case "players":
		g.View(func(w *engine.World) {
			on := map[int]bool{}
			for _, s := range w.Online() {
				on[s.PlayerID] = true
			}
			fmt.Printf("Day %d\n", w.Glo.GameAge)
			for _, p := range w.Players {
				flags := ""
				if !p.Active {
					flags += " (closed)"
				}
				if on[p.ID] {
					flags += " (online)"
				}
				if p.BBSKey != "" {
					flags += " bbs:" + p.BBSKey
				}
				if p.Logon != "" {
					flags += " web:" + p.Logon
				}
				fmt.Printf("%4d %-21s %-21s %8d BP%s\n", p.ID, p.Name, p.Parlor, p.Exp, flags)
			}
		})
	case "config":
		g.Store.Tx(func(w *engine.World) error {
			if len(pos) > 1 {
				// round-trip through JSON so key names match the config file
				m := map[string]any{}
				b, _ := json.Marshal(w.Config)
				json.Unmarshal(b, &m)
				for _, kv := range pos[1:] {
					k, v, _ := strings.Cut(kv, "=")
					if _, ok := m[k]; !ok {
						fmt.Println("unknown setting:", k)
						continue
					}
					switch {
					case v == "true" || v == "false":
						m[k] = v == "true"
					default:
						if f, err := strconv.ParseFloat(v, 64); err == nil {
							m[k] = f
						} else {
							m[k] = v
						}
					}
				}
				b, _ = json.Marshal(m)
				json.Unmarshal(b, &w.Config)
			}
			b, _ := json.MarshalIndent(w.Config, "", "  ")
			fmt.Println(string(b))
			return nil
		})
	case "maint":
		g.Store.Tx(func(w *engine.World) error {
			g.MaintCheck(w, true)
			fmt.Println("Maintenance done, now day", w.Glo.GameAge)
			return nil
		})
	case "reset":
		g.Store.Tx(func(w *engine.World) error {
			g.ResetGame(w, wipe)
			g.MaintCheck(w, true)
			fmt.Println("Game reset. Day", w.Glo.GameAge)
			return nil
		})
	case "delete":
		name := strings.Join(pos[1:], " ")
		g.Store.Tx(func(w *engine.World) error {
			p := w.ByName(name)
			if p == nil {
				fmt.Println("No such parlor")
				return nil
			}
			p.Active, p.BBSKey = false, ""
			fmt.Println("Closed", p.Name)
			return nil
		})
	case "news":
		g.Store.Tx(func(w *engine.World) error {
			w.AddNews("front", "`7NOTICE FROM CITY HALL\r\n`^"+strings.Join(pos[1:], " ")+"\r\n\r\n")
			fmt.Println("Posted.")
			return nil
		})
	default:
		usage()
	}
}
